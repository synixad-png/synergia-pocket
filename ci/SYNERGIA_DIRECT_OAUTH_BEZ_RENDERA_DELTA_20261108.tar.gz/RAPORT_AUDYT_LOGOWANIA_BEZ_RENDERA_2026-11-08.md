# SYNERGIA DIRECT — audyt i poprawka logowania natywnego (8 listopada 2026)

## Punkt wyjścia

Baza: `SYNERGIA_DIRECT_OAUTH_COOKIE_JAR_KANDYDAT_PELNE_ZRODLA_BEZ_IPA.zip` z zachowanymi 108 plikami Swift i pełnymi modułami użytkownika. Zmieniony jest tylko `Sources/DirectOAuthLoginClient.swift`. Nie podłączono Rendera, Pythona na serwerze ani pośredniczącego API.

## Potwierdzona rozbieżność

Istniejący klient kończył ręczny łańcuch przekierowań OAuth i natychmiast wymagał obecności `oauth_token`. Nie wykonywał wywołania `GET https://synergia.librus.pl/refreshToken` po przekierowaniach ani niezależnej walidacji `/Me` w tej samej sesji HTTP.

Niezależny port w Swift, dla którego autor zgłosił udane testy z realnym kontem, używa wywołania `/refreshToken` przed dostępem do API 2.0. Samo HTTP 200 nie potwierdza jednak logowania: odpowiedź `/Me` i tożsamość muszą być sprawdzone.

Źródła referencyjne:
- MIT, aktualizowany klient Python: https://github.com/MichalZaniewicz/librus-synergia/blob/main/docs/authentication.md
- Swift iOS (GPL-3.0, wyłącznie obserwacja zachowania, BEZ kopiowania kodu GPL do projektu): https://github.com/wadamczewski/szkolny.eu-iOS/blob/b7c7987/Packages/LibrusKit/Sources/LibrusKit/Synergia/SynergiaSessions.swift
- Zgłoszenie autora realnego testu portu: https://github.com/szkolny-eu/szkolny-android/issues/230

## Zaimplementowany przebieg

1. GET `/loguj/portalRodzina` bez automatycznego śledzenia przekierowań, zachowanie cookies.
2. GET zwróconego adresu autoryzacji `client_id=46` bez śledzenia 302, zachowanie cookies.
3. POST formularza `action=login` do `/OAuth/Authorization?client_id=46` (hasło tylko w pamięci procesu, brak automatycznych ponowień).
4. Podążanie wyłącznie za dozwolonymi przekierowaniami OAuth, odmowa przy `error=...` albo CAPTCHA.
5. **NOWE** GET `/refreshToken` z tą samą sesją i magazynem cookies; wymagany HTTP 200 oraz `oauth_token` w domenie Synergii.
6. **NOWE** GET `/gateway/api/2.0/Me` z cookies; wymagany HTTP 200 i jednoznaczny identyfikator konta przez istniejący `DirectAccountIdentity.parse`.
7. Przekazanie cookies do istniejącego `WKHTTPCookieStore`; dalsza niezależna kontrola `/Me` przez `Portal.verifyAccount()` pozostaje niezmieniona.

## Wyniki testów

- 108/108 plików Swift przechodzi składnię `swiftc -frontend -parse`.
- Produkcyjny klient `DirectOAuthLoginClient.swift` przechodzi `swiftc -typecheck` na Linux z `FoundationNetworking` i `NativeSchoolLoginPolicy` / `DirectAccountIdentity`.
- Produkcyjny klient (nie replika) przeszedł pełny odtworzony test **7 żądań**, obejmujący POST, zachowanie/izolację cookies, 302, `/refreshToken`, `/Me` i przekazanie cookies: PASS.
- Negatywne ścieżki: refresh 200 bez tokenu, refresh 401, `/Me` 401, brak identyfikatora, `error=access_denied` i CAPTCHA: PASS.
- Wcześniejsze testy P60, referencyjnego bootstrap i cookies: PASS po dostosowaniu sprawdzania składni kroku dodającego User-Agent.
- 107/107 pozostałych źródeł Swift jest identyczne SHA-256 względem wskazanej bazy.
- **Nie przeprowadzono zalogowania na realne konto Librus ani testu interaktywnego iPhone/iPad; nie wykonano kompilacji Xcode tego kandydata.** Nie można więc twierdzić, że problem na urządzeniu jest ostatecznie rozwiązany.

## Bezpieczeństwo i ograniczenia

- Hasła użytkownika z rozmowy nie użyto w kodzie, testach, plikach ani GitHub Actions.
- Testy używają fikcyjnych danych i lokalnego stubu `URLProtocol`, bez połączenia z kontami uczniów.
- Domeny i ścieżki cookies są filtrowane, obowiązuje HTTPS; dane ucznia nie są logowane.
- Kod GPL-3.0 z cudzego portu NIE został skopiowany; jego przebieg posłużył do identyfikacji zgodnego zachowania protokołu.
- Nie dodano backendu, konta pośredniego ani hostingu.
- Odnawianie sesji po upływie czasu w trakcie wielogodzinnego korzystania jest osobnym zagadnieniem, którego działanie wymaga testu po potwierdzeniu pierwszego logowania.
- Biblioteka `librus-synergia` korzysta z nieoficjalnego interfejsu i API może ulec zmianie.

## Zgodność harmonogramu

Nie zmieniono ani kolejności, ani zakresu 36 stałych zadań (`HARMONOGRAM_STALY.md`). Procent globalny bez potwierdzonego logowania na rzeczywistym koncie: **79% (21% pozostało)**, tak jak w poprzednim raporcie. Kandydata nie nazwano nową ukończoną wersją. Nie wygenerowano IPA.

## Co jeszcze musi nastąpić

Po kompilacji Xcode i instalacji na iOS należy wykonać prawdziwą próbę logowania, sprawdzić zarówno `/Me` w natywnej sesji, jak i po instalacji cookies w WebKit, odczytać oceny i zweryfikować zachowanie po uśpieniu urządzenia. Wszelkie błędy należy diagnozować po etapie HTTP, bez logowania wartości ciasteczek, haseł i danych ucznia.
