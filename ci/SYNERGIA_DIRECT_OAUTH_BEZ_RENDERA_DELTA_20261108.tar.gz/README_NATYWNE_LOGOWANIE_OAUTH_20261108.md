# SYNERGIA DIRECT — natywny OAuth, kandydat bez Rendera

To **kandydat źródłowy**, a nie potwierdzone działające wydanie IPA. Baza źródłowa P61 + referencyjny bootstrap + bezpieczny magazyn cookies. Jedyna zmiana produkcyjna: `Sources/DirectOAuthLoginClient.swift` (po zakończeniu OAuth wykonywane są także `/refreshToken` oraz `/Me`).

Aby odtworzyć testy w Swift/Linux:

```bash
bash Tests/run_native_oauth_complete.sh
```

Natywna kompilacja iOS, kiedy zostanie zlecona, wymaga macOS i Xcode. Zapoznaj się z `RAPORT_AUDYT_LOGOWANIA_BEZ_RENDERA_2026-11-08.md`. Nie publikuj sekretów w GitHubie ani raportach.

W tym pakiecie pozostały historyczne skrypty P60/P61, w tym test pierwotnego przekierowania P61. Docelowy zestaw testów tego kandydata jest w `Tests/run_native_oauth_complete.sh` i nie uruchamia wycofanego mechanizmu P61.
