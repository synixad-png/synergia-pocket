import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Deterministic transport replay exercising the *actual* production
/// DirectOAuthLoginClient, not a copied test-only state machine.
/// Fixtures represent the documented 2026 auth flow. All credentials fake.
final class OAuthReplayProtocol: URLProtocol {
    enum Scenario { case success, refreshNoToken, refreshUnauthorized, meUnauthorized, invalidMe, deniedRedirect, captcha }
    static var scenario: Scenario = .success
    static var requests: [URLRequest] = []
    static let lock = NSLock()

    class func reset(_ new: Scenario) {
        lock.lock()
        scenario = new
        requests.removeAll()
        lock.unlock()
    }

    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func stopLoading() {}

    override func startLoading() {
        Self.lock.lock()
        let stage = Self.requests.count
        Self.requests.append(request)
        let selected = Self.scenario
        Self.lock.unlock()
        guard let url = request.url else { fatalError("Missing URL") }
        let method = request.httpMethod ?? "GET"
        let actualHost = url.host ?? ""
        let allowedHosts: Set<String> = ["synergia.librus.pl", "api.librus.pl"]
        precondition(url.scheme == "https" && allowedHosts.contains(actualHost), "Unsafe request")
        var status = 200
        var headers = [String: String]()
        var body = Data()
        switch stage {
        case 0:
            precondition(method == "GET" && url.path == "/loguj/portalRodzina")
            status = 302
            headers["Location"] = "https://api.librus.pl/OAuth/Authorization?client_id=46&response_type=code&scope=mydata&state=teststate"
            headers["Set-Cookie"] = "DZIENNIKSID=sampleA; Domain=synergia.librus.pl; Path=/; Secure; HttpOnly"
        case 1:
            precondition(method == "GET" && url.path == "/OAuth/Authorization")
            status = 302
            headers["Location"] = "https://api.librus.pl/OAuth/Authorization?client_id=46&state=anotherstate"
            headers["Set-Cookie"] = "DeviceCookie=sampleB; Domain=api.librus.pl; Path=/OAuth; Secure; HttpOnly"
        case 2:
            precondition(method == "POST" && url.path == "/OAuth/Authorization")
            let cookie = request.value(forHTTPHeaderField: "Cookie") ?? ""
            precondition(cookie.contains("DeviceCookie=sampleB"), "API cookie missing from login POST")
            precondition(!cookie.contains("DZIENNIKSID=sampleA"), "School cookie leaked to API")
            if selected == .captcha {
                body = Data("<html>captcha challenge</html>".utf8)
            } else {
                headers["Content-Type"] = "application/json"
                body = Data(#"{"status":"ok","goTo":"/OAuth/Authorization/2FA?client_id=46"}"#.utf8)
            }
        case 3:
            precondition(method == "GET" && url.path == "/OAuth/Authorization/2FA")
            status = 302
            headers["Location"] = selected == .deniedRedirect
                ? "https://synergia.librus.pl/finish?error=access_denied"
                : "https://synergia.librus.pl/finish"
        case 4:
            precondition(method == "GET" && url.path == "/finish")
            body = Data("ok".utf8)
        case 5:
            precondition(method == "GET" && url.path == "/refreshToken")
            if selected == .refreshUnauthorized { status = 401 }
            else if selected != .refreshNoToken {
                headers["Set-Cookie"] = "oauth_token=sampleToken; Domain=synergia.librus.pl; Path=/; Secure; HttpOnly"
            }
        case 6:
            precondition(method == "GET" && url.path == "/gateway/api/2.0/Me")
            let cookie = request.value(forHTTPHeaderField: "Cookie") ?? ""
            precondition(cookie.contains("oauth_token=sampleToken"), "Gateway access lacks oauth_token")
            if selected == .meUnauthorized { status = 401 }
            body = selected == .invalidMe
                ? Data(#"{"Me":{}}"#.utf8)
                : Data(#"{"Me":{"Id":8472}}"#.utf8)
            headers["Content-Type"] = "application/json"
        default:
            fatalError("Unexpected extra request stage \(stage)")
        }
        let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        if !body.isEmpty { client?.urlProtocol(self, didLoad: body) }
        client?.urlProtocolDidFinishLoading(self)
    }
}

@main struct FullOAuthReplay {
    static func makeConfig() -> URLSessionConfiguration {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [OAuthReplayProtocol.self]
        return config
    }

    static func expectFailure(_ scenario: OAuthReplayProtocol.Scenario,
                              _ label: String, check: (DirectOAuthLoginError) -> Bool) async {
        OAuthReplayProtocol.reset(scenario)
        do {
            _ = try await DirectOAuthLoginClient(configuration: makeConfig())
                .authenticate(login: "school123", password: "fake-secret-only-for-test")
            fatalError("Expected failure: \(label)")
        } catch let issue as DirectOAuthLoginError {
            precondition(check(issue), "Incorrect failure classification: \(label) -> \(issue)")
            print("PASS:", label)
        } catch {
            fatalError("Unexpected error type on \(label): \(error)")
        }
    }

    @MainActor static func main() async {
        OAuthReplayProtocol.reset(.success)
        do {
            let result = try await DirectOAuthLoginClient(configuration: makeConfig())
                .authenticate(login: "school123", password: "fake-secret-only-for-test")
            let reqs = OAuthReplayProtocol.requests
            precondition(reqs.count == 7)
            precondition(reqs.map { $0.url?.path ?? "" } == [
                "/loguj/portalRodzina", "/OAuth/Authorization", "/OAuth/Authorization",
                "/OAuth/Authorization/2FA", "/finish", "/refreshToken", "/gateway/api/2.0/Me"
            ])
            precondition(result.contains(where: { $0.name == "oauth_token" }))
            precondition(result.contains(where: { $0.name == "DeviceCookie" }))
            print("PASS: full production OAuth 7-step replay, cookie isolation, refresh, live /Me, token handoff")
        } catch { fatalError("Full flow failed: \(error)") }

        await expectFailure(.refreshNoToken, "HTTP 200 without gateway token is rejected", check: {
            $0 == .gatewayTokenMissing
        })
        await expectFailure(.refreshUnauthorized, "refresh HTTP 401 is isolated", check: {
            $0 == .gatewayRefreshUnavailable(401)
        })
        await expectFailure(.meUnauthorized, "Me HTTP 401 is rejected", check: {
            $0 == .gatewayIdentityUnavailable(401)
        })
        await expectFailure(.invalidMe, "Me missing identity is rejected", check: {
            $0 == .gatewayIdentityInvalid
        })
        await expectFailure(.deniedRedirect, "OAuth access_denied is rejected", check: {
            $0 == .authorizationDenied
        })
        await expectFailure(.captcha, "CAPTCHA cannot be bypassed", check: {
            $0 == .captchaRequired
        })
    }
}
