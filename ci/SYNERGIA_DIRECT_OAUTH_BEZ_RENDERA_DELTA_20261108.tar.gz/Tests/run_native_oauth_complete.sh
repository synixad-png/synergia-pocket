#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 Tests/verify_native_oauth_full.py
bash Tests/run_p60_offline.sh
bash Tests/run_cookie_policy_from_production.sh
swiftc -typecheck Sources/NativeSchoolLoginPolicy.swift Sources/DirectAccountIdentity.swift Sources/DirectOAuthLoginClient.swift
swiftc Sources/NativeSchoolLoginPolicy.swift Sources/DirectAccountIdentity.swift Sources/DirectOAuthLoginClient.swift Tests/native_oauth_complete_replay.swift -o /tmp/synergia_native_oauth_complete_replay
/tmp/synergia_native_oauth_complete_replay
swiftc -frontend -parse Sources/*.swift
printf 'PASS: native complete OAuth source, production-class replay, 108 source parses\n'
