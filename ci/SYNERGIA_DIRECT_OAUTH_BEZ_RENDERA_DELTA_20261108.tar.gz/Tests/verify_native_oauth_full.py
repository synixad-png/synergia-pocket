#!/usr/bin/env python3
"""Regression scope and protocol invariants; no accounts or credentials needed."""
from pathlib import Path
import hashlib, json, sys
root = Path(__file__).resolve().parents[1]
source = root / 'Sources'
manifest = json.loads((root / 'Tests' / 'NATIVE_OAUTH_PROTECTED_SHA256.json').read_text())
files = list(source.glob('*.swift'))
assert len(files) == 108, f'Expected 108 Swift files; got {len(files)}'
unchanged = []
for file in files:
    if file.name == 'DirectOAuthLoginClient.swift':
        continue
    expected = manifest.get('Sources/' + file.name)
    if not expected:
        raise AssertionError(f'Missing baseline hash for {file.name}')
    actual = hashlib.sha256(file.read_bytes()).hexdigest()
    assert actual == expected, f'Protected Swift regression: {file.name}'
    unchanged.append(file.name)
assert len(unchanged) == 107
s = (source / 'DirectOAuthLoginClient.swift').read_text()
a = s.index('var next = try DirectOAuthLoginPolicy.continuation(reply)')
b = s.index('return all.filter(DirectOAuthLoginPolicy.transferable)', a)
flow = s[a:b]
assert 'DirectOAuthLoginPolicy.refresh' in flow
assert 'DirectOAuthLoginPolicy.me' in flow
assert flow.index('DirectOAuthLoginPolicy.refresh') < flow.index('DirectOAuthLoginPolicy.me')
assert 'gatewayTokenMissing' in flow and 'gatewayIdentityInvalid' in flow
assert 'DirectAccountIdentity.parse(payload)' in flow
assert 'authorizationDenied' in flow
assert 'captchaRequired' in flow
assert 'DirectOAuthCookiePolicy.receive(http, from: url, in: cookieJar)' in s
assert 'DirectOAuthCookiePolicy.requestHeader(for: url, in: cookieJar)' in s
assert 'httpShouldHandleCookies = false' in s
assert 'URLSessionConfiguration.ephemeral' in s
assert 'SecTrustSetExceptions' not in s
assert 'refreshToken' in s and '/gateway/api/2.0/Me' in s
assert 'try await DirectOAuthLoginClient.install' in (source/'Portal.swift').read_text()
assert 'self.verifyAccount()' in (source/'Portal.swift').read_text()
print('PASS: 107 protected Swift files identical; complete flow refreshToken -> Me -> cookie handoff; no Render')
