#!/usr/bin/env python3
from pathlib import Path
from hashlib import sha256
import tempfile, subprocess, json
root=Path(__file__).resolve().parents[1]
src=root/'Sources'
a=(src/'DirectOAuthLoginClient.swift').read_text()
manifest=json.loads((root/'Tests'/'P60_ALL_SWIFT_SHA256.json').read_text())
actual={p.name:sha256(p.read_bytes()).hexdigest() for p in src.glob('*.swift')}
assert len(actual)==108 and set(actual)==set(manifest)
assert {n for n in actual if actual[n]!=manifest[n]}=={'DirectOAuthLoginClient.swift'}
# Login must not follow the bootstrap redirect: reference Python client does one GET with allow_redirects=False.
assert 'let (_, bootstrap) = try await perform(authorization' in a  # request now supplies confirmed browser UA
assert 'bootstrapAuthorizationResponseIsAllowed' in a
assert 'authorizationPageHop(' not in a
assert 'authorizationReady' not in a
assert 'let (reply, submitted) = try await perform(DirectOAuthLoginPolicy.auth' in a
assert 'let all = cookieJar?.cookies ?? []' in a
assert 'DirectOAuthCookiePolicy.receive(http, from: url, in: cookieJar)' in a
assert 'DirectOAuthCookiePolicy.requestHeader(for: url, in: cookieJar)' in a
assert 'URLSessionConfiguration.ephemeral' in a
assert 'DirectOAuthLoginPolicy.isSchoolSession' in a
assert 'SecTrustSetExceptions' not in a
assert 'try await DirectOAuthLoginClient.install' in (src/'Portal.swift').read_text()
subprocess.run(['swiftc','-frontend','-parse',*[str(p) for p in src.glob('*.swift')]],check=True)
with tempfile.TemporaryDirectory() as d:
    d=Path(d)
    prefix=a.split('private final class DirectOAuthNoRedirects',1)[0].replace('import WebKit', '#if canImport(FoundationNetworking)\nimport FoundationNetworking\n#endif')
    (d/'policy.swift').write_text(prefix)
    subprocess.run(['swiftc',str(d/'policy.swift'),str(src/'NativeSchoolLoginPolicy.swift'),str(root/'Tests/reference_oauth_bootstrap_standalone.swift'),'-o',str(d/'test')],check=True)
    subprocess.run([str(d/'test')],check=True)
print('PASS: 108 Swift parsed, 107 unchanged, reference OAuth bootstrap and allowed redirects')
