#!/bin/bash
# Uruchom na macOS z Xcode. To TYLKO walidacja kodu, bez tworzenia IPA.
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_native_oauth_complete.sh
command -v xcodegen >/dev/null || { echo 'Brak xcodegen' >&2; exit 2; }
command -v xcodebuild >/dev/null || { echo 'Brak Xcode' >&2; exit 2; }
xcodegen generate
xcodebuild -project SynergiaDirect.xcodeproj -scheme SynergiaDirect -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
