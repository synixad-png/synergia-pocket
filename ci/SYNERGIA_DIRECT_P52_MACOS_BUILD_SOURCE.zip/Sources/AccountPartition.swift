import Foundation
import CryptoKit

/// Opaque on-disk account directories; do not expose student IDs as file names.
enum AccountPartition {
    static func directory(for accountId: String, under root: URL) -> URL {
        let digest = SHA256.hash(data: Data(accountId.utf8))
            .map { String(format: "%02x", $0) }.joined()
        return root.appendingPathComponent(digest, isDirectory: true)
    }
}
