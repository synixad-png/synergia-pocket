import Foundation

/// Conservative local previews. These do not fetch undocumented endpoints or
/// assert that a single HTML page is a complete school record.
struct CalendarCandidate: Identifiable {
    let id: String
    let dateText: String
    let title: String
    let subject: String?
    let details: String?
}
struct HomeworkCandidate: Identifiable {
    let id: String
    let subject: String
    let description: String
    let dueDate: String?
    let teacher: String?
}
struct AnnouncementCandidate: Identifiable {
    let id: String
    let title: String
    let body: String?
    let dateText: String?
    let author: String?
}
struct SchoolPreview<Item> {
    let items: [Item]
    let warnings: [String]
}

enum AdditionalParsers {
    private static func text(_ fields: [String: String], _ name: String) -> String? {
        guard let value = fields[name]?.trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty else { return nil }
        return value
    }
    static func calendar(_ snapshot: ModuleSnapshot) -> SchoolPreview<CalendarCandidate> {
        let rule = SchoolTableParser.ColumnRule(required: [
            "date": ["data", "termin", "dzien"], "title": ["wydarzenie", "temat", "nazwa", "zdarzenie"]
        ], optional: ["subject": ["przedmiot"], "details": ["opis", "szczegoly"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        let items = parsed.rows.compactMap { row -> CalendarCandidate? in
            guard let date = text(row.fields, "date"), let title = text(row.fields, "title"),
                  date.count <= 80, title.count <= 240 else { return nil }
            return CalendarCandidate(id: row.id, dateText: date, title: title,
                subject: text(row.fields, "subject"), details: text(row.fields, "details"))
        }
        return SchoolPreview(items: items, warnings: parsed.warnings)
    }
    static func homework(_ snapshot: ModuleSnapshot) -> SchoolPreview<HomeworkCandidate> {
        let rule = SchoolTableParser.ColumnRule(required: [
            "subject": ["przedmiot"], "description": ["zadanie", "tresc zadania", "opis zadania", "praca domowa"]
        ], optional: ["due": ["termin", "do kiedy", "data oddania"], "teacher": ["nauczyciel"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        let items = parsed.rows.compactMap { row -> HomeworkCandidate? in
            guard let subject = text(row.fields, "subject"),
                  let description = text(row.fields, "description"),
                  subject.count <= 150 else { return nil }
            return HomeworkCandidate(id: row.id, subject: subject, description: description,
                dueDate: text(row.fields, "due"), teacher: text(row.fields, "teacher"))
        }
        return SchoolPreview(items: items, warnings: parsed.warnings)
    }
    static func announcements(_ snapshot: ModuleSnapshot) -> SchoolPreview<AnnouncementCandidate> {
        let rule = SchoolTableParser.ColumnRule(required: [
            "title": ["tytul", "temat", "ogloszenie"]
        ], optional: ["body": ["tresc", "opis"], "date": ["data", "opublikowano"],
                      "author": ["autor", "nadawca"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        let items = parsed.rows.compactMap { row -> AnnouncementCandidate? in
            guard let title = text(row.fields, "title"), title.count <= 240,
                  // A title-only match from an unrelated table is insufficient.
                  text(row.fields, "body") != nil || text(row.fields, "date") != nil || text(row.fields, "author") != nil else { return nil }
            return AnnouncementCandidate(id: row.id, title: title, body: text(row.fields, "body"),
                dateText: text(row.fields, "date"), author: text(row.fields, "author"))
        }
        return SchoolPreview(items: items, warnings: parsed.warnings)
    }
}
