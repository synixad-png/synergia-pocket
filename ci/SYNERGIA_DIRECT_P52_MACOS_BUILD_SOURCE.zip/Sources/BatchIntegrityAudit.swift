import Foundation

/// Conservative quality gate for batches of user-approved pages. This does not
/// establish that Synergia provided all its records; it only protects the local
/// cache against internally inconsistent or obviously empty captures.
struct BatchIntegrityReport: Equatable {
    let accepted: Bool
    let pageCount: Int
    let recordCount: Int
    let tableCount: Int
    let issueCodes: [String]
    var explanation: String {
        accepted
        ? "Zestaw wewnętrznie spójny; kompletność względem Synergii niepotwierdzona."
        : "Odrzucono niepełny lub niespójny zestaw; wcześniejsze dane pozostają bez zmian."
    }
}

enum BatchIntegrityAudit {
    static func inspect(_ pages: [ModuleSnapshot], module: SchoolModule) -> BatchIntegrityReport {
        var problems: [String] = []
        if pages.isEmpty { problems.append("no_pages") }
        if pages.count > 20 { problems.append("page_limit") }
        if pages.contains(where: { $0.module != module }) { problems.append("wrong_module") }
        if Set(pages.map(\.sourceURL)).count != pages.count { problems.append("duplicate_page") }
        if pages.contains(where: { page in
            guard let url = URL(string: page.sourceURL) else { return true }
            return !PortalPolicy.isAllowed(url) || url.user != nil || url.password != nil
        }) { problems.append("invalid_origin") }

        let rows = pages.map { $0.records.count }
        let tableCounts = pages.map { $0.tables?.count ?? 0 }
        if (module == .grades || module == .messages) && pages.count > 1 {
            if rows.contains(0) && rows.contains(where: { $0 > 0 }) {
                problems.append("mixed_empty_page")
            }
            if tableCounts.contains(0) && tableCounts.contains(where: { $0 > 0 }) {
                problems.append("mixed_missing_tables")
            }
        }
        if pages.count > 0 && pages.allSatisfy({ $0.records.isEmpty && ($0.tables ?? []).isEmpty && $0.links.isEmpty }) {
            problems.append("no_structured_data")
        }
        // Each page is limited independently: a truncated, over-limit result
        // must not be accidentally counted as an exhaustive data snapshot.
        if pages.contains(where: { $0.records.count >= 4000 || ($0.tables?.count ?? 0) > 40 }) {
            problems.append("capture_limit")
        }
        return BatchIntegrityReport(accepted: problems.isEmpty, pageCount: pages.count,
            recordCount: rows.reduce(0,+), tableCount: tableCounts.reduce(0,+),
            issueCodes: problems)
    }
}
