import Foundation

/// Explicitly conservative classification. A raw web table is never represented as a verified grade.
struct CaptureReport: Identifiable, Codable {
    var id: UUID = UUID()
    var module: SchoolModule
    var sourceTitle: String
    var sourceURL: String
    var rowCount: Int
    var linkCount: Int
    var capturedAt: Date = Date()
    var warnings: [String]
}

enum CaptureAnalyzer {
    /// A partial capture cannot replace the last locally stored snapshot.
    static func safeToReplace(_ capture: PageCapture) -> Bool {
        capture.documentReady == true && capture.isTruncated != true && capture.hasPagination != true
    }

    static func validate(_ capture: PageCapture, for module: SchoolModule) -> [String] {
        var warnings: [String] = []
        let normalized = "\(capture.title) \(capture.heading) \(capture.url)".folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "pl_PL"))
        let indicators = module.identifyingWords.map {
            $0.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "pl_PL"))
        }
        if !indicators.contains(where: { normalized.contains($0) }) {
            warnings.append("Nagłówek lub adres strony nie potwierdza wybranego modułu.")
        }
        if capture.documentReady != true { warnings.append("Dokument nie zakończył ładowania.") }
        if capture.isTruncated == true { warnings.append("Odczyt osiągnął limit długości — wynik może być ucięty.") }
        if capture.hasPagination == true { warnings.append("Na stronie wykryto stronicowanie; nie jest to kompletny zbiór.") }
        if capture.rows.isEmpty { warnings.append("Nie wykryto wierszy tabel HTML; dane mogą być prezentowane w kartach lub ładowane dynamicznie.") }
        if capture.rows.count >= 1000 { warnings.append("Osiągnięto limit 1000 wierszy w pojedynczym odczycie.") }
        if capture.links.count >= 250 { warnings.append("Osiągnięto limit 250 linków w pojedynczym odczycie.") }
        warnings.append("Zawartość nie została potwierdzona z rzeczywistym kontem. Liczba wierszy nie jest liczbą ocen lub wiadomości.")
        return warnings
    }
}
