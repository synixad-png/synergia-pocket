import Foundation

/// Local-only, testable descriptive labels. Does not alter server read markers,
/// attendance counts, message recipients or their storage.
enum DirectAccessibilityPresentation {
    static func noticeReadLabel(_ wasRead: Bool?) -> String {
        switch wasRead {
        case .some(true): return "Przeczytane"
        case .some(false): return "Nieprzeczytane"
        case .none: return "Brak statusu odczytu"
        }
    }

    static func noticeReadSymbol(_ wasRead: Bool?) -> String {
        switch wasRead {
        case .some(true): return "checkmark.circle"
        case .some(false): return "circle.fill"
        case .none: return "questionmark.circle"
        }
    }

    static func attendanceStatusLabel(typeName: String, isPresenceKind: Bool) -> String {
        let name = typeName.trimmingCharacters(in: .whitespacesAndNewlines)
        let kind = isPresenceKind ? "Rodzaj obecności" : "Rodzaj nieobecności"
        return "\(kind): \(name.isEmpty ? "brak nazwy typu" : name)"
    }
}
