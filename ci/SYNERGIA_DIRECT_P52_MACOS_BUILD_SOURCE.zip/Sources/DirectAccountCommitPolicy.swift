import Foundation

/// Gate for committing a network response to account-scoped persistent storage.
/// Both /Me checks and the verified UI owner must refer to the same student,
/// and neither the account epoch nor the operation may change during awaits.
/// This policy is deliberately independent of WebKit for offline regression tests.
enum DirectAccountCommitPolicy {
    static func permits(
        verifiedAtStart: String?,
        verifiedNow: String?,
        remoteBefore: String,
        remoteAfter: String,
        accountEpochUnchanged: Bool,
        requestEpochUnchanged: Bool,
        foregroundAndVisible: Bool
    ) -> Bool {
        guard let start = verifiedAtStart, !start.isEmpty,
              let current = verifiedNow, !current.isEmpty else { return false }
        return accountEpochUnchanged && requestEpochUnchanged && foregroundAndVisible &&
            remoteBefore == start && remoteAfter == start && current == start
    }
}
