import Foundation
import CoreFoundation

// Only a uniquely identified account can own local grades. If the live
// response changes shape, reject it rather than borrowing another identifier.
struct DirectAccountIdentity: Equatable {
    let id: String

    enum IdentityError: Error, Equatable {
        case missingIdentifier
        case conflictingIdentifiers
    }

    static func parse(_ response: [String: Any]) throws -> DirectAccountIdentity {
        let roots: [[String: Any]] = [response,
             response["Me"] as? [String: Any] ?? [:]]
        var ids: [String] = []
        for root in roots {
            if let id = normalized(root["Id"]) { ids.append(id) }
            if let user = root["User"] as? [String: Any],
               let id = normalized(user["Id"]) { ids.append(id) }
        }
        guard !ids.isEmpty else { throw IdentityError.missingIdentifier }
        guard Set(ids).count == 1 else { throw IdentityError.conflictingIdentifiers }
        return DirectAccountIdentity(id: ids[0])
    }

    private static func normalized(_ value: Any?) -> String? {
        if let string = value as? String {
            let cleaned = string.trimmingCharacters(in: .whitespacesAndNewlines)
            return cleaned.isEmpty ? nil : cleaned
        }
        if let number = value as? NSNumber,
           CFGetTypeID(number) != CFBooleanGetTypeID() { return number.stringValue }
        return nil
    }
}
