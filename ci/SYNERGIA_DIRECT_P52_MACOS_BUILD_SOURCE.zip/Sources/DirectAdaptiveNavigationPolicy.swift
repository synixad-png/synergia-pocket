import Foundation

/// Five stable destinations shared by the compact tab bar and regular-width
/// iPad sidebar. No account, network, cache or persistence state is stored here.
enum DirectPrimarySection: String, CaseIterable, Identifiable {
    case start, grades, timetable, messages, more
    var id: String { rawValue }
    var title: String {
        switch self {
        case .start: return "Start"
        case .grades: return "Oceny"
        case .timetable: return "Plan"
        case .messages: return "Wiadomości"
        case .more: return "Więcej"
        }
    }
    var symbol: String {
        switch self {
        case .start: return "house.fill"
        case .grades: return "graduationcap.fill"
        case .timetable: return "calendar"
        case .messages: return "envelope.fill"
        case .more: return "square.grid.2x2.fill"
        }
    }
}

enum DirectNavigationStyle: Equatable { case tabs, sidebar }

/// Horizontal size class handles iPad split-screen and Stage Manager: a
/// compact iPad window behaves like an iPhone without a device-type guess.
enum DirectAdaptiveNavigationPolicy {
    static func selectedOrStart(_ selected: DirectPrimarySection?) -> DirectPrimarySection {
        selected ?? .start
    }
    static func style(isRegularWidth: Bool) -> DirectNavigationStyle {
        isRegularWidth ? .sidebar : .tabs
    }
    static func readableMaxWidth(isRegularWidth: Bool) -> Double {
        isRegularWidth ? 920 : .infinity
    }
}


/// Readable content limits for a wide iPad window. Compact windows retain
/// all available width, regardless of physical device or orientation.
/// This policy never accesses user/account/network state.
enum DirectAdaptiveContentKind: CaseIterable {
    case module, messageReader, loginForm, settings
}

extension DirectAdaptiveNavigationPolicy {
    static func contentMaxWidth(isRegularWidth: Bool, kind: DirectAdaptiveContentKind) -> Double {
        guard isRegularWidth else { return .infinity }
        switch kind {
        case .module: return 920
        case .messageReader: return 760
        case .loginForm: return 640
        case .settings: return 820
        }
    }
}
