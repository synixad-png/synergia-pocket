import Foundation

/// Prevent any deletion outside the application's dedicated ephemeral area.
/// The importer creates exactly one UUID directory per attachment; only that
/// immediate directory is disposable. Never follow a symlink outside the root.
enum DirectAttachmentLocalFilePolicy {
    static func disposableDirectory(fileURL: URL, filename: String, under root: URL) -> URL? {
        guard root.isFileURL, fileURL.isFileURL,
              DirectAttachmentPolicy.safeFileName(filename) else { return nil }
        let normalizedRoot = root.standardizedFileURL
        let normalized = fileURL.standardizedFileURL
        let parent = normalized.deletingLastPathComponent()
        guard normalized.lastPathComponent == filename,
              parent.deletingLastPathComponent() == normalizedRoot,
              UUID(uuidString: parent.lastPathComponent) != nil else { return nil }
        // A symlink created by another process must not make the app delete
        // data outside its own temporary subtree.
        guard parent.resolvingSymlinksInPath().deletingLastPathComponent() ==
                normalizedRoot.resolvingSymlinksInPath(),
              normalized.resolvingSymlinksInPath().deletingLastPathComponent() ==
                parent.resolvingSymlinksInPath() else { return nil }
        return parent
    }
}
