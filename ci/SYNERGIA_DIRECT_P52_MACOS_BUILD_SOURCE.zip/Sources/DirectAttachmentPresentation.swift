import Foundation

/// Local, user-requested previews only. This allow-list does not decide which
/// attachments may be downloaded or exported; it decides whether iOS QuickLook
/// may be opened from the trusted, temporary file location.
enum DirectAttachmentPresentation {
    private static let previewExtensions: Set<String> = [
        "pdf", "png", "jpg", "jpeg", "heic", "heif", "gif",
        "txt", "rtf", "csv", "doc", "docx", "xls", "xlsx", "ppt", "pptx"
    ]

    static func canPreview(_ name: String) -> Bool {
        guard DirectAttachmentPolicy.safeFileName(name) else { return false }
        let suffix = (name as NSString).pathExtension.lowercased()
        return previewExtensions.contains(suffix)
    }

    static func kindSymbol(_ name: String) -> String {
        switch (name as NSString).pathExtension.lowercased() {
        case "pdf": return "doc.richtext"
        case "jpg", "jpeg", "png", "gif", "heic", "heif": return "photo"
        case "txt", "rtf", "csv": return "doc.text"
        case "doc", "docx", "xls", "xlsx", "ppt", "pptx": return "doc.fill"
        case "zip", "7z", "rar": return "doc.zipper"
        default: return "doc"
        }
    }

    static func sizeDescription(_ declaredSize: Int?) -> String {
        guard let declaredSize else { return "Rozmiar niepodany" }
        return ByteCountFormatter.string(fromByteCount: Int64(declaredSize), countStyle: .file)
    }

    static func isTooLarge(_ declaredSize: Int?) -> Bool {
        guard let declaredSize else { return false }
        return declaredSize > DirectAttachmentPolicy.maxBytes
    }
}
