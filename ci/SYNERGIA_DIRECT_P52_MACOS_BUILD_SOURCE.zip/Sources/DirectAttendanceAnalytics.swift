import Foundation

/// Diagnostic aggregates of RECEIVED marks only. Never infer a scheduled-lesson denominator.
/// Missing presence marks and parallel lesson groups make a school attendance % unreliable.
struct DirectAttendanceMonthStatistics: Equatable, Identifiable {
    let month: String? // Gregorian YYYY-MM, nil for malformed server date
    let counts: DirectAttendanceCounters
    var id: String { month.map { "month:\($0)" } ?? "month:unknown" }
    var label: String { month ?? "Data nierozpoznana" }
}

/// Day-level breakdown of *received* attendance records only. Invalid source
/// dates are retained in a separate group instead of being silently discarded.
struct DirectAttendanceDayStatistics: Equatable, Identifiable {
    let day: String?
    let counts: DirectAttendanceCounters
    var id: String { day.map { "day:\($0)" } ?? "day:unknown" }
    var label: String { day ?? "Data nierozpoznana" }
}

struct DirectAttendanceSubjectSemesterStatistics: Equatable, Identifiable {
    let subjectId: String?
    let subjectName: String
    let semester: Int?
    let counts: DirectAttendanceCounters
    var id: String {
        let subjectKey = subjectId.map { "id:\($0.utf8.count):\($0)" } ?? "missing"
        let semesterKey = semester.map { "number:\($0)" } ?? "missing"
        return subjectKey + ";" + semesterKey
    }
    var semesterLabel: String { semester.map { "Semestr \($0)" } ?? "Semestr nieustalony" }
}

struct DirectAttendanceTypeStatistics: Equatable, Identifiable {
    let typeId: String
    let name: String
    let isPresenceKind: Bool
    let count: Int
    var id: String { "\(typeId)|\(name)|\(isPresenceKind)" }
}

struct DirectAttendanceQuality: Equatable {
    let records: Int
    let unresolvedSubjects: Int
    let missingSubjectNames: Int
    let unknownSemesters: Int
    let unknownLessonNumbers: Int
    let invalidDates: Int
    let repeatedLessonSlots: Int
    /// Duplicate identifiers in a *merged/cached* set can inflate totals even
    /// though a single decoded response rejects duplicate IDs.
    let repeatedRecordIds: Int
    let inconsistentTypeIds: Int
    var hasCautions: Bool {
        unresolvedSubjects > 0 || missingSubjectNames > 0 || unknownSemesters > 0 || unknownLessonNumbers > 0 ||
        invalidDates > 0 || repeatedLessonSlots > 0 || repeatedRecordIds > 0 || inconsistentTypeIds > 0
    }
}

struct DirectAttendanceAnalytics: Equatable {
    let summary: DirectAttendanceSummary
    let months: [DirectAttendanceMonthStatistics]
    let days: [DirectAttendanceDayStatistics]
    let subjectSemesters: [DirectAttendanceSubjectSemesterStatistics]
    let types: [DirectAttendanceTypeStatistics]
    let quality: DirectAttendanceQuality
}

enum DirectAttendanceFilter: Equatable {
    enum Semester: Equatable { case all, unspecified, numbered(Int) }
    enum Subject: Equatable { case all, unspecified, id(String) }
    enum Status: Equatable { case all, present, absent, late, excused, explicitlyUnexcused, unspecifiedAbsence }
    enum Month: Equatable { case all, invalid, yearMonth(String) }

    static func select(_ records: [DirectAttendance], semester: Semester = .all,
                       subject: Subject = .all, status: Status = .all,
                       month: Month = .all) -> [DirectAttendance] {
        records.filter { entry in
            switch semester {
            case .all: break
            case .unspecified: if entry.semester != nil { return false }
            case .numbered(let number): if entry.semester != number { return false }
            }
            switch subject {
            case .all: break
            case .unspecified: if entry.subjectId != nil { return false }
            case .id(let id): if entry.subjectId != id { return false }
            }
            switch month {
            case .all: break
            case .invalid: if DirectAttendanceCalendar.month(for: entry.date) != nil { return false }
            case .yearMonth(let selected): if DirectAttendanceCalendar.month(for: entry.date) != selected { return false }
            }
            switch status {
            case .all: return true
            case .present: return entry.isPresenceKind
            case .absent: return !entry.isPresenceKind
            case .late: return entry.isPresenceKind && DirectAttendanceStatus.isLate(entry.typeName)
            case .excused: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .excused
            case .explicitlyUnexcused: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .unexcused
            case .unspecifiedAbsence: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .unspecified
            }
        }
    }
}

enum DirectAttendanceAnalyticsBuilder {
    static func build(_ records: [DirectAttendance], subjects: [String: String]) -> DirectAttendanceAnalytics {
        let groupedDays = Dictionary(grouping: records) { DirectAttendanceCalendar.day($0.date) }
        let days = groupedDays.map { day, entries in
            DirectAttendanceDayStatistics(day: day, counts: DirectAttendanceStatistics.count(entries))
        }.sorted { a, b in
            switch (a.day, b.day) {
            case let (a?, b?): return a > b // latest valid school date first
            case (.some, nil): return true
            default: return false
            }
        }
        let groupedMonths = Dictionary(grouping: records) { DirectAttendanceCalendar.month(for: $0.date) }
        let months = groupedMonths.map { month, entries in
            DirectAttendanceMonthStatistics(month: month, counts: DirectAttendanceStatistics.count(entries))
        }.sorted { a, b in
            switch (a.month, b.month) {
            case let (a?, b?): return a < b
            case (.some, nil): return true
            default: return false
            }
        }
        struct CrossKey: Hashable { let subject: String?; let semester: Int? }
        let cross = Dictionary(grouping: records) { CrossKey(subject: $0.subjectId, semester: $0.semester) }
        let subjectSemesters = cross.map { key, entries in
            DirectAttendanceSubjectSemesterStatistics(subjectId: key.subject,
                subjectName: DirectAttendanceSubjectLabel.text(id: key.subject, names: subjects),
                semester: key.semester, counts: DirectAttendanceStatistics.count(entries))
        }.sorted { a, b in
            let order = a.subjectName.localizedStandardCompare(b.subjectName)
            if order != .orderedSame { return order == .orderedAscending }
            if a.subjectId != b.subjectId { return (a.subjectId ?? "") < (b.subjectId ?? "") }
            return (a.semester ?? Int.max) < (b.semester ?? Int.max)
        }
        struct TypeKey: Hashable { let id: String; let normalizedName: String; let present: Bool }
        let groupedTypes = Dictionary(grouping: records) {
            TypeKey(id: $0.typeId, normalizedName: DirectAttendanceStatus.normalized($0.typeName), present: $0.isPresenceKind)
        }
        let types = groupedTypes.map { key, entries in
            DirectAttendanceTypeStatistics(typeId: key.id,
                name: entries.sorted { $0.id < $1.id }.first?.typeName ?? "Typ nieustalony",
                isPresenceKind: key.present, count: entries.count)
        }.sorted { a, b in
            if a.count != b.count { return a.count > b.count }
            return a.id < b.id
        }
        // Multiple entries at the same date/period can be valid corrections or group records.
        // Report collisions only; never delete or merge marks based on a heuristic.
        var knownSlots = Set<String>()
        var repeats = 0
        for record in records {
            if let day = DirectAttendanceCalendar.day(record.date),
               let no = record.lessonNumber, no > 0 {
                let slot = "\(day)|\(no)"
                if !knownSlots.insert(slot).inserted { repeats += 1 }
            }
        }
        // Never merge or delete records on this diagnostic alone: compare all
        // received rows conservatively until the server/merge source is known.
        var seenRecordIds = Set<String>()
        var repeatedRecordIds = 0
        for record in records {
            if !seenRecordIds.insert(record.id).inserted { repeatedRecordIds += 1 }
        }
        let inconsistentTypes = Dictionary(grouping: records, by: \.typeId)
            .values.filter { Set($0.map { "\(DirectAttendanceStatus.normalized($0.typeName))|\($0.isPresenceKind)" }).count > 1 }.count
        let quality = DirectAttendanceQuality(records: records.count,
            unresolvedSubjects: records.filter { $0.subjectId == nil }.count,
            missingSubjectNames: records.filter { record in
                guard let id = record.subjectId else { return false }
                return subjects[id]?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty != false
            }.count,
            unknownSemesters: records.filter { $0.semester == nil }.count,
            unknownLessonNumbers: records.filter { ($0.lessonNumber ?? 0) <= 0 }.count,
            invalidDates: records.filter { DirectAttendanceCalendar.day($0.date) == nil }.count,
            repeatedLessonSlots: repeats, repeatedRecordIds: repeatedRecordIds,
            inconsistentTypeIds: inconsistentTypes)
        return DirectAttendanceAnalytics(summary: DirectAttendanceStatistics.summarize(records, subjects: subjects),
            months: months, days: days,
            subjectSemesters: subjectSemesters, types: types, quality: quality)
    }
}
