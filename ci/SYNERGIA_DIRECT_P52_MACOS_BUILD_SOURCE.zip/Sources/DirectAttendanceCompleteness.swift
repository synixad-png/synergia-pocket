import Foundation
import CoreFoundation

/// Reject known-incomplete attendance responses without guessing unseen pages.
/// An absent count/pagination flag does NOT prove full-year coverage.
enum AttendanceCompletenessError: Error, Equatable {
    case invalidTotal
    case incomplete(expected: Int, received: Int)
    case unsupportedPagination
    case unexplainedEmptyReplacement
    case missingRecords(Int)
}

enum DirectAttendanceCompleteness {
    private static func integer(_ raw: Any) -> Int? {
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            let value = number.doubleValue
            if value.isFinite, value >= 0, value.rounded() == value, value <= Double(Int.max) {
                return number.intValue
            }
        }
        if let text = raw as? String, let value = Int(text), value >= 0 { return value }
        return nil
    }
    /// Any disappearance may be a partial server read; without an authoritative
    /// deletion feed do not replace a previously saved attendance record.
    static func validateNoUnexplainedDisappearance(previous: [DirectAttendance],
                                                   incoming: [DirectAttendance]) throws {
        let incomingIDs = Set(incoming.map(\.id))
        let missing = previous.filter { !incomingIDs.contains($0.id) }.count
        if missing > 0 { throw AttendanceCompletenessError.missingRecords(missing) }
    }

    static func validate(root: [String: Any], decodedCount: Int, previousCount: Int) throws {
        var total: Int?
        for key in ["Total", "TotalCount"] {
            if let raw = root[key] {
                guard let parsed = integer(raw) else { throw AttendanceCompletenessError.invalidTotal }
                if let current = total, current != parsed { throw AttendanceCompletenessError.invalidTotal }
                total = parsed
            }
        }
        if let total, total != decodedCount {
            throw AttendanceCompletenessError.incomplete(expected: total, received: decodedCount)
        }
        for key in ["Next", "NextPage", "NextPageUrl", "next"] {
            guard let value = root[key], !(value is NSNull) else { continue }
            if let text = value as? String, text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { continue }
            if let number = value as? NSNumber,
               CFGetTypeID(number) == CFBooleanGetTypeID(), !number.boolValue { continue }
            throw AttendanceCompletenessError.unsupportedPagination
        }
        if decodedCount == 0 && previousCount > 0 && total != 0 {
            throw AttendanceCompletenessError.unexplainedEmptyReplacement
        }
    }
}
