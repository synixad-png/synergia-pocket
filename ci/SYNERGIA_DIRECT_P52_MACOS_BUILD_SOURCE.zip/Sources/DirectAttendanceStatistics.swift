import Foundation

enum DirectAttendanceStatus {
    enum Excuse { case excused, unexcused, unspecified }
    static func normalized(_ text: String) -> String {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "pl_PL"))
            .lowercased().filter { !$0.isWhitespace }
    }
    static func isLate(_ text: String) -> Bool { normalized(text).contains("spozn") }
    /// This is only a cautious reading of the school's *label*, not an official
    /// excuse decision. `IsPresenceKind` from the server remains the sole source
    /// of the presence/absence split. Pending or merely requested excuses are
    /// not confirmed excuses. No school-specific numeric type IDs are assumed.
    static func excuse(_ text: String) -> Excuse {
        let s = normalized(text)
        // A status mentioning an application, waiting period, or lack of a
        // document does not confirm either a final excuse or a final refusal.
        // Check these before matching the "usprawiedliw" word stem.
        let unresolvedPhrases = [
            "dousprawiedliwienia", "oczekujenausprawiedliwienie", "oczekujenausprawiedliw",
            "oczekujenarozpatrzenie", "prosbaousprawiedliwienie",
            "wniosekousprawiedliwienie", "brakusprawiedliwienia", "bezusprawiedliwienia",
            "usprawiedliwieniewtoku", "usprawiedliwieniedoakceptacji"
        ]
        if unresolvedPhrases.contains(where: s.contains) { return .unspecified }
        // "Nieusprawiedliwiona" and "nieuspr." are explicit negative forms.
        if s.contains("nieusprawiedliwion") || s.hasSuffix("nieuspr.") ||
           s.hasSuffix("nieuspr") { return .unexcused }
        // Positive *adjectival* forms say that the absence is already excused.
        // Nouns such as "usprawiedliwienie" do not state a final decision.
        if s.contains("usprawiedliwion") || s.hasSuffix("uspr.") ||
           s.hasSuffix("uspr") { return .excused }
        return .unspecified
    }
}

/// Keep a missing lesson->subject link distinct from a known subject ID whose
/// display name was not returned. Neither case permits a fabricated subject.
enum DirectAttendanceSubjectLabel {
    static func text(id: String?, names: [String: String]) -> String {
        guard let id, !id.isEmpty else { return "Przedmiot nieustalony (brak powiązania lekcji)" }
        guard let name = names[id],
              !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return "Nieznana nazwa przedmiotu (ID: \(id))"
        }
        return name
    }
}

enum DirectAttendanceCalendar {
    /// Strict date portion: YYYY-MM-DD, optionally followed by T or a space and a time.
    /// A malformed date must not be silently bucketed under a plausible month.
    /// Reject malformed time tails rather than grouping e.g. T99:99 or Tabc as a valid day.
    /// This checks syntax, not the timezone-adjusted calendar day: the server's date
    /// portion is deliberately retained without guessing a local school timezone.
    private static func validTimeSuffix(_ suffix: ArraySlice<UInt8>) -> Bool {
        let bytes = Array(suffix)
        guard bytes.count >= 6, bytes[0] == 84 || bytes[0] == 32 else { return false }
        func number(_ start: Int, _ count: Int) -> Int? {
            guard start + count <= bytes.count else { return nil }
            var value = 0
            for index in start..<(start + count) {
                let byte = bytes[index]
                guard (48...57).contains(byte) else { return nil }
                value = value * 10 + Int(byte - 48)
            }
            return value
        }
        guard bytes[3] == 58, let hour = number(1, 2), hour < 24,
              let minute = number(4, 2), minute < 60 else { return false }
        var position = 6
        var hasSeconds = false
        if position < bytes.count && bytes[position] == 58 {
            position += 1
            guard let second = number(position, 2), second < 60 else { return false }
            position += 2
            hasSeconds = true
        }
        if position < bytes.count && bytes[position] == 46 {
            guard hasSeconds else { return false }
            position += 1
            let first = position
            while position < bytes.count && (48...57).contains(bytes[position]) { position += 1 }
            guard position > first else { return false }
        }
        if position == bytes.count { return true }
        if bytes[position] == 90 { return position + 1 == bytes.count } // UTC Z
        if bytes[position] == 43 || bytes[position] == 45 {
            guard position + 6 == bytes.count, bytes[position + 3] == 58,
                  let offsetHour = number(position + 1, 2), offsetHour <= 14,
                  let offsetMinute = number(position + 4, 2), offsetMinute < 60,
                  (offsetHour < 14 || offsetMinute == 0) else { return false }
            return true
        }
        return false
    }

    static func day(_ raw: String) -> String? {
        guard raw.utf8.count >= 10 else { return nil }
        let bytes = Array(raw.utf8)
        guard bytes[4] == 45, bytes[7] == 45,
              (0..<10).allSatisfy({ i in i == 4 || i == 7 || (48...57).contains(bytes[i]) }),
              (bytes.count == 10 || validTimeSuffix(bytes[10...])) else { return nil }
        let y = Int(raw.prefix(4))!, m = Int(raw.dropFirst(5).prefix(2))!, d = Int(raw.dropFirst(8).prefix(2))!
        guard y >= 1, (1...12).contains(m), (1...31).contains(d) else { return nil }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        guard let date = calendar.date(from: DateComponents(year: y, month: m, day: d)),
              calendar.component(.year, from: date) == y,
              calendar.component(.month, from: date) == m,
              calendar.component(.day, from: date) == d else { return nil }
        return String(raw.prefix(10))
    }
    static func month(for raw: String) -> String? { day(raw).map { String($0.prefix(7)) } }
}


/// Zestawienie wyłącznie wpisów zwróconych przez Attendances.
/// Nie jest oficjalną frekwencją: w części szkół nauczyciele nie wpisują każdej lekcji.
struct DirectAttendanceCounters: Equatable {
    let recorded: Int
    let present: Int
    let absent: Int
    let late: Int
    let excused: Int
    let explicitlyUnexcused: Int
    let absenceStatusUnknown: Int

    var consistent: Bool {
        recorded == present + absent &&
        absent == excused + explicitlyUnexcused + absenceStatusUnknown &&
        late <= present
    }
}

struct DirectAttendanceSubjectStatistics: Equatable, Identifiable {
    let subjectId: String?
    let name: String
    let counts: DirectAttendanceCounters
    var id: String { subjectId.map { "subject:\($0)" } ?? "unknown-subject" }
}

struct DirectAttendanceSemesterStatistics: Equatable, Identifiable {
    let semester: Int?
    let counts: DirectAttendanceCounters
    var id: String { semester.map { "semester:\($0)" } ?? "unknown-semester" }
    var label: String { semester.map { "Semestr \($0)" } ?? "Semestr nieustalony" }
}

struct DirectAttendanceSummary: Equatable {
    let all: DirectAttendanceCounters
    let bySemester: [DirectAttendanceSemesterStatistics]
    let bySubject: [DirectAttendanceSubjectStatistics]
    let distinctDates: Int
}

enum DirectAttendanceStatistics {
    static func count(_ records: [DirectAttendance]) -> DirectAttendanceCounters {
        var present = 0, absent = 0, late = 0, excused = 0, unexcused = 0, unknown = 0
        for record in records {
            if record.isPresenceKind {
                present += 1
                if DirectAttendanceStatus.isLate(record.typeName) { late += 1 }
            } else {
                absent += 1
                switch DirectAttendanceStatus.excuse(record.typeName) {
                case .excused: excused += 1
                case .unexcused: unexcused += 1
                case .unspecified: unknown += 1
                }
            }
        }
        return DirectAttendanceCounters(recorded: records.count, present: present, absent: absent,
            late: late, excused: excused, explicitlyUnexcused: unexcused,
            absenceStatusUnknown: unknown)
    }

    static func summarize(_ records: [DirectAttendance], subjects: [String: String]) -> DirectAttendanceSummary {
        let groupedSemester = Dictionary(grouping: records, by: \.semester)
        let semesters = groupedSemester.map { semester, rows in
            DirectAttendanceSemesterStatistics(semester: semester, counts: count(rows))
        }.sorted { left, right in
            switch (left.semester, right.semester) {
            case let (a?, b?): return a < b
            case (.some, nil): return true
            default: return false
            }
        }
        let bySubject = Dictionary(grouping: records, by: \.subjectId)
        let subjectsSummary = bySubject.map { subject, rows in
            DirectAttendanceSubjectStatistics(subjectId: subject,
                name: DirectAttendanceSubjectLabel.text(id: subject, names: subjects),
                counts: count(rows))
        }.sorted { a, b in
            let comparison = a.name.localizedStandardCompare(b.name)
            return comparison == .orderedSame ? a.id < b.id : comparison == .orderedAscending
        }
        return DirectAttendanceSummary(all: count(records), bySemester: semesters,
            bySubject: subjectsSummary, distinctDates: Set(records.compactMap { DirectAttendanceCalendar.day($0.date) }).count)
    }
}
