import Foundation
import CryptoKit

/// Local, account-scoped attendance snapshot. Nothing is shown before live /Me verification.
@MainActor
final class DirectAttendanceStore: ObservableObject {
    @Published private(set) var records: [DirectAttendance] = []
    @Published private(set) var subjects: [String: String] = [:]
    @Published private(set) var capturedAt: Date?
    private(set) var verifiedAccountId: String?
    private let directory: URL

    private struct Saved: Codable {
        let accountId: String
        let records: [DirectAttendance]
        let subjects: [String: String]
        let capturedAt: Date
    }

    init(directory: URL? = nil) {
        let root = directory ?? FileManager.default.urls(for: .applicationSupportDirectory,
            in: .userDomainMask)[0].appendingPathComponent("school-data", isDirectory: true)
        self.directory = root.appendingPathComponent("attendance-accounts", isDirectory: true)
    }
    private func file(for accountId: String) -> URL {
        let key = SHA256.hash(data: Data(accountId.utf8))
            .map { String(format: "%02x", $0) }.joined()
        return directory.appendingPathComponent(key + ".json")
    }
    func lock() {
        verifiedAccountId = nil
        records = []; subjects = [:]; capturedAt = nil
    }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        guard let data = try? Data(contentsOf: file(for: accountId)),
              let saved = try? JSONDecoder().decode(Saved.self, from: data),
              saved.accountId == accountId else { return }
        records = saved.records
        subjects = saved.subjects
        capturedAt = saved.capturedAt
    }
    func replace(records: [DirectAttendance], subjects: [String: String], accountId: String) throws {
        guard !accountId.isEmpty, verifiedAccountId == accountId else {
            throw StoreError.accountNotVerified
        }
        let now = Date()
        let payload = Saved(accountId: accountId, records: records, subjects: subjects, capturedAt: now)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try JSONEncoder().encode(payload).write(to: file(for: accountId),
            options: [.atomic, .completeFileProtection])
        self.records = records
        self.subjects = subjects
        self.capturedAt = now
    }
    enum StoreError: Error { case accountNotVerified }
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.removeItem(at: directory)
        }
    }
}
