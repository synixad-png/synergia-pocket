import Foundation

/// Stable, UI-safe transport advice. A 403 (no permission) or a 429 (rate
/// limit) must never be misreported as a password/session failure.
/// No action here submits credentials or automatically retries a POST.
enum DirectConnectionIssue: Equatable {
    case loginRequired
    case forbidden
    case rateLimited
    case maintenance
    case offline
    case timedOut
    case interrupted
    case invalidResponse
    case serviceError(Int)
    case unknown

    static func http(_ status: Int) -> DirectConnectionIssue {
        switch status {
        case 401: return .loginRequired
        case 403: return .forbidden
        case 408: return .timedOut
        case 429: return .rateLimited
        case 503: return .maintenance
        case 500...599: return .serviceError(status)
        default: return .serviceError(status)
        }
    }

    /// Check a no-redirect HTTP answer without ever opening the Location URL.
    /// Only recognized official sign-in destinations and public login landings
    /// mean loginRequired; arbitrary redirects are invalid responses.
    static func redirect(status: Int, location: String?, from origin: URL) -> DirectConnectionIssue {
        guard [301, 302, 303, 307, 308].contains(status),
              let location, !location.isEmpty,
              let target = URL(string: location, relativeTo: origin)?.absoluteURL,
              target.scheme?.lowercased() == "https",
              let host = target.host?.lowercased(),
              ["synergia.librus.pl", "portal.librus.pl", "api.librus.pl"].contains(host),
              target.user == nil, target.password == nil else { return .invalidResponse }
        let path = target.path.lowercased()
        if path.contains("/loguj") || path.contains("/login") || path.contains("/oauth/authorization") {
            return .loginRequired
        }
        // The official direct-login URL can redirect to Librus Rodzina's
        // public landing instead of a login form. An API /Me redirect to this
        // exact public landing cannot establish the user's school session.
        if host == "portal.librus.pl" && ["/", "/rodzina", "/rodzina/"].contains(path) {
            return .loginRequired
        }
        return .invalidResponse
    }

    static func network(_ error: Error) -> DirectConnectionIssue {
        let e = error as NSError
        guard e.domain == NSURLErrorDomain else { return .unknown }
        switch e.code {
        case URLError.notConnectedToInternet.rawValue: return .offline
        case URLError.timedOut.rawValue: return .timedOut
        case URLError.networkConnectionLost.rawValue, URLError.cancelled.rawValue:
            return .interrupted
        default: return .unknown
        }
    }

    var isAuthenticationProblem: Bool { self == .loginRequired }
    var canRetryReadManually: Bool {
        switch self {
        case .offline, .timedOut, .interrupted, .rateLimited, .maintenance, .serviceError:
            return true
        default: return false
        }
    }

    var message: String {
        switch self {
        case .loginRequired:
            return "Sesja wygasła lub nie została uruchomiona. Zaloguj się na oficjalnej stronie Synergii i potwierdź konto."
        case .forbidden:
            return "Serwer odmówił dostępu (403). Moduł może być wyłączony w szkole; ponowne logowanie nie musi pomóc."
        case .rateLimited:
            return "Serwer ograniczył liczbę żądań (429). Spróbuj ponownie później; nie ponawiam automatycznie."
        case .maintenance:
            return "Serwer Synergii jest chwilowo niedostępny (503). Dane nie zostały nadpisane."
        case .offline:
            return "Brak połączenia z internetem. Po odzyskaniu sieci ponów odczyt ręcznie."
        case .timedOut:
            return "Upłynął limit czasu odpowiedzi. Sprawdź połączenie i ponów odczyt ręcznie."
        case .interrupted:
            return "Połączenie zostało przerwane. Nie uznaję tego za wylogowanie."
        case .invalidResponse:
            return "Serwer zwrócił nieznaną strukturę danych. Nie nadpisano dotychczasowego odczytu."
        case .serviceError(let status):
            return "Serwer zwrócił HTTP \(status). Nie uznaję tego za wygaśnięcie sesji."
        case .unknown:
            return "Nie można potwierdzić połączenia. Dane pozostają zablokowane do ponownej weryfikacji."
        }
    }
}
