import Foundation

/// Pure comparison policy. A missing record is never a confirmed deletion.
/// Caller must establish an identical, live account before comparing snapshots.
struct CoreSyncChanges: Equatable {
    let newGrades: Int
    let editedGrades: Int
    let newAttendance: Int
    let editedAttendance: Int
    let newMessages: Int
    let disappearedGrades: Int
    let disappearedAttendance: Int
    let disappearedMessages: Int

    var hasNews: Bool {
        newGrades > 0 || editedGrades > 0 || newAttendance > 0 || editedAttendance > 0 || newMessages > 0
    }
}

enum CoreSyncComparisonError: Error, Equatable {
    case duplicateID(String)
    case differentAccount
    case incompleteMessages
}

enum DirectCoreSyncAudit {
    private static func index<T: Identifiable & Equatable>(_ records: [T]) throws -> [String: T] where T.ID == String {
        var indexed: [String: T] = [:]
        for record in records {
            guard indexed[record.id] == nil else { throw CoreSyncComparisonError.duplicateID(record.id) }
            indexed[record.id] = record
        }
        return indexed
    }

    static func compareGrades(previous: [DirectGrade], current: [DirectGrade]) throws -> (added: Int, edited: Int, missing: Int) {
        let old = try index(previous), now = try index(current)
        let common = Set(old.keys).intersection(now.keys)
        return (Set(now.keys).subtracting(old.keys).count,
                common.filter { old[$0] != now[$0] }.count,
                Set(old.keys).subtracting(now.keys).count)
    }

    static func compareSupplemental(previous: [SupplementalGrade], current: [SupplementalGrade]) throws -> (added: Int, edited: Int, missing: Int) {
        let old = try index(previous), now = try index(current)
        let common = Set(old.keys).intersection(now.keys)
        return (Set(now.keys).subtracting(old.keys).count,
                common.filter { old[$0] != now[$0] }.count,
                Set(old.keys).subtracting(now.keys).count)
    }

    static func compareAttendance(previous: [DirectAttendance], current: [DirectAttendance]) throws -> (added: Int, edited: Int, missing: Int) {
        let old = try index(previous), now = try index(current)
        let common = Set(old.keys).intersection(now.keys)
        return (Set(now.keys).subtracting(old.keys).count,
                common.filter { old[$0] != now[$0] }.count,
                Set(old.keys).subtracting(now.keys).count)
    }

    /// No inbox delta without two complete reads from the same account.
    static func compareInbox(previous: DirectMailboxSnapshot, current: DirectMailboxSnapshot) throws -> (added: Int, missing: Int) {
        guard previous.accountId == current.accountId else { throw CoreSyncComparisonError.differentAccount }
        guard previous.complete && current.complete else { throw CoreSyncComparisonError.incompleteMessages }
        let old = try index(previous.messages), now = try index(current.messages)
        return (Set(now.keys).subtracting(old.keys).count,
                Set(old.keys).subtracting(now.keys).count)
    }
}

/// Notifications are generic, opt-in, foreground-initiated, and never fired
/// for a first snapshot, incomplete read, changed account or missing record.
struct CoreLocalNotificationPlan: Equatable {
    let grades: Bool
    let attendance: Bool
    let messages: Bool
    static let none = CoreLocalNotificationPlan(grades: false, attendance: false, messages: false)

    static func make(consent: Bool, accountMatched: Bool,
                     hadGradesBaseline: Bool, hadAttendanceBaseline: Bool, hadInboxBaseline: Bool,
                     gradesReliable: Bool, attendanceReliable: Bool, inboxReliable: Bool,
                     changes: CoreSyncChanges) -> CoreLocalNotificationPlan {
        guard consent && accountMatched else { return .none }
        return CoreLocalNotificationPlan(
            grades: hadGradesBaseline && gradesReliable && (changes.newGrades > 0 || changes.editedGrades > 0),
            attendance: hadAttendanceBaseline && attendanceReliable && (changes.newAttendance > 0 || changes.editedAttendance > 0),
            messages: hadInboxBaseline && inboxReliable && changes.newMessages > 0)
    }
}
