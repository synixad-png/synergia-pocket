import Foundation

/// Read-only presentation of account-scoped JSON snapshots on the Start screen.
/// A local read does not mean complete, current, or verified against live Synergia now.
enum DirectDashboardTileKind: Equatable {
    case locked
    case notRecorded
    case recorded
}

struct DirectDashboardTileState: Equatable {
    let kind: DirectDashboardTileKind
    let capturedAt: Date?
    let localCount: Int?

    static func evaluate(accountVerified: Bool, sameAccount: Bool,
                         capturedAt: Date?, localCount: Int?) -> DirectDashboardTileState {
        guard accountVerified && sameAccount else {
            return .init(kind: .locked, capturedAt: nil, localCount: nil)
        }
        guard let capturedAt else {
            // A count without a corresponding timestamp is not a saved snapshot.
            return .init(kind: .notRecorded, capturedAt: nil, localCount: nil)
        }
        return .init(kind: .recorded, capturedAt: capturedAt,
                     localCount: localCount.flatMap { $0 >= 0 ? $0 : nil })
    }

    var title: String {
        switch kind {
        case .locked: return "Dane zablokowane"
        case .notRecorded: return "Brak zapisu JSON"
        case .recorded: return "Odczyt w aplikacji"
        }
    }

    var accessibilityText: String {
        switch kind {
        case .locked: return "Dane zablokowane. Zweryfikuj konto."
        case .notRecorded: return "Brak lokalnego odczytu JSON."
        case .recorded:
            let when = capturedAt.map { "Odczyt z \($0.formatted(date: .abbreviated, time: .shortened)). " } ?? ""
            guard let localCount else { return when + "Dostępny odczyt w aplikacji. Aktualność niepotwierdzona." }
            return when + "W odczycie: \(localCount) wpisów. Aktualność i kompletność niepotwierdzone."
        }
    }
}

struct DirectDashboardSummary: Equatable {
    let verified: Bool
    let recordedModules: Int
    let totalModules: Int

    static func evaluate(verified: Bool, tiles: [DirectDashboardTileState]) -> DirectDashboardSummary {
        // Always hide counts if the login has not been verified or the privacy shield is active.
        guard verified else { return .init(verified: false, recordedModules: 0, totalModules: tiles.count) }
        return .init(verified: true,
                     recordedModules: tiles.filter { $0.kind == .recorded }.count,
                     totalModules: tiles.count)
    }

    var title: String {
        verified ? "Moduły z odczytem: \(recordedModules)/\(totalModules)" : "Dane szkolne są zablokowane"
    }

    var explanation: String {
        verified
        ? "To dane JSON odczytane wcześniej lub zapisane lokalnie; nie potwierdzają aktualności ani kompletności w Synergii."
        : "Najpierw zaloguj się w aplikacji i potwierdź aktywne konto."
    }
}
