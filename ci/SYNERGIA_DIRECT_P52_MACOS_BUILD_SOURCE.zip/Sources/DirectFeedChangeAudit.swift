import Foundation

/// Conservative comparison of gateway snapshots. An item absent from an
/// incomplete page is NOT reported as deleted.
struct DirectFeedDelta: Equatable {
    let added: Int
    let changed: Int
    let missingUnconfirmed: Int
    let removedConfirmed: Int
    let comparable: Bool
    let reason: String

    var summary: String {
        if !comparable { return "Nie można wiarygodnie porównać odczytów: \(reason)" }
        let comparableCounts = reason.hasPrefix("liczniki obu odpowiedzi są zgodne")
        if !comparableCounts {
            return "Odczyty bez potwierdzonej kompletności. Nie zgłaszamy nowych ani zmienionych wpisów; " +
                "orientacyjnie: nowe \(added), różna treść \(changed), niewidoczne \(missingUnconfirmed). " +
                "Brak wpisu nie jest dowodem usunięcia."
        }
        if missingUnconfirmed > 0 {
            return "Porównanie niejednoznaczne: \(missingUnconfirmed) wcześniejszych wpisów jest niewidocznych. " +
                "Możliwe nowe \(added), zmienione \(changed); wstrzymano zgłaszanie zmian i usunięć."
        }
        return "Dwa odczyty z potwierdzonym licznikiem: zaobserwowano nowe \(added), zmienione \(changed). " +
            "Nie jest to potwierdzenie oficjalnej zmiany w dzienniku; usunięć nie wywnioskowano."
    }
}

enum DirectFeedChangeAudit {
    static func compare(previous: DirectSchoolFeed, current: DirectSchoolFeed) -> DirectFeedDelta {
        guard previous.module == current.module, !previous.verifiedAccountId.isEmpty,
              previous.verifiedAccountId == current.verifiedAccountId else {
            return failure("różne konto lub moduł")
        }
        func keyed(_ feed: DirectSchoolFeed) -> [String: DirectSchoolFeedEntry]? {
            var result: [String: DirectSchoolFeedEntry] = [:]
            for entry in feed.records {
                guard let serverId = entry.serverId, !serverId.isEmpty,
                      result.updateValue(entry, forKey: serverId) == nil else { return nil }
            }
            return result
        }
        guard let before = keyed(previous), let after = keyed(current) else {
            return failure("brak stabilnych lub unikalnych identyfikatorów serwera")
        }
        let additions = after.keys.filter { before[$0] == nil }.count
        let updates = after.reduce(into: 0) { count, pair in
            if let earlier = before[pair.key],
               (earlier.title != pair.value.title || earlier.details != pair.value.details ||
                earlier.homeworkFiles != pair.value.homeworkFiles || earlier.schoolFile != pair.value.schoolFile ||
                earlier.notice != pair.value.notice || earlier.agenda != pair.value.agenda ||
                earlier.homework != pair.value.homework || earlier.document != pair.value.document) {
                count += 1
            }
        }
        let missing = before.keys.filter { after[$0] == nil }.count
        // Even a complete snapshot can no longer contain a record because of
        // a permission/filter/server change. A deletion needs a separate,
        // authoritative event. We NEVER infer one from absence alone.
        let bothCountsKnown = previous.completenessKnown && current.completenessKnown
        return DirectFeedDelta(added: additions, changed: updates,
                               missingUnconfirmed: missing, removedConfirmed: 0,
                               comparable: true, reason: bothCountsKnown ?
                                   "liczniki obu odpowiedzi są zgodne, usunięcia nadal niepotwierdzone" :
                                   "brak potwierdzenia kompletności przynajmniej jednej listy")
    }

    private static func failure(_ reason: String) -> DirectFeedDelta {
        DirectFeedDelta(added: 0, changed: 0, missingUnconfirmed: 0,
                        removedConfirmed: 0, comparable: false, reason: reason)
    }
}
