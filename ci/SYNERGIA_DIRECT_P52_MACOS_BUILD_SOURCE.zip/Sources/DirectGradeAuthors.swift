import Foundation
import CoreFoundation

/// Explicit /Users lookup; never infer which teacher assigned a grade.
enum DirectGradeAuthorsError: Error, Equatable {
    case malformedRoot, duplicateUser(String), malformedUser(String), mismatchedUser(String)
}

enum DirectGradeAuthors {
    private static func identifier(_ value: Any?) -> String? {
        if let s = value as? String, !s.isEmpty { return s }
        if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
           n.doubleValue.isFinite, n.doubleValue.rounded() == n.doubleValue { return n.stringValue }
        return nil
    }
    static func decode(_ root: [String: Any]) throws -> [String: String] {
        guard let entries = root["Users"] as? [[String: Any]] else { throw DirectGradeAuthorsError.malformedRoot }
        var result: [String: String] = [:]
        for entry in entries {
            guard let id = identifier(entry["Id"]) else { throw DirectGradeAuthorsError.malformedUser("Id") }
            guard result[id] == nil else { throw DirectGradeAuthorsError.duplicateUser(id) }
            // FirstName / LastName may be null; an empty name is not guessed.
            let fields = ["FirstName", "LastName"]
            for key in fields {
                if let value = entry[key], !(value is NSNull), !(value is String) {
                    throw DirectGradeAuthorsError.malformedUser(id)
                }
            }
            let parts = fields.compactMap { (entry[$0] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
            result[id] = parts.joined(separator: " ")
        }
        return result
    }
    /// Only plain numeric IDs are safe for the verified gateway /Users/{id} route.
    static func requestableUserId(_ value: String) -> Bool {
        !value.isEmpty && value.count <= 12 && value.first != "0" &&
            value.utf8.allSatisfy { $0 >= 48 && $0 <= 57 }
    }

    static func decodeSingle(_ root: [String: Any], requestedId: String) throws -> String? {
        guard requestableUserId(requestedId), let entry = root["User"] as? [String: Any],
              let received = identifier(entry["Id"]), received == requestedId else {
            throw DirectGradeAuthorsError.mismatchedUser(requestedId)
        }
        // Use the same validated fields as the list decoder; no inference from
        // account login, subject, or the teacher listed in the timetable.
        let names = try decode(["Users": [entry]])
        return names[requestedId]?.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func missingIds(_ grades: [DirectGrade], users: [String:String]) -> [String] {
        Array(Set(grades.compactMap(\.teacherId)).filter {
            users[$0]?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty != false
        }).sorted()
    }

    static func reconcile(grades: [DirectGrade], current: [String: String],
                          previous: [String: String]) -> DirectGradeAuthorResolution {
        let ids = Set(grades.compactMap(\.teacherId))
        var accepted: [String: String] = [:]
        var fromPrevious = Set<String>()
        for id in ids {
            let fresh = current[id]?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let old = previous[id]?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if !fresh.isEmpty { accepted[id] = fresh }
            else if !old.isEmpty { accepted[id] = old; fromPrevious.insert(id) }
        }
        return DirectGradeAuthorResolution(names: accepted, staleIds: fromPrevious,
              unresolvedIds: ids.subtracting(accepted.keys).sorted())
    }
}

struct DirectGradeAuthorResolution {
    let names: [String: String]
    let staleIds: Set<String>
    let unresolvedIds: [String]
    var summary: String {
        "Autorzy wpisów: aktualnie ustaleni: \(names.count - staleIds.count), " +
        "z wcześniejszego odczytu: \(staleIds.count), nieustaleni: \(unresolvedIds.count). "
    }
}

