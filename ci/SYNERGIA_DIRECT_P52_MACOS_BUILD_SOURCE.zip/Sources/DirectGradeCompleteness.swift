import Foundation
import CoreFoundation

/// Conservative guard for a complete JSON grade snapshot. It never guesses
/// that a partial response is the complete school grade book.
/// The service-specific schema and pagination still require account validation.
enum DirectGradeCompletenessError: Error, Equatable {
    case invalidTotal
    case incomplete(expected: Int, received: Int)
    case continuationPresent
    case unexpectedEmptyReplacement
}

enum DirectGradeCompleteness {
    private static func integer(_ raw: Any) -> Int? {
        if let n = raw as? NSNumber {
            guard CFGetTypeID(n) != CFBooleanGetTypeID() else { return nil }
            let value = n.doubleValue
            guard value.isFinite, value >= 0, value.rounded() == value, value <= Double(Int.max) else { return nil }
            return n.intValue
        }
        if let s = raw as? String, let v = Int(s), v >= 0 { return v }
        return nil
    }

    /// Rejects known incomplete snapshots before they reach protected storage.
    /// An absent total is NOT proof of completeness, so the UI must still label
    /// this source as unverified. This code does not claim to implement paging.
    static func validate(root: [String: Any], decodedCount: Int, previousCount: Int) throws {
        for key in ["TotalCount", "Total"] {
            if let raw = root[key] {
                guard let expected = integer(raw) else { throw DirectGradeCompletenessError.invalidTotal }
                if expected != decodedCount {
                    throw DirectGradeCompletenessError.incomplete(expected: expected, received: decodedCount)
                }
            }
        }
        // If a continuation is explicitly advertised, the first page is not
        // a complete snapshot (even when it contains valid grade records).
        for key in ["Next", "NextPage", "NextPageUrl", "next"] {
            if let raw = root[key], !(raw is NSNull) {
                if let s = raw as? String, s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { continue }
                if let flag = raw as? Bool, flag == false { continue }
                throw DirectGradeCompletenessError.continuationPresent
            }
        }
        // Zero grades may be legitimate, but a missing explicit zero total
        // cannot establish that an empty result is complete, including on
        // the first synchronization of a new account.
        if decodedCount == 0 {
            guard root.keys.contains("TotalCount") || root.keys.contains("Total") else {
                throw DirectGradeCompletenessError.unexpectedEmptyReplacement
            }
        }
    }
}
