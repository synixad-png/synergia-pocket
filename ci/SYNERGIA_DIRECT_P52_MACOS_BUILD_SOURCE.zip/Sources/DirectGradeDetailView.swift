import SwiftUI

/// Full, selectable grade details. Always resolves current data from the store,
/// not a snapshot retained by NavigationLink while the user changes accounts.
struct DirectGradeDetailView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    let gradeID: String
    let expectedAccountID: String
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    // LabeledContent compresses long subjects and teacher names on narrow screens.
    // Accessibility text sizes get a stacked label and a full-width, selectable value.
    @ViewBuilder private func detailLine(_ title: String, _ value: String) -> some View {
        if dynamicTypeSize.isAccessibilitySize {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.footnote).foregroundStyle(.secondary)
                Text(verbatim: value).font(.body)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 4)
            .accessibilityElement(children: .combine)
        } else {
            LabeledContent(title, value: value)
        }
    }

    private var liveGrade: DirectGrade? {
        GradeDetailAccess.resolve(
            gradeID: gradeID, expectedAccountID: expectedAccountID,
            verifiedAccountID: portal.store.verifiedAccountId,
            cacheAccountID: portal.directGradeStore.verifiedAccountId,
            privacyShieldActive: portal.privacyShieldActive,
            grades: portal.directGradeStore.grades)
    }

    var body: some View {
        Group {
            if let grade = liveGrade {
                List {
                    Section("Ocena") {
                        detailLine("Wartość", grade.value)
                        detailLine("Przedmiot", portal.directGradeStore.subjects[grade.subjectId] ?? "ID \(grade.subjectId)")
                        detailLine("Semestr", grade.semester.map(String.init) ?? "Nieustalony")
                        detailLine("Data wystawienia", grade.addedAt ?? "Nieustalona")
                        if let name = grade.categoryName {
                            detailLine("Kategoria", name)
                        } else if let categoryID = grade.categoryId {
                            detailLine("Kategoria", "Nieustalona (ID \(categoryID))")
                        } else {
                            detailLine("Kategoria", "Nieustalona")
                        }
                        if let weight = grade.weight {
                            detailLine("Waga", weight.formatted())
                        } else {
                            detailLine("Waga", "Nieustalona")
                        }
                        detailLine("Wliczanie do średniej", grade.countsToAverage.map { $0 ? "Tak" : "Nie" } ?? "Nieustalone")
                        detailLine("Autor wpisu", GradeSubjectAuthorAudit.attribution(for: grade,
                                names: portal.directGradeStore.teachers,
                                earlierIds: portal.directGradeStore.olderTeacherIds).label)
                    }
                    Section("Komentarze (\(grade.commentTexts.count))") {
                        if grade.commentTexts.isEmpty {
                            Text("W aktualnie zapisanym odczycie nie ma komentarzy do tej oceny.")
                                .foregroundStyle(.secondary)
                        }
                        // Different comments may have equal text; their individual
                        // positions keep both entries visible without deduplication.
                        ForEach(Array(grade.commentTexts.enumerated()), id: \.offset) { entry in
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Komentarz \(entry.offset + 1)")
                                    .font(.caption).foregroundStyle(.secondary)
                                Text(verbatim: entry.element.isEmpty
                                     ? "(Komentarz nie zawiera tekstu)" : entry.element)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .textSelection(.enabled)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 6)
                        }
                    }
                    Section {
                        Text("Informacje pochodzą z ostatniego poprawnego odczytu JSON; nie gwarantują aktualności ani kompletności danych na serwerze.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            } else {
                ContentUnavailableView("Dane oceny zablokowane",
                                       systemImage: "lock.shield",
                                       description: Text("Po zmianie konta, wylogowaniu lub ukryciu danych otwórz oceny ponownie po weryfikacji konta."))
            }
        }
        .navigationTitle("Szczegóły oceny")
        .navigationBarTitleDisplayMode(.inline)
    }
}
