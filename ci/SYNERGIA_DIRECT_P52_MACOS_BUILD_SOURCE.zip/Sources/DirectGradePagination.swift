import Foundation
import CoreFoundation

/// Only documented-by-response continuation forms are followed. No inferred pagination.
/// Non-empty unknown continuation metadata blocks committing the snapshot.
enum GradePagingError: LocalizedError, Equatable {
    case invalidContinuation
    case unsupportedContinuation
    case repeatedPage
    case tooManyPages
    case inconsistentTotal
    case duplicateGradeID
    case missingGrades
    case interruptedPageChain

    var errorDescription: String? {
        switch self {
        case .invalidContinuation, .unsupportedContinuation:
            return "Serwer przesłał nieobsługiwany adres kolejnej strony ocen. Zachowano poprzednie dane."
        case .repeatedPage:
            return "Odczyt ocen przerwano: serwer wskazał ponownie tę samą stronę."
        case .tooManyPages:
            return "Odczyt ocen przerwano po osiągnięciu bezpiecznego limitu stron."
        case .inconsistentTotal:
            return "Liczba ocen zgłoszona przez serwer nie zgadza się z odczytem wszystkich stron."
        case .duplicateGradeID:
            return "Serwer zwrócił powtórzony lub nieprawidłowy identyfikator oceny."
        case .missingGrades:
            return "W odpowiedzi brakuje wymaganej listy ocen."
        case .interruptedPageChain:
            return "Nie odczytano pełnego łańcucha stron ocen. Nie zapisano częściowego wyniku."
        }
    }
}

enum DirectGradePagination {
    static let maximumPages = 20
    private static let nextKeys = ["Next", "NextPage", "NextPageUrl", "next"]

    private static func total(_ root: [String: Any]) throws -> Int? {
        var result: Int?
        for key in ["TotalCount", "Total"] {
            guard let raw = root[key] else { continue }
            let number: Int?
            if let n = raw as? NSNumber {
                guard CFGetTypeID(n) != CFBooleanGetTypeID() else { throw DirectGradeCompletenessError.invalidTotal }
                let v = n.doubleValue
                number = v.isFinite && v >= 0 && v.rounded() == v && v <= Double(Int.max) ? n.intValue : nil
            } else if let text = raw as? String { number = Int(text) }
            else { number = nil }
            guard let n = number, n >= 0 else { throw DirectGradeCompletenessError.invalidTotal }
            if let old = result, old != n { throw GradePagingError.inconsistentTotal }
            result = n
        }
        return result
    }

    static func continuation(_ root: [String: Any], current: URL, base: URL) throws -> URL? {
        let entries = nextKeys.compactMap { key -> Any? in root[key] }
        let meaningful = entries.filter { value in
            if value is NSNull { return false }
            if let s = value as? String { return !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            if let n = value as? NSNumber, CFGetTypeID(n) == CFBooleanGetTypeID() { return n.boolValue }
            return true
        }
        if meaningful.isEmpty { return nil }
        guard meaningful.count == 1, let next = meaningful[0] as? String,
              let url = URL(string: next, relativeTo: current)?.absoluteURL,
              url.scheme == "https", url.host?.lowercased() == "synergia.librus.pl",
              url.user == nil, url.password == nil, url.port == nil, url.fragment == nil,
              url.path == base.path,
              GatewayJSONPolicy.safeContinuationQuery(url) else {
            throw GradePagingError.unsupportedContinuation
        }
        // Guard as close as possible to the server-provided link: do not
        // issue a second HTTP request to the very same page.
        guard url.absoluteString != current.absoluteString else {
            throw GradePagingError.repeatedPage
        }
        return url
    }

    /// Validate every page before creating the only snapshot that can be persisted.
    static func merge(_ pages: [[String: Any]], previousCount: Int) throws -> [String: Any] {
        guard !pages.isEmpty, pages.count <= maximumPages else { throw GradePagingError.tooManyPages }
        var merged: [[String: Any]] = []
        var ids = Set<String>()
        var expectedTotal: Int?
        let base = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Grades")!
        var current = base
        var visited = Set<String>([base.absoluteString])
        for (index, page) in pages.enumerated() {
            // A caller must not commit a prefix of a paginated response.
            // Every intermediate page needs an explicit same-resource continuation;
            // the final page must not advertise another page.
            let next = try continuation(page, current: current, base: base)
            if index < pages.count - 1 {
                guard let next else { throw GradePagingError.interruptedPageChain }
                guard visited.insert(next.absoluteString).inserted else { throw GradePagingError.repeatedPage }
                current = next
            } else if next != nil {
                throw GradePagingError.interruptedPageChain
            }
            guard let rows = page["Grades"] as? [[String: Any]] else { throw GradePagingError.missingGrades }
            if let reported = try total(page) {
                if let old = expectedTotal, old != reported { throw GradePagingError.inconsistentTotal }
                expectedTotal = reported
            }
            for row in rows {
                guard let rawID = row["Id"], !(rawID is NSNull) else { throw GradePagingError.duplicateGradeID }
                let id: String
                if let value = rawID as? String, !value.isEmpty { id = value }
                else if let number = rawID as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
                        number.doubleValue.isFinite, number.doubleValue.rounded() == number.doubleValue {
                    id = number.stringValue
                } else { throw GradePagingError.duplicateGradeID }
                guard ids.insert(id).inserted else { throw GradePagingError.duplicateGradeID }
                merged.append(row)
            }
        }
        if let total = expectedTotal, total != merged.count { throw GradePagingError.inconsistentTotal }
        // An empty response without an explicit server total is ambiguous even
        // for the very first synchronization. It may mean an empty account,
        // an incomplete endpoint response or data not yet loaded.
        // Fail closed rather than persist an unverified empty grade book.
        if merged.isEmpty && expectedTotal != 0 {
            throw DirectGradeCompletenessError.unexpectedEmptyReplacement
        }
        var result: [String: Any] = ["Grades": merged]
        if let expectedTotal { result["TotalCount"] = expectedTotal }
        return result
    }
}
