import Foundation
import CryptoKit

/// Account-scoped local JSON storage. No previous account data is displayed
/// without a fresh, matching /Me response. Legacy v0.25 cache remains unread.
@MainActor
final class DirectGradeStore: ObservableObject {
    @Published private(set) var grades: [DirectGrade] = []
    @Published private(set) var supplemental: [SupplementalGrade] = []
    @Published private(set) var subjects: [String: String] = [:]
    @Published private(set) var teachers: [String: String] = [:]
    @Published private(set) var olderTeacherIds: Set<String> = []
    @Published private(set) var capturedAt: Date?
    private(set) var verifiedAccountId: String?
    private let directory: URL
    private let legacyFile: URL

    private struct Saved: Codable {
        let accountId: String
        let grades: [DirectGrade]
        let subjects: [String: String]
        let teachers: [String: String]?
        let olderTeacherIds: [String]?
        let supplemental: [SupplementalGrade]?
        let capturedAt: Date
    }

    init(directory: URL? = nil) {
        let root = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("school-data", isDirectory: true)
        self.directory = root.appendingPathComponent("direct-accounts", isDirectory: true)
        self.legacyFile = root.appendingPathComponent("direct-grades.json")
        try? FileManager.default.createDirectory(at: self.directory, withIntermediateDirectories: true)
        // Fail closed: never load data at startup and never read the legacy shared file.
    }

    /// Hashing prevents account IDs from appearing in filenames or becoming paths.
    private func file(for accountId: String) -> URL {
        let digest = SHA256.hash(data: Data(accountId.utf8))
            .map { String(format: "%02x", $0) }.joined()
        return directory.appendingPathComponent(digest + ".json", isDirectory: false)
    }

    func lock() {
        verifiedAccountId = nil
        grades = []; supplemental = []; subjects = [:]; teachers = [:]; olderTeacherIds = []; capturedAt = nil
    }

    /// A fresh matching live /Me response must precede each unlock.
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        guard let bytes = try? Data(contentsOf: file(for: accountId)),
              let saved = try? JSONDecoder().decode(Saved.self, from: bytes),
              saved.accountId == accountId else { return }
        grades = saved.grades
        supplemental = saved.supplemental ?? []
        subjects = saved.subjects
        teachers = saved.teachers ?? [:]
        olderTeacherIds = Set(saved.olderTeacherIds ?? [])
        capturedAt = saved.capturedAt
    }

    func replace(grades: [DirectGrade], subjects: [String: String], accountId: String, supplemental: [SupplementalGrade] = [], teachers: [String: String] = [:],
                 olderTeacherIds: Set<String> = []) throws {
        guard !accountId.isEmpty, verifiedAccountId == accountId else {
            throw StoreError.accountNotVerified
        }
        let now = Date()
        let saved = Saved(accountId: accountId, grades: grades, subjects: subjects,
            teachers: teachers, olderTeacherIds: Array(olderTeacherIds).sorted(),
            supplemental: supplemental, capturedAt: now)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let bytes = try JSONEncoder().encode(saved)
        try bytes.write(to: file(for: accountId), options: [.atomic, .completeFileProtection])
        self.grades = grades
        self.supplemental = supplemental
        self.subjects = subjects
        self.teachers = teachers
        self.olderTeacherIds = olderTeacherIds
        self.capturedAt = now
    }

    enum StoreError: Error { case accountNotVerified }

    /// Removes all account-specific JSON caches and any unread legacy file.
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.removeItem(at: directory)
        }
        if FileManager.default.fileExists(atPath: legacyFile.path) {
            try FileManager.default.removeItem(at: legacyFile)
        }
    }
}
