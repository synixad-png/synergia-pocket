import Foundation

/// Optional, read-only fields from HomeWorkAssignments. Missing values stay unknown.
/// In particular the API response is not evidence that a student submitted or
/// completed an assignment. Never infer subject from teacher or calendar events.
struct DirectHomeworkAssignment: Codable, Equatable {
    let dueDay: String?
    let publishedDay: String?
    let body: String?
    let categoryName: String?
    let subjectName: String?

    static func parse(_ record: [String: Any]) -> DirectHomeworkAssignment {
        let category = record["Category"] as? [String: Any]
        let subject = record["Subject"] as? [String: Any]
        // Date / StartDate is NOT assumed to be the deadline. Only fields
        // explicitly indicating a due date may be labelled "Termin".
        let due = DirectSchoolAgendaEvent.validDay(record["DueDate"])
            ?? DirectSchoolAgendaEvent.validDay(record["Deadline"])
        let published = DirectSchoolAgendaEvent.validDay(record["addedOnDate"])
            ?? DirectSchoolAgendaEvent.validDay(record["CreationDate"])
        let rawBody = DirectSchoolAgendaEvent.text(record["Text"])
            ?? DirectSchoolAgendaEvent.text(record["Description"])
        return DirectHomeworkAssignment(
            dueDay: due, publishedDay: published,
            body: rawBody.flatMap { DirectSchoolNotice.plainText($0) },
            categoryName: DirectSchoolAgendaEvent.text(category?["Name"]),
            subjectName: DirectSchoolAgendaEvent.text(subject?["Name"])
        )
    }
}

enum DirectHomeworkPresentation {
    enum Period: Int, CaseIterable {
        case all = 0, upcoming = 1, overdue = 2, undated = 3
    }

    static func entries(_ feed: DirectSchoolFeed, query: String = "",
                        period: Period = .all, today: String) -> [DirectSchoolFeedEntry] {
        guard feed.module == .homework else { return [] }
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let trustedToday = DirectSchoolAgendaEvent.validDay(today)
        return feed.records.filter { entry in
            let due = entry.homework?.dueDay
            let matchingPeriod: Bool
            switch period {
            case .all: matchingPeriod = true
            case .upcoming:
                if let due, let trustedToday { matchingPeriod = due >= trustedToday }
                else { matchingPeriod = false }
            case .overdue:
                if let due, let trustedToday { matchingPeriod = due < trustedToday }
                else { matchingPeriod = false }
            case .undated: matchingPeriod = due == nil
            }
            return matchingPeriod && (term.isEmpty ||
                entry.title.localizedCaseInsensitiveContains(term) ||
                (entry.homework?.body?.localizedCaseInsensitiveContains(term) ?? false) ||
                (entry.homework?.categoryName?.localizedCaseInsensitiveContains(term) ?? false) ||
                (entry.homework?.subjectName?.localizedCaseInsensitiveContains(term) ?? false) ||
                (entry.homeworkFiles?.contains { $0.name.localizedCaseInsensitiveContains(term) } ?? false))
        }.sorted {
            switch ($0.homework?.dueDay, $1.homework?.dueDay) {
            case let (left?, right?) where left != right: return left < right
            case (.some, .none): return true
            case (.none, .some): return false
            default:
                let compare = $0.title.localizedStandardCompare($1.title)
                if compare != .orderedSame { return compare == .orderedAscending }
                return ($0.serverId ?? $0.id) < ($1.serverId ?? $1.id)
            }
        }
    }

    static func groups(_ entries: [DirectSchoolFeedEntry]) -> [(day: String, entries: [DirectSchoolFeedEntry])] {
        var groups: [(day: String, entries: [DirectSchoolFeedEntry])] = []
        for entry in entries {
            let day = entry.homework?.dueDay ?? "Brak potwierdzonego terminu"
            if let last = groups.indices.last, groups[last].day == day { groups[last].entries.append(entry) }
            else { groups.append((day, [entry])) }
        }
        return groups
    }
}
