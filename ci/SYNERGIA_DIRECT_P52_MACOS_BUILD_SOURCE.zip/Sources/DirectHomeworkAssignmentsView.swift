import SwiftUI

/// Direct, read-only assignments. A local date filter is NOT a completion
/// indicator, and downloading a file is NOT sending homework to the teacher.
struct DirectHomeworkAssignmentsView: View {
    let feed: DirectSchoolFeed
    let fileURLs: [String: URL]
    let downloadBusy: Bool
    let downloadStatus: String
    let onDownload: (DirectHomeworkFileReference, DirectSchoolFeedEntry) -> Void

    @State private var query = ""
    @State private var selection = DirectHomeworkPresentation.Period.all.rawValue

    private var today: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Warsaw")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    private var visible: [DirectSchoolFeedEntry] {
        DirectHomeworkPresentation.entries(feed, query: query,
            period: DirectHomeworkPresentation.Period(rawValue: selection) ?? .all, today: today)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Szukaj zadań i plików", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Picker("Terminy zadań", selection: $selection) {
                Text("Wszystkie").tag(0)
                Text("Na dziś i później").tag(1)
                Text("Po terminie").tag(2)
                Text("Bez terminu").tag(3)
            }.pickerStyle(.menu)
            Text("Wyświetlono \(visible.count) z \(feed.records.count) pobranych wpisów; kompletność listy nie jest potwierdzona.")
                .font(.caption).foregroundStyle(.secondary)
            if visible.isEmpty {
                Text("Brak zadań spełniających wybrane kryteria.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(Array(DirectHomeworkPresentation.groups(visible).enumerated()), id: \.offset) { _, group in
                VStack(alignment: .leading, spacing: 8) {
                    Text(group.day == "Brak potwierdzonego terminu" ? group.day : "Termin: \(group.day)")
                        .font(.headline)
                    ForEach(group.entries) { item in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(item.title).font(.subheadline.bold()).textSelection(.enabled)
                            if let homework = item.homework {
                                if let day = homework.publishedDay {
                                    Text("Opublikowano: \(day)").font(.caption).foregroundStyle(.secondary)
                                }
                                if let category = homework.categoryName {
                                    Label(category, systemImage: "tag").font(.caption)
                                }
                                if let subject = homework.subjectName {
                                    Text("Przedmiot: \(subject)").font(.caption)
                                } else {
                                    Text("Przedmiot: niepotwierdzony w odpowiedzi JSON")
                                        .font(.footnote).foregroundStyle(.secondary)
                                }
                                if let text = homework.body, text != item.title {
                                    Text(text).font(.subheadline).textSelection(.enabled)
                                }
                            } else {
                                Text("Starszy zapis bez szczegółów. Odśwież dane po zalogowaniu.")
                                    .font(.caption).foregroundStyle(.secondary)
                                ForEach(Array(item.details.enumerated()), id: \.offset) { detail in
                                    if let safe = DirectSchoolNotice.plainText(detail.element) {
                                        Text(safe).font(.caption).textSelection(.enabled)
                                    }
                                }
                            }
                            if let files = item.homeworkFiles {
                                if files.isEmpty {
                                    Text("Serwer zwrócił pustą listę załączników do tego zadania.")
                                        .font(.footnote).foregroundStyle(.secondary)
                                }
                                ForEach(files) { file in
                                    if let url = fileURLs[file.key] {
                                        ShareLink(item: url) {
                                            Label("Udostępnij / Zapisz: \(file.name)", systemImage: "square.and.arrow.up")
                                        }
                                    } else {
                                        Button {
                                            onDownload(file, item)
                                        } label: {
                                            Label("Pobierz: \(file.name)", systemImage: "arrow.down.doc")
                                        }.disabled(downloadBusy)
                                    }
                                }
                            } else {
                                Text("Lista załączników nie została potwierdzona przez serwer.")
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                            Divider()
                        }.padding(.vertical, 3)
                    }
                }
            }
            if downloadBusy { ProgressView("Pobieranie załącznika…") }
            if !downloadStatus.isEmpty {
                Text(downloadStatus).font(.caption).foregroundStyle(.secondary)
            }
            Text("Filtr „Po terminie” oznacza jedynie datę — nie potwierdza, że zadanie jest nieodrobione. " +
                 "Aplikacja nie zgaduje statusu przesłania rozwiązania. Dane offline mogą być nieaktualne.")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .onChange(of: feed.verifiedAccountId) { _, _ in query = ""; selection = 0 }
    }
}
