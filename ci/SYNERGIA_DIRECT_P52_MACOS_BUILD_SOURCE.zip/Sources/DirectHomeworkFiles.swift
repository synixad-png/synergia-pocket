import Foundation
import CoreFoundation

/// Confirmed references from HomeWorkAssignments.HomeworkAssigmentFiles.
/// A user-provided URL or a displayed filename is never a download authority.
struct DirectHomeworkFileReference: Identifiable, Equatable, Codable {
    let assignmentId: String
    let id: String
    let name: String
    var key: String { "\(assignmentId):\(id)" }
}

enum DirectHomeworkFileError: Error, LocalizedError, Equatable {
    case malformedReference, untrustedRedirect, invalidResponse, fileTooLarge, emptyFile, accountChanged, notReady
    var errorDescription: String? {
        switch self {
        case .malformedReference: return "Synergia nie udostępniła prawidłowych danych tego załącznika."
        case .untrustedRedirect: return "Zablokowano przekierowanie poza zatwierdzoną domenę plików Librusa."
        case .invalidResponse: return "Serwer nie zwrócił prawidłowego pliku."
        case .fileTooLarge: return "Załącznik przekracza limit 15 MB."
        case .emptyFile: return "Serwer zwrócił pusty plik."
        case .accountChanged: return "Zmieniono lub utracono sesję konta."
        case .notReady: return "Serwer nie przygotował pliku w dozwolonym czasie."
        }
    }
}

enum DirectHomeworkFilePolicy {
    static let maxBytes = 15_000_000
    static let attachmentPath = "/gateway/api/2.0/HomeWorkAssignments/Attachment/"
    static let downloadPath = "/homework/downloadFile/"

    static func numericId(_ value: Any?) -> String? {
        if let string = value as? String, !string.isEmpty, string.count <= 18,
           string.utf8.allSatisfy({ (48...57).contains($0) }), string != "0" { return string }
        if let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
           number.int64Value > 0, number.doubleValue == Double(number.int64Value) {
            return number.stringValue
        }
        return nil
    }

    static func parse(_ row: [String: Any]) throws -> [DirectHomeworkFileReference]? {
        guard let raw = row["HomeworkAssigmentFiles"] else { return nil }
        guard let list = raw as? [[String: Any]], list.count <= 30,
              let homework = numericId(row["Id"]) else { throw DirectHomeworkFileError.malformedReference }
        var result: [DirectHomeworkFileReference] = []
        var seen: Set<String> = []
        for file in list {
            guard let id = numericId(file["Id"]),
                  let name = file["Name"] as? String, !name.isEmpty, name.count <= 240,
                  name == name.trimmingCharacters(in: .whitespacesAndNewlines),
                  !name.hasPrefix("."), !name.contains("/"), !name.contains("\\"),
                  !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
                  let link = file["Url"] as? String,
                  let u = URL(string: link),
                  u.scheme == "https", u.host?.lowercased() == "synergia.librus.pl",
                  u.port == nil, u.query == nil, u.fragment == nil, u.user == nil, u.password == nil,
                  u.path == attachmentPath + homework + "-" + id,
                  seen.insert(id).inserted else { throw DirectHomeworkFileError.malformedReference }
            result.append(DirectHomeworkFileReference(assignmentId: homework, id: id, name: name))
        }
        return result
    }

    static func downloadURL(_ file: DirectHomeworkFileReference) throws -> URL {
        guard numericId(file.id) == file.id, numericId(file.assignmentId) == file.assignmentId,
              !file.name.isEmpty else { throw DirectHomeworkFileError.malformedReference }
        return URL(string: "https://synergia.librus.pl" + downloadPath + file.id)!
    }

    enum Ticket: Equatable {
        case getFile(URL)
        case singleUseKey(page: URL, key: String)
    }

    static func ticket(_ location: String) throws -> Ticket {
        guard let u = URL(string: location), u.scheme == "https",
              u.host?.lowercased() == "sandbox.librus.pl", u.port == nil,
              u.user == nil, u.password == nil, u.fragment == nil,
              u.absoluteString.utf8.count <= 4096 else { throw DirectHomeworkFileError.untrustedRedirect }
        if u.path.hasPrefix("/GetFile/"), u.query == nil,
           u.path.count > 9, !u.path.contains(".."), !u.path.contains("%"), !u.path.hasSuffix("/get") {
            return .getFile(u)
        }
        guard u.path == "/index.php",
              let components = URLComponents(url: u, resolvingAgainstBaseURL: false),
              let params = components.queryItems, params.count == 2,
              params.first(where: { $0.name == "action" })?.value == "CSTryToDownload",
              let key = params.first(where: { $0.name == "singleUseKey" })?.value,
              !key.isEmpty, key.count <= 256,
              key.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95 }),
              Set(params.map(\.name)).count == 2 else { throw DirectHomeworkFileError.untrustedRedirect }
        return .singleUseKey(page: u, key: key)
    }

    static func keyURL(action: String, key: String? = nil) throws -> URL {
        guard action == "CSCheckKey" || action == "CSDownload" else { throw DirectHomeworkFileError.untrustedRedirect }
        var components = URLComponents(string: "https://sandbox.librus.pl/index.php")!
        components.queryItems = [URLQueryItem(name: "action", value: action)]
        if action == "CSDownload" {
            guard let key, isSafeKey(key) else { throw DirectHomeworkFileError.untrustedRedirect }
            components.queryItems?.append(URLQueryItem(name: "singleUseKey", value: key))
        }
        return components.url!
    }

    private static func isSafeKey(_ key: String) -> Bool {
        !key.isEmpty && key.count <= 256 && key.utf8.allSatisfy {
            (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95
        }
    }

    static func fileResponseOK(status: Int, type: String?, size: Int64) -> Bool {
        guard status == 200, size <= Int64(maxBytes) else { return false }
        if let t = type?.lowercased(), t.contains("text/html") || t.contains("application/xhtml") ||
           t.contains("text/xml") || t.contains("application/json") { return false }
        return true
    }
}
