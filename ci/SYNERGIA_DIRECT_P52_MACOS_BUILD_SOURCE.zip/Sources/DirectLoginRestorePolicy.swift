import Foundation

/// A one-shot coordinator for reuse of the official persistent WebKit session.
/// No passwords, tokens, cookies or speculative login state are stored here.
/// An authenticated identity is only established by the separate live /Me call.
struct DirectLoginRestorePolicy {
    private(set) var startupCheckClaimed = false
    private(set) var awaitingOfficialReturn = false

    /// The app may check /Me exactly once at first display, even when the
    /// embedded browser has not yet performed a navigation in this process.
    mutating func claimStartupVerification() -> Bool {
        guard !startupCheckClaimed else { return false }
        startupCheckClaimed = true
        return true
    }

    mutating func officialLoginOpened() {
        awaitingOfficialReturn = true
    }

    /// A completed navigation on the official authenticated Synergia origin
    /// triggers one attempt to verify /Me. It does NOT indicate login success.
    mutating func claimVerificationAfterReturn(to url: URL?) -> Bool {
        guard awaitingOfficialReturn, Self.isTrustedLanding(url) else { return false }
        awaitingOfficialReturn = false
        return true
    }

    /// Used after a manual verification or deliberate removal of local state.
    mutating func cancelPendingReturn() {
        awaitingOfficialReturn = false
    }

    static func isTrustedLanding(_ url: URL?) -> Bool {
        guard let url,
              url.scheme?.lowercased() == "https",
              url.host?.lowercased() == "synergia.librus.pl",
              url.user == nil, url.password == nil,
              url.port == nil else { return false }
        let path = url.path.lowercased()
        // A sign-in or logout form is not a signed-in destination.
        return !path.contains("/login") && !path.contains("/loguj") &&
               !path.contains("/logout") && !path.contains("/wyloguj") &&
               !path.contains("/oauth/")
    }
}
