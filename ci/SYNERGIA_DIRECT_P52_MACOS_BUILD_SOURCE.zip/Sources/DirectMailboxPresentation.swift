import Foundation

/// Tylko prezentacja już zweryfikowanego, pobranego odczytu. Nie wykonuje żądań
/// sieciowych i nie modyfikuje serwerowego statusu przeczytania wiadomości.
enum DirectMailboxViewFilter: String, CaseIterable, Identifiable {
    case all = "Wszystkie"
    case withAttachments = "Załączniki"
    case confirmedRead = "Z datą odczytu"
    case withoutReadDate = "Brak daty odczytu"

    var id: String { rawValue }
}

struct DirectMailboxPresentation {
    let messages: [DirectMessage]
    let fetchedCount: Int
    let serverTotal: Int?
    let complete: Bool
    let selectionDescription: String

    /// Brak daty readDate to tylko brak pola w zwróconych danych; nie dowodzi
    /// statusu „nieprzeczytane”. W Wysłanych readDate może dotyczyć odbiorcy.
    static func readDateDescription(_ message: DirectMessage) -> String {
        guard let raw = message.readAt?.trimmingCharacters(in: .whitespacesAndNewlines),
              !raw.isEmpty else { return "Brak potwierdzonej daty odczytu" }
        return "Data odczytu wg serwera: \(raw)"
    }

    static func present(snapshot: DirectMailboxSnapshot?, verifiedAccountId: String?,
                        privacyShielded: Bool, mailbox: DirectMailbox,
                        query: String, filter: DirectMailboxViewFilter) -> DirectMailboxPresentation? {
        guard !privacyShielded, let account = verifiedAccountId, !account.isEmpty,
              let snapshot, snapshot.accountId == account,
              snapshot.mailbox == mailbox,
              snapshot.messages.allSatisfy({ $0.mailbox == mailbox }) else { return nil }

        // Kolejność zachowana z serwera. Brak gwarantowanego formatu dat nie
        // upoważnia do wyliczania daty ani arbitralnego sortowania leksykalnego.
        let search = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let visible = snapshot.messages.filter { message in
            let matchesSearch = search.isEmpty ||
                message.subject.localizedStandardContains(search) ||
                message.correspondent.localizedStandardContains(search) ||
                message.preview.localizedStandardContains(search)
            guard matchesSearch else { return false }
            let hasReadDate = message.readAt?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
            switch filter {
            case .all: return true
            case .withAttachments: return message.hasAttachments
            case .confirmedRead: return hasReadDate
            case .withoutReadDate: return !hasReadDate
            }
        }
        return DirectMailboxPresentation(messages: visible, fetchedCount: snapshot.messages.count,
            serverTotal: snapshot.total, complete: snapshot.complete,
            selectionDescription: "Wyświetlono \(visible.count) z \(snapshot.messages.count) pobranych wpisów")
    }
}
