import Foundation

/// Foreground-only coordination of the three explicit dashboard refreshes.
/// This is an in-memory lock and receipt, not a scheduler or a network client.
enum DirectManualRefreshKind: String, CaseIterable {
    case coreJSON
    case additionalJSON
    case approvedPages

    var label: String {
        switch self {
        case .coreJSON: return "Oceny, frekwencja i wiadomości"
        case .additionalJSON: return "Zadania, terminarz, ogłoszenia i dokumenty"
        case .approvedPages: return "Zapisane strony"
        }
    }
}

struct DirectManualRefreshTicket: Equatable {
    let id: UUID
    let kind: DirectManualRefreshKind
    let accountId: String
    let startedAt: Date
}

enum DirectManualRefreshOutcome: Equatable {
    case completed  // The transport finished; individual modules may still have errors.
    case interrupted
}

struct DirectManualRefreshReceipt: Equatable {
    let kind: DirectManualRefreshKind
    let outcome: DirectManualRefreshOutcome
    let seconds: TimeInterval
    let endedAt: Date
}

struct DirectManualRefreshCoordinator {
    private(set) var active: DirectManualRefreshTicket?
    private(set) var cancellationRequested = false
    private(set) var last: DirectManualRefreshReceipt?

    mutating func begin(_ kind: DirectManualRefreshKind, accountId: String,
                        at date: Date = Date(), id: UUID = UUID()) -> DirectManualRefreshTicket? {
        guard active == nil, !accountId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let ticket = DirectManualRefreshTicket(id: id, kind: kind, accountId: accountId, startedAt: date)
        active = ticket
        cancellationRequested = false
        return ticket
    }

    /// Keep the gate locked until the async worker has returned: a cancelled
    /// WKWebView request may still be in flight after the UI has rejected its result.
    mutating func requestCancellation(of kind: DirectManualRefreshKind) -> Bool {
        guard active?.kind == kind, !cancellationRequested else { return false }
        cancellationRequested = true
        return true
    }

    func isCurrent(_ ticket: DirectManualRefreshTicket, accountId: String) -> Bool {
        active == ticket && !cancellationRequested && ticket.accountId == accountId
    }

    @discardableResult
    mutating func finish(_ ticket: DirectManualRefreshTicket,
                         at date: Date = Date()) -> DirectManualRefreshReceipt? {
        guard active == ticket else { return nil }
        let receipt = DirectManualRefreshReceipt(kind: ticket.kind,
            outcome: cancellationRequested ? .interrupted : .completed,
            seconds: max(0, date.timeIntervalSince(ticket.startedAt)), endedAt: date)
        last = receipt
        active = nil
        cancellationRequested = false
        return receipt
    }
}
