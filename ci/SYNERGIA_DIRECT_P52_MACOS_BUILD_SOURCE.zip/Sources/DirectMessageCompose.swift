import Foundation
import CoreFoundation

/// Lokalny model redagowania. Nie zapisuje treści na dysku i nie inicjuje wysyłki.
struct DirectRecipientGroup: Identifiable, Equatable {
    let id: String
    let name: String
}

struct DirectRecipient: Identifiable, Equatable {
    let id: String       // accountId z /receivers/groups/school-employees
    let name: String
    let groupId: String
    let available: Bool? // nil oznacza brak pewnej informacji, nie "dostępny"
}

struct DirectRecipientGroupsSnapshot {
    let accountId: String
    let messageSessionId: String
    let groups: [DirectRecipientGroup]
}

struct DirectRecipientListSnapshot {
    let accountId: String
    let messageSessionId: String
    let groupId: String
    let recipients: [DirectRecipient]
}

struct DirectReplyContext: Equatable {
    let originalMessageId: String
    let originalSenderId: String
    let subject: String
    let recipientName: String
    let accountId: String
    let messageSessionId: String
}

struct DirectValidatedDraft: Equatable {
    let recipientAccountId: String
    let messageSessionId: String
    let subject: String
    let text: String
    let originalMessageId: Int?
}

enum DirectComposeError: Error, Equatable, LocalizedError {
    case unexpectedShape, unsafeIdentifier, duplicateIdentifier, tooManyRecipients
    case missingRecipient, unavailableRecipient, emptySubject, emptyText, tooLong
    case replyNotAllowed, staleSession, invalidConfirmation

    var errorDescription: String? {
        switch self {
        case .unexpectedShape: return "Serwer zwrócił nieznany format listy odbiorców."
        case .unsafeIdentifier: return "Niepoprawny identyfikator odbiorcy lub grupy."
        case .duplicateIdentifier: return "Powtórzony identyfikator odbiorcy."
        case .tooManyRecipients: return "Zbyt długa lista odbiorców."
        case .missingRecipient: return "Najpierw wybierz odbiorcę z listy Synergii."
        case .unavailableRecipient: return "Odbiorca jest oznaczony jako niedostępny."
        case .emptySubject: return "Wprowadź temat wiadomości."
        case .emptyText: return "Wprowadź treść wiadomości."
        case .tooLong: return "Temat lub treść przekracza limit."
        case .replyNotAllowed: return "Nie można odpowiedzieć na tę wiadomość."
        case .staleSession: return "Odbiorcy pochodzą z innego lub niezweryfikowanego konta."
        case .invalidConfirmation: return "Wymagane jest nowe, świadome potwierdzenie wysyłki."
        }
    }
}

enum DirectMessageCompose {
    static let maxSubjectCharacters = 200
    static let maxTextCharacters = 10_000
    static let maxRecipientGroups = 80
    static let maxRecipientsPerGroup = 2_000
    static let skippedGroups: Set<String> = ["parentsCouncil", "schoolParentsCouncil", "customGroups", "sadmin"]

    private static func text(_ value: Any?, max: Int = 250) -> String? {
        guard let raw = value as? String else { return nil }
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return !cleaned.isEmpty && cleaned.count <= max ? cleaned : nil
    }

    private static func id(_ value: Any?) -> String? {
        if let s = value as? String, DirectMessageParser.safeIdentifier(s) { return s }
        if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
           n.doubleValue == Double(n.int64Value), n.int64Value > 0 {
            let result = n.stringValue
            return DirectMessageParser.safeIdentifier(result) ? result : nil
        }
        return nil
    }

    /// GET /receivers/types?includeClass=true -> {data:{list:[{id,name}],defaultGroup}}
    static func groups(_ json: [String: Any], accountId: String,
                       messageSessionId: String) throws -> DirectRecipientGroupsSnapshot {
        guard !accountId.isEmpty, DirectMessageParser.safeIdentifier(messageSessionId), let data = json["data"] as? [String: Any],
              let rows = data["list"] as? [[String: Any]], rows.count <= maxRecipientGroups else {
            throw DirectComposeError.unexpectedShape
        }
        var seen = Set<String>()
        var result: [DirectRecipientGroup] = []
        for row in rows {
            guard let groupId = id(row["id"]), let name = text(row["name"]) else {
                throw DirectComposeError.unsafeIdentifier
            }
            guard seen.insert(groupId).inserted else { throw DirectComposeError.duplicateIdentifier }
            if !skippedGroups.contains(groupId) {
                result.append(DirectRecipientGroup(id: groupId, name: name))
            }
        }
        return DirectRecipientGroupsSnapshot(accountId: accountId,
                                             messageSessionId: messageSessionId, groups: result)
    }

    /// GET /receivers/groups/school-employees?receiverType=<id>
    static func recipients(_ json: [String: Any], group: DirectRecipientGroup,
                           accountId: String, messageSessionId: String) throws -> DirectRecipientListSnapshot {
        guard !accountId.isEmpty, DirectMessageParser.safeIdentifier(messageSessionId),
              DirectMessageParser.safeIdentifier(group.id),
              let rows = json["receivers"] as? [[String: Any]],
              rows.count <= maxRecipientsPerGroup else { throw DirectComposeError.unexpectedShape }
        var result: [DirectRecipient] = []
        var seen = Set<String>()
        for row in rows {
            guard let recipientId = id(row["accountId"]),
                  let name = text(row["label"], max: 400) else { throw DirectComposeError.unsafeIdentifier }
            guard seen.insert(recipientId).inserted else { throw DirectComposeError.duplicateIdentifier }
            var available: Bool?
            if let status = row["availabilityStatus"] as? [String: Any] {
                if let raw = status["isAvailable"] {
                    guard let boolean = raw as? Bool else { throw DirectComposeError.unexpectedShape }
                    available = boolean
                }
            }
            result.append(DirectRecipient(id: recipientId, name: name,
                                          groupId: group.id, available: available))
        }
        return DirectRecipientListSnapshot(accountId: accountId,
                                           messageSessionId: messageSessionId,
                                           groupId: group.id, recipients: result)
    }

    /// Walidacja bez kontaktu z serwerem, wyłącznie na świeżej liście odbiorców.
    static func draft(recipient: DirectRecipient?, listed: DirectRecipientListSnapshot?,
                      accountId: String, subject: String, text: String,
                      reply: DirectReplyContext? = nil) throws -> DirectValidatedDraft {
        guard !accountId.isEmpty else { throw DirectComposeError.staleSession }
        let chosenId: String
        let messageSessionId: String
        var originalId: Int?
        if let reply {
            guard reply.accountId == accountId,
                  let parsed = Int(reply.originalMessageId), parsed > 0,
                  DirectMessageParser.safeIdentifier(reply.originalSenderId),
                  DirectMessageParser.safeIdentifier(reply.messageSessionId) else {
                throw DirectComposeError.replyNotAllowed
            }
            chosenId = reply.originalSenderId
            messageSessionId = reply.messageSessionId
            originalId = parsed
        } else {
            guard let recipient, let listed else { throw DirectComposeError.missingRecipient }
            guard listed.accountId == accountId, recipient.groupId == listed.groupId,
                  listed.recipients.contains(recipient) else { throw DirectComposeError.staleSession }
            guard recipient.available != false else { throw DirectComposeError.unavailableRecipient }
            chosenId = recipient.id
            messageSessionId = listed.messageSessionId
        }
        guard DirectMessageParser.safeIdentifier(messageSessionId),
              DirectMessageParser.safeIdentifier(chosenId) else { throw DirectComposeError.unsafeIdentifier }
        let topic = subject.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !topic.isEmpty else { throw DirectComposeError.emptySubject }
        guard !body.isEmpty else { throw DirectComposeError.emptyText }
        guard topic.count <= maxSubjectCharacters, body.count <= maxTextCharacters,
              topic.utf8.count <= 1_000, body.utf8.count <= 50_000 else { throw DirectComposeError.tooLong }
        return DirectValidatedDraft(recipientAccountId: chosenId,
                                    messageSessionId: messageSessionId, subject: topic,
                                    text: body, originalMessageId: originalId)
    }

    static func htmlEscapedBody(_ body: String) -> String {
        let normalized = body.replacingOccurrences(of: "\r\n", with: "\n")
                             .replacingOccurrences(of: "\r", with: "\n")
        return normalized.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&#39;")
            .replacingOccurrences(of: "\n", with: "<br>")
    }

    static func payload(_ draft: DirectValidatedDraft) -> [String: Any] {
        var object: [String: Any] = [
            "receivers": ["schoolReceivers": [["accountId": draft.recipientAccountId]]],
            "topic": Data(draft.subject.utf8).base64EncodedString(),
            "content": Data(htmlEscapedBody(draft.text).utf8).base64EncodedString(),
            "storageId": NSNull(), "category": "normal"
        ]
        if let original = draft.originalMessageId { object["originalMessageId"] = original }
        return object
    }
}

enum DirectSendResult: Equatable {
    case sent(messageId: String?)
    case refused(String) // odpowiedź przed wysłaniem lub pewna odmowa 4xx
    case uncertain(String) // mogło zostać wysłane — nigdy nie ponawiamy automatycznie
}

enum DirectSendResponse {
    /// Nie zgadujemy sukcesu po odpowiedzi błędnej. Odpowiedź reply może być pusta.
    static func evaluate(status: Int, data: Data) -> DirectSendResult {
        if [400, 401, 403, 404, 422].contains(status) {
            return .refused("Synergia odrzuciła żądanie (HTTP \(status)).")
        }
        guard [200, 201, 204].contains(status) else {
            return .uncertain("Brak jednoznacznego potwierdzenia (HTTP \(status)). Sprawdź Wysłane.")
        }
        if data.isEmpty { return .sent(messageId: nil) }
        guard data.count <= 1_000_000,
              let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return .uncertain("Nieznana odpowiedź serwera. Sprawdź Wysłane, zanim spróbujesz ponownie.")
        }
        for key in ["errors", "error", "Errors", "Error"] {
            if let value = root[key], !(value is NSNull) {
                if let array = value as? [Any], array.isEmpty { continue }
                return .uncertain("Serwer zgłosił błąd mimo odpowiedzi HTTP \(status). Sprawdź Wysłane.")
            }
        }
        var messageId: String?
        if let returned = (root["data"] as? [String: Any])?["status"] as? String,
           !["sent", "ok", "success"].contains(returned.lowercased()) {
            return .uncertain("Niepotwierdzony status wiadomości w odpowiedzi serwera. Sprawdź Wysłane.")
        }
        // An arbitrary empty or unrelated JSON body is not an acknowledgement.
        // Only explicitly recognized success or an issued message id may confirm
        // a non-empty JSON response; 200/201 with empty body keep prior semantics.
        let responseData = root["data"] as? [String: Any]
        let responseStatus = responseData?["status"] as? String
        let hasAcknowledgement = responseStatus.map { ["sent", "ok", "success"].contains($0.lowercased()) } == true ||
            responseData?["messageId"] != nil
        guard hasAcknowledgement else {
            return .uncertain("Odpowiedź JSON nie potwierdza wysyłki. Sprawdź Wysłane.")
        }
        if let value = responseData?["messageId"] {
            if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
               n.doubleValue == Double(n.int64Value), n.int64Value > 0,
               DirectMessageParser.safeIdentifier(n.stringValue) {
                messageId = n.stringValue
            } else if let s = value as? String, DirectMessageParser.safeIdentifier(s) {
                messageId = s
            } else {
                return .uncertain("Nieprawidłowy identyfikator w potwierdzeniu serwera. Sprawdź Wysłane.")
            }
        }
        return .sent(messageId: messageId)
    }
}
