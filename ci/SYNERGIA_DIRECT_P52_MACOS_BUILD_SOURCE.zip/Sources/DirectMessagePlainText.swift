import Foundation

/// Plain-text-only rendering of the XML/CDATA and HTML used by Librus.
/// Never pass downloaded HTML into WKWebView, AttributedString(markdown:),
/// or an HTML parser that could load remote images or links.
enum DirectMessagePlainText {
    private static func replacing(_ source: String, pattern: String, with value: String) -> String {
        source.replacingOccurrences(of: pattern, with: value, options: .regularExpression)
    }

    private static func decodedEntity(_ raw: String) -> String? {
        let value = String(raw.dropFirst().dropLast()) // &...;
        let polish: [String: String] = [
            "aogon": "ą", "Aogon": "Ą", "cacute": "ć", "Cacute": "Ć",
            "eogon": "ę", "Eogon": "Ę", "lstrok": "ł", "Lstrok": "Ł",
            "nacute": "ń", "Nacute": "Ń", "oacute": "ó", "Oacute": "Ó",
            "sacute": "ś", "Sacute": "Ś", "zacute": "ź", "Zacute": "Ź",
            "zdot": "ż", "Zdot": "Ż"
        ]
        if let decoded = polish[value] { return decoded }
        switch value.lowercased() {
        case "amp": return "&"
        case "lt": return "<"
        case "gt": return ">"
        case "quot": return "\""
        case "apos", "#39": return "'"
        case "nbsp": return " "
        case "ndash": return "–"
        case "mdash": return "—"
        case "hellip": return "…"
        case "bull": return "•"
        default: break
        }
        let number: UInt32?
        if value.lowercased().hasPrefix("#x") {
            number = UInt32(value.dropFirst(2), radix: 16)
        } else if value.hasPrefix("#") {
            number = UInt32(value.dropFirst(), radix: 10)
        } else { return nil }
        guard let n = number, n != 0, n != 0xFEFF,
              !((0xD800...0xDFFF).contains(n)),
              (n >= 0x20 || n == 9 || n == 10 || n == 13),
              let scalar = UnicodeScalar(n) else { return nil }
        return String(scalar)
    }

    private static func decodeEntities(_ text: String) -> String {
        guard let re = try? NSRegularExpression(pattern: "&(?:#[xX][0-9a-fA-F]{1,8}|#[0-9]{1,10}|[A-Za-z]{2,12});") else { return text }
        let original = text as NSString
        let matches = re.matches(in: text, range: NSRange(location: 0, length: original.length))
        var result = text
        for match in matches.reversed() {
            let entity = original.substring(with: match.range)
            if let decoded = decodedEntity(entity), let range = Range(match.range, in: result) {
                result.replaceSubrange(range, with: decoded)
            }
        }
        return result
    }

    static func render(_ input: String) -> String {
        // Bounded by DirectMessageParser before entering this function.
        var text = input
        // Encoded full body usually starts with <Message><Content><![CDATA[.
        text = text.replacingOccurrences(of: "<![CDATA[", with: "")
                   .replacingOccurrences(of: "]]>", with: "")
        // Remove raw active content, including its contents.
        for tag in ["script", "style", "iframe", "object", "svg", "form", "noscript"] {
            text = replacing(text, pattern: "(?is)<\\s*" + tag + "\\b[^>]*>.*?<\\s*/\\s*" + tag + "\\s*>", with: "")
        }
        // Preserve readable paragraph and list boundaries.
        text = replacing(text, pattern: "(?i)<\\s*br\\s*/?\\s*>", with: "\n")
        text = replacing(text, pattern: "(?i)<\\s*/?\\s*(?:p|div|li|ul|ol|h[1-6])\\b[^>]*>", with: "\n")
        // Strip remaining HTML/XML tags as inert text. No URLs are fetched.
        text = replacing(text, pattern: "(?s)</?[A-Za-z][A-Za-z0-9:_-]*\\b[^>]*>", with: "")
        text = replacing(text, pattern: "(?s)<!--.*?-->", with: "")
        text = decodeEntities(text)
        text = text.replacingOccurrences(of: "\r\n", with: "\n")
                   .replacingOccurrences(of: "\r", with: "\n")
                   .replacingOccurrences(of: "\u{00A0}", with: " ")
        text = replacing(text, pattern: "[ \\t]+\\n", with: "\n")
        text = replacing(text, pattern: "\\n{3,}", with: "\n\n")
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
