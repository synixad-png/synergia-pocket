import Foundation

/// Screen-only rule. Reading a message may mark it as read remotely,
/// so the view must not start (or appear to start) a rejected request.
/// The portal independently enforces authorization and in-flight request locks.
enum DirectMessageReadRequestPolicy {
    static func canStart(hasAccess: Bool, operationBusy: Bool) -> Bool {
        hasAccess && !operationBusy
    }
}
