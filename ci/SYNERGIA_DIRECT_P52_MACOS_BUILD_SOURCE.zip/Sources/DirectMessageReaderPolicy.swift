import Foundation

/// Pure, offline-testable UI access policy for a single message detail.
/// The owner is captured at opening and must remain the same while displaying.
enum DirectMessageReaderPolicy {
    static func canDisplay(message: DirectMessage, verifiedAccountId: String?,
                           authorizedAccountId: String, snapshot: DirectMailboxSnapshot?,
                           privacyShielded: Bool) -> Bool {
        guard !privacyShielded, !authorizedAccountId.isEmpty,
              verifiedAccountId == authorizedAccountId,
              let snapshot, snapshot.accountId == authorizedAccountId,
              snapshot.mailbox == message.mailbox else { return false }
        return snapshot.messages.contains { $0.id == message.id && $0.mailbox == message.mailbox }
    }

    static func matches(detail: DirectMessageDetail, message: DirectMessage) -> Bool {
        detail.id == message.id && detail.mailbox == message.mailbox
    }

    /// Split arbitrarily long inert plain text into bounded view chunks,
    /// preserving every Character, newline and their original order.
    /// No HTML parsing or network activity occurs here.
    static func chunks(_ body: String, limit: Int = 5000) -> [String] {
        guard !body.isEmpty else { return [] }
        let boundedLimit = max(256, min(10_000, limit))
        var result: [String] = []
        var start = body.startIndex
        while start < body.endIndex {
            let bound = body.index(start, offsetBy: boundedLimit, limitedBy: body.endIndex) ?? body.endIndex
            var end = bound
            if bound < body.endIndex {
                let prefix = body[start..<bound]
                if let newline = prefix.lastIndex(of: "\n"),
                   body.distance(from: start, to: newline) >= boundedLimit / 3 {
                    end = body.index(after: newline)
                }
            }
            result.append(String(body[start..<end]))
            start = end
        }
        return result
    }
}

enum DirectMessageReaderTextSize: Int, CaseIterable, Identifiable {
    case normal = 17, larger = 21, largest = 25
    var id: Int { rawValue }
    var pointSize: CGFloat { CGFloat(rawValue) }
    var label: String {
        switch self {
        case .normal: return "Standardowa"
        case .larger: return "Duża"
        case .largest: return "Bardzo duża"
        }
    }
}
