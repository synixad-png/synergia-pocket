import Foundation
import CoreFoundation

/// Rzeczywiste pola API Wiadomości opisane w kilku niezależnych klientach.
/// Wyłącznie odczyt; żaden model nie jest prośbą o wysłanie wiadomości.
/// Skrzynki potwierdzone w dokumentacji bieżących klientów Wiadomości.
/// 404 dla opcjonalnej skrzynki oznacza brak modułu w konkretnej szkole.
enum DirectMailbox: String, CaseIterable, Identifiable {
    case inbox = "inbox"
    case outbox = "outbox"
    case notes = "notes"
    case alerts = "alerts"
    case substitutions = "substitutions"
    case absences = "absences"
    case justifications = "justifications"
    case trash = "trash"
    case archiveInbox = "archive/inbox"
    case archiveOutbox = "archive/outbox"

    var id: String { rawValue }
    var label: String {
        switch self {
        case .inbox: return "Odebrane"
        case .outbox: return "Wysłane"
        case .notes: return "Uwagi"
        case .alerts: return "Powiadomienia"
        case .substitutions: return "Zastępstwa"
        case .absences: return "Nieobecności"
        case .justifications: return "Usprawiedliwienia"
        case .trash: return "Kosz"
        case .archiveInbox: return "Archiwum odebranych"
        case .archiveOutbox: return "Archiwum wysłanych"
        }
    }
    var isOutgoing: Bool { self == .outbox || self == .archiveOutbox }
    var isArchived: Bool { self == .archiveInbox || self == .archiveOutbox }
    var mayMarkRead: Bool { !isOutgoing }
    /// Pobieranie załączników archiwum zwracało 401 w testach istniejącego klienta.
    var supportsDirectAttachments: Bool { !isArchived }
}

struct DirectMessage: Identifiable, Equatable {
    let id: String
    let mailbox: DirectMailbox
    let subject: String
    let correspondent: String
    let sentAt: String?
    let readAt: String?
    let preview: String
    let hasAttachments: Bool
}

struct DirectMessageAttachment: Identifiable, Equatable {
    let id: String
    let name: String
    let sizeBytes: Int?
}

struct DirectMessageDetail: Identifiable, Equatable {
    let id: String
    let mailbox: DirectMailbox
    let subject: String
    let sender: String
    let sentAt: String?
    let body: String
    let attachments: [DirectMessageAttachment]
    let senderId: String?
    let replyAllowed: Bool
}

struct DirectMessagePage {
    let mailbox: DirectMailbox
    let messages: [DirectMessage]
    let total: Int?
}

struct DirectMailboxSnapshot {
    let mailbox: DirectMailbox
    let messages: [DirectMessage]
    let total: Int?
    let fetchedAt: Date
    let accountId: String
    let messageSessionId: String?
    let complete: Bool
}

enum DirectMessageError: Error, Equatable, LocalizedError {
    case unexpectedShape
    case invalidRecord
    case invalidIdentifier
    case duplicateIdentifier
    case invalidBase64
    case tooManyMessages
    case invalidTotal
    case incompleteMailbox
    case accountNotVerified

    var errorDescription: String? {
        switch self {
        case .unexpectedShape: return "Nierozpoznany format odpowiedzi wiadomości."
        case .invalidRecord: return "Niekompletny lub błędny wpis wiadomości."
        case .invalidIdentifier: return "Nieprawidłowy identyfikator wiadomości."
        case .duplicateIdentifier: return "Powtórzony identyfikator wiadomości."
        case .invalidBase64: return "Nie można bezpiecznie odczytać treści wiadomości."
        case .tooManyMessages: return "Przekroczono limit pobieranych wiadomości."
        case .invalidTotal: return "Sprzeczny licznik wiadomości na serwerze."
        case .incompleteMailbox: return "Nie odebrano wszystkich zgłoszonych wiadomości."
        case .accountNotVerified: return "Konto nie jest zweryfikowane."
        }
    }
}

enum DirectMessageParser {
    static let pageSize = 50
    static let maxPages = 40
    static let maxMessages = pageSize * maxPages

    static func safeIdentifier(_ value: String) -> Bool {
        !value.isEmpty && value.utf8.count <= 128 && value.utf8.allSatisfy {
            (48...57).contains($0) || (65...90).contains($0) ||
            (97...122).contains($0) || $0 == 45 || $0 == 95
        }
    }

    private static func text(_ value: Any?, max: Int = 1000) -> String? {
        guard let raw = value as? String else { return nil }
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty, s.count <= max else { return nil }
        return s
    }
    private static func messageId(_ item: [String: Any]) throws -> String {
        guard let id = text(item["messageId"], max: 128), safeIdentifier(id) else {
            throw DirectMessageError.invalidIdentifier
        }
        return id
    }
    private static func name(_ item: [String: Any], base: String) -> String? {
        if let full = text(item[base + "Name"], max: 250) { return full }
        let first = text(item[base + "FirstName"], max: 120)
        let last = text(item[base + "LastName"], max: 120)
        return [first, last].compactMap { $0 }.joined(separator: " ").nonEmpty
    }
    private static func plainText(_ value: Any?, required: Bool) throws -> String {
        guard let raw = value as? String else {
            if required { throw DirectMessageError.invalidRecord }
            return ""
        }
        guard raw.count <= 2_000_000,
              let decoded = Data(base64Encoded: raw),
              decoded.count <= 1_000_000 else { throw DirectMessageError.invalidBase64 }
        // Podgląd może urwać się w środku polskiego znaku UTF-8.
        // Pełną treść dekodujemy ściśle, podgląd łagodnie.
        let value: String
        if required {
            guard let full = String(data: decoded, encoding: .utf8) else { throw DirectMessageError.invalidBase64 }
            value = full
        } else {
            value = String(decoding: decoded, as: UTF8.self)
        }
        guard value.count <= 500_000 else { throw DirectMessageError.invalidBase64 }
        // Wiadomości zawierają XML/CDATA i HTML; nigdy nie uruchamiamy
        // skryptów ani nie osadzamy ich w WebView.
        return DirectMessagePlainText.render(value)
    }
    private static func count(_ root: [String: Any], records: Int) throws -> Int? {
        guard let raw = root["total"] ?? root["Total"] else { return nil }
        guard let n = raw as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
              n.intValue >= records, n.intValue <= 100_000,
              n.doubleValue == Double(n.intValue) else { throw DirectMessageError.invalidTotal }
        return n.intValue
    }

    /// API zwraca zwykle {data:[],total:N}, lecz część skrzynek zwraca
    /// bezpośrednio tablicę. W tym drugim wypadku kompletność = nieustalona.
    static func list(_ payload: Any, mailbox: DirectMailbox) throws -> DirectMessagePage {
        let rows: [[String: Any]]
        let total: Int?
        if let root = payload as? [String: Any] {
            guard let parsed = root["data"] as? [[String: Any]] else {
                throw DirectMessageError.unexpectedShape
            }
            rows = parsed
            total = try count(root, records: rows.count)
        } else if let bare = payload as? [[String: Any]] {
            rows = bare
            total = nil
        } else {
            throw DirectMessageError.unexpectedShape
        }
        guard rows.count <= pageSize else { throw DirectMessageError.unexpectedShape }
        var seen = Set<String>()
        let result = try rows.map { item -> DirectMessage in
            let id = try messageId(item)
            guard seen.insert(id).inserted else { throw DirectMessageError.duplicateIdentifier }
            guard let subject = text(item["topic"], max: 500),
                  let correspondent = name(item, base: mailbox.isOutgoing ? "receiver" : "sender") else {
                throw DirectMessageError.invalidRecord
            }
            // A missing preview is acceptable. An explicitly present but invalid
            // base64 payload is an error, not a blank preview.
            let preview = try plainText(item["content"], required: false)
            let attached = item["isAnyFileAttached"] as? Bool ?? false
            return DirectMessage(id: id, mailbox: mailbox, subject: subject,
                correspondent: correspondent,
                sentAt: text(item["sendDate"], max: 100),
                readAt: text(item["readDate"], max: 100),
                preview: preview, hasAttachments: attached)
        }
        return DirectMessagePage(mailbox: mailbox, messages: result, total: total)
    }

    static func detail(_ root: [String: Any], mailbox: DirectMailbox,
                       requestedId: String) throws -> DirectMessageDetail {
        guard safeIdentifier(requestedId), let record = root["data"] as? [String: Any] else {
            throw DirectMessageError.unexpectedShape
        }
        let id = try messageId(record)
        guard requestedId == id, let subject = text(record["topic"], max: 500),
              let sender = name(record, base: mailbox.isOutgoing ? "receiver" : "sender")
                    ?? name(record, base: "sender") else { throw DirectMessageError.invalidRecord }
        let body = try plainText(record["Message"], required: true)
        guard let entries = record["attachments"] as? [[String: Any]], entries.count <= 100 else {
            throw DirectMessageError.invalidRecord
        }
        var seen = Set<String>()
        let attachments = try entries.map { entry -> DirectMessageAttachment in
            guard let attachmentId = text(entry["id"], max: 128), safeIdentifier(attachmentId),
                  let filename = text(entry["filename"] ?? entry["name"], max: 240),
                  !filename.contains("/"), !filename.contains("\\"),
                  !filename.contains("\0"), !filename.hasPrefix(".") else {
                throw DirectMessageError.invalidRecord
            }
            guard seen.insert(attachmentId).inserted else { throw DirectMessageError.duplicateIdentifier }
            var size: Int? = nil
            if let raw = entry["size"] {
                guard let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
                      number.int64Value >= 0, number.int64Value <= 100_000_000,
                      number.doubleValue == Double(number.int64Value) else { throw DirectMessageError.invalidRecord }
                size = Int(number.int64Value)
            }
            return DirectMessageAttachment(id: attachmentId, name: filename, sizeBytes: size)
        }
        // Reply requires both the actual sender's account id and a positive
        // noReply == 0 flag. Unknown flags do not enable a send action.
        let senderId = text(record["senderId"], max: 128).flatMap {
            safeIdentifier($0) ? $0 : nil
        }
        let allowed: Bool
        if let number = record["noReply"] as? NSNumber,
           CFGetTypeID(number) != CFBooleanGetTypeID(),
           number.intValue == 0, number.doubleValue == 0 { allowed = true }
        else { allowed = false }
        return DirectMessageDetail(id: id, mailbox: mailbox, subject: subject,
            sender: sender, sentAt: text(record["sendDate"], max: 100),
            body: body, attachments: attachments, senderId: senderId,
            replyAllowed: mailbox == .inbox && senderId != nil && allowed)
    }

    static func merge(_ pages: [DirectMessagePage], mailbox: DirectMailbox,
                      accountId: String, fetchedAt: Date = Date(),
                      messageSessionId: String? = nil) throws -> DirectMailboxSnapshot {
        guard !accountId.isEmpty, !pages.isEmpty, pages.count <= maxPages else {
            throw DirectMessageError.incompleteMailbox
        }
        var seen = Set<String>()
        var output: [DirectMessage] = []
        var expectedTotal: Int? = nil
        for (index, page) in pages.enumerated() {
            guard page.mailbox == mailbox else { throw DirectMessageError.unexpectedShape }
            if let t = page.total {
                if let old = expectedTotal, old != t { throw DirectMessageError.invalidTotal }
                expectedTotal = t
            }
            for message in page.messages {
                guard seen.insert(message.id).inserted else { throw DirectMessageError.duplicateIdentifier }
                output.append(message)
            }
            guard output.count <= maxMessages else { throw DirectMessageError.tooManyMessages }
            // Any non-final short page with more records expected is an error.
            if index < pages.count - 1 && page.messages.count != pageSize {
                throw DirectMessageError.incompleteMailbox
            }
        }
        if let expectedTotal, output.count != expectedTotal { throw DirectMessageError.incompleteMailbox }
        // No server-reported total: cannot claim mailbox completeness.
        let complete = expectedTotal != nil
        return DirectMailboxSnapshot(mailbox: mailbox, messages: output,
            total: expectedTotal, fetchedAt: fetchedAt, accountId: accountId,
            messageSessionId: messageSessionId, complete: complete)
    }
}

private extension String {
    var nonEmpty: String? { isEmpty ? nil : self }
}
