import Foundation

/// Presentational safeguards. Network fetches and storage have independent account fences.
/// A non-existent snapshot should be labelled "not requested", not "foreign account".
enum DirectModuleAccessPolicy {
    static func canDisplay(verifiedAccountId: String?, privacyShieldActive: Bool,
                           ownerAccountId: String?, hasData: Bool) -> Bool {
        guard let verifiedAccountId, !verifiedAccountId.isEmpty,
              !privacyShieldActive else { return false }
        if let ownerAccountId {
            return ownerAccountId == verifiedAccountId
        }
        return !hasData
    }

    /// Every refresh is an explicit foreground gesture, never automatic/background.
    static func canRefresh(verifiedAccountId: String?, privacyShieldActive: Bool,
                           anyOperationBusy: Bool) -> Bool {
        guard let verifiedAccountId, !verifiedAccountId.isEmpty else { return false }
        return !privacyShieldActive && !anyOperationBusy
    }


    /// A previously attempted send is never retried. The owner may perform one
    /// deliberate read-only outbox fetch while the compose form remains locked.
    static func canReviewOutbox(verifiedAccountId: String?, privacyShieldActive: Bool,
                                pendingSendReview: Bool, anyOperationBusy: Bool) -> Bool {
        pendingSendReview && canRefresh(verifiedAccountId: verifiedAccountId,
                                        privacyShieldActive: privacyShieldActive,
                                        anyOperationBusy: anyOperationBusy)
    }

    static func guidance(for module: String) -> String {
        switch module {
        case "grades": return "Oceny i ich szczegóły z potwierdzonego konta."
        case "attendance": return "Obecności i nieobecności; brak wpisu nie potwierdza obecności."
        case "messages": return "Odebrane i wysłane wiadomości; wybierz odpowiednią skrzynkę."
        case "timetable": return "Plan dotyczy wybranego tygodnia, nie całego semestru."
        case "calendar": return "Wydarzenia zapisane w ostatnim odczycie."
        case "homework": return "Zadania i dostępne załączniki do pobrania."
        case "announcements": return "Ogłoszenia dostępne dla zweryfikowanego konta."
        case "documents": return "Dokumenty i pliki szkolne; pobieraj tylko na żądanie."
        default: return "Odczyt danych szkolnych w aplikacji."
        }
    }
}
