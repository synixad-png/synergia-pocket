import Foundation

/// Jeden jawny model stanu odczytu dla widoków bezpośredniego JSON.
/// `complete` oznacza wyłącznie zgodność licznika odpowiedzi (jeśli serwer go podał),
/// NIE dowód, że Synergia udostępniła wszystkie szkolne wpisy.
enum DirectReadDisplayKind: String, Equatable {
    case locked, loading, notRequested, failed, stale, partial, available, empty

    var title: String {
        switch self {
        case .locked: return "Dane zablokowane"
        case .loading: return "Trwa odczyt"
        case .notRequested: return "Brak odczytu JSON"
        case .failed: return "Odczyt nieudany"
        case .stale: return "Dane z poprzedniego odczytu"
        case .partial: return "Dane — kompletność niepotwierdzona"
        case .available: return "Odczyt z potwierdzonym licznikiem"
        case .empty: return "Pusta odpowiedź z potwierdzonym licznikiem"
        }
    }
    var symbol: String {
        switch self {
        case .locked: return "lock.shield"
        case .loading: return "arrow.triangle.2.circlepath"
        case .notRequested: return "tray"
        case .failed: return "exclamationmark.triangle"
        case .stale: return "clock.badge.exclamationmark"
        case .partial: return "exclamationmark.circle"
        case .available: return "checkmark.circle"
        case .empty: return "tray"
        }
    }
    var guidance: String {
        switch self {
        case .locked: return "Potwierdź aktywne konto przez /Me. Dane innego konta nie są udostępniane."
        case .loading: return "Trwa sprawdzanie konta i odpowiedzi serwera."
        case .notRequested: return "Uruchom odczyt. Osobny zapis diagnostyczny HTML nie zastępuje danych JSON."
        case .failed: return "Nie udało się pobrać danych. Nie oznacza to, że w Synergii nie ma wpisów."
        case .stale: return "Wcześniejszy zapis nie został potwierdzony w bieżącej sesji lub ostatni odczyt się nie powiódł. Nie traktuj go jako aktualnego."
        case .partial: return "Liczba wpisów w całej Synergii nie została potwierdzona. Brak wpisu nie oznacza jego usunięcia."
        case .available: return "Licznik odpowiedzi jest zgodny. To nie potwierdza zakresu uprawnień szkoły ani wszystkich semestrów."
        case .empty: return "Serwer potwierdził zero wpisów w tym odczycie. Nie dowodzi to braku danych w innych modułach."
        }
    }
}

struct DirectReadPresentation: Equatable {
    let kind: DirectReadDisplayKind
    let count: Int?
    let capturedAt: Date?

    static func evaluate(verified: Bool, loading: Bool, failed: Bool,
                         count: Int?, capturedAt: Date?, complete: Bool,
                         accountMatches: Bool = true, fresh: Bool = true) -> DirectReadPresentation {
        guard verified && accountMatches else { return .init(kind: .locked, count: nil, capturedAt: nil) }
        if loading { return .init(kind: .loading, count: count, capturedAt: capturedAt) }
        if failed { return .init(kind: capturedAt == nil ? .failed : .stale, count: count, capturedAt: capturedAt) }
        guard let capturedAt, let count else { return .init(kind: .notRequested, count: nil, capturedAt: nil) }
        if !fresh { return .init(kind: .stale, count: count, capturedAt: capturedAt) }
        let kind: DirectReadDisplayKind = complete ? (count == 0 ? .empty : .available) : .partial
        return .init(kind: kind, count: count, capturedAt: capturedAt)
    }
}
