import Foundation

/// Pure screen-lifecycle decisions. Only presentation state is reset;
/// source documents, Keychain entries and in-memory message drafts are untouched.
enum DirectModuleScreenLifecycle {
    static func requiresAccountReset(previous: String?, current: String?) -> Bool {
        previous != current
    }

    static func shouldClosePrivatePresentations(shieldEnabled: Bool) -> Bool {
        shieldEnabled
    }
}
