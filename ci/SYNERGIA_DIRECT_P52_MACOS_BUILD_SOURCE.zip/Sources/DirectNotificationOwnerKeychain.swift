import Foundation
import Security

/// Verified notification owner is bound in the device-only Keychain rather
/// than to unprotected notification preferences. No passwords or messages.
/// Failure to read or write must fail closed, never inherit prior consent.
enum DirectNotificationOwnerKeychain {
    private static let service = "pl.synixad.synergiadirect.notification.owner.v1"
    private static let name = "verified-synergia-owner"

    static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: name,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let owner = String(data: data, encoding: .utf8),
              !owner.isEmpty else { return nil }
        return owner
    }

    @discardableResult
    static func bind(_ verifiedAccount: String) -> Bool {
        guard !verifiedAccount.isEmpty else { return false }
        clear()
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: name,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            kSecValueData as String: Data(verifiedAccount.utf8)
        ]
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }

    static func clear() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: name
        ]
        SecItemDelete(query as CFDictionary)
    }
}
