import Foundation

/// Pure, fail-closed codec, shared by iOS storage and portable offline tests.
/// This does NOT authorize offline access; only a matching live /Me does.
enum DirectOfflineFeedCacheError: Error, Equatable {
    case wrongAccountOrModule, unsupportedVersion, invalidSnapshot, oversized
}

enum DirectOfflineFeedCache {
    static let version = 1
    static let maximumBytes = 2_500_000
    static let maximumRecords = 500
    static let modules: [SchoolModule] = [.homework, .calendar, .announcements, .documents]
    private struct Envelope: Codable {
        let schemaVersion: Int
        let accountId: String
        let feed: DirectSchoolFeed
    }

    static func encode(_ feed: DirectSchoolFeed, expectedAccountId: String,
                       now: Date = Date()) throws -> Data {
        try check(feed, module: feed.module, expectedAccountId: expectedAccountId, now: now)
        let bytes = try JSONEncoder().encode(Envelope(schemaVersion: version,
                                accountId: expectedAccountId, feed: feed))
        guard bytes.count <= maximumBytes else { throw DirectOfflineFeedCacheError.oversized }
        return bytes
    }

    static func decode(_ bytes: Data, module: SchoolModule, expectedAccountId: String,
                       now: Date = Date()) throws -> DirectSchoolFeed {
        guard bytes.count <= maximumBytes else { throw DirectOfflineFeedCacheError.oversized }
        let envelope = try JSONDecoder().decode(Envelope.self, from: bytes)
        guard envelope.schemaVersion == version else { throw DirectOfflineFeedCacheError.unsupportedVersion }
        guard envelope.accountId == expectedAccountId else {
            throw DirectOfflineFeedCacheError.wrongAccountOrModule
        }
        try check(envelope.feed, module: module, expectedAccountId: expectedAccountId, now: now)
        return envelope.feed
    }

    private static func check(_ feed: DirectSchoolFeed, module: SchoolModule,
                              expectedAccountId: String, now: Date) throws {
        guard modules.contains(module), feed.module == module,
              !expectedAccountId.isEmpty, expectedAccountId.count <= 256,
              feed.verifiedAccountId == expectedAccountId else {
            throw DirectOfflineFeedCacheError.wrongAccountOrModule
        }
        guard feed.fetchedAt.timeIntervalSince1970 >= 946684800,
              feed.fetchedAt <= now.addingTimeInterval(300),
              feed.records.count <= maximumRecords,
              feed.reportedTotal.map({ $0 >= feed.records.count && $0 <= 100_000 }) ?? true else {
            throw DirectOfflineFeedCacheError.invalidSnapshot
        }
        var ids = Set<String>()
        for entry in feed.records {
            guard !entry.id.isEmpty, entry.id.count <= 140,
                  !entry.title.isEmpty, entry.title.count <= 12_000,
                  entry.details.count <= 50, entry.details.allSatisfy({ $0.count <= 12_100 }),
                  (entry.serverId?.count ?? 0) <= 128,
                  ids.insert(entry.id).inserted else {
                throw DirectOfflineFeedCacheError.invalidSnapshot
            }
            // Cached links are not authority: revalidate against the same
            // constrained official endpoints before they can be used.
            if let file = entry.schoolFile {
                guard module == .documents, safeFilename(file.displayName),
                      (try? DirectSchoolFilePolicy.documentURL(file)) != nil else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
            }
            if let document = entry.document {
                guard module == .documents,
                      document.addedDay.map({ DirectSchoolAgendaEvent.validDay($0) == $0 }) ?? true,
                      document.serverStatus.map({ !$0.isEmpty && $0.count <= 120 &&
                          !($0.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }) }) ?? true else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
            }
            if let homework = entry.homework {
                guard module == .homework,
                      homework.dueDay.map({ DirectSchoolAgendaEvent.validDay($0) == $0 }) ?? true,
                      homework.publishedDay.map({ DirectSchoolAgendaEvent.validDay($0) == $0 }) ?? true,
                      homework.body.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      homework.categoryName.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      homework.subjectName.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
            }
            if let agenda = entry.agenda {
                guard module == .calendar,
                      agenda.day.map({ DirectSchoolAgendaEvent.validDay($0) == $0 }) ?? true,
                      agenda.endDay.map({ DirectSchoolAgendaEvent.validDay($0) == $0 }) ?? true,
                      agenda.body.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      agenda.categoryName.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      agenda.subjectName.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      agenda.categoryId.map({ !$0.isEmpty && $0.count <= 128 }) ?? true,
                      agenda.subjectId.map({ !$0.isEmpty && $0.count <= 128 }) ?? true,
                      agenda.lessonNumber.map({ !$0.isEmpty && $0.count <= 128 }) ?? true else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
            }
            if let notice = entry.notice {
                guard module == .announcements,
                      notice.body.map({ !$0.isEmpty && $0.count <= 12_000 }) ?? true,
                      notice.startDate.map({ $0.count <= 64 }) ?? true,
                      notice.endDate.map({ $0.count <= 64 }) ?? true,
                      notice.creationDate.map({ $0.count <= 64 }) ?? true,
                      notice.authorId.map({ !$0.isEmpty && $0.count <= 128 }) ?? true else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
            }
            if let files = entry.homeworkFiles {
                guard module == .homework, files.count <= 30 else {
                    throw DirectOfflineFeedCacheError.invalidSnapshot
                }
                var fileIDs = Set<String>()
                for file in files {
                    guard fileIDs.insert(file.key).inserted,
                          safeFilename(file.name),
                          (try? DirectHomeworkFilePolicy.downloadURL(file)) != nil else {
                        throw DirectOfflineFeedCacheError.invalidSnapshot
                    }
                }
            }
        }
    }
    private static func safeFilename(_ name: String) -> Bool {
        !name.isEmpty && name.count <= 240 &&
        name == name.trimmingCharacters(in: .whitespacesAndNewlines) &&
        !name.hasPrefix(".") && !name.contains("/") && !name.contains("\\") &&
        !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
    }
}
