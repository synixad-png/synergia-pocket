import Foundation

/// Protected on-device snapshots. Never read until the account has passed /Me.
/// All records loaded from disk are labeled STALE in the UI.
@MainActor
final class DirectOfflineFeedStore {
    private(set) var verifiedAccountId: String?
    private(set) var feeds: [SchoolModule: DirectSchoolFeed] = [:]
    private let root: URL

    init(directory: URL? = nil) {
        let base = directory ?? FileManager.default.urls(for: .applicationSupportDirectory,
            in: .userDomainMask)[0].appendingPathComponent("school-data", isDirectory: true)
        root = base.appendingPathComponent("feed-accounts", isDirectory: true)
    }
    private func file(for module: SchoolModule, account: String) -> URL {
        AccountPartition.directory(for: account, under: root)
            .appendingPathComponent(module.rawValue).appendingPathExtension("json")
    }
    func lock() {
        verifiedAccountId = nil
        feeds.removeAll()
    }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty, accountId.count <= 256 else { return }
        verifiedAccountId = accountId
        for module in DirectOfflineFeedCache.modules {
            let path = file(for: module, account: accountId)
            guard let attributes = try? FileManager.default.attributesOfItem(atPath: path.path),
                  let size = attributes[.size] as? NSNumber,
                  size.intValue <= DirectOfflineFeedCache.maximumBytes,
                  let bytes = try? Data(contentsOf: path),
                  let restored = try? DirectOfflineFeedCache.decode(bytes, module: module,
                      expectedAccountId: accountId) else { continue }
            feeds[module] = restored
        }
    }
    func replace(_ feed: DirectSchoolFeed) throws {
        guard let account = verifiedAccountId, account == feed.verifiedAccountId else {
            throw DirectOfflineFeedCacheError.wrongAccountOrModule
        }
        let data = try DirectOfflineFeedCache.encode(feed, expectedAccountId: account)
        let target = file(for: feed.module, account: account)
        try FileManager.default.createDirectory(at: target.deletingLastPathComponent(),
            withIntermediateDirectories: true)
        try data.write(to: target, options: [.atomic, .completeFileProtection])
        var dir = target.deletingLastPathComponent()
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? dir.setResourceValues(values)
        feeds[feed.module] = feed
    }
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: root.path) {
            try FileManager.default.removeItem(at: root)
        }
    }
}
