import Foundation

/// Offline fallback is permitted only for a transport loss in the SAME
/// already-verified foreground session. No auth/identity/server errors qualify.
/// This never bypasses the mandatory live /Me when opening a new session.
enum DirectOfflineRecovery {
    static func mayRetain(previouslyVerified: Bool, accountUnchanged: Bool,
                          isForeground: Bool, observedRemoteAccount: String?,
                          expectedAccount: String, failure: Error) -> Bool {
        guard previouslyVerified, accountUnchanged, isForeground,
              !expectedAccount.isEmpty,
              observedRemoteAccount == nil || observedRemoteAccount == expectedAccount,
              let gateway = failure as? GatewayReadError else { return false }
        guard case .transport(let issue) = gateway else { return false }
        return issue == .offline || issue == .timedOut || issue == .interrupted
    }
}
