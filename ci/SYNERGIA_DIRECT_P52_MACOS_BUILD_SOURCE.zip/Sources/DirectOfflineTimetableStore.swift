import Foundation

/// Validated, account-scoped week (plus optional substitutions and *display-only* lookups).
/// Loading it never certifies freshness or substitutes for a live /Me identity check.
struct DirectOfflineTimetableSnapshot: Codable, Equatable {
    let week: DirectTimetableWeek
    let history: DirectPlanChangesSnapshot?
    let subjects: [String: String]
    let teachers: [String: String]
}

enum DirectOfflineTimetableError: Error, Equatable {
    case locked, wrongAccount, invalidWeek, invalidSnapshot, unsupportedVersion, oversized
}

enum DirectOfflineTimetableCodec {
    static let version = 1
    static let maximumBytes = 2_500_000
    static let maxStoredWeeks = 16
    private struct Envelope: Codable {
        let version: Int
        let accountId: String
        let monday: String
        let snapshot: DirectOfflineTimetableSnapshot
    }

    static func encode(_ snapshot: DirectOfflineTimetableSnapshot, account: String, now: Date = Date()) throws -> Data {
        try validate(snapshot, monday: snapshot.week.monday, account: account, now: now)
        let data = try JSONEncoder().encode(Envelope(version: version, accountId: account,
            monday: snapshot.week.monday, snapshot: snapshot))
        guard data.count <= maximumBytes else { throw DirectOfflineTimetableError.oversized }
        return data
    }

    static func decode(_ data: Data, monday: String, account: String, now: Date = Date()) throws -> DirectOfflineTimetableSnapshot {
        guard data.count <= maximumBytes else { throw DirectOfflineTimetableError.oversized }
        let envelope = try JSONDecoder().decode(Envelope.self, from: data)
        guard envelope.version == version else { throw DirectOfflineTimetableError.unsupportedVersion }
        guard envelope.accountId == account else { throw DirectOfflineTimetableError.wrongAccount }
        guard envelope.monday == monday else { throw DirectOfflineTimetableError.invalidWeek }
        try validate(envelope.snapshot, monday: monday, account: account, now: now)
        return envelope.snapshot
    }

    private static func validDate(_ string: String) -> Date? {
        guard string.count == 10, string.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return nil }
        var cal = Calendar(identifier: .iso8601)
        cal.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        let fmt = DateFormatter()
        fmt.calendar = cal
        fmt.timeZone = cal.timeZone
        fmt.locale = Locale(identifier: "en_US_POSIX")
        fmt.dateFormat = "yyyy-MM-dd"
        fmt.isLenient = false
        guard let date = fmt.date(from: string), fmt.string(from: date) == string else { return nil }
        return date
    }
    private static func validTime(_ time: String?) -> Bool {
        guard let time else { return true }
        let parts = time.split(separator: ":", omittingEmptySubsequences: false)
        guard parts.count == 2, time.count == 5,
              let h = Int(parts[0]), let m = Int(parts[1]),
              parts[0].count == 2, parts[1].count == 2 else { return false }
        return (0...23).contains(h) && (0...59).contains(m)
    }
    private static func stringOK(_ string: String?, limit: Int = 130) -> Bool {
        guard let string else { return true }
        return !string.isEmpty && string.utf8.count <= limit
    }
    private static func checkLookups(_ dict: [String: String]) -> Bool {
        dict.count <= 3000 && dict.allSatisfy { key, value in
            stringOK(key) && stringOK(value, limit: 240)
        }
    }
    private static func dateAllowed(_ date: Date, now: Date) -> Bool {
        date.timeIntervalSince1970 >= 946684800 && date <= now.addingTimeInterval(300)
    }
    static func validate(_ s: DirectOfflineTimetableSnapshot, monday: String,
                         account: String, now: Date = Date()) throws {
        guard !account.isEmpty, account.count <= 256,
              s.week.accountId == account,
              s.week.monday == monday, DirectTimetableParser.isMonday(monday),
              dateAllowed(s.week.fetchedAt, now: now),
              s.week.reportedDates.count > 0, s.week.reportedDates.count <= 7,
              s.week.reportedDates == Array(Set(s.week.reportedDates)).sorted(),
              s.week.entries.count <= 250,
              checkLookups(s.subjects), checkLookups(s.teachers),
              let first = validDate(monday) else { throw DirectOfflineTimetableError.invalidSnapshot }
        var cal = Calendar(identifier: .iso8601)
        cal.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        guard let nextMonday = cal.date(byAdding: .day, value: 7, to: first) else {
            throw DirectOfflineTimetableError.invalidSnapshot
        }
        for date in s.week.reportedDates {
            guard let day = validDate(date), day >= first, day < nextMonday else {
                throw DirectOfflineTimetableError.invalidSnapshot
            }
        }
        var ids = Set<String>()
        for item in s.week.entries {
            guard s.week.reportedDates.contains(item.date),
                  item.id == "\(item.date):\(item.slot):\(item.parallelIndex)",
                  ids.insert(item.id).inserted,
                  (0..<24).contains(item.slot), (1...8).contains(item.parallelCount),
                  (0..<item.parallelCount).contains(item.parallelIndex),
                  item.lessonNumber.map({ (1...50).contains($0) }) ?? true,
                  validTime(item.timeFrom), validTime(item.timeTo),
                  stringOK(item.subjectId), stringOK(item.teacherId), stringOK(item.classroomId),
                  item.lessonNumber != nil || item.timeFrom != nil || item.timeTo != nil ||
                     item.subjectId != nil || item.isCanceled == true else {
                throw DirectOfflineTimetableError.invalidSnapshot
            }
        }
        if let history = s.history {
            guard history.accountId == account, dateAllowed(history.fetchedAt, now: now),
                  history.changes.count <= 3000 else { throw DirectOfflineTimetableError.invalidSnapshot }
            var changes = Set<String>()
            for change in history.changes {
                guard stringOK(change.id), changes.insert(change.id).inserted,
                      validDate(change.originalDate) != nil,
                      change.currentDate.map({ validDate($0) != nil }) ?? true,
                      change.originalLessonNumber.map({ (1...50).contains($0) }) ?? true,
                      change.currentLessonNumber.map({ (1...50).contains($0) }) ?? true,
                      stringOK(change.originalSubjectId), stringOK(change.currentSubjectId),
                      stringOK(change.originalTeacherId), stringOK(change.currentTeacherId),
                      stringOK(change.originalClassroom, limit: 100),
                      stringOK(change.currentClassroom, limit: 100) else {
                    throw DirectOfflineTimetableError.invalidSnapshot
                }
            }
        }
    }
}

/// A bounded store of independently validated weeks. The directory is never inspected
/// before a successful live /Me. The snapshot is returned only to that account.
@MainActor
final class DirectOfflineTimetableStore {
    private(set) var verifiedAccountId: String?
    private(set) var weeks: [String: DirectOfflineTimetableSnapshot] = [:]
    private let root: URL

    init(directory: URL? = nil) {
        let base = directory ?? FileManager.default.urls(for: .applicationSupportDirectory,
            in: .userDomainMask)[0].appendingPathComponent("school-data", isDirectory: true)
        root = base.appendingPathComponent("timetable-accounts", isDirectory: true)
    }
    private func folder(_ account: String) -> URL {
        AccountPartition.directory(for: account, under: root)
    }
    private func path(_ monday: String, account: String) -> URL {
        folder(account).appendingPathComponent(monday).appendingPathExtension("json")
    }
    func lock() {
        verifiedAccountId = nil
        weeks.removeAll()
    }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty, accountId.count <= 256 else { return }
        verifiedAccountId = accountId
        let dir = folder(accountId)
        guard let names = try? FileManager.default.contentsOfDirectory(atPath: dir.path) else { return }
        for name in names.filter({ $0.hasSuffix(".json") }).sorted(by: >).prefix(256) {
            if weeks.count >= DirectOfflineTimetableCodec.maxStoredWeeks { break }
            let monday = String(name.dropLast(5))
            guard DirectTimetableParser.isMonday(monday) else { continue }
            let file = path(monday, account: accountId)
            guard let attr = try? FileManager.default.attributesOfItem(atPath: file.path),
                  let size = attr[.size] as? NSNumber,
                  (attr[.type] as? FileAttributeType) == .typeRegular,
                  size.intValue <= DirectOfflineTimetableCodec.maximumBytes,
                  let data = try? Data(contentsOf: file),
                  let snapshot = try? DirectOfflineTimetableCodec.decode(data, monday: monday, account: accountId) else { continue }
            weeks[monday] = snapshot
        }
    }
    func snapshot(monday: String) -> DirectOfflineTimetableSnapshot? {
        guard verifiedAccountId != nil, DirectTimetableParser.isMonday(monday) else { return nil }
        return weeks[monday]
    }
    func replace(_ snapshot: DirectOfflineTimetableSnapshot) throws {
        guard let owner = verifiedAccountId, owner == snapshot.week.accountId else {
            throw DirectOfflineTimetableError.wrongAccount
        }
        let monday = snapshot.week.monday
        let data = try DirectOfflineTimetableCodec.encode(snapshot, account: owner)
        let dir = folder(owner)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try data.write(to: path(monday, account: owner), options: [.atomic, .completeFileProtection])
        var directory = dir
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? directory.setResourceValues(values)
        weeks[monday] = snapshot
        // Most recently fetched weeks survive, even if the user refreshed
        // an older calendar week. Do not keep unbounded corrupt/obsolete files.
        let ranked = weeks.keys.sorted { first, second in
            let a = weeks[first]!.week.fetchedAt
            let b = weeks[second]!.week.fetchedAt
            return a == b ? first > second : a > b
        }
        for old in ranked.dropFirst(DirectOfflineTimetableCodec.maxStoredWeeks) {
            weeks.removeValue(forKey: old)
        }
        if let filenames = try? FileManager.default.contentsOfDirectory(atPath: dir.path) {
            for name in filenames where name.hasSuffix(".json") {
                let monday = String(name.dropLast(5))
                guard DirectTimetableParser.isMonday(monday), weeks[monday] == nil else { continue }
                try? FileManager.default.removeItem(at: path(monday, account: owner))
            }
        }
    }
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: root.path) {
            try FileManager.default.removeItem(at: root)
        }
    }
}
