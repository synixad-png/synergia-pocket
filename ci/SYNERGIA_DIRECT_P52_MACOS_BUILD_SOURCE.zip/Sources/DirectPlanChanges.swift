import Foundation
import CoreFoundation

/// Original-vs-new dates and lesson references are kept separate; no guessing
/// which class or teacher belongs to the pupil's parallel group.
struct DirectPlanChange: Codable, Equatable, Identifiable {
    enum Kind: String, Codable { case cancelled, substitution, shifted, unknown }
    let id: String
    let originalDate: String
    let originalLessonNumber: Int?
    let currentDate: String?
    let currentLessonNumber: Int?
    let originalSubjectId: String?
    let currentSubjectId: String?
    let originalTeacherId: String?
    let currentTeacherId: String?
    let originalClassroom: String?
    let currentClassroom: String?
    let kind: Kind
    var affectedDate: String { originalDate }
}
struct DirectPlanChangesSnapshot: Codable, Equatable {
    let changes: [DirectPlanChange]
    let accountId: String
    let fetchedAt: Date
    var count: Int { changes.count }
    func forWeek(_ monday: String) -> [DirectPlanChange] {
        guard DirectTimetableParser.isMonday(monday) else { return [] }
        var cal = Calendar(identifier: .iso8601)
        cal.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        let form = DateFormatter()
        form.calendar = cal
        form.timeZone = cal.timeZone
        form.locale = Locale(identifier: "en_US_POSIX")
        form.dateFormat = "yyyy-MM-dd"
        form.isLenient = false
        guard let first = form.date(from: monday),
              let end = cal.date(byAdding: .day, value: 6, to: first) else { return [] }
        return changes.filter { item in
            [item.originalDate, item.currentDate].compactMap { $0 }.contains { text in
                guard let day = form.date(from: text) else { return false }
                return (first...end).contains(day)
            }
        }
    }
}

enum DirectPlanChangeError: Error, LocalizedError, Equatable {
    case unknownResponse, malformedChange, duplicateId, tooManyEntries
    var errorDescription: String? {
        switch self {
        case .unknownResponse: return "Serwer nie zwrócił rozpoznanej listy zmian planu."
        case .malformedChange: return "Nieprawidłowy wpis historii zmian planu."
        case .duplicateId: return "Historia planu zawiera powtórzony identyfikator."
        case .tooManyEntries: return "Zbyt wiele wpisów zmian planu."
        }
    }
}

enum DirectPlanChangesParser {
    private static func date(_ value: Any?) -> String? {
        guard let string = value as? String, string.count >= 10 else { return nil }
        let day = String(string.prefix(10))
        guard day.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return nil }
        if string.count > 10, !string.dropFirst(10).hasPrefix("T"),
           !string.dropFirst(10).hasPrefix(" ") { return nil }
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        let formatter = DateFormatter()
        formatter.calendar = cal
        formatter.timeZone = cal.timeZone
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.isLenient = false
        guard let parsed = formatter.date(from: day), formatter.string(from: parsed) == day else { return nil }
        return day
    }
    private static func identifier(_ value: Any?) -> String? {
        if let str = value as? String, !str.isEmpty, str.utf8.count <= 128,
           str.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) ||
             (97...122).contains($0) || $0 == 45 || $0 == 95 }) { return str }
        if let num = value as? NSNumber, CFGetTypeID(num) != CFBooleanGetTypeID(), num.int64Value >= 0,
           num.doubleValue == Double(num.int64Value) { return num.stringValue }
        return nil
    }
    private static func reference(_ value: Any?) -> String? {
        guard let dict = value as? [String: Any] else { return nil }
        return identifier(dict["Id"])
    }
    private static func lessonNumber(_ value: Any?) -> Int? {
        let result: Int?
        if let raw = value as? String { result = Int(raw) }
        else if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
                n.doubleValue == Double(n.intValue) { result = n.intValue }
        else { result = nil }
        guard let n = result, (1...50).contains(n) else { return nil }
        return n
    }
    private static func classroom(_ value: Any?) -> String? {
        guard let text = value as? String else { return nil }
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return !clean.isEmpty && clean.count <= 100 ? clean : nil
    }

    static func parse(_ json: [String: Any], accountId: String, at fetchedAt: Date = Date()) throws -> DirectPlanChangesSnapshot {
        guard let records = json["Substitutions"] as? [[String: Any]] else { throw DirectPlanChangeError.unknownResponse }
        guard records.count <= 3000 else { throw DirectPlanChangeError.tooManyEntries }
        var found = Set<String>()
        var result: [DirectPlanChange] = []
        for row in records {
            guard let id = identifier(row["Id"]), let originalDate = date(row["OrgDate"]) else {
                throw DirectPlanChangeError.malformedChange
            }
            guard found.insert(id).inserted else { throw DirectPlanChangeError.duplicateId }
            let newDate = date(row["Date"])
            let cancellation = row["IsCancelled"] as? Bool
            let shifted = row["IsShifted"] as? Bool
            let kind: DirectPlanChange.Kind
            if cancellation == true { kind = .cancelled }
            else if shifted == true { kind = .shifted }
            else if newDate != nil { kind = .substitution }
            else { kind = .unknown }
            result.append(DirectPlanChange(id: id, originalDate: originalDate,
                originalLessonNumber: lessonNumber(row["OrgLessonNo"]),
                currentDate: newDate, currentLessonNumber: lessonNumber(row["LessonNo"]),
                originalSubjectId: reference(row["OrgSubject"]), currentSubjectId: reference(row["Subject"]),
                originalTeacherId: reference(row["OrgTeacher"]), currentTeacherId: reference(row["Teacher"]),
                originalClassroom: classroom(row["OrgClassroomSymbol"]),
                currentClassroom: classroom(row["ClassroomSymbol"]), kind: kind))
        }
        return DirectPlanChangesSnapshot(changes: result, accountId: accountId, fetchedAt: fetchedAt)
    }
}
