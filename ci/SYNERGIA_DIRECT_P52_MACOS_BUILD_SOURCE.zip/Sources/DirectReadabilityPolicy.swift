import Foundation

/// Pure, platform-independent layout breakpoint; keeps dynamic-type behavior testable
/// without iOS SDK. The adaptive grid automatically uses only one card per row
/// on iPhone widths when the minimum exceeds available width.
enum DirectReadabilityPolicy {
    static func minimumTileWidth(accessibilityText: Bool) -> Double {
        accessibilityText ? 280 : 165
    }

    /// Columns are only a presentation choice, never a data filter.
    static func expectedColumns(availableWidth: Double, accessibilityText: Bool, spacing: Double = 12) -> Int {
        let width = max(0, availableWidth)
        let minimum = minimumTileWidth(accessibilityText: accessibilityText)
        return max(1, Int((width + spacing) / (minimum + spacing)))
    }
}
