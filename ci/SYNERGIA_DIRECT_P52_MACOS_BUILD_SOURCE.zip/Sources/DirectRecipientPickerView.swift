import SwiftUI

/// Wyszukiwalny, duży wybór odbiorcy zamiast menu z setkami pozycji.
/// Nie przechowuje odbiorców ani treści wiadomości na dysku.
struct DirectRecipientPickerView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.dismiss) private var dismiss
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var query = ""
    let snapshot: DirectRecipientListSnapshot

    private var validAccount: Bool {
        portal.store.verifiedAccountId == snapshot.accountId &&
        portal.directRecipientList?.accountId == snapshot.accountId &&
        portal.directRecipientList?.messageSessionId == snapshot.messageSessionId &&
        portal.directRecipientList?.groupId == snapshot.groupId &&
        !portal.privacyShieldActive
    }

    private var results: [DirectRecipient] {
        let search = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !search.isEmpty else { return snapshot.recipients }
        return snapshot.recipients.filter { $0.name.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        NavigationStack {
            List {
                if !validAccount {
                    Label("Konto lub lista odbiorców uległa zmianie. Zamknij okno i pobierz odbiorców ponownie.",
                          systemImage: "lock.shield")
                        .foregroundStyle(.orange)
                } else if results.isEmpty {
                    Text("Brak odbiorców pasujących do wyszukiwania.")
                        .foregroundStyle(.secondary)
                } else {
                    Section("Odbiorcy z aktualnej listy (\(results.count))") {
                        ForEach(results) { recipient in
                            Button {
                                guard validAccount, !portal.directSendBusy,
                                      !portal.directSendReviewRequired else { return }
                                portal.selectDirectRecipient(recipient)
                                dismiss()
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(recipient.name)
                                            .font(.body)
                                            .foregroundStyle(.primary)
                                            .fixedSize(horizontal: false, vertical: true)
                                        if recipient.available == false {
                                            Text("Odbiorca niedostępny")
                                                .font(.footnote).foregroundStyle(.secondary)
                                        } else if recipient.available == nil {
                                            Text("Dostępność niepotwierdzona")
                                                .font(.footnote).foregroundStyle(.secondary)
                                        }
                                    }
                                    Spacer()
                                    if portal.directSelectedRecipient?.id == recipient.id {
                                        Image(systemName: "checkmark.circle.fill")
                                            .accessibilityHidden(true)
                                    }
                                }
                            }
                            .accessibilityLabel(recipient.name +
                                (recipient.available == false ? ", odbiorca niedostępny" :
                                 recipient.available == nil ? ", dostępność niepotwierdzona" : "") +
                                (portal.directSelectedRecipient?.id == recipient.id ? ", zaznaczony" : ""))
                            .accessibilityHint("Wybiera odbiorcę bieżącej wiadomości")
                            .disabled(recipient.available == false || portal.directSendBusy ||
                                      portal.directRecipientBusy || portal.directSendReviewRequired)
                        }
                    }
                }
            }
            .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
                isRegularWidth: horizontalSizeClass == .regular, kind: .loginForm)))
            .frame(maxWidth: .infinity)
            .searchable(text: $query, prompt: "Szukaj po nazwie odbiorcy")
            .navigationTitle("Wybierz odbiorcę")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Zamknij") { dismiss() }
                }
            }
            .onChange(of: portal.store.verifiedAccountId) { _, id in
                if id != snapshot.accountId { dismiss() }
            }
            .onChange(of: portal.privacyShieldActive) { _, enabled in
                if enabled { dismiss() }
            }
        }
    }
}
