import Foundation

/// UI-only eligibility for opening a reply composer from a verified message.
/// This does not send a message, fetch data or mutate a draft. The portal
/// remains the authority for preparing a reply and can still reject it.
enum DirectReplyPresentationPolicy {
    static func canOffer(detail: DirectMessageDetail,
                         snapshot: DirectMailboxSnapshot?,
                         verifiedAccountId: String?,
                         privacyShielded: Bool,
                         operationBusy: Bool,
                         reviewRequired: Bool) -> Bool {
        guard !privacyShielded, !operationBusy, !reviewRequired,
              let accountId = verifiedAccountId, !accountId.isEmpty,
              detail.mailbox == .inbox, detail.replyAllowed,
              let senderId = detail.senderId,
              DirectMessageParser.safeIdentifier(senderId),
              let snapshot,
              snapshot.mailbox == .inbox,
              snapshot.accountId == accountId else { return false }
        return snapshot.messages.contains { $0.mailbox == .inbox && $0.id == detail.id }
    }
}
