import Foundation
import CoreFoundation

/// Optional metadata from HomeWorks (school agenda, NOT HomeWorkAssignments).
/// A missing or malformed source field stays unknown; nothing is inferred from
/// the student's timetable or an unrelated homework record.
struct DirectSchoolAgendaEvent: Codable, Equatable {
    let day: String?
    let endDay: String?
    let body: String?
    let categoryName: String?
    let categoryId: String?
    let subjectName: String?
    let subjectId: String?
    let lessonNumber: String?

    static func parse(_ record: [String: Any]) -> DirectSchoolAgendaEvent {
        let category = record["Category"] as? [String: Any]
        let subject = record["Subject"] as? [String: Any]
        let content = text(record["Content"])
        return DirectSchoolAgendaEvent(
            day: validDay(record["Date"]), endDay: validDay(record["EndDate"]),
            body: content.flatMap { DirectSchoolNotice.plainText($0) },
            categoryName: text(category?["Name"]) ?? text(record["CategoryName"]),
            categoryId: id(category?["Id"]),
            subjectName: text(subject?["Name"]) ?? text(record["SubjectName"]),
            subjectId: id(subject?["Id"]), lessonNumber: id(record["LessonNo"])
        )
    }

    static func text(_ input: Any?) -> String? {
        guard let raw = input as? String else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value.count <= 12_000,
              !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) && $0.value != 10 }) else {
            return nil
        }
        return value
    }

    private static func id(_ input: Any?) -> String? {
        if let raw = input as? String {
            let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            return s.isEmpty || s.count > 128 || !s.allSatisfy({ $0.isNumber }) ? nil : s
        }
        if let number = input as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
           number.doubleValue >= 0, number.doubleValue == Double(number.int64Value) {
            return number.stringValue
        }
        return nil
    }

    /// Date or timestamp with a YYYY-MM-DD calendar prefix; never silently
    /// normalize invalid dates such as February 30.
    static func validDay(_ value: Any?) -> String? {
        guard let raw = value as? String, raw.count >= 10, raw.count <= 64 else { return nil }
        let prefix = String(raw.prefix(10))
        let chars = Array(prefix)
        guard chars.count == 10, chars[4] == "-", chars[7] == "-",
              chars.enumerated().allSatisfy({ [4,7].contains($0.offset) || $0.element.isASCII && $0.element.isNumber }),
              raw.count == 10 || (raw.dropFirst(10).first == "T" || raw.dropFirst(10).first == " ") else { return nil }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let year = Int(prefix.prefix(4))!
        let month = Int(prefix.dropFirst(5).prefix(2))!
        let day = Int(prefix.suffix(2))!
        guard (1900...2200).contains(year),
              let check = calendar.date(from: DateComponents(year: year, month: month, day: day)),
              calendar.component(.year, from: check) == year,
              calendar.component(.month, from: check) == month,
              calendar.component(.day, from: check) == day else { return nil }
        return prefix
    }
}

/// Pure presentation policy — sorting/filtering must not change cache contents.
enum DirectSchoolAgendaPresentation {
    enum Period: Int { case all = 0, upcoming = 1, past = 2, undated = 3 }

    static func entries(_ feed: DirectSchoolFeed, query: String = "", period: Period = .all,
                        today: String) -> [DirectSchoolFeedEntry] {
        guard feed.module == .calendar else { return [] }
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let matched = feed.records.filter { entry in
            let day = entry.agenda?.day
            let inPeriod: Bool
            switch period {
            case .all: inPeriod = true
            case .upcoming: inPeriod = day.map({ $0 >= today }) ?? false
            case .past: inPeriod = day.map({ $0 < today }) ?? false
            case .undated: inPeriod = day == nil
            }
            return inPeriod && (needle.isEmpty || entry.title.localizedCaseInsensitiveContains(needle) ||
                (entry.agenda?.body?.localizedCaseInsensitiveContains(needle) ?? false) ||
                (entry.agenda?.categoryName?.localizedCaseInsensitiveContains(needle) ?? false) ||
                (entry.agenda?.subjectName?.localizedCaseInsensitiveContains(needle) ?? false))
        }
        return matched.sorted {
            switch ($0.agenda?.day, $1.agenda?.day) {
            case let (lhs?, rhs?): return lhs == rhs ? $0.title.localizedStandardCompare($1.title) == .orderedAscending : lhs < rhs
            case (.some, .none): return true
            case (.none, .some): return false
            case (.none, .none): return $0.title.localizedStandardCompare($1.title) == .orderedAscending
            }
        }
    }

    static func groups(_ entries: [DirectSchoolFeedEntry]) -> [(day: String, entries: [DirectSchoolFeedEntry])] {
        var result: [(day: String, entries: [DirectSchoolFeedEntry])] = []
        for entry in entries {
            let day = entry.agenda?.day ?? "Bez rozpoznanej daty"
            if let last = result.indices.last, result[last].day == day { result[last].entries.append(entry) }
            else { result.append((day, [entry])) }
        }
        return result
    }
}
