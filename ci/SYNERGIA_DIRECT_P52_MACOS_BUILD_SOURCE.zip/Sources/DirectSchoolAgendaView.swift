import SwiftUI

/// Read-only HomeWorks agenda. Explicitly separate from assignments and weekly plan.
struct DirectSchoolAgendaView: View {
    let feed: DirectSchoolFeed
    @State private var search = ""
    @State private var selectedPeriod = 0

    private var today: String {
        var formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Warsaw")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    private var filtered: [DirectSchoolFeedEntry] {
        DirectSchoolAgendaPresentation.entries(feed, query: search,
            period: DirectSchoolAgendaPresentation.Period(rawValue: selectedPeriod) ?? .all, today: today)
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Szukaj wydarzeń i kategorii", text: $search)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Picker("Zakres wydarzeń", selection: $selectedPeriod) {
                Text("Wszystkie").tag(0)
                Text("Nadchodzące").tag(1)
                Text("Minione").tag(2)
                Text("Bez daty").tag(3)
            }.pickerStyle(.menu)
            Text("Wyświetlono \(filtered.count) z \(feed.records.count) odczytanych wpisów. " +
                 "Nie jest to potwierdzenie kompletności całego terminarza.")
                .font(.caption).foregroundStyle(.secondary)
            if filtered.isEmpty {
                Text("Brak wpisów spełniających wybrane kryteria.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(Array(DirectSchoolAgendaPresentation.groups(filtered).enumerated()), id: \.offset) { _, group in
                VStack(alignment: .leading, spacing: 6) {
                    Text(group.day).font(.headline).foregroundStyle(.indigo)
                    ForEach(group.entries) { entry in
                        VStack(alignment: .leading, spacing: 5) {
                            Text(entry.title).font(.subheadline.bold()).textSelection(.enabled)
                            if let info = entry.agenda {
                                if let label = info.categoryName {
                                    Label(label, systemImage: "tag").font(.caption)
                                } else if info.categoryId != nil {
                                    Text("Kategoria: nazwa niedostępna").font(.caption).foregroundStyle(.secondary)
                                }
                                if let subject = info.subjectName { Text("Przedmiot: \(subject)").font(.caption) }
                                if let lesson = info.lessonNumber { Text("Lekcja: \(lesson)").font(.caption) }
                                if let end = info.endDay, end != info.day { Text("Do: \(end)").font(.caption) }
                                if let body = info.body, body != entry.title {
                                    Text(body).font(.subheadline).textSelection(.enabled)
                                }
                            } else {
                                Text("Starszy format zapisu. Odśwież po zalogowaniu, aby uzyskać szczegóły.")
                                    .font(.caption).foregroundStyle(.secondary)
                                ForEach(Array(entry.details.enumerated()), id: \.offset) { detail in
                                    Text(detail.element).font(.caption).textSelection(.enabled)
                                }
                            }
                            Divider()
                        }.padding(.vertical, 4)
                    }
                }
            }
            Text("Terminarz (HomeWorks) i zadania domowe (HomeWorkAssignments) są niezależne. " +
                 "Brak nazwy kategorii nie oznacza, że wydarzenie jej nie ma. " +
                 "Zapis offline może być nieaktualny.")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .onChange(of: feed.verifiedAccountId) { _, _ in search = ""; selectedPeriod = 0 }
    }
}
