import Foundation

/// Optional, read-only metadata from SchoolFiles.Data. A missing field stays unknown.
/// `fileStatus` is shown verbatim as a passive label: it never authorizes a download.
struct DirectSchoolDocument: Equatable, Codable {
    let addedDay: String?
    let serverStatus: String?

    static func parse(_ record: [String: Any]) -> DirectSchoolDocument {
        let status = DirectSchoolAgendaEvent.text(record["fileStatus"])
            .flatMap { DirectSchoolNotice.plainText($0) }
            .flatMap { $0.count <= 120 ? $0 : nil }
        return DirectSchoolDocument(
            addedDay: DirectSchoolAgendaEvent.validDay(record["addedOnDate"]),
            serverStatus: status
        )
    }
}

/// Filters and sorting only. Does not write to Synergia, infer file MIME types,
/// or turn a server-provided status string into download permission.
enum DirectSchoolDocumentsPresentation {
    enum Availability: Int, CaseIterable {
        case all = 0, verifiedLink = 1, noVerifiedLink = 2
    }
    enum Order: Int, CaseIterable {
        case name = 0, newest = 1
    }

    /// A filename extension is merely a hint from the name, not a verified MIME type.
    static func filenameExtension(_ name: String) -> String? {
        guard !name.isEmpty, name.count <= 240, !name.hasPrefix("."),
              !name.contains("/"), !name.contains("\\"),
              !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              let dot = name.lastIndex(of: "."), dot != name.startIndex else { return nil }
        let suffix = String(name[name.index(after: dot)...])
        guard (1...12).contains(suffix.utf8.count),
              suffix.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) }) else { return nil }
        return suffix.lowercased()
    }

    /// Duplicate server IDs make a download ambiguous; both entries remain visible,
    /// but neither is authorized as a trustworthy download target.
    static func uniqueDownloadReference(_ entry: DirectSchoolFeedEntry,
                                        in feed: DirectSchoolFeed) -> DirectSchoolFileReference? {
        guard feed.module == .documents, let file = entry.schoolFile,
              entry.serverId == file.id,
              (try? DirectSchoolFilePolicy.documentURL(file)) != nil,
              feed.records.filter({ $0.serverId == file.id }).count == 1 else { return nil }
        return file
    }

    static func extensions(_ feed: DirectSchoolFeed) -> [String] {
        guard feed.module == .documents else { return [] }
        return Array(Set(feed.records.compactMap { filenameExtension($0.title) })).sorted()
    }

    static func entries(_ feed: DirectSchoolFeed, query: String = "",
                        availability: Availability = .all, extensionFilter: String? = nil,
                        order: Order = .name) -> [DirectSchoolFeedEntry] {
        guard feed.module == .documents else { return [] }
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let filtered = feed.records.filter { entry in
            let available = uniqueDownloadReference(entry, in: feed) != nil
            let matchesAvailability: Bool
            switch availability {
            case .all: matchesAvailability = true
            case .verifiedLink: matchesAvailability = available
            case .noVerifiedLink: matchesAvailability = !available
            }
            let matchesExtension = extensionFilter == nil ||
                filenameExtension(entry.title) == extensionFilter
            let matchesTerm = term.isEmpty || entry.title.localizedCaseInsensitiveContains(term) ||
                (entry.document?.serverStatus?.localizedCaseInsensitiveContains(term) ?? false) ||
                (entry.document?.addedDay?.contains(term) ?? false) ||
                (filenameExtension(entry.title)?.localizedCaseInsensitiveContains(term) ?? false)
            return matchesAvailability && matchesExtension && matchesTerm
        }
        return filtered.sorted { a, b in
            if order == .newest, a.document?.addedDay != b.document?.addedDay {
                switch (a.document?.addedDay, b.document?.addedDay) {
                case let (lhs?, rhs?): return lhs > rhs
                case (.some, .none): return true
                case (.none, .some): return false
                default: break
                }
            }
            let nameOrder = a.title.localizedStandardCompare(b.title)
            if nameOrder != .orderedSame { return nameOrder == .orderedAscending }
            return (a.serverId ?? a.id) < (b.serverId ?? b.id)
        }
    }
}
