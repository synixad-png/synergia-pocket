import Foundation

/// Read-only normalized display records. The parser does not infer missing data,
/// silently accept unrecognized API response formats, or claim completeness.
struct DirectSchoolFeedEntry: Identifiable, Equatable, Codable {
    let id: String
    let title: String
    let details: [String]
    let schoolFile: DirectSchoolFileReference?
    let serverId: String?
    let homeworkFiles: [DirectHomeworkFileReference]?
    let notice: DirectSchoolNotice?
    let agenda: DirectSchoolAgendaEvent?
    let homework: DirectHomeworkAssignment?
    let document: DirectSchoolDocument?
}

struct DirectSchoolFeed: Equatable, Codable {
    let module: SchoolModule
    let records: [DirectSchoolFeedEntry]
    let fetchedAt: Date
    let reportedTotal: Int?
    let verifiedAccountId: String
    var completenessKnown: Bool { reportedTotal.map { $0 == records.count } ?? false }
}

enum DirectSchoolFeedError: Error, LocalizedError {
    case unsupportedModule, unknownShape, malformedEntry, excessiveRecords, invalidTotal
    var errorDescription: String? {
        switch self {
        case .unsupportedModule: return "Ten moduł nie obsługuje jeszcze bezpośredniego JSON."
        case .unknownShape: return "Nierozpoznany format odpowiedzi: nie zapisano niepotwierdzonych danych."
        case .malformedEntry: return "Niekompletny lub nieprawidłowy wpis serwera."
        case .excessiveRecords: return "Zbyt wiele wpisów w odpowiedzi; odczyt zatrzymano."
        case .invalidTotal: return "Niespójny licznik wpisów."
        }
    }
}

enum DirectSchoolFeedParser {
    static func resource(for module: SchoolModule) throws -> SynergiaGatewayClient.Resource {
        switch module {
        case .homework: return .homeworkAssignments
        case .calendar: return .homework
        case .announcements: return .schoolNotices
        case .documents: return .schoolFiles
        default: throw DirectSchoolFeedError.unsupportedModule
        }
    }

    static func parse(_ root: [String: Any], module: SchoolModule, accountId: String,
                      date: Date = Date()) throws -> DirectSchoolFeed {
        let primary: String
        switch module {
        case .homework: primary = "HomeWorkAssignments"
        case .calendar: primary = "HomeWorks"
        case .announcements: primary = "SchoolNotices"
        case .documents: primary = "Data"
        default: throw DirectSchoolFeedError.unsupportedModule
        }
        let payload = root[primary]
        let records: [[String: Any]]
        if let list = payload as? [[String: Any]] { records = list }
        else if let dictionary = payload as? [String: Any],
                let list = (dictionary["Items"] ?? dictionary["items"] ?? dictionary["Data"]) as? [[String: Any]] {
            records = list
        } else { throw DirectSchoolFeedError.unknownShape }
        guard records.count <= 500 else { throw DirectSchoolFeedError.excessiveRecords }
        let totalRaw = root["Total"] ?? root["total"] ?? root["TotalCount"]
        let total: Int?
        if let number = totalRaw as? NSNumber {
            let n = number.intValue
            guard n >= records.count, n >= 0, n <= 100_000, number.doubleValue == Double(n) else {
                throw DirectSchoolFeedError.invalidTotal
            }
            total = n
        } else if totalRaw == nil { total = nil }
        else { throw DirectSchoolFeedError.invalidTotal }
        // An empty response with no count is not proof that there are no records.
        guard !records.isEmpty || total == 0 else { throw DirectSchoolFeedError.unknownShape }
        let entries = try records.enumerated().map { offset, record -> DirectSchoolFeedEntry in
            let title = firstText(record, keys: titleKeys(module))
            let subtitle = firstText(record, keys: ["Description", "Content", "Body", "Text", "Note"])
            let heading = module == .calendar ?
                (firstText(record, keys: ["Title", "Name", "Event"]).flatMap { DirectSchoolNotice.plainText($0) } ??
                 (record["Content"] as? String).flatMap { DirectSchoolNotice.plainText($0) }) :
                module == .announcements ?
                (firstText(record, keys: ["Subject", "Title", "Name"]) ??
                 (record["Content"] as? String).flatMap { DirectSchoolNotice.plainText($0) }) :
                module == .homework ?
                (title ?? subtitle).flatMap { DirectSchoolNotice.plainText($0) } :
                (title ?? subtitle)
            guard let heading, !heading.isEmpty else { throw DirectSchoolFeedError.malformedEntry }
            var parts: [String] = []
            for (field, label) in [("Date", "Data"), ("StartDate", "Od"),
                                    ("EndDate", "Do"), ("DueDate", "Do"),
                                    ("Deadline", "Termin"), ("CreationDate", "Dodano"),
                                    ("addedOnDate", "Dodano"), ("fileStatus", "Status"),
                                    ("Topic", "Temat"), ("Text", "Treść"),
                                    ("LessonNo", "Lekcja"), ("Subject", "Przedmiot"),
                                    ("Teacher", "Nauczyciel"), ("Description", "Opis"),
                                    ("Content", "Treść"), ("Body", "Treść")] {
                if (module == .announcements || module == .calendar) && (field == "Content" || field == "Body") { continue }
                if let value = cleanText(record[field]), value != heading {
                    let item = "\(label): \(value)"
                    if !parts.contains(item) { parts.append(item) }
                }
            }
            // Positional identity is scoped to one feed snapshot, not a stable
            // server ID. Never use it for detecting added/deleted records.
            let attachments = module == .homework ? try DirectHomeworkFilePolicy.parse(record) : nil
            // Stable identifiers only when provided by the service; position in
            // a response is NOT a stable key for detecting changes.
            let rawId = record[module == .documents ? "id" : "Id"]
            let serverId: String?
            if let number = rawId as? NSNumber { serverId = number.stringValue }
            else if let value = rawId as? String, !value.isEmpty, value.count <= 128 { serverId = value }
            else { serverId = nil }
            return DirectSchoolFeedEntry(id: "\(module.rawValue)-\(offset)", title: heading, details: parts,
                                         schoolFile: module == .documents ? DirectSchoolFilePolicy.parse(record) : nil,
                                         serverId: serverId, homeworkFiles: attachments,
                                         notice: module == .announcements ? DirectSchoolNotice.parse(record) : nil,
                                         agenda: module == .calendar ? DirectSchoolAgendaEvent.parse(record) : nil,
                                         homework: module == .homework ? DirectHomeworkAssignment.parse(record) : nil,
                                         document: module == .documents ? DirectSchoolDocument.parse(record) : nil)
        }
        return DirectSchoolFeed(module: module, records: entries, fetchedAt: date,
                                reportedTotal: total, verifiedAccountId: accountId)
    }

    private static func titleKeys(_ module: SchoolModule) -> [String] {
        switch module {
        case .homework: return ["Topic", "Text", "Title", "Description"]
        case .calendar: return ["Content", "Title", "Name", "Event", "Description"]
        case .announcements: return ["Subject", "Title", "Name", "Content"]
        case .documents: return ["displayName", "name", "Name"]
        default: return []
        }
    }
    private static func firstText(_ dictionary: [String: Any], keys: [String]) -> String? {
        for key in keys { if let value = cleanText(dictionary[key]) { return value } }
        return nil
    }
    private static func cleanText(_ value: Any?) -> String? {
        guard let value else { return nil }
        // Nested dictionaries and arrays are references, not display values.
        guard !(value is [String: Any]), !(value is [Any]), !(value is NSNull) else { return nil }
        let string: String
        if let s = value as? String { string = s }
        else if let number = value as? NSNumber { string = number.stringValue }
        else { return nil }
        let clean = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, clean.count <= 12_000 else { return nil }
        return clean
    }
}
