import Foundation
import CoreFoundation

/// A link from SchoolFiles, not from any HTML page or user text.
/// Only this exact Synergia endpoint may receive Synergia session cookies.
struct DirectSchoolFileReference: Equatable, Identifiable, Codable {
    let id: String
    let displayName: String
    let path: String
}

enum DirectSchoolFileError: Error, LocalizedError, Equatable {
    case invalidReference, untrustedRedirect, invalidResponse, fileTooLarge, emptyFile, accountChanged
    var errorDescription: String? {
        switch self {
        case .invalidReference: return "Dokument ma nieprawidłowy identyfikator lub adres pobierania."
        case .untrustedRedirect: return "Zablokowano niepotwierdzony adres przekierowania dokumentu."
        case .invalidResponse: return "Serwer nie zwrócił poprawnego pliku."
        case .fileTooLarge: return "Plik przekracza limit 15 MB."
        case .emptyFile: return "Serwer zwrócił pusty plik."
        case .accountChanged: return "Konto lub sesja zmieniły się podczas pobierania."
        }
    }
}

enum DirectSchoolFilePolicy {
    static let maxBytes = 15_000_000
    static let prefix = "/pliki_szkoly/pobierz/"

    private static func identifier(_ raw: Any?) -> String? {
        let text: String
        if let string = raw as? String { text = string }
        else if let num = raw as? NSNumber, CFGetTypeID(num) != CFBooleanGetTypeID(),
                num.doubleValue == Double(num.int64Value) {
            text = num.stringValue
        } else { return nil }
        guard (1...64).contains(text.count), text.utf8.allSatisfy({
            (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95
        }) else { return nil }
        return text
    }

    static func parse(_ item: [String: Any]) -> DirectSchoolFileReference? {
        guard let id = identifier(item["id"]),
              let name = item["displayName"] as? String,
              !name.isEmpty, name.count <= 240,
              name == name.trimmingCharacters(in: .whitespacesAndNewlines),
              !name.hasPrefix("."), !name.contains("/"), !name.contains("\\"),
              !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              let link = item["downloadUrl"] as? String,
              link == prefix + id else { return nil }
        return DirectSchoolFileReference(id: id, displayName: name, path: link)
    }

    static func documentURL(_ file: DirectSchoolFileReference) throws -> URL {
        guard file.path == prefix + file.id,
              identifier(file.id) == file.id,
              !file.displayName.isEmpty,
              let url = URL(string: "https://synergia.librus.pl" + file.path),
              url.scheme == "https", url.host == "synergia.librus.pl", url.query == nil,
              url.fragment == nil, url.user == nil, url.password == nil else {
            throw DirectSchoolFileError.invalidReference
        }
        return url
    }

    /// Only the documented GetFile ticket on the official Librus sandbox.
    static func redirectTicket(_ location: String) throws -> URL {
        guard let url = URL(string: location),
              url.scheme == "https", url.host?.lowercased() == "sandbox.librus.pl",
              url.port == nil, url.user == nil, url.password == nil, url.fragment == nil,
              url.query == nil,
              url.path.hasPrefix("/GetFile/"),
              url.path.count > "/GetFile/".count,
              !url.path.hasSuffix("/get"),
              !url.path.contains(".."), !url.path.contains("%"),
              url.path.utf8.count <= 2048 else { throw DirectSchoolFileError.untrustedRedirect }
        return url
    }

    static func actualDownloadURL(_ ticket: URL) throws -> URL {
        let checked = try redirectTicket(ticket.absoluteString)
        let target = checked.appendingPathComponent("get")
        guard target.host == checked.host, target.scheme == "https", target.query == nil,
              target.fragment == nil, target.path == checked.path + "/get" else {
            throw DirectSchoolFileError.untrustedRedirect
        }
        return target
    }

    static func validFileResponse(status: Int, contentType: String?, length: Int64) -> Bool {
        guard status == 200, length <= Int64(maxBytes) else { return false }
        if let type = contentType?.lowercased(),
           type.contains("text/html") || type.contains("application/xhtml") ||
           type.contains("text/xml") { return false }
        return true
    }
}
