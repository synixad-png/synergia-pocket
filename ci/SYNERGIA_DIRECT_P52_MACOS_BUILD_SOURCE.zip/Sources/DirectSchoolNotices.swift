import Foundation
import CoreFoundation

/// Optional, read-only metadata. `nil` means the server did not supply a
/// supported value; it must never be interpreted as read/unread.
struct DirectSchoolNotice: Codable, Equatable {
    let body: String?
    let wasRead: Bool?
    let startDate: String?
    let endDate: String?
    let creationDate: String?
    let authorId: String?

    static func parse(_ json: [String: Any]) -> DirectSchoolNotice {
        let content = json["Content"] as? String
        let plain = content.flatMap { plainText($0) }
        let wasRead: Bool?
        if let value = json["WasRead"] as? NSNumber,
           CFGetTypeID(value) == CFBooleanGetTypeID() {
            wasRead = value.boolValue
        } else { wasRead = nil }
        let by = json["AddedBy"] as? [String: Any]
        let authorId: String?
        if let id = by?["Id"] as? String, !id.isEmpty, id.count <= 128 { authorId = id }
        else if let id = by?["Id"] as? NSNumber, CFGetTypeID(id) != CFBooleanGetTypeID() {
            authorId = id.stringValue
        } else { authorId = nil }
        return DirectSchoolNotice(body: plain, wasRead: wasRead,
            startDate: dateText(json["StartDate"]),
            endDate: dateText(json["EndDate"]),
            creationDate: dateText(json["CreationDate"]), authorId: authorId)
    }

    private static func dateText(_ value: Any?) -> String? {
        guard let value = value as? String else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.count <= 64,
              !trimmed.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
        else { return nil }
        return trimmed
    }

    /// Show HTML as inert, selectable text; never render remote scripts, images,
    /// embedded frames or links inside a privileged web view.
    static func plainText(_ html: String) -> String? {
        guard !html.isEmpty, html.count <= 120_000 else { return nil }
        let stripped = html.replacingOccurrences(of: "(?is)<(script|style|iframe|object|svg)\\b[^>]*>.*?</\\1\\s*>",
            with: "", options: .regularExpression)
        let blockSeparated = stripped.replacingOccurrences(
            of: "(?i)</?(br|p|div|li|tr|h[1-6])\\b[^>]*>", with: "\n", options: .regularExpression)
        let withoutTags = blockSeparated.replacingOccurrences(of: "<[^>]*>", with: "", options: .regularExpression)
        var decoded = withoutTags
        for (entity, replacement) in ["&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">",
                                      "&quot;": "\"", "&#39;": "'", "&apos;": "'", "&ndash;": "–", "&mdash;": "—"] {
            decoded = decoded.replacingOccurrences(of: entity, with: replacement)
        }
        let numerical = try? NSRegularExpression(pattern: "&#(x[0-9a-fA-F]{1,6}|[0-9]{1,7});")
        if let numerical {
            let matches = numerical.matches(in: decoded, range: NSRange(decoded.startIndex..., in: decoded))
            for match in matches.reversed() {
                guard let capture = Range(match.range(at: 1), in: decoded),
                      let replacementRange = Range(match.range, in: decoded) else { continue }
                let encoded = String(decoded[capture])
                let hex = encoded.lowercased().hasPrefix("x")
                let digits = hex ? String(encoded.dropFirst()) : encoded
                if let code = UInt32(digits, radix: hex ? 16 : 10),
                   let scalar = UnicodeScalar(code),
                   !CharacterSet.controlCharacters.contains(scalar) || code == 10 {
                    decoded.replaceSubrange(replacementRange, with: String(scalar))
                }
            }
        }
        let lines = decoded.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        let normalized = lines.filter { !$0.isEmpty }.joined(separator: "\n")
        guard !normalized.isEmpty, normalized.count <= 12_000 else { return nil }
        return normalized
    }
}

/// Pure bounded merger. A repeated or missing server ID is an error rather
/// than proof the last page was read. The official total is never invented.
enum DirectSchoolNoticePagingError: Error, Equatable {
    case malformedPage, duplicateIdentifier, tooManyPages, conflictingTotal
}

enum DirectSchoolNoticePaging {
    static let pageSize = 50
    static let maximumPages = 5

    static func rowCount(_ root: [String: Any]) throws -> Int {
        guard let rows = root["SchoolNotices"] as? [[String: Any]], rows.count <= 500 else {
            throw DirectSchoolNoticePagingError.malformedPage
        }
        return rows.count
    }

    static func merge(_ pages: [[String: Any]], accountId: String, date: Date = Date()) throws -> DirectSchoolFeed {
        guard !pages.isEmpty, pages.count <= maximumPages else { throw DirectSchoolNoticePagingError.tooManyPages }
        var rows = [[String: Any]]()
        var ids = Set<String>()
        var announcedTotal: Int?
        for page in pages {
            guard let sourceRows = page["SchoolNotices"] as? [[String: Any]],
                  sourceRows.count <= 500 else { throw DirectSchoolNoticePagingError.malformedPage }
            if let rawTotal = page["Total"] ?? page["total"] ?? page["TotalCount"] {
                guard let n = rawTotal as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
                      n.intValue >= 0, n.intValue <= 100_000, n.doubleValue == Double(n.intValue),
                      announcedTotal == nil || announcedTotal == n.intValue else {
                    throw DirectSchoolNoticePagingError.conflictingTotal
                }
                announcedTotal = n.intValue
            }
            for row in sourceRows {
                let serverId: String
                if let id = row["Id"] as? String, !id.isEmpty, id.count <= 128 { serverId = id }
                else if let n = row["Id"] as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID() {
                    serverId = n.stringValue
                } else { throw DirectSchoolNoticePagingError.malformedPage }
                guard ids.insert(serverId).inserted else { throw DirectSchoolNoticePagingError.duplicateIdentifier }
                rows.append(row)
                guard rows.count <= 500 else { throw DirectSchoolNoticePagingError.tooManyPages }
            }
        }
        guard !rows.isEmpty || announcedTotal == 0 else { throw DirectSchoolNoticePagingError.malformedPage }
        guard announcedTotal == nil || announcedTotal! >= rows.count else {
            throw DirectSchoolNoticePagingError.conflictingTotal
        }
        // Pass the official global total only when present in the response.
        var combined: [String: Any] = ["SchoolNotices": rows]
        if let announcedTotal { combined["Total"] = announcedTotal }
        return try DirectSchoolFeedParser.parse(combined, module: .announcements,
                                                accountId: accountId, date: date)
    }
}
