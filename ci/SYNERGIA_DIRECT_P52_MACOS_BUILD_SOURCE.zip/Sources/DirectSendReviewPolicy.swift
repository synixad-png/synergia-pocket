import Foundation

/// Wynik wysłania może być niejednoznaczny, nawet jeśli połączenie się zakończyło.
/// Blokada chroni przed przypadkowym ponowieniem tego samego POST.
enum DirectSendReviewPolicy {
    static let reviewRequiredMessage =
        "Wysyłka może być zakończona sukcesem. Sprawdź najpierw folder Wysłane. " +
        "Nie wysyłaj ponownie bez sprawdzenia, aby nie utworzyć duplikatu."

    static func requiresReview(_ result: DirectSendResult) -> Bool {
        if case .uncertain = result { return true }
        return false
    }

    static func status(_ result: DirectSendResult) -> String {
        switch result {
        case .sent(let id):
            return "Serwer potwierdził wysyłkę" + (id.map { " (nr \($0))" } ?? "") + ". Sprawdź folder Wysłane."
        case .refused(let reason):
            return "NIE WYSŁANO: " + reason
        case .uncertain(let reason):
            return "STATUS NIEPEWNY: " + reason + " " + reviewRequiredMessage
        }
    }

    static func preview(destination: String, draft: DirectValidatedDraft) -> String {
        let body = draft.text
        // No logging or disk cache. The full body stays visible in the editor.
        let excerpt = String(body.prefix(220)) + (body.count > 220 ? "…" : "")
        return "Do: \(destination)\nTemat: \(draft.subject)\n" +
            "Tryb: \(draft.originalMessageId == nil ? "Nowa wiadomość" : "Odpowiedź")\n" +
            "Treść: \(excerpt)\n" +
            "Sprawdź dokładnie odbiorcę, temat i treść przed wysłaniem."
    }
}
