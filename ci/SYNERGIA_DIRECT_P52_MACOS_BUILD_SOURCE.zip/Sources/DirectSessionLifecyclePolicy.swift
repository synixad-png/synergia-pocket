import Foundation

/// Coordinates live identity verification with WebKit navigation, backgrounding
/// and asynchronous local sign-out. Never stores credentials or assumes a login.
struct DirectSessionLifecyclePolicy {
    private(set) var verificationInFlight = false
    private(set) var isClearing = false

    /// A second /Me check is rejected until the current verification terminates
    /// or has been invalidated by navigation/backgrounding.
    mutating func beginVerification() -> Bool {
        guard !isClearing && !verificationInFlight else { return false }
        verificationInFlight = true
        return true
    }

    mutating func finishVerification() {
        verificationInFlight = false
    }

    /// The Portal invalidates its captured account epoch at the same time.
    /// Late responses may not reopen a cancelled identity check.
    mutating func cancelVerification() {
        verificationInFlight = false
    }

    /// Sign-out must be atomic relative to any new session verification.
    mutating func beginCleanup() -> Bool {
        guard !isClearing else { return false }
        isClearing = true
        verificationInFlight = false
        return true
    }

    /// Call only when the WebKit data-store purge callback has completed.
    mutating func finishCleanup() {
        isClearing = false
    }
}
