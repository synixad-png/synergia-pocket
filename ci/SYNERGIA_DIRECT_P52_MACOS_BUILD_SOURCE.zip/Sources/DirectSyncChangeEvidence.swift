import Foundation

/// Audit of two authenticated manual reads. A server snapshot is an observation,
/// not an authoritative school event. In particular, absence is never deletion.
/// This policy never stores student identifiers or any message/grade contents.
enum DirectChangeConfidence: Equatable {
    case noBaseline
    case reliableObservation
    case partialRead
    case missingRecords
    case unavailable
}

struct DirectEvaluatedChange: Equatable {
    let confidence: DirectChangeConfidence
    let added: Int
    let changed: Int
    let absentUnconfirmed: Int
    let description: String

    var mayNotify: Bool { confidence == .reliableObservation && (added > 0 || changed > 0) }
}

enum DirectSyncChangeEvidence {
    /// Count changes only after two comparable reads of one verified account.
    /// Callers verify /Me before/after the transport, the account epoch and IDs.
    static func evaluate(name: String, baseline: Bool, fetched: Bool,
                         complete: Bool, observedAdded: Int, observedChanged: Int,
                         absent: Int) -> DirectEvaluatedChange {
        let quality: DirectChangeConfidence
        if !fetched || min(observedAdded, observedChanged, absent) < 0 {
            quality = .unavailable
        } else if !complete {
            quality = .partialRead
        } else if !baseline {
            quality = .noBaseline
        } else if absent > 0 {
            quality = .missingRecords
        } else {
            quality = .reliableObservation
        }
        let safeAdded = quality == .reliableObservation ? observedAdded : 0
        let safeChanged = quality == .reliableObservation ? observedChanged : 0
        let hint: String
        switch quality {
        case .noBaseline:
            hint = "pierwszy odczyt jest punktem odniesienia; brak alarmu o nowych wpisach"
        case .unavailable:
            hint = "nie odczytano wiarygodnych danych; wyników nie porównano"
        case .partialRead:
            hint = "odczyt niekompletny; nie zgłoszono nowych ani zmienionych wpisów"
        case .missingRecords:
            hint = "\(absent) wcześniejszych wpisów nie widać; porównanie wstrzymane, usunięcia niepotwierdzone"
        case .reliableObservation:
            hint = "w dwóch porównywalnych odczytach zaobserwowano: nowe \(safeAdded), zmienione \(safeChanged); nie jest to oficjalny rejestr zmian"
        }
        return DirectEvaluatedChange(confidence: quality, added: safeAdded,
            changed: safeChanged, absentUnconfirmed: max(0, absent),
            description: "\(name): \(hint).")
    }
}
