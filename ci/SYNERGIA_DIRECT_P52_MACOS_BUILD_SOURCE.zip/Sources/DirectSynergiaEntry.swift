import Foundation

/// Explains the current official page without inferring authentication from it.
/// A successful authenticated GET /Me remains the only account proof.
enum DirectSynergiaEntry {
    static let journalURL = URL(string: "https://synergia.librus.pl")!
    /// Entry used by the school-credential form (not Konto LIBRUS e-mail login).
    /// Reported by maintainers of the third-party Librus API after April 2026's login changes.
    /// Authentication success is never assumed: /Me must still return the school account.
    static let schoolLoginURL = URL(string: "https://synergia.librus.pl/loguj/portalRodzina")!
    /// Fallback school login page, with its own official on-domain form.
    static let backupSchoolLoginURL = URL(string: "https://www.librus.com.pl/")!

    static func isSchoolLoginForm(_ url: URL?) -> Bool {
        guard let url, url.scheme?.lowercased() == "https",
              url.host?.lowercased() == "synergia.librus.pl",
              url.user == nil, url.password == nil, url.port == nil else { return false }
        return url.path.lowercased().hasPrefix("/loguj") || url.path.lowercased().hasPrefix("/login")
    }

    static func origin(_ url: URL?) -> String {
        guard let url, url.scheme?.lowercased() == "https", let host = url.host?.lowercased() else {
            return "Nie ustalono bezpiecznej strony"
        }
        if isSchoolLoginForm(url) { return "Formularz logowania szkolnego Synergia" }
        if host == "synergia.librus.pl" { return "Dziennik Synergia" }
        if host == "www.librus.com.pl" { return "Alternatywny formularz szkolny Librus" }
        if host == "wiadomosci.librus.pl" { return "Wiadomości Synergii" }
        if isPublicPortal(url) { return "Portal informacyjny Librus — to nie dziennik" }
        return "Inna strona — konto niepotwierdzone"
    }

    /// Public marketing/login pages are NOT school diary pages. This check
    /// does not reveal whether the user has previously authenticated elsewhere.
    static func isPublicPortal(_ url: URL?) -> Bool {
        guard let url, url.scheme?.lowercased() == "https",
              let host = url.host?.lowercased() else { return false }
        return ["portal.librus.pl", "rodzina.librus.pl", "www.librus.pl", "librus.pl"].contains(host)
    }

    /// A saved module URL must belong to the school diary, not to a promotional
    /// portal or an authentication form. Messages legitimately use their own host.
    static func isDiaryModuleURL(_ url: URL?, messages: Bool = false) -> Bool {
        guard let url, url.scheme?.lowercased() == "https",
              url.port == nil, url.user == nil, url.password == nil,
              let host = url.host?.lowercased() else { return false }
        let allowed = host == "synergia.librus.pl" || (messages && host == "wiadomosci.librus.pl")
        guard allowed else { return false }
        let p = url.path.lowercased()
        return !p.contains("/login") && !p.contains("/loguj") &&
               !p.contains("/wyloguj") && !p.contains("/logout") &&
               !p.contains("/oauth/")
    }
}
