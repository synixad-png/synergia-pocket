import Foundation

/// Plan jednego tygodnia ze źródła Timetables?weekStart=YYYY-MM-DD.
/// Równoległe lekcje są niezależnymi pozycjami; bez danych o grupie ucznia
/// nie można ustalić, na którą z nich powinien iść.
struct DirectTimetableEntry: Codable, Equatable, Identifiable {
    let id: String                 // identity local to THIS week snapshot only
    let date: String
    let slot: Int                 // index only, not guessed LessonNo
    let parallelIndex: Int
    let parallelCount: Int
    let lessonNumber: Int?
    let timeFrom: String?
    let timeTo: String?
    let subjectId: String?
    let teacherId: String?
    let classroomId: String?
    let isCanceled: Bool?
    let isSubstitution: Bool?
}

struct DirectTimetableWeek: Codable, Equatable {
    let monday: String
    let reportedDates: [String]
    let entries: [DirectTimetableEntry]
    let fetchedAt: Date
    let accountId: String
    var splitPeriods: Int { Set(entries.filter { $0.parallelCount > 1 }.map { "\($0.date):\($0.slot)" }).count }
}

enum DirectTimetableError: Error, Equatable, LocalizedError {
    case malformedWeek, invalidDate, missingTimetable, malformedDay, tooManyLessons, malformedLesson
    var errorDescription: String? {
        switch self {
        case .malformedWeek: return "Błędna data tygodnia planu."
        case .invalidDate: return "Niepoprawna data w planie lekcji."
        case .missingTimetable: return "Brak rozpoznanego planu tygodnia w odpowiedzi serwera."
        case .malformedDay: return "Nieprawidłowa struktura dnia w planie."
        case .tooManyLessons: return "Zbyt wiele wpisów w planie; odczyt wstrzymano."
        case .malformedLesson: return "Nierozpoznany wpis lekcji; odczyt wstrzymano."
        }
    }
}

enum DirectTimetableParser {
    private static func calendar() -> Calendar {
        var calendar = Calendar(identifier: .iso8601)
        calendar.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        return calendar
    }
    private static func formatter() -> DateFormatter {
        let f = DateFormatter()
        f.calendar = calendar()
        f.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        f.isLenient = false
        return f
    }
    static func monday(containing date: Date) -> String {
        let cal = calendar()
        let start = cal.dateInterval(of: .weekOfYear, for: date)!.start
        return formatter().string(from: start)
    }
    static func isMonday(_ text: String) -> Bool {
        guard text.count == 10, text.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil,
              let date = formatter().date(from: text), formatter().string(from: date) == text else { return false }
        return calendar().component(.weekday, from: date) == 2
    }
    private static func isoDay(_ text: String) -> Date? {
        guard text.count == 10, text.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil,
              let date = formatter().date(from: text), formatter().string(from: date) == text else { return nil }
        return date
    }
    private static func reference(_ value: Any?) -> String? {
        guard let object = value as? [String: Any] else { return nil }
        if let text = object["Id"] as? String, !text.isEmpty, text.count < 130 { return text }
        if let n = object["Id"] as? NSNumber, n.intValue >= 0 { return n.stringValue }
        return nil
    }
    private static func number(_ raw: Any?) -> Int? {
        if let text = raw as? String, let value = Int(text), (1...50).contains(value) { return value }
        if let n = raw as? NSNumber, (1...50).contains(n.intValue), n.doubleValue == Double(n.intValue) { return n.intValue }
        return nil
    }
    private static func cleanTime(_ raw: Any?) -> String? {
        guard let value = raw as? String, value.count == 5,
              value.range(of: #"^\d{2}:\d{2}$"#, options: .regularExpression) != nil else { return nil }
        let parts = value.split(separator: ":")
        guard parts.count == 2, let h = Int(parts[0]), let m = Int(parts[1]),
              (0...23).contains(h), (0...59).contains(m) else { return nil }
        return value
    }
    static func parse(_ root: [String: Any], monday: String, accountId: String,
                      date fetchedAt: Date = Date()) throws -> DirectTimetableWeek {
        guard isMonday(monday) else { throw DirectTimetableError.malformedWeek }
        guard let dictionary = root["Timetable"] as? [String: Any], !dictionary.isEmpty,
              dictionary.count <= 7 else { throw DirectTimetableError.missingTimetable }
        guard let start = isoDay(monday), let end = calendar().date(byAdding: .day, value: 6, to: start) else {
            throw DirectTimetableError.malformedWeek
        }
        var entries: [DirectTimetableEntry] = []
        for day in dictionary.keys.sorted() {
            guard let d = isoDay(day), (start...end).contains(d) else { throw DirectTimetableError.invalidDate }
            guard let slots = dictionary[day] as? [[[String: Any]]], slots.count <= 24 else {
                throw DirectTimetableError.malformedDay
            }
            for (slot, parallels) in slots.enumerated() {
                guard parallels.count <= 8 else { throw DirectTimetableError.tooManyLessons }
                for (index, row) in parallels.enumerated() {
                    guard !row.isEmpty else { throw DirectTimetableError.malformedLesson }
                    let no = number(row["LessonNo"])
                    let from = cleanTime(row["HourFrom"])
                    let to = cleanTime(row["HourTo"])
                    let subject = reference(row["Subject"])
                    // A lesson without subject may be cancelled, special or unassigned,
                    // but it must have at least some reliably readable field.
                    guard no != nil || from != nil || to != nil || subject != nil ||
                          (row["IsCanceled"] as? Bool) == true else {
                        throw DirectTimetableError.malformedLesson
                    }
                    entries.append(DirectTimetableEntry(id: "\(day):\(slot):\(index)",
                        date: day, slot: slot, parallelIndex: index, parallelCount: parallels.count,
                        lessonNumber: no, timeFrom: from, timeTo: to,
                        subjectId: subject, teacherId: reference(row["Teacher"]),
                        classroomId: reference(row["Classroom"]),
                        isCanceled: row["IsCanceled"] as? Bool,
                        isSubstitution: row["IsSubstitutionClass"] as? Bool))
                    if entries.count > 250 { throw DirectTimetableError.tooManyLessons }
                }
            }
        }
        return DirectTimetableWeek(monday: monday, reportedDates: dictionary.keys.sorted(),
            entries: entries, fetchedAt: fetchedAt, accountId: accountId)
    }
}
