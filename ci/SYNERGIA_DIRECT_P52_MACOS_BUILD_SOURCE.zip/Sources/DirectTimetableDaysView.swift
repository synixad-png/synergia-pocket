import SwiftUI

/// Read-only, grouped by actual published dates. Does not infer pupil's group.
struct DirectTimetableDaysView: View {
    let week: DirectTimetableWeek
    let subjects: [String: String]
    let teachers: [String: String]
    @State private var selectedDay = ""

    private var days: [DirectTimetablePresentation.Day] {
        DirectTimetablePresentation.days(for: week)
    }
    private var visibleDays: [DirectTimetablePresentation.Day] {
        selectedDay.isEmpty ? days : days.filter { $0.date == selectedDay }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Wyświetlany dzień", selection: $selectedDay) {
                Text("Cały tydzień").tag("")
                ForEach(days) { day in
                    Text(DirectTimetablePresentation.dayLabel(day.date)).tag(day.date)
                }
            }
            .pickerStyle(.menu)
            .accessibilityLabel("Filtr planu według dnia")

            Text("Lekcje są pogrupowane według dnia i kolejności godzin. Brak dnia w odpowiedzi nie oznacza dnia wolnego.")
                .font(.footnote).foregroundStyle(.secondary)

            ForEach(visibleDays) { day in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(DirectTimetablePresentation.dayLabel(day.date))
                            .font(.headline)
                        Spacer()
                        if day.state == .reportedWithEntries {
                            Text("Godzin: \(day.periodCount)")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    if day.state == .notReported {
                        Label("Brak danych o tym dniu z serwera — nie potwierdzono dnia wolnego.", systemImage: "questionmark.circle")
                            .font(.caption).foregroundStyle(.orange)
                    } else if day.state == .reportedEmpty {
                        Label("Serwer zwrócił ten dzień bez wpisów lekcji.", systemImage: "calendar.badge.exclamationmark")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        if day.parallelPeriods > 0 {
                            Text("Równoległe lekcje: \(day.parallelPeriods) godzin. Nie znamy przydziału ucznia do grupy.")
                                .font(.caption).foregroundStyle(.orange)
                        }
                        ForEach(day.entries) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.lessonNumber.map { "Lekcja \($0)" } ?? "Numer lekcji nieustalony")
                                        .font(.subheadline.bold())
                                    if item.isCanceled == true {
                                        Label("Odwołana", systemImage: "xmark.circle")
                                            .font(.footnote).foregroundStyle(.red)
                                    }
                                    if item.isSubstitution == true {
                                        Label("Zastępstwo", systemImage: "arrow.triangle.2.circlepath")
                                            .font(.footnote).foregroundStyle(.orange)
                                    }
                                }
                                Text(DirectTimetablePresentation.subjectName(item.subjectId, names: subjects))
                                    .font(.subheadline)
                                if item.timeFrom != nil || item.timeTo != nil {
                                    Text("Godziny: \(item.timeFrom ?? "nieustalone") – \(item.timeTo ?? "nieustalone")")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                if item.teacherId != nil {
                                    Text(DirectTimetablePresentation.teacherName(item.teacherId, names: teachers))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                if let classroom = item.classroomId {
                                    Text("Sala — identyfikator: \(classroom)")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                if item.parallelCount > 1 {
                                    Text("Grupa równoległa \(item.parallelIndex + 1) / \(item.parallelCount) — przydział ucznia niepotwierdzony")
                                        .font(.caption).foregroundStyle(.orange)
                                }
                            }
                            .padding(10)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                        }
                    }
                }
                .padding(.vertical, 3)
            }
        }
    }
}
