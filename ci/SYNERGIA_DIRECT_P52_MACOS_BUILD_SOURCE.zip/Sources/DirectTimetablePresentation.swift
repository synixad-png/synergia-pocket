import Foundation

/// Display-only interpretation of a previously verified timetable snapshot.
/// A missing day is NOT an empty school day, and parallel entries are never
/// treated as an identified pupil's group.
enum DirectTimetablePresentation {
    enum DayState: Equatable {
        case notReported
        case reportedEmpty
        case reportedWithEntries
    }

    struct Day: Identifiable, Equatable {
        let date: String
        let state: DayState
        let entries: [DirectTimetableEntry]
        let periodCount: Int
        let parallelPeriods: Int
        var id: String { date }
    }

    private static func schoolCalendar() -> Calendar {
        var calendar = Calendar(identifier: .iso8601)
        calendar.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        return calendar
    }
    private static func dayFormatter() -> DateFormatter {
        let formatter = DateFormatter()
        formatter.calendar = schoolCalendar()
        formatter.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.isLenient = false
        return formatter
    }

    /// Week transitions are calendar-day operations in Warsaw, not fixed 24h
    /// timestamp arithmetic; this remains correct through the DST switch.
    static func shiftedWeek(containing date: Date, offset: Int) -> Date? {
        guard abs(offset) <= 52 else { return nil }
        return schoolCalendar().date(byAdding: .day, value: offset * 7, to: date)
    }

    /// Seven calendar days are displayed even if the server published only one.
    static func days(for week: DirectTimetableWeek) -> [Day] {
        guard DirectTimetableParser.isMonday(week.monday),
              let start = dayFormatter().date(from: week.monday) else { return [] }
        let calendar = schoolCalendar()
        let formatter = dayFormatter()
        let reported = Set(week.reportedDates)
        return (0..<7).compactMap { delta in
            guard let date = calendar.date(byAdding: .day, value: delta, to: start) else { return nil }
            let key = formatter.string(from: date)
            let entries = week.entries.filter { $0.date == key }.sorted { first, second in
                if first.slot != second.slot { return first.slot < second.slot }
                return first.parallelIndex < second.parallelIndex
            }
            let periods = Set(entries.map(\.slot))
            let parallel = Set(entries.filter { $0.parallelCount > 1 }.map(\.slot))
            let state: DayState = !reported.contains(key) ? .notReported :
                (entries.isEmpty ? .reportedEmpty : .reportedWithEntries)
            return Day(date: key, state: state, entries: entries,
                       periodCount: periods.count, parallelPeriods: parallel.count)
        }
    }

    static func dayLabel(_ date: String) -> String {
        guard let source = dayFormatter().date(from: date) else { return date }
        let formatter = DateFormatter()
        formatter.calendar = schoolCalendar()
        formatter.timeZone = TimeZone(identifier: "Europe/Warsaw")!
        formatter.locale = Locale(identifier: "pl_PL")
        formatter.dateFormat = "EEEE, d MMMM"
        return formatter.string(from: source)
    }

    static func subjectName(_ id: String?, names: [String: String]) -> String {
        label(id, names: names, unknown: "Przedmiot nieustalony", known: "Nieznana nazwa przedmiotu")
    }
    static func teacherName(_ id: String?, names: [String: String]) -> String {
        label(id, names: names, unknown: "Nauczyciel nieustalony", known: "Nieznane nazwisko nauczyciela")
    }
    private static func label(_ id: String?, names: [String: String], unknown: String, known: String) -> String {
        guard let id, !id.isEmpty else { return unknown }
        if let name = names[id], !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return name }
        return "\(known) (ID: \(id))"
    }
}
