import Foundation
import CoreFoundation

/// Server-provided unread counters. A missing category stays unknown, never 0.
struct DirectUnreadCounts: Equatable {
    let values: [String: Int]
    let checkedAt: Date
    static let fields: [(key: String, label: String)] = [
        ("inbox", "Odebrane"), ("notes", "Uwagi"),
        ("alerts", "Powiadomienia"), ("substitutions", "Zastępstwa"),
        ("absences", "Nieobecności"), ("justifications", "Usprawiedliwienia"),
        ("trash", "Kosz"), ("archiveInbox", "Archiwum odebranych"),
        ("archiveNotes", "Archiwum uwag"), ("archiveAlerts", "Archiwum powiadomień"),
        ("archiveSubstitutions", "Archiwum zastępstw"),
        ("archiveAbsences", "Archiwum nieobecności"),
        ("archiveJustifications", "Archiwum usprawiedliwień"),
        ("archiveTrash", "Archiwum kosza")
    ]
}

enum DirectUnreadCountError: Error, LocalizedError {
    case unexpectedResponse, invalidCount
    var errorDescription: String? {
        switch self {
        case .unexpectedResponse: return "Nieznana struktura liczników nieprzeczytanych wiadomości."
        case .invalidCount: return "Serwer zwrócił nieprawidłową liczbę nieprzeczytanych wiadomości."
        }
    }
}

enum DirectUnreadCountParser {
    static func parse(_ json: [String: Any], at time: Date = Date()) throws -> DirectUnreadCounts {
        guard let data = json["data"] as? [String: Any] else { throw DirectUnreadCountError.unexpectedResponse }
        var result: [String: Int] = [:]
        for key in DirectUnreadCounts.fields.map(\.key) {
            guard let raw = data[key] else { continue }
            guard let n = raw as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
                  n.doubleValue == Double(n.intValue), (0...1_000_000).contains(n.intValue) else {
                throw DirectUnreadCountError.invalidCount
            }
            result[key] = n.intValue
        }
        guard result["inbox"] != nil else { throw DirectUnreadCountError.unexpectedResponse }
        return DirectUnreadCounts(values: result, checkedAt: time)
    }
}
