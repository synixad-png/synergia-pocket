import Foundation
import UniformTypeIdentifiers

struct SavedAttachment: Codable, Identifiable, Hashable {
    var id: UUID
    var displayName: String
    var relativeName: String
    var sourceURL: String
    var savedAt: Date
    var byteCount: Int64
}

/// Only the currently verified account can view or persist its downloads.
/// Unscoped legacy index/files are never read after upgrading.
@MainActor
final class DownloadStore: ObservableObject {
    @Published private(set) var items: [SavedAttachment] = []
    private(set) var verifiedAccountId: String?
    private let root: URL

    init(root: URL? = nil) {
        let base = root ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        self.root = base.appendingPathComponent("school-downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: self.root, withIntermediateDirectories: true)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        var folder = self.root; try? folder.setResourceValues(values)
    }
    private func accountFolder(_ id: String) -> URL {
        AccountPartition.directory(for: id, under: root.appendingPathComponent("accounts", isDirectory: true))
    }
    private func index(for id: String) -> URL { accountFolder(id).appendingPathComponent("index.json") }
    func lock() { verifiedAccountId = nil; items = [] }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        guard let bytes = try? Data(contentsOf: index(for: accountId)),
              let decoded = try? JSONDecoder().decode([SavedAttachment].self, from: bytes) else { return }
        items = decoded.filter { item in
            item.relativeName.hasPrefix(item.id.uuidString + ".") && !item.relativeName.contains("/") &&
            FileManager.default.fileExists(atPath: accountFolder(accountId).appendingPathComponent(item.relativeName).path)
        }
    }
    enum StoreError: Error { case unverifiedAccount }
    func file(for attachment: SavedAttachment) -> URL? {
        guard let id = verifiedAccountId,
              items.contains(where: { $0.id == attachment.id && $0.relativeName == attachment.relativeName }),
              attachment.relativeName.hasPrefix(attachment.id.uuidString + "."),
              !attachment.relativeName.contains("/") else { return nil }
        let url = accountFolder(id).appendingPathComponent(attachment.relativeName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }
    func importDownload(from temporaryURL: URL, suggestedFilename: String, sourceURL: String) throws -> SavedAttachment {
        guard let account = verifiedAccountId else { throw StoreError.unverifiedAccount }
        let folder = accountFolder(account)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let id = UUID()
        let name = String(suggestedFilename.replacingOccurrences(of: "\\", with: "/")
            .split(separator: "/").last ?? "załącznik")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let ext = URL(fileURLWithPath: name).pathExtension.lowercased()
        let validExtension = !ext.isEmpty && ext.count <= 10 && ext.allSatisfy { $0.isASCII && ($0.isLetter || $0.isNumber) }
        let relativeName = id.uuidString + "." + (validExtension ? ext : "bin")
        let output = folder.appendingPathComponent(relativeName)
        try FileManager.default.copyItem(at: temporaryURL, to: output)
        try (output as NSURL).setResourceValue(FileProtectionType.complete, forKey: .fileProtectionKey)
        let attributes = try FileManager.default.attributesOfItem(atPath: output.path)
        let byteCount = (attributes[.size] as? NSNumber)?.int64Value ?? 0
        let result = SavedAttachment(id: id, displayName: name.isEmpty ? "załącznik" : name,
             relativeName: relativeName, sourceURL: sourceURL, savedAt: Date(), byteCount: byteCount)
        items.insert(result, at: 0)
        do { try persist() }
        catch { items.removeAll { $0.id == id }; try? FileManager.default.removeItem(at: output); throw error }
        return result
    }
    func remove(_ item: SavedAttachment) throws {
        guard let account = verifiedAccountId, let file = file(for: item) else { return }
        try FileManager.default.removeItem(at: file)
        items.removeAll { $0.id == item.id }
        try persist()
        assert(verifiedAccountId == account)
    }
    private func persist() throws {
        guard let id = verifiedAccountId else { throw StoreError.unverifiedAccount }
        let folder = accountFolder(id)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try JSONEncoder().encode(items).write(to: index(for: id), options: [.atomic, .completeFileProtection])
    }
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: root.path) { try FileManager.default.removeItem(at: root) }
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }
}
