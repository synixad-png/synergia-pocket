import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Deterministic boundary checks for the read-only Synergia JSON transport.
/// Pure Foundation: testable without an iPhone, a live account or WebKit.
/// This policy validates transport structure; it cannot confirm undocumented
/// gateway endpoint behavior without a real, authorized account.
enum GatewayJSONPolicy {
    static let maximumJSONBytes = 4_000_000
    static let maximumContinuationQueryBytes = 2_048

    /// RFC 6265 domain-match and path-match. A host-only cookie for librus.pl
    /// MUST NOT be sent to synergia.librus.pl. A domain cookie (.librus.pl)
    /// may be sent to its subdomains if its other restrictions also match.
    static func cookieApplies(_ cookie: HTTPCookie, to url: URL, now: Date = Date()) -> Bool {
        guard url.scheme?.lowercased() == "https", url.port == nil,
              let host = url.host?.lowercased(), cookie.isSecure,
              cookie.expiresDate.map({ $0 > now }) ?? true else { return false }
        let rawDomain = cookie.domain.lowercased()
        let domainCookie = rawDomain.hasPrefix(".")
        let domain = domainCookie ? String(rawDomain.dropFirst()) : rawDomain
        guard !domain.isEmpty, !domain.hasPrefix("."), !domain.hasSuffix("."),
              (domainCookie ? (host == domain || host.hasSuffix("." + domain)) : host == domain)
        else { return false }
        let path = url.path.isEmpty ? "/" : url.path
        let cookiePath = cookie.path.isEmpty ? "/" : cookie.path
        guard cookiePath.hasPrefix("/") else { return false }
        if path == cookiePath { return true }
        guard path.hasPrefix(cookiePath) else { return false }
        if cookiePath.hasSuffix("/") { return true }
        // Path /gateway is not a match for /gateway-malicious or /gateway2.
        let suffix = path.dropFirst(cookiePath.count)
        return suffix.first == "/"
    }

    static func applicableCookies(_ cookies: [HTTPCookie], to url: URL, now: Date = Date()) -> [HTTPCookie] {
        cookies.filter { cookieApplies($0, to: url, now: now) }
    }

    /// MIME type must actually be JSON, not e.g. text/html; note=application/json.
    static func isJSONContentType(_ contentType: String?) -> Bool {
        guard let contentType else { return false }
        let mime = contentType.split(separator: ";", maxSplits: 1, omittingEmptySubsequences: false)
            .first?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ?? ""
        if mime == "application/json" { return true }
        guard mime.hasPrefix("application/"), mime.hasSuffix("+json") else { return false }
        let subtype = mime.dropFirst("application/".count).dropLast("+json".count)
        return !subtype.isEmpty && subtype.allSatisfy { $0.isASCII && ($0.isLetter || $0.isNumber || "+-._".contains($0)) }
    }

    /// Content-Length is advisory; always check the actual byte count too.
    /// -1 represents a response with no declared length.
    static func withinJSONLimit(bodyBytes: Int, expectedBytes: Int64) -> Bool {
        bodyBytes >= 0 && bodyBytes <= maximumJSONBytes &&
        (expectedBytes == -1 || (expectedBytes >= 0 && expectedBytes <= Int64(maximumJSONBytes)))
    }

    /// Follow only an explicit same-path, same-origin Grades continuation.
    /// The parameter names come from the server's continuation URL, never
    /// from guesses about the API. Reject empty/duplicate/control parameters.
    static func safeContinuationQuery(_ url: URL) -> Bool {
        guard let parts = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let rawQuery = parts.percentEncodedQuery,
              !rawQuery.isEmpty, rawQuery.utf8.count <= maximumContinuationQueryBytes,
              let items = parts.queryItems,
              (1...8).contains(items.count) else { return false }
        var seen = Set<String>()
        for item in items {
            guard !item.name.isEmpty, item.name.utf8.count <= 64,
                  item.name.unicodeScalars.allSatisfy({ CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.[]").contains($0) }),
                  seen.insert(item.name.lowercased()).inserted,
                  let value = item.value, !value.isEmpty, value.utf8.count <= 1_024,
                  !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
            else { return false }
        }
        return true
    }
}
