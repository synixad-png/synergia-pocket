import Foundation

/// Counts observed changes without interpreting a missing record as a
/// confirmed deletion. The caller must verify both snapshots belong to the
/// same live account before comparing them.
struct GradeChangeAuditResult: Equatable {
    let added: Int
    let edited: Int
    let absentInLatestRead: Int
    let movedBetweenSemesters: Int
    let unchanged: Int
    let unassignedOrOtherSemesterChanges: Int

    var summary: String {
        "Nowe identyfikatory: \(added), zmienione rekordy (w tym przeniesione): \(edited), brak w ostatnim odczycie: \(absentInLatestRead), zmiana semestru: \(movedBetweenSemesters), bez zmian: \(unchanged), zmiany ocen bez standardowego semestru: \(unassignedOrOtherSemesterChanges). Brak wpisu nie oznacza potwierdzonego usunięcia."
    }
}

enum GradeChangeAudit {
    /// Stable IDs distinguish a newly observed grade from an edited one.
    /// An ID that moves semestr is counted once, not as a new/deleted grade.
    static func compare(previous: [DirectGrade], incoming: [DirectGrade]) throws -> GradeChangeAuditResult {
        func indexed(_ grades: [DirectGrade]) throws -> [String: DirectGrade] {
            var result: [String: DirectGrade] = [:]
            for grade in grades {
                guard result[grade.id] == nil else {
                    throw GradeSemesterCoverageError.snapshotContainsDuplicateID(grade.id)
                }
                result[grade.id] = grade
            }
            return result
        }
        let before = try indexed(previous)
        let after = try indexed(incoming)
        let oldIDs = Set(before.keys)
        let newIDs = Set(after.keys)
        let shared = oldIDs.intersection(newIDs)
        let changed = shared.filter { before[$0] != after[$0] }
        let moved = shared.filter { before[$0]?.semester != after[$0]?.semester }
        let unknown = changed.filter { id in
            let a = before[id]?.semester, b = after[id]?.semester
            guard let a, let b else { return true }
            return ![1, 2].contains(a) || ![1, 2].contains(b)
        }
        return GradeChangeAuditResult(
            added: newIDs.subtracting(oldIDs).count,
            edited: changed.count,
            absentInLatestRead: oldIDs.subtracting(newIDs).count,
            movedBetweenSemesters: moved.count,
            unchanged: shared.count - changed.count,
            unassignedOrOtherSemesterChanges: unknown.count)
    }
}
