import Foundation

/// Resolve details only from the *current* account-scoped grade snapshot.
/// Never retain a previously opened grade object in a navigation destination:
/// account switching, logout or the privacy shield must invalidate it immediately.
enum GradeDetailAccess {
    static func resolve(gradeID: String, expectedAccountID: String,
                        verifiedAccountID: String?, cacheAccountID: String?,
                        privacyShieldActive: Bool, grades: [DirectGrade]) -> DirectGrade? {
        guard !gradeID.isEmpty, !expectedAccountID.isEmpty,
              !privacyShieldActive,
              verifiedAccountID == expectedAccountID,
              cacheAccountID == expectedAccountID else { return nil }
        return grades.first { $0.id == gradeID }
    }
}
