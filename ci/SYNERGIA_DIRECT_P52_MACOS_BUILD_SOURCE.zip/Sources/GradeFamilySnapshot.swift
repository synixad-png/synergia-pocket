import Foundation

/// A missing/forbidden family is NOT an empty family. Keep only the old rows
/// for families that couldn't be read, within the already verified account.
/// Fresh, successfully fetched families always replace their old rows,
/// including an explicitly empty collection.
enum GradeFamilySnapshot {
    static func reconcile(fresh: [SupplementalGrade],
                          previous: [SupplementalGrade],
                          unavailable: Set<SupplementalGradeFamily>) -> [SupplementalGrade] {
        let current = fresh.filter { !unavailable.contains($0.family) }
        let retained = previous.filter { unavailable.contains($0.family) }
        return current + retained
    }
}
