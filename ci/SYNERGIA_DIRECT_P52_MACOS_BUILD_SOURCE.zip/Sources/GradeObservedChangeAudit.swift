import Foundation

/// Evidence from two account-matched, already decoded snapshots. This is not
/// proof of a change in the school's official register: a server response can
/// omit older records or present changed enrichment metadata.
struct GradeObservedChangeReport: Equatable {
    let addedStandard: Int
    let editedStandard: Int
    let metadataOnlyStandard: Int
    let movedStandard: Int
    let missingStandard: Int
    let unchangedStandard: Int
    let addedSupplemental: Int
    let editedSupplemental: Int
    let missingSupplemental: Int
    let unchangedSupplemental: Int
    let unavailableFamilies: [String]

    var observedNew: Int { addedStandard + addedSupplemental }
    var observedEdited: Int { editedStandard + editedSupplemental }
    var hasObservedNews: Bool { observedNew > 0 || observedEdited > 0 }
    var hasMissing: Bool { missingStandard > 0 || missingSupplemental > 0 }
    var allFamiliesRead: Bool { unavailableFamilies.isEmpty }

    var summary: String {
        let unavailable = unavailableFamilies.isEmpty ? "brak" : unavailableFamilies.joined(separator: ", ")
        return "Nowo zaobserwowane identyfikatory: \(observedNew) " +
            "(zwykłe \(addedStandard), dodatkowe \(addedSupplemental)); " +
            "zmieniona treść oceny: \(observedEdited) " +
            "(zwykłe \(editedStandard), dodatkowe \(editedSupplemental)); " +
            "tylko zmiana opisowych metadanych kategorii: \(metadataOnlyStandard); " +
            "przeniesienia między semestrami: \(movedStandard); " +
            "brak w ostatnim odczycie: \(missingStandard + missingSupplemental); " +
            "nieodczytane rodziny: \(unavailable). " +
            "To porównanie dwóch zapisanych odczytów, nie potwierdzenie zmian w dzienniku ani usunięć."
    }
}

/// Ignores only metadata added during enrichment (category display name,
/// derived weight and averaging flag). Values, subjects, category references,
/// semester, date, comments and explicit AddedBy reference remain significant.
private struct GradeObservedContent: Equatable {
    let subjectId: String
    let categoryId: String?
    let value: String
    let semester: Int?
    let addedAt: String?
    let commentTexts: [String]
    let authorId: String?

    init(_ row: DirectGrade) {
        subjectId = row.subjectId
        categoryId = row.categoryId
        value = row.value
        semester = row.semester
        addedAt = row.addedAt
        commentTexts = row.commentTexts
        authorId = row.teacherId
    }
}

enum GradeObservedAuditError: Error, Equatable {
    case duplicateSupplementalID(String)
}

enum GradeObservedChangeAudit {
    /// Caller must have matched remote /Me before and after reads, account and
    /// request epochs, and validated pagination + snapshot completeness.
    /// Unavailable supplemental families are not compared as a new empty set.
    static func compare(previous: [DirectGrade], current: [DirectGrade],
                        previousSupplemental: [SupplementalGrade],
                        currentSupplemental: [SupplementalGrade],
                        unavailable: Set<SupplementalGradeFamily> = []) throws -> GradeObservedChangeReport {
        func standardIndex(_ rows: [DirectGrade]) throws -> [String: DirectGrade] {
            var byID: [String: DirectGrade] = [:]
            for row in rows {
                guard !row.id.isEmpty, byID[row.id] == nil else {
                    throw GradeSemesterCoverageError.snapshotContainsDuplicateID(row.id)
                }
                byID[row.id] = row
            }
            return byID
        }
        func supplementalIndex(_ rows: [SupplementalGrade]) throws -> [String: SupplementalGrade] {
            var byID: [String: SupplementalGrade] = [:]
            for row in rows {
                guard !row.sourceId.isEmpty, byID[row.id] == nil else {
                    throw GradeObservedAuditError.duplicateSupplementalID(row.id)
                }
                byID[row.id] = row
            }
            return byID
        }
        let old = try standardIndex(previous)
        let fresh = try standardIndex(current)
        let oldIDs = Set(old.keys), newIDs = Set(fresh.keys)
        let shared = oldIDs.intersection(newIDs)
        let contentChanges = shared.filter { id in
            guard let a = old[id], let b = fresh[id] else { return false }
            return GradeObservedContent(a) != GradeObservedContent(b)
        }
        let metadataOnly = shared.filter { id in
            guard let a = old[id], let b = fresh[id] else { return false }
            return GradeObservedContent(a) == GradeObservedContent(b) && a != b
        }
        let moved = shared.filter { old[$0]?.semester != fresh[$0]?.semester }

        // Check duplicates in *all* families, including unavailable ones,
        // before excluding stale, retained rows from comparison.
        let oldOther = try supplementalIndex(previousSupplemental)
        let newOther = try supplementalIndex(currentSupplemental)
        let oldComparable = oldOther.filter { !unavailable.contains($0.value.family) }
        let newComparable = newOther.filter { !unavailable.contains($0.value.family) }
        let oldOtherIDs = Set(oldComparable.keys), newOtherIDs = Set(newComparable.keys)
        let otherShared = oldOtherIDs.intersection(newOtherIDs)
        let otherEdited = otherShared.filter { oldComparable[$0] != newComparable[$0] }

        return GradeObservedChangeReport(
            addedStandard: newIDs.subtracting(oldIDs).count,
            editedStandard: contentChanges.count,
            metadataOnlyStandard: metadataOnly.count,
            movedStandard: moved.count,
            missingStandard: oldIDs.subtracting(newIDs).count,
            unchangedStandard: shared.count - contentChanges.count - metadataOnly.count,
            addedSupplemental: newOtherIDs.subtracting(oldOtherIDs).count,
            editedSupplemental: otherEdited.count,
            missingSupplemental: oldOtherIDs.subtracting(newOtherIDs).count,
            unchangedSupplemental: otherShared.count - otherEdited.count,
            unavailableFamilies: unavailable.map(\.rawValue).sorted())
    }
}
