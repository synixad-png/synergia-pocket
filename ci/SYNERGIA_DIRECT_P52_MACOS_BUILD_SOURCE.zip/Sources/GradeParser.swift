import Foundation

/// A conservative, offline interpretation of an HTML table capture.
/// These values are PROVISIONAL until compared against the user's actual Synergia account.
struct GradeCandidate: Codable, Identifiable, Equatable {
    let id: String
    let subject: String
    let value: String
    let dateText: String?
    let weightText: String?
    let category: String?
    let comment: String?
    let semester: String?
    let sourceRow: Int
}

struct GradePreview: Codable {
    let capturedAt: Date
    let sourceURL: String
    let grades: [GradeCandidate]
    let rejectedRows: Int
    let possibleDuplicateGroups: Int
    let warnings: [String]
}

enum GradeParser {
    private static let subjectHeaders: Set<String> = ["przedmiot", "nazwa przedmiotu", "subject"]
    private static let valueHeaders: Set<String> = ["ocena", "stopien", "grade", "wartosc oceny"]
    private static let dateHeaders: Set<String> = ["data", "data wystawienia", "date"]
    private static let weightHeaders: Set<String> = ["waga", "weight"]
    private static let categoryHeaders: Set<String> = ["kategoria", "rodzaj", "category"]
    private static let commentHeaders: Set<String> = ["komentarz", "opis oceny", "comment"]
    private static let semesterHeaders: Set<String> = ["semestr", "okres", "semester"]

    // No semester guessed from the capture date; only an explicit label is accepted.
    private static func explicitSemester(_ caption: String) -> String? {
        let text = normalized(caption)
        if text.range(of: #"\b(semestr|okres)\s*(i|1|pierwszy)\b"#, options: .regularExpression) != nil { return "1" }
        if text.range(of: #"\b(semestr|okres)\s*(ii|2|drugi)\b"#, options: .regularExpression) != nil { return "2" }
        return nil
    }

    private static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "pl_PL"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
    }

    private static func valueIsPlausible(_ text: String) -> Bool {
        // One grade only. Ranges, averages and long sequences are not silently split.
        let value = normalized(text).replacingOccurrences(of: " ", with: "")
        return value.range(of: #"^[1-6][+-]?$"#, options: .regularExpression) != nil
    }

    private static func optional(_ row: [String], index: Int?) -> String? {
        guard let index, index < row.count else { return nil }
        let value = row[index].trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }

    /// Only parse rows with explicit, unambiguous subject AND grade column headers.
    /// Never infer from column position alone, and never report the result as complete.
    static func preview(snapshot: ModuleSnapshot) -> GradePreview {
        // Never combine headers from one HTML table with data from another.
        // Legacy snapshots lack table boundaries and are deliberately not semantically parsed.
        let tables = snapshot.tables ?? []
        var candidates: [GradeCandidate] = []
        var rejected = 0
        var recognizedTables = 0
        var seen = Set<String>()

        for (tableIndex, table) in tables.enumerated() {
          var header: (subject: Int, value: Int, date: Int?, weight: Int?, category: Int?, comment: Int?, semester: Int?)?
          for (rowIndex, row) in table.rows.enumerated() {
            let cells = row.map(normalized)
            let subjectIndices = cells.indices.filter { subjectHeaders.contains(cells[$0]) }
            let gradeIndices = cells.indices.filter { valueHeaders.contains(cells[$0]) }
            if subjectIndices.count == 1 && gradeIndices.count == 1 && subjectIndices[0] != gradeIndices[0] {
                let single: (Set<String>) -> Int? = { names in
                    let hits = cells.indices.filter { names.contains(cells[$0]) }
                    return hits.count == 1 ? hits[0] : nil
                }
                header = (subjectIndices[0], gradeIndices[0], single(dateHeaders), single(weightHeaders), single(categoryHeaders), single(commentHeaders), single(semesterHeaders))
                recognizedTables += 1
                continue
            }
            guard let columns = header else { continue }
            // Rows without enough cells, summary rows, other table headers and malformed grades are ignored.
            guard columns.subject < row.count, columns.value < row.count else {
                rejected += 1
                continue
            }
            let subject = row[columns.subject].trimmingCharacters(in: .whitespacesAndNewlines)
            let value = row[columns.value].trimmingCharacters(in: .whitespacesAndNewlines)
            guard !subject.isEmpty, subject.count <= 120, valueIsPlausible(value),
                  !subjectHeaders.contains(normalized(subject)) else {
                rejected += 1
                continue
            }
            let date = optional(row, index: columns.date)
            let weight = optional(row, index: columns.weight)
            let category = optional(row, index: columns.category)
            let comment = optional(row, index: columns.comment)
            let semester = optional(row, index: columns.semester) ?? explicitSemester(table.caption)
            // A stable key across repeated reads; source row avoids accidentally collapsing repeated grades.
            let key = "\(snapshot.sourceURL)|\(tableIndex)|\(rowIndex)|\(subject)|\(value)"
            guard seen.insert(key).inserted else { continue }
            candidates.append(GradeCandidate(id: key, subject: subject, value: value,
                                             dateText: date, weightText: weight,
                                             category: category, comment: comment, semester: semester, sourceRow: rowIndex + 1))
        }
        }
        var warnings = ["Wstępna interpretacja tabel HTML, niezweryfikowana z kontem Synergii.",
                        "Liczba rozpoznanych pozycji NIE oznacza liczby wszystkich ocen."]
        if snapshot.tables == nil { warnings.append("Starszy zapis nie zawiera granic tabel. Wykonaj nowy odczyt przed interpretacją ocen.") }
        if recognizedTables == 0 { warnings.append("Brak tabel z jednoznacznymi nagłówkami Przedmiot i Ocena.") }
        if candidates.contains(where: { $0.semester == nil }) {
            warnings.append("Nie dla wszystkich ocen ustalono semestr; brakujące wartości nie są zgadywane.")
        }
        // Duplicate values may be genuinely separate grades. Flag only; never silently remove.
        let grouped = Dictionary(grouping: candidates) { grade in
            [grade.subject, grade.value, grade.dateText ?? "", grade.weightText ?? "",
             grade.category ?? "", grade.comment ?? "", grade.semester ?? ""].joined(separator: "|#|")
        }
        let potentialDuplicates = grouped.values.filter { $0.count > 1 }.count
        if potentialDuplicates > 0 {
            warnings.append("Wykryto \(potentialDuplicates) grup możliwych duplikatów. Zachowano wszystkie pozycje; identyczne oceny mogą być odrębne.")
        }
        if rejected > 0 { warnings.append("Pominięto \(rejected) wierszy, których nie można bezpiecznie rozpoznać.") }
        return GradePreview(capturedAt: snapshot.capturedAt, sourceURL: snapshot.sourceURL,
                            grades: candidates, rejectedRows: rejected, possibleDuplicateGroups: potentialDuplicates, warnings: warnings)
    }
}
