import Foundation

/// Detects missing metadata that would make a grade appear complete when it is not.
/// This is not proof that the remote service returned every grade.
enum GradeReferenceIntegrityError: Error, Equatable {
    case missingSubject(String)
}

enum GradeReferenceIntegrity {
    static func validate(grades: [DirectGrade], subjects: [String: String]) throws {
        for grade in grades {
            guard let name = subjects[grade.subjectId],
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw GradeReferenceIntegrityError.missingSubject(grade.subjectId)
            }
        }
    }
}
