import Foundation

/// Counts what is present in a downloaded snapshot. It does not pretend that
/// an undocumented endpoint guarantees coverage of both school semesters.
struct GradeSemesterReport: Equatable {
    let firstCount: Int
    let secondCount: Int
    let unspecifiedCount: Int
    let otherSemesterCount: Int
    var observedBothSemesters: Bool { firstCount > 0 && secondCount > 0 }
    var message: String {
        var parts = ["Semestr 1: \(firstCount)", "semestr 2: \(secondCount)"]
        if unspecifiedCount > 0 { parts.append("bez semestru: \(unspecifiedCount)") }
        if otherSemesterCount > 0 { parts.append("inny numer semestru: \(otherSemesterCount)") }
        parts.append("Kompletność obu semestrów niepotwierdzona")
        return parts.joined(separator: " · ")
    }
}

enum GradeSemesterCoverageError: Error, Equatable {
    case previouslyObservedSemesterDisappeared(Int)
    case snapshotContainsDuplicateID(String)
    case unexplainedMissingGradeIDs(semester: Int, count: Int)
}

enum GradeSemesterCoverage {
    static func report(_ grades: [DirectGrade]) -> GradeSemesterReport {
        GradeSemesterReport(
            firstCount: grades.filter { $0.semester == 1 }.count,
            secondCount: grades.filter { $0.semester == 2 }.count,
            unspecifiedCount: grades.filter { $0.semester == nil }.count,
            otherSemesterCount: grades.filter { $0.semester != nil && $0.semester != 1 && $0.semester != 2 }.count)
    }

    /// Prevents a partial read of one semester from replacing a previously
    /// stored whole semester. Individual deletions remain possible.
    /// No guarantees are inferred when a semester has never been observed.
    static func validateReplacement(incoming: [DirectGrade], previous: [DirectGrade]) throws -> GradeSemesterReport {
        var ids = Set<String>()
        for grade in incoming {
            guard ids.insert(grade.id).inserted else { throw GradeSemesterCoverageError.snapshotContainsDuplicateID(grade.id) }
        }
        let after = report(incoming)
        // A successful HTTP response is not evidence that the set is complete.
        // Even when both semesters remain present, disappearing individual IDs
        // could indicate partial backend coverage. A moved record (same ID) is
        // not missing; only identities absent from the entire new set are blocked.
        // A confirmed deletion workflow can be added only when supported by an
        // authoritative Synergia response, not guessed from a shorter snapshot.
        let incomingIDs = Set(incoming.map(\.id))
        for semester in [1, 2] {
            let missing = previous.filter { $0.semester == semester && !incomingIDs.contains($0.id) }
            if !missing.isEmpty {
                throw GradeSemesterCoverageError.unexplainedMissingGradeIDs(semester: semester, count: missing.count)
            }
        }
        // Preserve records with unknown semester too; otherwise those can vanish
        // invisibly, because they are outside the two reported semester counts.
        let unassignedMissing = previous.filter {
            ($0.semester == nil || ($0.semester != 1 && $0.semester != 2)) &&
            !incomingIDs.contains($0.id)
        }
        if !unassignedMissing.isEmpty {
            throw GradeSemesterCoverageError.unexplainedMissingGradeIDs(semester: 0, count: unassignedMissing.count)
        }
        return after
    }
}


/// A comparison of two snapshots belonging to the same previously verified
/// account. It reports evidence, not an assertion that school grades changed:
/// the remote service may return a partial view without identifying it.
struct GradeSemesterDelta: Equatable {
    let semester: Int
    let previousCount: Int
    let incomingCount: Int
    let addedIds: [String]
    let missingIds: [String]
    let changedIds: [String]
    let movedInIds: [String]
    let movedOutIds: [String]

    var hasUnexplainedShrinkage: Bool {
        incomingCount < previousCount && !missingIds.isEmpty
    }
}

extension GradeSemesterCoverage {
    /// Same grade ID is never counted as a new grade just because its row was
    /// reordered. Changed grade IDs are reported separately by semester.
    /// All records with missing/unexpected semester are preserved in the
    /// original snapshot; they are not silently assigned to one of the two.
    static func compare(incoming: [DirectGrade], previous: [DirectGrade]) throws -> [GradeSemesterDelta] {
        func index(_ records: [DirectGrade]) throws -> [String: DirectGrade] {
            var result: [String: DirectGrade] = [:]
            for record in records {
                guard result.updateValue(record, forKey: record.id) == nil else {
                    throw GradeSemesterCoverageError.snapshotContainsDuplicateID(record.id)
                }
            }
            return result
        }
        let incomingById = try index(incoming)
        let previousById = try index(previous)
        return [1, 2].map { semester in
            let old = previous.filter { $0.semester == semester }
            let new = incoming.filter { $0.semester == semester }
            let oldIDs = Set(old.map(\.id))
            let newIDs = Set(new.map(\.id))
            let movedIn = newIDs.filter { id in
                guard let oldGrade = previousById[id] else { return false }
                return oldGrade.semester != semester
            }
            let movedOut = oldIDs.filter { id in
                guard let newGrade = incomingById[id] else { return false }
                return newGrade.semester != semester
            }
            let changed = oldIDs.intersection(newIDs).filter { id in
                previousById[id] != incomingById[id]
            }
            return GradeSemesterDelta(
                semester: semester, previousCount: old.count, incomingCount: new.count,
                addedIds: newIDs.subtracting(oldIDs).subtracting(Set(movedIn)).sorted(),
                missingIds: oldIDs.subtracting(newIDs).subtracting(Set(movedOut)).sorted(),
                changedIds: changed.sorted(),
                movedInIds: movedIn.sorted(), movedOutIds: movedOut.sorted())
        }
    }
}
