import Foundation

/// Pure presentation logic. Never infers grade completeness from a semester number.
/// A missing or nonstandard semester is explicitly retained in the Inne group.
enum GradeSemesterPresentation {
    static func select(_ grades: [DirectGrade], filter: Int) -> [DirectGrade] {
        let selected: [DirectGrade]
        switch filter {
        case 1, 2: selected = grades.filter { $0.semester == filter }
        case 3: selected = grades.filter { $0.semester != 1 && $0.semester != 2 }
        default: selected = grades
        }
        // Stable comparison: date is optional and may be non-ISO. Do not parse
        // or manufacture a chronology from an unknown remote date format.
        return selected.sorted { a, b in
            if a.subjectId != b.subjectId { return a.subjectId < b.subjectId }
            if a.addedAt != b.addedAt { return (a.addedAt ?? "") < (b.addedAt ?? "") }
            return a.id < b.id
        }
    }

    static func summary(grades: [DirectGrade], filter: Int) -> String {
        let shown = select(grades, filter: filter).count
        let all = grades.count
        let unknown = grades.filter { $0.semester != 1 && $0.semester != 2 }.count
        return "Oceny zwykłe: \(shown) z \(all) zapisanych. " +
            "Bez standardowego numeru semestru: \(unknown). " +
            "Kompletność danych z Synergii niepotwierdzona."
    }
}
