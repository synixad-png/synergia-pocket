import Foundation

/// Pure presentation audit of the account-scoped snapshot. It never fetches
/// remote data or infers a grade author from a timetable/subject assignment.
enum GradeAuthorAttribution: Equatable {
    case current(String)
    case earlier(String)
    case unresolved
    case notProvided

    var label: String {
        switch self {
        case .current(let name): return name
        case .earlier(let name): return name + " (z wcześniejszego odczytu)"
        case .unresolved, .notProvided: return "Nieustalony"
        }
    }
}

struct GradeSubjectAuthorAudit: Equatable {
    let totalGrades: Int
    let namedSubjects: Int
    let unnamedSubjects: Int
    let missingSubjectIds: [String]
    let currentAuthors: Int
    let earlierAuthors: Int
    let unresolvedAuthors: Int
    let noAuthorReference: Int

    static func attribution(for grade: DirectGrade,
                            names: [String: String],
                            earlierIds: Set<String>) -> GradeAuthorAttribution {
        guard let id = grade.teacherId, !id.isEmpty else { return .notProvided }
        guard let name = names[id]?.trimmingCharacters(in: .whitespacesAndNewlines),
              !name.isEmpty else { return .unresolved }
        return earlierIds.contains(id) ? .earlier(name) : .current(name)
    }

    static func summarize(_ grades: [DirectGrade],
                          subjects: [String: String],
                          authors: [String: String],
                          earlierAuthorIds: Set<String>) -> GradeSubjectAuthorAudit {
        var named = 0, unnamed = 0
        var fresh = 0, earlier = 0, unknown = 0, noRef = 0
        var missingIds = Set<String>()
        for grade in grades {
            if let name = subjects[grade.subjectId],
               !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                named += 1
            } else {
                unnamed += 1
                missingIds.insert(grade.subjectId)
            }
            switch attribution(for: grade, names: authors, earlierIds: earlierAuthorIds) {
            case .current: fresh += 1
            case .earlier: earlier += 1
            case .unresolved: unknown += 1
            case .notProvided: noRef += 1
            }
        }
        return GradeSubjectAuthorAudit(totalGrades: grades.count,
            namedSubjects: named, unnamedSubjects: unnamed,
            missingSubjectIds: missingIds.sorted(), currentAuthors: fresh,
            earlierAuthors: earlier, unresolvedAuthors: unknown,
            noAuthorReference: noRef)
    }

    var hasWarnings: Bool {
        unnamedSubjects > 0 || earlierAuthors > 0 || unresolvedAuthors > 0 || noAuthorReference > 0
    }

    var message: String {
        "Powiązania ocen (\(totalGrades)): przedmiot ustalony \(namedSubjects), " +
        "nieustalony \(unnamedSubjects); autor wpisu z zapisanego odczytu \(currentAuthors), " +
        "z wcześniejszego odczytu \(earlierAuthors), " +
        "nieustalony \(unresolvedAuthors), bez wskazanego autora \(noAuthorReference). " +
        "Autor wpisu nie musi być nauczycielem prowadzącym przedmiot."
    }
}
