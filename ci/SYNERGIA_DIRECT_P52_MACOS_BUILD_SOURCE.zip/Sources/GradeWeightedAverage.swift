import Foundation

// Local, *indicative* grade mean, never a school-issued or official average.
// Refuses to calculate when any included grade has unknown eligibility,
// missing weight, an ambiguous value or a duplicated identity. Does not
// infer +/- scales or replace missing category metadata with defaults.
struct LocalGradeMean: Equatable, Identifiable {
    var id: String { subjectId + ":" + String(semester) }
    let subjectId: String
    let semester: Int
    let mean: Double?
    let includedCount: Int
    let excludedCount: Int
    let unresolvedCount: Int
    let reason: String?
}

enum GradeWeightedAverage {
    private static func exactNumericValue(_ text: String) -> Double? {
        let valueText = text.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ",", with: ".")
        // No +, -, fractional shorthand, behaviour symbols or arbitrary free text.
        guard !valueText.isEmpty,
              valueText.range(of: #"^[1-6](?:\.[0-9]+)?$"#, options: .regularExpression) != nil,
              let value = Double(valueText), value >= 1, value <= 6, value.isFinite else { return nil }
        return value
    }

    static func calculate(_ grades: [DirectGrade]) -> [LocalGradeMean] {
        // A corrupt/stale cache could contain repeated grade IDs even though
        // the live parser rejects them. In this situation never show an
        // apparently precise average based on duplicates.
        let idCounts = grades.reduce(into: [String: Int]()) { result, grade in
            result[grade.id, default: 0] += 1
        }
        let groups = Dictionary(grouping: grades.filter { $0.semester == 1 || $0.semester == 2 }) {
            "\($0.subjectId)|\($0.semester!)"
        }
        return groups.values.compactMap { group in
            guard let first = group.first, let semester = first.semester else { return nil }
            var entries: [(value: Double, weight: Double)] = []
            var excluded = 0
            var unresolved = 0
            for grade in group {
                guard idCounts[grade.id] == 1 else { unresolved += 1; continue }
                guard let counts = grade.countsToAverage else { unresolved += 1; continue }
                if !counts { excluded += 1; continue }
                guard let weight = grade.weight, weight.isFinite, weight >= 0,
                      let gradeValue = exactNumericValue(grade.value) else {
                    unresolved += 1
                    continue
                }
                if weight == 0 { excluded += 1; continue }
                entries.append((value: gradeValue, weight: weight))
            }

            // Normalization prevents valid, large finite category weights
            // (e.g. 1e308 + 1e308) from overflowing the denominator and
            // producing NaN / Infinity in the UI. This does not infer weights.
            let mean: Double?
            if unresolved == 0, let maximum = entries.map(\.weight).max(), maximum > 0 {
                let scaled = entries.map { (value: $0.value, weight: $0.weight / maximum) }
                let denominator = scaled.reduce(0.0) { $0 + $1.weight }
                let numerator = scaled.reduce(0.0) { $0 + $1.value * $1.weight }
                let result = numerator / denominator
                mean = denominator > 0 && denominator.isFinite && result.isFinite ? result : nil
            } else {
                mean = nil
            }
            let reason: String? = mean != nil ? nil : (unresolved > 0
                ? "Nie można obliczyć: brak jednoznacznej wagi, statusu, wartości lub występuje powtórzony identyfikator oceny."
                : "Brak ocen z dodatnią wagą wliczanych do średniej.")
            return LocalGradeMean(subjectId: first.subjectId, semester: semester,
                                  mean: mean, includedCount: entries.count,
                                  excludedCount: excluded, unresolvedCount: unresolved,
                                  reason: reason)
        }.sorted { ($0.subjectId, $0.semester) < ($1.subjectId, $1.semester) }
    }
}
