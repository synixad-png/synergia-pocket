import Foundation

/// A local audit of candidate identities, NOT confirmation of Synergia's record IDs.
/// Never send notifications or label an entry as a new grade based on this report.
struct IdentityChangeReport {
    let module: SchoolModule
    let comparable: Bool
    let previousRecognized: Int
    let currentRecognized: Int
    let stableLinkCandidates: Int
    let possibleAdded: Int
    let possibleRemoved: Int
    let possibleEdited: Int
    let uncertain: Int
    let explanation: String
}

private struct LinkCandidate {
    let key: String
    let values: [String]
}

enum IdentityChangeAudit {
    private static func gradeCandidates(_ snapshot: ModuleSnapshot) -> ([LinkCandidate], Int, Int) {
        let preview = GradeParser.preview(snapshot: snapshot)
        guard let tables = snapshot.tables else { return ([], preview.grades.count, preview.rejectedRows) }
        var candidates: [LinkCandidate] = []
        for grade in preview.grades {
            // The provisional id encodes: sourceURL|tableIndex|rowIndex|subject|value.
            // It is never treated as a persistent identity.
            let parts = grade.id.components(separatedBy: "|")
            guard parts.count >= 5, let tableIndex = Int(parts[parts.count - 4]),
                  tables.indices.contains(tableIndex),
                  let link = RecordIdentity.uniqueLink(in: tables[tableIndex], rowIndex: grade.sourceRow - 1) else { continue }
            candidates.append(LinkCandidate(key: link.url,
                values: [grade.subject, grade.value, grade.dateText ?? "", grade.weightText ?? "",
                         grade.category ?? "", grade.comment ?? "", grade.semester ?? ""]))
        }
        return (candidates, preview.grades.count, preview.rejectedRows)
    }

    private static func messageCandidates(_ snapshot: ModuleSnapshot) -> ([LinkCandidate], Int, Int) {
        guard let tables = snapshot.tables else { return ([], 0, 0) }
        let rule = SchoolTableParser.ColumnRule(required: [
            "sender": ["nadawca", "od"], "subject": ["temat", "tytul"]
        ], optional: ["recipient": ["odbiorca", "do"], "date": ["data", "wyslano"],
                      "body": ["tresc", "pelna tresc", "wiadomosc"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        var candidates: [LinkCandidate] = []
        for row in parsed.rows {
            guard tables.indices.contains(row.tableIndex) else { continue }
            let links = MessageLinkInspector.inspect(table: tables[row.tableIndex], rowIndex: row.rowIndex)
            guard !links.ambiguous, let detail = links.detail else { continue }
            candidates.append(LinkCandidate(key: detail.url,
                values: [row.fields["sender"] ?? "", row.fields["subject"] ?? "",
                         row.fields["recipient"] ?? "", row.fields["date"] ?? "",
                         row.fields["body"] ?? ""]))
        }
        return (candidates, parsed.rows.count, parsed.discarded)
    }

    private static func unique(_ values: [LinkCandidate]) -> [String: [String]] {
        let grouped = Dictionary(grouping: values, by: \.key)
        return grouped.compactMapValues { $0.count == 1 ? $0[0].values : nil }
    }

    static func compare(previous: ModuleSnapshot, current: ModuleSnapshot) -> IdentityChangeReport {
        let module = current.module
        let isSupported = module == .grades || module == .messages
        let sameOrigin = previous.module == module && previous.sourceURL == current.sourceURL
        let oldTables = previous.tables ?? []
        let newTables = current.tables ?? []
        let sameLayout = !oldTables.isEmpty && oldTables.count == newTables.count &&
            zip(oldTables, newTables).allSatisfy { $0.caption == $1.caption && $0.rows.first == $1.rows.first }
        let old = module == .grades ? gradeCandidates(previous) : messageCandidates(previous)
        let now = module == .grades ? gradeCandidates(current) : messageCandidates(current)
        // Rejected rows indicate that the parser does not understand the full dataset.
        let compatible = isSupported && sameOrigin && sameLayout && old.2 == 0 && now.2 == 0
        let oldUnique = unique(old.0), newUnique = unique(now.0)
        let oldKeys = Set(oldUnique.keys), newKeys = Set(newUnique.keys)
        let overlap = oldKeys.intersection(newKeys)
        let edits = overlap.filter { oldUnique[$0] != newUnique[$0] }.count
        // Only overlapping links can be compared as candidate edits. Entries without
        // stable links, or repeated links, remain ambiguous and are never "deleted".
        let uncertain = max(old.1 - oldUnique.count, now.1 - newUnique.count)
        let added = newKeys.subtracting(oldKeys).count
        let removed = oldKeys.subtracting(newKeys).count
        let completeIdentities = uncertain == 0 && oldUnique.count == old.1 && newUnique.count == now.1
        let comparable = compatible && completeIdentities
        return IdentityChangeReport(module: module, comparable: comparable,
            previousRecognized: old.1, currentRecognized: now.1,
            stableLinkCandidates: overlap.count,
            possibleAdded: comparable ? added : 0,
            possibleRemoved: comparable ? removed : 0,
            possibleEdited: compatible ? edits : 0,
            uncertain: uncertain,
            explanation: comparable
                ? "Porównanie kandydatów z unikalnych odnośników. Nie potwierdzono semantyki identyfikatorów po stronie Synergii; brak automatycznych powiadomień."
                : "Niewystarczające dane, brak jednoznacznych linków, zmiana układu lub pominięte wiersze. Nie wnioskuj o nowych ani usuniętych wpisach."
        )
    }
}
