import Foundation

/// All legacy HTML snapshots are quarantined until /Me verifies the account.
/// Legacy unscoped files are deliberately left unread and are erased on explicit reset.
@MainActor
final class LocalStore: ObservableObject {
    @Published private(set) var snapshots: [SchoolModule: ModuleSnapshot] = [:]
    private(set) var verifiedAccountId: String?
    private let directory: URL

    init(directory: URL? = nil) {
        let base = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        self.directory = base.appendingPathComponent("school-data", isDirectory: true)
        try? FileManager.default.createDirectory(at: self.directory, withIntermediateDirectories: true)
        // Fail closed. Never read old unscoped <module>.json at launch.
    }

    private func folder(for accountId: String) -> URL {
        AccountPartition.directory(for: accountId, under: directory.appendingPathComponent("html-accounts", isDirectory: true))
    }
    private func path(for module: SchoolModule, accountId: String) -> URL {
        folder(for: accountId).appendingPathComponent(module.rawValue).appendingPathExtension("json")
    }
    func lock() { verifiedAccountId = nil; snapshots.removeAll() }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        for module in SchoolModule.allCases {
            if let bytes = try? Data(contentsOf: path(for: module, accountId: accountId)),
               let item = try? JSONDecoder().decode(ModuleSnapshot.self, from: bytes),
               item.module == module { snapshots[module] = item }
        }
    }
    func snapshot(for module: SchoolModule) -> ModuleSnapshot? {
        guard verifiedAccountId != nil else { return nil }
        return snapshots[module]
    }
    enum StoreError: Error { case unverifiedAccount }
    func save(_ value: ModuleSnapshot) throws {
        guard let id = verifiedAccountId else { throw StoreError.unverifiedAccount }
        let folder = folder(for: id)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try JSONEncoder().encode(value).write(to: path(for: value.module, accountId: id),
            options: [.atomic, .completeFileProtection])
        snapshots[value.module] = value
    }
    func erase() throws {
        lock()
        if FileManager.default.fileExists(atPath: directory.path) {
            // Do not delete JSON grades managed by DirectGradeStore.
            let scoped = directory.appendingPathComponent("html-accounts")
            if FileManager.default.fileExists(atPath: scoped.path) { try FileManager.default.removeItem(at: scoped) }
            for module in SchoolModule.allCases {
                let legacy = directory.appendingPathComponent(module.rawValue).appendingPathExtension("json")
                if FileManager.default.fileExists(atPath: legacy.path) { try FileManager.default.removeItem(at: legacy) }
            }
        }
    }
}
