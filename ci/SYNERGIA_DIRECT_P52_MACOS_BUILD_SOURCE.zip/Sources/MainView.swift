import SwiftUI
import QuickLook

struct MainView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var selectedSection: DirectPrimarySection? = .start

    // List selection for the regular-width sidebar is optional on iOS.
    // The compact TabView uses the same authoritative selection via a
    // nonoptional binding, preventing mismatches when an iPad window resizes.
    private var compactSelection: Binding<DirectPrimarySection> {
        Binding(
            get: { DirectAdaptiveNavigationPolicy.selectedOrStart(selectedSection) },
            set: { selectedSection = $0 }
        )
    }

    /// The same five destinations are available in both layouts. SwiftUI's
    /// horizontal size class changes for iPad multitasking; never use the
    /// physical device model or orientation as the navigation breakpoint.
    @ViewBuilder
    private var adaptiveNavigation: some View {
        if DirectAdaptiveNavigationPolicy.style(isRegularWidth: horizontalSizeClass == .regular) == .sidebar {
            NavigationSplitView {
                List(DirectPrimarySection.allCases, selection: $selectedSection) { section in
                    NavigationLink(value: section) {
                        Label(section.title, systemImage: section.symbol)
                    }
                }
                .listStyle(.sidebar)
                .navigationTitle("SYNERGIA DIRECT")
            } detail: {
                NavigationStack { rootContent(for: DirectAdaptiveNavigationPolicy.selectedOrStart(selectedSection)) }
            }
        } else {
            TabView(selection: compactSelection) {
                NavigationStack { DashboardView() }
                    .tabItem { Label("Start", systemImage: "house.fill") }
                    .tag(DirectPrimarySection.start)
                NavigationStack { ModuleView(module: .grades) }
                    .tabItem { Label("Oceny", systemImage: "graduationcap.fill") }
                    .tag(DirectPrimarySection.grades)
                NavigationStack { ModuleView(module: .timetable) }
                    .tabItem { Label("Plan", systemImage: "calendar") }
                    .tag(DirectPrimarySection.timetable)
                NavigationStack { ModuleView(module: .messages) }
                    .tabItem { Label("Wiadomości", systemImage: "envelope.fill") }
                    .tag(DirectPrimarySection.messages)
                NavigationStack { MoreView() }
                    .tabItem { Label("Więcej", systemImage: "square.grid.2x2.fill") }
                    .tag(DirectPrimarySection.more)
            }
        }
    }

    @ViewBuilder
    private func rootContent(for section: DirectPrimarySection) -> some View {
        switch section {
        case .start: DashboardView()
        case .grades: ModuleView(module: .grades)
        case .timetable: ModuleView(module: .timetable)
        case .messages: ModuleView(module: .messages)
        case .more: MoreView()
        }
    }

    var body: some View {
        adaptiveNavigation
            .tint(.indigo)
            .overlay {
                if portal.privacyShieldActive {
                    ZStack {
                        Color(.systemBackground).ignoresSafeArea()
                        VStack(spacing: 12) {
                            Image(systemName: "lock.shield.fill")
                                .font(.largeTitle)
                            Text("SYNERGIA DIRECT").font(.headline)
                            Text("Dane ukryte do czasu aktywacji i weryfikacji sesji.")
                                .font(.caption).multilineTextAlignment(.center)
                        }.padding(24)
                    }
                }
            }
            .onAppear { portal.restoreOfficialSessionAtLaunch() }
            .onChange(of: scenePhase) { _, newPhase in
                portal.scenePhaseChanged(to: newPhase)
            }
            .alert("Synergia Direct", isPresented: Binding(
                get: { portal.alert != nil },
                set: { if !$0 { portal.alert = nil } }
            )) {
                Button("OK") { portal.alert = nil }
            } message: { Text(portal.alert ?? "") }
    }
}

struct DashboardView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @State private var showTechnicalDetails = false
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    // 1 column on narrow iPhones and at Accessibility text sizes;
    // iPad still gains columns as its available width permits.
    private var columns: [GridItem] {
        [GridItem(.adaptive(minimum: CGFloat(DirectReadabilityPolicy.minimumTileWidth(
            accessibilityText: dynamicTypeSize.isAccessibilitySize)), spacing: 12))]
    }

    private var verifiedSession: Bool {
        portal.store.verifiedAccountId != nil && !portal.privacyShieldActive
    }

    private func tile(for module: SchoolModule) -> DirectDashboardTileState {
        guard let account = portal.store.verifiedAccountId, !portal.privacyShieldActive else {
            return .evaluate(accountVerified: false, sameAccount: false, capturedAt: nil, localCount: nil)
        }
        switch module {
        case .grades:
            let db = portal.directGradeStore
            return .evaluate(accountVerified: true, sameAccount: db.capturedAt == nil || db.verifiedAccountId == account,
                             capturedAt: db.capturedAt, localCount: db.grades.count + db.supplemental.count)
        case .attendance:
            let db = portal.directAttendanceStore
            return .evaluate(accountVerified: true, sameAccount: db.capturedAt == nil || db.verifiedAccountId == account,
                             capturedAt: db.capturedAt, localCount: db.records.count)
        case .messages:
            let snapshots = Array(portal.directMailboxes.values)
            // Multiple folders are not a claim of complete mail coverage.
            return .evaluate(accountVerified: true,
                             sameAccount: snapshots.allSatisfy { $0.accountId == account },
                             capturedAt: snapshots.map(\.fetchedAt).max(), localCount: nil)
        case .timetable:
            let week = portal.directTimetable
            let chosenWeek = DirectTimetableParser.monday(containing: portal.timetableChosenDate)
            let correctWeek = week?.monday == chosenWeek
            return .evaluate(accountVerified: true, sameAccount: week == nil || week?.accountId == account,
                             capturedAt: correctWeek ? week?.fetchedAt : nil,
                             localCount: correctWeek ? week?.entries.count : nil)
        case .calendar, .homework, .announcements, .documents:
            let feed = portal.directFeeds[module]
            return .evaluate(accountVerified: true, sameAccount: feed == nil || feed?.verifiedAccountId == account,
                             capturedAt: feed?.fetchedAt, localCount: feed?.records.count)
        }
    }

    private var overview: DirectDashboardSummary {
        .evaluate(verified: verifiedSession, tiles: SchoolModule.allCases.map { tile(for: $0) })
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header
                connectionCard
                overviewCard
                refreshControls
                moduleGrid
                technicalDetails
            }
            .padding(16)
            .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.readableMaxWidth(
                isRegularWidth: horizontalSizeClass == .regular)))
            .frame(maxWidth: .infinity)
        }
        .navigationTitle("SYNERGIA DIRECT")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Twój dziennik").font(.largeTitle.bold())
            Text("Szkoła, plan i wiadomości w jednym miejscu")
                .font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 8)
    }

    private var connectionCard: some View {
        NavigationLink(destination: ConnectionView()) {
            HStack(spacing: 12) {
                Image(systemName: verifiedSession ? "checkmark.shield.fill" : "lock.iphone")
                    .font(.title2).foregroundStyle(.indigo)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 5) {
                    Text(verifiedSession ? "Konto zweryfikowane" : "Połącz z Synergią")
                        .font(.headline)
                    Text(portal.accountStatus).font(.caption).foregroundStyle(.secondary)
                        .lineLimit(3)
                }
                Spacer(minLength: 4)
                Image(systemName: "chevron.right")
                    .font(.caption.bold()).foregroundStyle(.secondary)
                    .accessibilityHidden(true)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .foregroundStyle(.primary)
            .background(.indigo.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
        }
        .accessibilityLabel(verifiedSession ? "Konto zweryfikowane. Ustawienia połączenia" : "Połącz z Synergią")
        .accessibilityHint("Otwiera logowanie i sprawdzanie aktywnego konta wewnątrz aplikacji")
    }

    private var overviewCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: verifiedSession ? "square.stack.3d.up" : "lock.shield")
                    .foregroundStyle(verifiedSession ? Color.indigo : Color.secondary)
                    .accessibilityHidden(true)
                Text(overview.title).font(.headline).monospacedDigit()
            }
            Text(overview.explanation).font(.footnote).foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
        .accessibilityElement(children: .combine)
    }

    private var refreshControls: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("Odświeżanie ręczne").font(.title3.bold())
            Button { portal.synchronizeCoreModules() } label: {
                Label("Odśwież oceny, frekwencję i wiadomości", systemImage: "arrow.triangle.2.circlepath")
                    .frame(maxWidth: .infinity, minHeight: 36)
            }
            .buttonStyle(.borderedProminent)
            .disabled(portal.coreSyncBusy || portal.isBusy || portal.isSyncing || portal.manualRefreshRunning != nil)
            .disabled(!verifiedSession)
            .disabled(portal.directGradeBusy || portal.directAttendanceBusy ||
                      portal.directMessagesBusy != nil || portal.directFeedBatchBusy)
            if portal.coreSyncBusy {
                ProgressView("Trwa sprawdzanie trzech modułów…")
            }
            if portal.manualRefreshRunning != nil {
                if portal.manualRefreshStopping {
                    ProgressView("Kończenie poprzedniego odczytu…")
                } else {
                    Button("Przerwij bieżące odświeżanie") { portal.cancelManualRefresh() }
                        .buttonStyle(.bordered)
                }
            }
            if verifiedSession {
                Text(portal.manualRefreshSummary).font(.caption).foregroundStyle(.secondary)
            }
            Text("Aplikacja nie sprawdza nowych wpisów automatycznie w tle.")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    private var moduleGrid: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Moduły").font(.title3.bold())
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(SchoolModule.allCases) { module in
                    let record = tile(for: module)
                    NavigationLink(destination: ModuleView(module: module)) {
                        VStack(alignment: .leading, spacing: 9) {
                            Image(systemName: module.symbol)
                                .font(.title2).foregroundStyle(.indigo)
                                .accessibilityHidden(true)
                            Text(module.title)
                                .font(.headline).foregroundStyle(.primary)
                                .fixedSize(horizontal: false, vertical: true)
                            Text(record.title)
                                .font(.subheadline).foregroundStyle(.secondary)
                            if let count = record.localCount, record.kind == .recorded {
                                Text("W odczycie: \(count)")
                                    .font(.footnote).foregroundStyle(.secondary)
                                    .monospacedDigit()
                            }
                            if let time = record.capturedAt {
                                Text(time.formatted(date: .numeric, time: .shortened))
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                        }
                        .frame(maxWidth: .infinity, minHeight: 106, alignment: .leading)
                        .padding(14)
                        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
                    }
                    .accessibilityLabel("\(module.title). \(record.accessibilityText)")
                    .accessibilityHint("Otwiera moduł w aplikacji")
                }
            }
        }
    }

    private var technicalDetails: some View {
        DisclosureGroup("Szczegóły synchronizacji i diagnostyka", isExpanded: $showTechnicalDetails) {
            VStack(alignment: .leading, spacing: 12) {
                Button { portal.verifyAccount() } label: {
                    Label("Sprawdź aktywną sesję", systemImage: "checkmark.shield")
                }
                .disabled(portal.isBusy || portal.isSyncing || portal.coreSyncBusy || portal.manualRefreshRunning != nil)
                if verifiedSession {
                    Text(portal.coreSyncStatus).font(.caption).foregroundStyle(.secondary)
                }
                Button { portal.refreshAllDirectFeeds() } label: {
                    Label("Odśwież zadania, terminarz, ogłoszenia i dokumenty JSON", systemImage: "arrow.clockwise.circle")
                }
                .buttonStyle(.bordered)
                .disabled(portal.coreSyncBusy || portal.directFeedBatchBusy ||
                          portal.manualRefreshRunning != nil || portal.directFeedBusy != nil ||
                          portal.isBusy || portal.isSyncing || portal.store.verifiedAccountId == nil)
                if portal.directFeedBatchBusy { ProgressView("Trwa odczyt czterech modułów…") }
                if verifiedSession {
                    Text("Zapis offline: \(portal.directOfflineFeedStore.feeds.count)/4 modułów. " +
                         "Odtworzony zapis jest NIEAKTUALNY do ponownego odświeżenia.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if let change = portal.coreSyncChanges, verifiedSession {
                    Text("Porównywalne odczyty: oceny +\(change.newGrades) / zmienione \(change.editedGrades), " +
                         "frekwencja +\(change.newAttendance) / zmienione \(change.editedAttendance), " +
                         "wiadomości +\(change.newMessages).")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(portal.coreSyncEvidenceSummary)
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Divider()
                Button { portal.syncApprovedModules() } label: {
                    Label("Synchronizuj zapisane moduły", systemImage: "arrow.triangle.2.circlepath")
                }
                .buttonStyle(.bordered)
                .disabled(portal.isSyncing || portal.isBusy || portal.manualRefreshRunning != nil)
                if verifiedSession {
                    Text(portal.syncSummary).font(.caption).foregroundStyle(.secondary)
                }
                if portal.isSyncing, portal.manualRefreshRunning == nil {
                    Button("Przerwij synchronizację") { portal.stopSync() }
                        .buttonStyle(.bordered)
                }
                if let run = portal.auditStore.lastRun, verifiedSession {
                    DisclosureGroup("Raport ostatniej synchronizacji") {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Zapisano stron: \(run.savedPages); pozostałych wyników: \(run.failedPages)")
                                .font(.caption)
                            if run.interrupted {
                                Text("Synchronizacja została przerwana.")
                                    .font(.caption).foregroundStyle(.orange)
                            }
                            ForEach(run.pages) { entry in
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("\(entry.module.title): \(entry.status.rawValue)")
                                        .font(.caption.bold())
                                    Text(entry.explanation).font(.caption2).foregroundStyle(.secondary)
                                    if entry.detectedPagination {
                                        Text("Wykryto wiele stron wyników.")
                                            .font(.caption2).foregroundStyle(.orange)
                                    }
                                }
                            }
                            Text("Raport dotyczy wyłącznie zatwierdzonych stron; nie potwierdza pełnej liczby ocen ani wiadomości w Synergii.")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if let delta = portal.lastDelta, verifiedSession {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Porównanie lokalne: \(delta.module.title)").font(.subheadline.bold())
                        if delta.comparable {
                            Text("Wiersze dodane: \(delta.addedRowOccurrences), usunięte: \(delta.removedRowOccurrences)")
                                .font(.caption)
                        } else {
                            Text("Odczyty nieporównywalne").font(.caption)
                        }
                        Text(delta.explanation).font(.caption2).foregroundStyle(.secondary)
                    }
                }
                Text("Synchronizacja tylko na pierwszym planie. Dane modułu zapisują się dopiero po zaakceptowaniu zatwierdzonych stron.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            .padding(.vertical, 12)
        }
        .font(.subheadline)
    }
}

struct ModuleView: View {
    @State private var gradeSemesterSelection = 0
    @State private var gradeSubjectSelection = ""
    @State private var showDirectSendConfirmation = false
    @State private var showDirectReviewAcknowledgement = false
    @State private var showDirectRecipientPicker = false
    @State private var selectedDirectMailbox: DirectMailbox = .inbox
    @State private var directMailboxSearch = ""
    @State private var directMailboxFilter: DirectMailboxViewFilter = .all
    @State private var openedDirectMessage: DirectMessage?
    @State private var showDiagnosticContent = false
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    let module: SchoolModule

    /// UI boundary only; the portal and stores still enforce their own account fences.
    /// Missing capture does not mean an existing account's data is locked.
    private var moduleDataAllowed: Bool {
        let id = portal.store.verifiedAccountId
        let shield = portal.privacyShieldActive
        switch module {
        case .grades:
            let db = portal.directGradeStore
            return DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                privacyShieldActive: shield, ownerAccountId: db.verifiedAccountId,
                hasData: db.capturedAt != nil || !db.grades.isEmpty || !db.supplemental.isEmpty)
        case .attendance:
            let db = portal.directAttendanceStore
            return DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                privacyShieldActive: shield, ownerAccountId: db.verifiedAccountId,
                hasData: db.capturedAt != nil || !db.records.isEmpty)
        case .messages:
            return DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                privacyShieldActive: shield, ownerAccountId: nil, hasData: false) &&
                portal.directMailboxes.values.allSatisfy { snapshot in
                    DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                        privacyShieldActive: shield, ownerAccountId: snapshot.accountId, hasData: true)
                }
        case .timetable:
            let snapshot = portal.directTimetable
            return DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                privacyShieldActive: shield, ownerAccountId: snapshot?.accountId,
                hasData: snapshot != nil)
        case .homework, .calendar, .announcements, .documents:
            let snapshot = portal.directFeeds[module]
            return DirectModuleAccessPolicy.canDisplay(verifiedAccountId: id,
                privacyShieldActive: shield, ownerAccountId: snapshot?.verifiedAccountId,
                hasData: snapshot != nil)
        }
    }

    /// Read-only UI requests use one shared lock. An uncertain send is a separate
    /// review state, not a network operation; it blocks ordinary refreshes but
    /// must not prevent a deliberate, read-only check of the Sent folder.
    private var activeNetworkOperation: Bool {
        portal.isBusy || portal.isSyncing || portal.coreSyncBusy ||
        portal.manualRefreshRunning != nil || portal.directGradeBusy ||
        portal.directAttendanceBusy || portal.directMessagesBusy != nil ||
        portal.directUnreadBusy || portal.directTimetableBusy ||
        portal.directFeedBusy != nil || portal.directFeedBatchBusy ||
        portal.directSendBusy || portal.directRecipientBusy ||
        portal.directMessageDetailBusy || portal.directAttachmentBusy != nil ||
        portal.directHomeworkFileBusy != nil || portal.directSchoolFileBusy != nil
    }

    private var canRefreshModule: Bool {
        DirectModuleAccessPolicy.canRefresh(verifiedAccountId: portal.store.verifiedAccountId,
            privacyShieldActive: portal.privacyShieldActive,
            anyOperationBusy: activeNetworkOperation || portal.directSendReviewRequired)
    }

    private var canReviewOutbox: Bool {
        DirectModuleAccessPolicy.canReviewOutbox(verifiedAccountId: portal.store.verifiedAccountId,
            privacyShieldActive: portal.privacyShieldActive,
            pendingSendReview: portal.directSendReviewRequired,
            anyOperationBusy: activeNetworkOperation)
    }

    /// Account transitions must never leave the previous pupil's search,
    /// recipient sheet or message reader open over the newly verified account.
    /// Do not clear the outgoing message draft: it is owned by the portal's
    /// account-scoped compose lifecycle, not by this presentation reset.
    private func closeSensitivePresentations() {
        openedDirectMessage = nil
        showDirectRecipientPicker = false
        showDirectSendConfirmation = false
        showDirectReviewAcknowledgement = false
        showDiagnosticContent = false
    }

    private func resetForVerifiedAccountChange() {
        closeSensitivePresentations()
        gradeSemesterSelection = 0
        gradeSubjectSelection = ""
        selectedDirectMailbox = .inbox
        directMailboxSearch = ""
        directMailboxFilter = .all
    }

    private func refreshThisModule() {
        guard canRefreshModule else { return }
        switch module {
        case .grades: portal.refreshDirectGrades()
        case .attendance: portal.refreshDirectAttendance()
        case .timetable: portal.refreshDirectTimetable()
        case .messages: portal.refreshDirectMessages(selectedDirectMailbox)
        case .homework, .calendar, .announcements, .documents:
            portal.refreshDirectFeed(module)
        }
    }

    private func refreshUnreadCounts() {
        guard canRefreshModule, module == .messages else { return }
        portal.refreshDirectUnreadCounts()
    }

    private func refreshRelatedFeeds() {
        guard canRefreshModule,
              [.homework, .calendar, .announcements, .documents].contains(module) else { return }
        portal.refreshAllDirectFeeds()
    }

    /// An opened reader must correspond to a verified mailbox entry, and a
    /// request must be allowed *before* presenting the reader. Otherwise the
    /// transport intentionally refuses the call and the sheet looks empty.
    private func canOpenDirectMessage(_ message: DirectMessage,
                                      snapshot: DirectMailboxSnapshot) -> Bool {
        DirectMessageReadRequestPolicy.canStart(
            hasAccess: DirectMessageReaderPolicy.canDisplay(
                message: message,
                verifiedAccountId: portal.store.verifiedAccountId,
                authorizedAccountId: snapshot.accountId,
                snapshot: snapshot,
                privacyShielded: portal.privacyShieldActive),
            operationBusy: activeNetworkOperation)
    }

    private func verifySentFolderAfterUncertainSend() {
        guard module == .messages, canReviewOutbox else { return }
        selectedDirectMailbox = .outbox
        directMailboxSearch = ""
        directMailboxFilter = .all
        portal.refreshDirectMessages(.outbox)
    }

    private var readPresentation: DirectReadPresentation {
        let account = portal.store.verifiedAccountId
        let verified = account != nil && !portal.privacyShieldActive
        let failed = portal.failedDirectReads.contains(module)
        switch module {
        case .grades:
            let db = portal.directGradeStore
            return .evaluate(verified: verified, loading: portal.directGradeBusy, failed: failed,
                             count: db.capturedAt == nil ? nil : db.grades.count + db.supplemental.count,
                             capturedAt: db.capturedAt, complete: false,
                             accountMatches: moduleDataAllowed,
                             fresh: portal.freshDirectReads.contains(.grades))
        case .attendance:
            let db = portal.directAttendanceStore
            return .evaluate(verified: verified, loading: portal.directAttendanceBusy, failed: failed,
                             count: db.capturedAt == nil ? nil : db.records.count,
                             capturedAt: db.capturedAt, complete: false,
                             accountMatches: moduleDataAllowed,
                             fresh: portal.freshDirectReads.contains(.attendance))
        case .messages:
            // Wiadomości obejmują wiele skrzynek; brak odczytu Odebranych
            // nie może ukrywać poprawnie pobranej skrzynki Wysłane lub archiwum.
            let snapshots = Array(portal.directMailboxes.values)
            let count = snapshots.isEmpty ? nil : snapshots.reduce(0) { $0 + $1.messages.count }
            let last = snapshots.map(\.fetchedAt).max()
            return .evaluate(verified: verified,
                             loading: portal.directMessagesBusy != nil || portal.directUnreadBusy,
                             failed: !portal.failedDirectMailboxes.isEmpty,
                             count: count, capturedAt: last,
                             complete: false, // Nie pobrano z definicji wszystkich skrzynek.
                             accountMatches: moduleDataAllowed)
        case .timetable:
            let plan = portal.directTimetable
            let chosenWeek = DirectTimetableParser.monday(containing: portal.timetableChosenDate)
            return .evaluate(verified: verified, loading: portal.directTimetableBusy,
                             failed: failed, count: plan?.monday == chosenWeek ? plan?.entries.count : nil,
                             capturedAt: plan?.monday == chosenWeek ? plan?.fetchedAt : nil,
                             complete: false,
                             accountMatches: moduleDataAllowed,
                             fresh: portal.freshDirectReads.contains(.timetable))
        case .homework, .calendar, .announcements, .documents:
            let feed = portal.directFeeds[module]
            return .evaluate(verified: verified,
                             loading: portal.directFeedBusy == module || portal.directFeedBatchBusy,
                             failed: failed, count: feed?.records.count, capturedAt: feed?.fetchedAt,
                             complete: feed?.completenessKnown ?? false,
                             accountMatches: moduleDataAllowed,
                             fresh: portal.freshDirectReads.contains(module))
        }
    }
    var body: some View {
        List {
            Section {
                HStack(alignment: .top, spacing: 12) {
                    Image(systemName: module.symbol)
                        .font(.title2).foregroundStyle(.indigo)
                        .accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(module.title).font(.headline)
                        Text(DirectModuleAccessPolicy.guidance(for: module.rawValue))
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                .accessibilityElement(children: .combine)
            }
            Section("Stan odczytu JSON") {
                DirectReadStatusPanel(state: readPresentation)
                if !moduleDataAllowed {
                    Text("Dane nie są dostępne dla bieżącej, zweryfikowanej sesji. " +
                         "Zaloguj się ponownie lub odśwież ten moduł po potwierdzeniu konta.")
                        .font(.footnote).foregroundStyle(.secondary)
                    NavigationLink("Otwórz logowanie wewnątrz aplikacji", destination: ConnectionView())
                }
            }
            if moduleDataAllowed {
            if module == .grades {
                Section("Oceny bezpośrednio z Synergii (JSON)") {
                    Button(action: refreshThisModule) {
                        Label("Pobierz oceny z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(!canRefreshModule)
                    if portal.directGradeBusy { ProgressView("Trwa odczyt JSON…") }
                    Text(portal.directGradeStatus)
                        .font(.caption).foregroundStyle(.secondary)
                    if let date = portal.directGradeStore.capturedAt {
                        Text("Ostatni poprawny zapis: \(date.formatted(date: .numeric, time: .shortened))")
                            .font(.caption)
                        Text("Ocen zwykłych: \(portal.directGradeStore.grades.count), pozostałych wpisów: \(portal.directGradeStore.supplemental.count). Kompletność konta nie została potwierdzona.")
                            .font(.caption).foregroundStyle(.orange)
                        let availableSubjects = Array(Set(
                            portal.directGradeStore.grades.map(\.subjectId) +
                            portal.directGradeStore.supplemental.compactMap(\.subjectId)))
                            .sorted { a, b in
                                (portal.directGradeStore.subjects[a] ?? a).localizedCompare(
                                    portal.directGradeStore.subjects[b] ?? b) == .orderedAscending
                            }
                        Picker("Przedmiot", selection: $gradeSubjectSelection) {
                            Text("Wszystkie przedmioty").tag("")
                            ForEach(availableSubjects, id: \.self) { id in
                                Text(portal.directGradeStore.subjects[id] ?? "ID \(id)").tag(id)
                            }
                        }
                        if !gradeSubjectSelection.isEmpty && !availableSubjects.contains(gradeSubjectSelection) {
                            Text("Poprzednio wybrany przedmiot nie występuje w tym koncie.")
                                .font(.caption).foregroundStyle(.orange)
                            Button("Pokaż wszystkie przedmioty") { gradeSubjectSelection = "" }
                        }
                        ForEach(portal.directGradeStore.supplemental.filter { item in
                            (gradeSubjectSelection.isEmpty || item.subjectId == gradeSubjectSelection) &&
                            (gradeSemesterSelection == 0 || (gradeSemesterSelection == 3
                                ? item.semester != 1 && item.semester != 2
                                : item.semester == gradeSemesterSelection))
                        }) { extra in
                            VStack(alignment: .leading, spacing: 2) {
                                Text("\(extra.family.rawValue): \(extra.value)")
                                if let subject = extra.subjectId {
                                    Text("Przedmiot: \(portal.directGradeStore.subjects[subject] ?? "ID \(subject)")")
                                        .font(.caption)
                                }
                                Text("Semestr: \(extra.semester.map(String.init) ?? "brak oznaczenia")")
                                    .font(.caption)
                            }
                        }
                        Text(GradePortfolioSemesterCoverage.report(
                            standard: portal.directGradeStore.grades,
                            supplemental: portal.directGradeStore.supplemental).message)
                            .font(.caption).foregroundStyle(.orange)
                    }
                    Picker("Semestr", selection: $gradeSemesterSelection) {
                        Text("Wszystkie").tag(0)
                        Text("I").tag(1)
                        Text("II").tag(2)
                        Text("Inne").tag(3)
                    }
                    .pickerStyle(.segmented)
                    let selectedGrades = GradeSemesterPresentation.select(
                        portal.directGradeStore.grades, filter: gradeSemesterSelection)
                        .filter { gradeSubjectSelection.isEmpty || $0.subjectId == gradeSubjectSelection }
                    let referenceAudit = GradeSubjectAuthorAudit.summarize(
                        selectedGrades,
                        subjects: portal.directGradeStore.subjects,
                        authors: portal.directGradeStore.teachers,
                        earlierAuthorIds: portal.directGradeStore.olderTeacherIds)
                    Text(referenceAudit.message)
                        .font(.caption)
                        .foregroundStyle(referenceAudit.hasWarnings ? Color.orange : Color.secondary)
                    Text(GradeSemesterPresentation.summary(
                        grades: portal.directGradeStore.grades.filter {
                            gradeSubjectSelection.isEmpty || $0.subjectId == gradeSubjectSelection
                        }, filter: gradeSemesterSelection))
                        .font(.caption).foregroundStyle(.secondary)
                    if !selectedGrades.isEmpty {
                        Section("Średnie lokalne — wyłącznie orientacyjne") {
                            Text("Nie są to średnie oficjalnie obliczone przez Synergię. Oceny z plusami, minusami i nieznanymi wagami nie są przeliczane na podstawie domysłów.")
                                .font(.caption).foregroundStyle(.secondary)
                            ForEach(GradeWeightedAverage.calculate(selectedGrades), id: \.id) { summary in
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("\(portal.directGradeStore.subjects[summary.subjectId] ?? summary.subjectId) · semestr \(summary.semester)")
                                        .font(.subheadline)
                                    if let value = summary.mean {
                                        Text("Średnia orientacyjna: \(value.formatted(.number.precision(.fractionLength(2))))")
                                    } else {
                                        Text(summary.reason ?? "Nie można obliczyć")
                                            .font(.caption).foregroundStyle(.orange)
                                    }
                                    Text("Wliczone: \(summary.includedCount) · pominięte: \(summary.excludedCount) · nierozstrzygnięte: \(summary.unresolvedCount)")
                                        .font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    ForEach(selectedGrades) { grade in
                        NavigationLink {
                            DirectGradeDetailView(
                                gradeID: grade.id,
                                expectedAccountID: portal.store.verifiedAccountId ?? "")
                        } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                if dynamicTypeSize.isAccessibilitySize {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(portal.directGradeStore.subjects[grade.subjectId] ?? "Przedmiot ID \(grade.subjectId)")
                                            .font(.headline)
                                            .fixedSize(horizontal: false, vertical: true)
                                        Text("Ocena: \(grade.value)")
                                            .font(.title3.bold())
                                    }
                                } else {
                                    HStack {
                                        Text(portal.directGradeStore.subjects[grade.subjectId] ?? "Przedmiot ID \(grade.subjectId)")
                                            .font(.headline)
                                            .fixedSize(horizontal: false, vertical: true)
                                        Spacer(minLength: 8)
                                        Text(grade.value).font(.title3.bold())
                                    }
                                }
                                if let date = grade.addedAt {
                                    Text("Data: \(date)").font(.caption).foregroundStyle(.secondary)
                                }
                                if !grade.commentTexts.isEmpty {
                                    Text("Komentarze: \(grade.commentTexts.count) — otwórz pełne szczegóły")
                                        .font(.caption).foregroundStyle(.secondary)
                                } else {
                                    Text("Otwórz pełne szczegóły oceny")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }.padding(.vertical, 3)
                        }
                    }
                }
            }
            if module == .messages {
                Section("Wiadomości bezpośrednio z Synergii (JSON)") {
                    Text("Sesja Wiadomości działa w osobnej domenie. Jeśli odczyt zgłosi brak sesji, otwórz najpierw oficjalną skrzynkę.")
                        .font(.caption).foregroundStyle(.secondary)
                    NavigationLink(destination: ConnectionView(initialModule: .messages, openMessages: true)) {
                        Label("Otwórz oficjalne Wiadomości", systemImage: "lock.shield")
                    }
                    Button(action: refreshUnreadCounts) {
                        Label("Pobierz liczniki nieprzeczytanych", systemImage: "number")
                    }
                    .disabled(!canRefreshModule)
                    if portal.directUnreadBusy { ProgressView("Sprawdzanie liczników…") }
                    if let unread = portal.directUnreadCounts {
                        ForEach(Array(DirectUnreadCounts.fields.enumerated()), id: \.offset) { item in
                            if let count = unread.values[item.element.key] {
                                Text("\(item.element.label): \(count)").font(.caption)
                            }
                        }
                    }
                    if !portal.directUnreadStatus.isEmpty {
                        Text(portal.directUnreadStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    Picker("Skrzynka", selection: $selectedDirectMailbox) {
                        ForEach(DirectMailbox.allCases) { mailbox in
                            Text(mailbox.label).tag(mailbox)
                        }
                    }
                    .pickerStyle(.menu)
                    .accessibilityLabel("Wybierz skrzynkę wiadomości")
                    .onChange(of: selectedDirectMailbox) { _, _ in
                        directMailboxSearch = ""
                        directMailboxFilter = .all
                    }
                    TextField("Szukaj w pobranych wiadomościach", text: $directMailboxSearch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .accessibilityLabel("Szukaj w pobranej skrzynce")
                    Picker("Filtr wiadomości", selection: $directMailboxFilter) {
                        ForEach(DirectMailboxViewFilter.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .pickerStyle(.menu)
                    Text("Szukasz wyłącznie w pobranej skrzynce. Brak daty odczytu nie dowodzi, że wiadomość jest nieprzeczytana.")
                        .font(.footnote).foregroundStyle(.secondary)
                    ForEach([selectedDirectMailbox]) { mailbox in
                        Button(action: refreshThisModule) {
                            Label("Pobierz: \(mailbox.label)", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .disabled(!canRefreshModule)
                        if portal.directMessagesBusy == mailbox { ProgressView("Pobieranie stron…") }
                        if let snapshot = portal.directMailboxes[mailbox] {
                            DirectReadStatusPanel(state: .evaluate(
                                verified: portal.store.verifiedAccountId != nil,
                                loading: portal.directMessagesBusy == mailbox,
                                failed: portal.failedDirectMailboxes.contains(mailbox),
                                count: snapshot.messages.count, capturedAt: snapshot.fetchedAt,
                                complete: snapshot.complete,
                                accountMatches: snapshot.accountId == portal.store.verifiedAccountId))
                        } else if portal.failedDirectMailboxes.contains(mailbox) {
                            DirectReadStatusPanel(state: .evaluate(
                                verified: portal.store.verifiedAccountId != nil,
                                loading: portal.directMessagesBusy == mailbox,
                                failed: true, count: nil, capturedAt: nil, complete: false))
                        }
                        Text(portal.directMessagesStatus[mailbox] ?? "Nie odczytano skrzynki")
                            .font(.caption).foregroundStyle(.secondary)
                        if let snapshot = portal.directMailboxes[mailbox],
                           let presented = DirectMailboxPresentation.present(
                                snapshot: snapshot,
                                verifiedAccountId: portal.store.verifiedAccountId,
                                privacyShielded: portal.privacyShieldActive,
                                mailbox: mailbox,
                                query: directMailboxSearch,
                                filter: directMailboxFilter) {
                            Text("\(mailbox.label): \(snapshot.messages.count) pobranych wpisów; odczyt \(snapshot.fetchedAt.formatted(date: .numeric, time: .shortened))")
                                .font(.caption).foregroundStyle(.secondary)
                            Text(presented.selectionDescription)
                                .font(.caption).foregroundStyle(.secondary)
                            if let total = presented.serverTotal {
                                Text("Liczba zgłoszona przez serwer: \(total)" +
                                     (presented.complete ? " (odczyt kompletny)" : " (niepotwierdzona kompletność)"))
                                    .font(.caption2).foregroundStyle(.secondary)
                            } else {
                                Text("Serwer nie potwierdził całkowitej liczby wiadomości.")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                            if presented.messages.isEmpty {
                                Text("Brak wpisów zgodnych z filtrem w pobranej skrzynce.")
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                            ForEach(presented.messages) { message in
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(message.subject).font(.headline)
                                    Text("\(mailbox.isOutgoing ? "Do" : "Od"): \(message.correspondent)")
                                        .font(.subheadline)
                                    if let date = message.sentAt { Text(date).font(.caption) }
                                    Text(DirectMailboxPresentation.readDateDescription(message))
                                        .font(.footnote).foregroundStyle(.secondary)
                                    if message.hasAttachments {
                                        Label("Wiadomość ma załączniki", systemImage: "paperclip")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    if !message.preview.isEmpty {
                                        Text(message.preview).font(.subheadline).lineLimit(3)
                                    }
                                    Button(mailbox.mayMarkRead ? "Otwórz treść (może oznaczyć jako przeczytaną)" : "Otwórz treść") {
                                        // Only a deliberate tap may read the remote message (and potentially mark it read).
                                        // Re-evaluate the gate inside the action; a disabled control alone
                                        // cannot protect against a state change before the tap is handled.
                                        guard canOpenDirectMessage(message, snapshot: snapshot) else { return }
                                        portal.refreshDirectMessageDetail(message)
                                        openedDirectMessage = message
                                    }
                                    .font(.subheadline)
                                    .buttonStyle(.bordered)
                                    .disabled(!canOpenDirectMessage(message, snapshot: snapshot))
                                }.padding(.vertical, 6)
                            }
                        }
                    }
                    if portal.directMessageDetailBusy { ProgressView("Odczyt treści…") }
                    if portal.directAttachmentBusy != nil { ProgressView("Pobieranie załącznika…") }
                    if !portal.directAttachmentStatus.isEmpty {
                        Text(portal.directAttachmentStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    if !portal.directMessageDetailStatus.isEmpty {
                        Text(portal.directMessageDetailStatus)
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text("Załączniki są pobierane tylko na żądanie, a wiadomości nie są zapisywane w lokalnym cache.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Section("Napisz wiadomość / odpowiedz") {
                    Text("Wysyłanie korzysta z oficjalnej domeny Wiadomości. Nie jest uruchamiane automatycznie. W przypadku niepewnego wyniku sprawdź folder Wysłane, zanim napiszesz ponownie.")
                        .font(.caption).foregroundStyle(.secondary)
                    Button {
                        portal.beginDirectNewMessage()
                    } label: {
                        Label("Nowa wiadomość — wyczyść formularz", systemImage: "square.and.pencil")
                    }
                    .disabled(portal.directSendBusy || portal.directRecipientBusy || portal.directSendReviewRequired)
                    if let reply = portal.directReplyContext {
                        Text("Odpowiedź do: \(reply.recipientName)")
                            .font(.subheadline.bold())
                        Text("Wątek: \(reply.subject)")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Button {
                            portal.refreshDirectRecipientGroups()
                        } label: {
                            Label("Pobierz grupy odbiorców", systemImage: "person.2")
                        }
                        .disabled(portal.directRecipientBusy || portal.directSendBusy || portal.directSendReviewRequired || portal.directMessagesBusy != nil)
                        if let groups = portal.directRecipientGroups {
                            Menu {
                                ForEach(groups.groups) { group in
                                    Button(group.name) { portal.refreshDirectRecipients(group) }
                                }
                            } label: {
                                Label(portal.directSelectedGroup?.name ?? "Wybierz grupę", systemImage: "person.3")
                            }
                            .disabled(portal.directRecipientBusy || portal.directSendBusy || portal.directSendReviewRequired)
                        }
                        if let recipients = portal.directRecipientList {
                            Button {
                                showDirectRecipientPicker = true
                            } label: {
                                Label(portal.directSelectedRecipient?.name ??
                                      "Wybierz odbiorcę (\(recipients.recipients.count))",
                                      systemImage: "person.crop.circle")
                            }
                            .disabled(recipients.recipients.isEmpty || portal.directRecipientBusy ||
                                      portal.directSendBusy || portal.directSendReviewRequired ||
                                      portal.privacyShieldActive)
                            Text("Wybór odbiorcy otwiera osobny ekran z wyszukiwarką. " +
                                 "Osoba niedostępna nie może zostać wybrana.")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    if portal.directRecipientBusy { ProgressView("Pobieranie odbiorców…") }
                    if !portal.directRecipientStatus.isEmpty {
                        Text(portal.directRecipientStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    TextField("Temat", text: $portal.directDraftSubject)
                        .textInputAutocapitalization(.sentences)
                        .disabled(portal.directSendBusy || portal.directSendReviewRequired)
                    TextEditor(text: $portal.directDraftBody)
                        .frame(minHeight: 120)
                        .accessibilityLabel("Treść wiadomości")
                        .disabled(portal.directSendBusy || portal.directSendReviewRequired)
                    Text("Temat: \(portal.directDraftSubject.count)/200 znaków · Treść: \(portal.directDraftBody.count)/10 000 znaków.")
                        .font(.caption2).foregroundStyle(.secondary)
                    Text("Brak załączników wychodzących. Szkic istnieje wyłącznie w pamięci aplikacji.")
                        .font(.caption2).foregroundStyle(.secondary)
                    if portal.directSendReviewRequired {
                        Label("Wynik poprzedniego wysłania jest niepewny. Wysyłanie zablokowane, szkic zachowany.",
                              systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                        Button(action: verifySentFolderAfterUncertainSend) {
                            Label("Pobierz folder Wysłane do sprawdzenia", systemImage: "tray.full")
                        }
                        .disabled(!canReviewOutbox)
                        .accessibilityHint("Tylko odczyt. Nie wysyła ponownie wiadomości")
                        Text("Sprawdź ręcznie, czy wiadomość dotarła — także w oficjalnej Synergii, " +
                             "jeśli lista w aplikacji jest niepełna. Nie wysyłaj duplikatu.")
                            .font(.caption).foregroundStyle(.secondary)
                        Button("Sprawdziłem Wysłane — odblokuj redagowanie") {
                            showDirectReviewAcknowledgement = true
                        }
                        .buttonStyle(.bordered)
                    }
                    Button {
                        if portal.prepareDirectSend() { showDirectSendConfirmation = true }
                    } label: {
                        Label("Sprawdź i potwierdź wysyłkę", systemImage: "paperplane")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(portal.directSendBusy || portal.directRecipientBusy || portal.directSendReviewRequired ||
                        portal.directMessagesBusy != nil || portal.directMessageDetailBusy ||
                        portal.directAttachmentBusy != nil || portal.directUnreadBusy ||
                        portal.privacyShieldActive)
                    if portal.directSendBusy { ProgressView("Wysyłanie — nie zamykaj sesji…") }
                    if !portal.directSendStatus.isEmpty {
                        Text(portal.directSendStatus).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            if [.homework, .calendar, .announcements, .documents].contains(module) {
                Section("Dane bezpośrednio z Synergii (JSON)") {
                    Button(action: refreshThisModule) {
                        Label("Pobierz dane z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(!canRefreshModule)
                    Button(action: refreshRelatedFeeds) {
                        Label("Odśwież zadania, terminarz, ogłoszenia i dokumenty", systemImage: "arrow.clockwise.circle")
                    }
                    .disabled(!canRefreshModule)
                    if portal.directFeedBusy == module || portal.directFeedBatchBusy {
                        ProgressView("Trwa odczyt JSON…")
                    }
                    Text(portal.directFeedStatus[module] ?? "Nie pobierano danych JSON")
                        .font(.caption).foregroundStyle(.secondary)
                    if let change = portal.directFeedDeltas[module] {
                        Text(change.summary).font(.caption).foregroundStyle(.secondary)
                    }
                    if let feed = portal.directFeeds[module] {
                        Text("Odczyt: \(feed.fetchedAt.formatted(date: .numeric, time: .shortened))")
                            .font(.caption)
                        if module == .announcements {
                            DirectSchoolNoticesView(feed: feed)
                        } else if module == .calendar {
                            DirectSchoolAgendaView(feed: feed)
                        } else if module == .homework {
                            DirectHomeworkAssignmentsView(
                                feed: feed,
                                fileURLs: portal.directHomeworkFileURLs,
                                downloadBusy: portal.directHomeworkFileBusy != nil ||
                                    portal.directFeedBusy != nil || portal.directFeedBatchBusy,
                                downloadStatus: portal.directHomeworkFileStatus,
                                onDownload: { file, item in
                                    portal.downloadDirectHomeworkFile(file, from: item)
                                }
                            )
                        } else if module == .documents {
                            DirectSchoolDocumentsView(
                                feed: feed,
                                fileURLs: portal.directSchoolFileURLs,
                                downloadBusy: portal.directSchoolFileBusy != nil ||
                                    portal.directFeedBusy != nil || portal.directFeedBatchBusy,
                                downloadStatus: portal.directSchoolFileStatus,
                                onDownload: { file, item in
                                    portal.downloadDirectSchoolFile(file, from: item)
                                }
                            )
                        }
                        Text("Odczyt tylko do odczytu. Nie potwierdza wszystkich stron ani pełnej liczby danych w szkole.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
            if module == .timetable {
                Section("Plan lekcji — bezpośredni JSON") {
                    HStack(spacing: 12) {
                        Button {
                            if let date = DirectTimetablePresentation.shiftedWeek(
                                containing: portal.timetableChosenDate, offset: -1) {
                                portal.timetableChosenDate = date
                            }
                        } label: { Label("Poprzedni tydzień", systemImage: "chevron.left") }
                        Spacer()
                        Button {
                            portal.timetableChosenDate = Date()
                        } label: { Text("Bieżący") }
                        Spacer()
                        Button {
                            if let date = DirectTimetablePresentation.shiftedWeek(
                                containing: portal.timetableChosenDate, offset: 1) {
                                portal.timetableChosenDate = date
                            }
                        } label: { Label("Następny tydzień", systemImage: "chevron.right") }
                    }
                    .font(.caption)
                    .disabled(portal.directTimetableBusy)
                    DatePicker("Tydzień zawierający", selection: $portal.timetableChosenDate,
                               displayedComponents: .date)
                        .onChange(of: portal.timetableChosenDate) { _, _ in
                            portal.selectCachedTimetableWeek()
                        }
                    Text("Zapisane tygodnie można przeglądać po potwierdzeniu konta. Zapis offline zawsze ma oznaczenie NIEAKTUALNY.")
                        .font(.caption2).foregroundStyle(.secondary)
                    Button(action: refreshThisModule) {
                        Label("Pobierz wybrany tydzień", systemImage: "calendar.badge.clock")
                    }
                    .disabled(!canRefreshModule)
                    if portal.directTimetableBusy { ProgressView("Trwa pobieranie planu…") }
                    Text(portal.directTimetableStatus).font(.caption).foregroundStyle(.secondary)
                    if let plan = portal.directTimetable,
                       plan.monday != DirectTimetableParser.monday(containing: portal.timetableChosenDate) {
                        Text("Wybrano inny tydzień. Pobierz go, aby zobaczyć właściwy plan; poprzedniego nie pokazano jako aktualny.")
                            .font(.caption).foregroundStyle(.orange)
                    }
                    if let plan = portal.directTimetable,
                       plan.monday == DirectTimetableParser.monday(containing: portal.timetableChosenDate) {
                        Text("Tydzień od \(plan.monday); dni w odpowiedzi: \(plan.reportedDates.count)")
                            .font(.caption.bold())
                        if plan.splitPeriods > 0 {
                            Text("Godziny z kilkoma grupami: \(plan.splitPeriods). To wszystkie grupy; przydział nieznany, NIE jest to potwierdzony plan konkretnego ucznia.")
                                .font(.caption).foregroundStyle(.orange)
                        }
                        DirectTimetableDaysView(week: plan,
                            subjects: portal.directTimetableSubjects,
                            teachers: portal.directTimetableTeachers)
                            .id(plan.monday)
                        Divider()
                        Text("Odwołania i zastępstwa").font(.headline)
                        Text(portal.directPlanChangesStatus).font(.caption).foregroundStyle(.secondary)
                        if let history = portal.directPlanChanges,
                           history.accountId == plan.accountId {
                            let changes = history.forWeek(plan.monday)
                            if changes.isEmpty {
                                Text("Brak wpisów zmian w odpowiedzi dla wybranego tygodnia.")
                                    .font(.caption)
                            }
                            ForEach(changes) { change in
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack {
                                        Text("Zmiana z \(change.originalDate)").font(.subheadline.bold())
                                        Spacer()
                                        Text(change.kind == .cancelled ? "Odwołano" :
                                             change.kind == .shifted ? "Przesunięto" :
                                             change.kind == .substitution ? "Zastępstwo" : "Typ nieustalony")
                                            .font(.caption)
                                    }
                                    let oldName = change.originalSubjectId.flatMap { portal.directTimetableSubjects[$0] }
                                    let newName = change.currentSubjectId.flatMap { portal.directTimetableSubjects[$0] }
                                    Text("Pierwotnie: \(oldName ?? "przedmiot nieustalony")" +
                                         (change.originalLessonNumber.map { ", lekcja \($0)" } ?? ""))
                                        .font(.caption)
                                    if let currentDate = change.currentDate {
                                        Text("Nowy termin: \(currentDate)" +
                                             (change.currentLessonNumber.map { ", lekcja \($0)" } ?? ""))
                                            .font(.caption)
                                    }
                                    if let newName {
                                        Text("Nowy przedmiot: \(newName)").font(.caption)
                                    }
                                    if let teacher = change.originalTeacherId.flatMap({ portal.directTimetableTeachers[$0] }),
                                       !teacher.isEmpty {
                                        Text("Dotychczasowy nauczyciel: \(teacher)").font(.caption)
                                    }
                                    if let teacher = change.currentTeacherId.flatMap({ portal.directTimetableTeachers[$0] }),
                                       !teacher.isEmpty {
                                        Text("Nauczyciel zastępujący: \(teacher)").font(.caption)
                                    }
                                    if let room = change.currentClassroom {
                                        Text("Sala: \(room)").font(.caption)
                                    }
                                }.padding(.vertical, 4)
                            }
                        }
                        Text("Plan obejmuje tylko wybrany tydzień. Brak nazw i danych grup nie jest uzupełniany zgadywaniem.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
            if module == .attendance {
                Section("Frekwencja bezpośrednio z Synergii (JSON)") {
                    Button(action: refreshThisModule) {
                        Label("Pobierz frekwencję z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(!canRefreshModule)
                    if portal.directAttendanceBusy { ProgressView("Trwa odczyt JSON…") }
                    Text(portal.directAttendanceStatus)
                        .font(.caption).foregroundStyle(.secondary)
                    if let date = portal.directAttendanceStore.capturedAt {
                        Text("Zapis: \(date.formatted(date: .numeric, time: .shortened)); wpisów: \(portal.directAttendanceStore.records.count)")
                            .font(.caption)
                    }
                    Text("Brak wpisu dla lekcji nie oznacza obecności. Status pochodzi z typów Synergii, a nie z numeru wpisu.")
                        .font(.caption2).foregroundStyle(.orange)
                    if !portal.directAttendanceStore.records.isEmpty {
                        DirectAttendanceAnalyticsView(records: portal.directAttendanceStore.records,
                            subjects: portal.directAttendanceStore.subjects,
                            accountId: portal.directAttendanceStore.verifiedAccountId)
                    } else if portal.directAttendanceStore.capturedAt != nil {
                        Text("W poprzednim zapisie nie ma wpisów frekwencji. Nie oznacza to braku lekcji ani potwierdzonej obecności.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            Section("Dodatkowy zapis stron — diagnostyka") {
                Toggle("Pokaż szczegóły odczytu HTML", isOn: $showDiagnosticContent)
                    .accessibilityHint("Rozwija stare, pomocnicze dane diagnostyczne; nie zastępują odczytu JSON")
                if let snapshot = portal.store.snapshot(for: module) {
                    Label("Zapis lokalny: \(snapshot.capturedAt.formatted(date: .abbreviated, time: .shortened))", systemImage: "clock")
                        .font(.caption)
                    Text("Odczyt diagnostyczny — zawartość nie została zweryfikowana względem pełnej listy w Synergii.")
                        .font(.caption).foregroundStyle(.orange)
                } else {
                    Text("Brak dodatkowego zapisu HTML. Dane JSON są pokazywane w sekcjach powyżej.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                NavigationLink(destination: ConnectionView(initialModule: module)) {
                    Label("Otwórz połączenie i odczytaj", systemImage: "arrow.triangle.2.circlepath")
                }
                if let route = portal.routes.route(for: module) {
                    Text("Adres modułu zapamiętany: \(route.approvedAt.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            if showDiagnosticContent, let snapshot = portal.store.snapshot(for: module) {
                Section("Spójność ostatniego lokalnego zapisu") {
                    let integrity = BatchIntegrityAudit.inspect([snapshot], module: module)
                    Text("Zapisane wiersze: \(integrity.recordCount); tabele: \(integrity.tableCount)")
                        .font(.caption)
                    Text(integrity.explanation)
                        .font(.caption2).foregroundStyle(.secondary)
                    Text("To kontrola techniczna pojedynczego zapisu, a nie dowód pełnej liczby danych w Synergii.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Section("Audyt rozpoznawania — bez treści danych") {
                    let coverage = ParserCoverageAudit.inspect(snapshot)
                    Text("Rozpoznane tabele: \(coverage.recognizedTables) z \(coverage.tableCount)")
                        .font(.caption)
                    Text("Wiersze do analizy: \(coverage.rowsConsidered); odrzucone: \(coverage.rowsRejected)")
                        .font(.caption)
                    DisclosureGroup("Pokaż anonimowy raport") {
                        Text(coverage.formatted())
                            .font(.system(.caption2, design: .monospaced))
                            .textSelection(.enabled)
                    }
                    Text("Raport nie zawiera nazwisk, ocen, wiadomości, adresów ani HTML. Nie potwierdza kompletności.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                if module == .grades {
                    let preview = GradeParser.preview(snapshot: snapshot)
                    let identity = GradeIdentityAudit.review(snapshot: snapshot)
                    Section("Wstępnie rozpoznane oceny (\(preview.grades.count))") {
                        Text("Kandydaci powiązania z wpisem: \(identity.linkedCandidates), niejednoznaczne: \(identity.ambiguousLinks), bez linku: \(identity.withoutLink). Nie są to potwierdzone identyfikatory.")
                            .font(.caption2).foregroundStyle(.secondary)
                        Text("Identyfikator oparty na numerze wiersza NIE jest trwały. Zmiana kolejności ocen nie oznacza dodania nowej oceny.")
                            .font(.caption2).foregroundStyle(.secondary)
                        Text("To nie jest potwierdzona pełna lista ocen. Rozpoznawane są wyłącznie tabele z jednoznacznymi nagłówkami.")
                            .font(.caption).foregroundStyle(.orange)
                        ForEach(preview.grades) { candidate in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(candidate.subject).font(.headline)
                                    Spacer()
                                    Text(candidate.value).font(.title3.bold())
                                }
                                if let date = candidate.dateText { Text("Data: \(date)").font(.caption) }
                                if let weight = candidate.weightText { Text("Waga: \(weight)").font(.caption) }
                                if let category = candidate.category { Text("Kategoria: \(category)").font(.caption) }
                                if let semester = candidate.semester { Text("Semestr: \(semester)").font(.caption) }
                                if let comment = candidate.comment { Text("Komentarz: \(comment)").font(.caption).textSelection(.enabled) }
                            }.padding(.vertical, 3)
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .timetable {
                    let preview = TimetableParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznany plan (\(preview.entries.count))") {
                        ForEach(preview.entries) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(entry.day) · \(entry.subject)").font(.headline)
                                Text("Lekcja: \(entry.lesson)").font(.caption)
                                if let time = entry.startTime { Text("Od: \(time)").font(.caption) }
                                if let time = entry.endTime { Text("Do: \(time)").font(.caption) }
                                if let room = entry.room { Text("Sala: \(room)").font(.caption) }
                                if let teacher = entry.teacher { Text("Nauczyciel: \(teacher)").font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .attendance {
                    let preview = AttendanceParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznana frekwencja (\(preview.entries.count))") {
                        ForEach(preview.entries) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(entry.dateText) · \(entry.subject)").font(.headline)
                                Text("Status: \(entry.status)").font(.subheadline)
                                if let lesson = entry.lesson { Text("Lekcja: \(lesson)").font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .messages {
                    let preview = MessageParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznane wiadomości (\(preview.messages.count))") {
                        ForEach(preview.messages) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.subject).font(.headline)
                                Text(item.sender).font(.subheadline)
                                if let date = item.dateText { Text(date).font(.caption).foregroundStyle(.secondary) }
                                if let recipient = item.recipient { Text("Do: \(recipient)").font(.caption) }
                                if let preview = item.previewText { Text(preview).font(.subheadline).textSelection(.enabled) }
                            }.padding(.vertical, 3)
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .messages {
                    let details = MessageDetails.preview(snapshot: snapshot)
                    Section("Skrzynki — odczyt lokalny") {
                        ForEach(LocalMailbox.allCases) { mailbox in
                            let entries = details.items.filter { $0.mailbox == mailbox }
                            if !entries.isEmpty {
                                DisclosureGroup("\(mailbox.rawValue) (\(entries.count))") {
                                    ForEach(entries) { item in
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(item.subject).font(.headline)
                                            Text("Od: \(item.sender)").font(.caption)
                                            if let recipient = item.recipient { Text("Do: \(recipient)").font(.caption) }
                                            if let date = item.dateText { Text(date).font(.caption) }
                                            if let link = item.detailLink {
                                                Button("Otwórz szczegóły w oficjalnej Synergii") {
                                                    portal.openTrustedLink(link)
                                                }.font(.caption)
                                            }
                                            if !item.attachmentCandidates.isEmpty {
                                                Text("Możliwe załączniki (\(item.attachmentCandidates.count)) — niezweryfikowane")
                                                    .font(.caption2).foregroundStyle(.orange)
                                                ForEach(item.attachmentCandidates) { attachment in
                                                    Button("Otwórz: \(attachment.title)") {
                                                        portal.openTrustedLink(attachment)
                                                    }.font(.caption)
                                                }
                                            }
                                            if let body = item.body {
                                                Text(body).font(.subheadline).textSelection(.enabled)
                                            } else {
                                                Text("Pełna treść niedostępna w lokalnym odczycie")
                                                    .font(.caption2).foregroundStyle(.secondary)
                                            }
                                        }.padding(.vertical, 4)
                                    }
                                }
                            }
                        }
                        ForEach(details.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .calendar {
                    let preview = AdditionalParsers.calendar(snapshot)
                    Section("Rozpoznane wydarzenia (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.title).font(.headline)
                                Text(item.dateText).font(.caption)
                                if let subject = item.subject { Text(subject).font(.caption) }
                                if let details = item.details { Text(details).textSelection(.enabled) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if module == .homework {
                    let preview = AdditionalParsers.homework(snapshot)
                    Section("Rozpoznane zadania (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.subject).font(.headline)
                                Text(item.description).textSelection(.enabled)
                                if let due = item.dueDate { Text("Termin: \(due)").font(.caption) }
                                if let teacher = item.teacher { Text(teacher).font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if module == .announcements {
                    let preview = AdditionalParsers.announcements(snapshot)
                    Section("Rozpoznane ogłoszenia (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.title).font(.headline)
                                if let body = item.body { Text(body).textSelection(.enabled) }
                                if let date = item.dateText { Text(date).font(.caption) }
                                if let author = item.author { Text(author).font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if !snapshot.records.isEmpty {
                    Section("Wiersze z widocznego dokumentu (\(snapshot.records.count))") {
                        ForEach(snapshot.records) { record in
                            VStack(alignment: .leading, spacing: 5) {
                                ForEach(Array(record.fields.enumerated()), id: \.offset) { index, value in
                                    Text(value).font(index == 0 ? .headline : .subheadline)
                                        .foregroundStyle(index == 0 ? .primary : .secondary)
                                        .textSelection(.enabled)
                                }
                            }.padding(.vertical, 5)
                        }
                    }
                }
                if !snapshot.excerpt.isEmpty {
                    Section("Fragment tekstu strony") {
                        Text(snapshot.excerpt).font(.subheadline).textSelection(.enabled)
                    }
                }
                if !snapshot.links.isEmpty {
                    Section("Odnośniki na stronie") {
                        ForEach(snapshot.links) { link in
                            Button {
                                portal.openTrustedLink(link)
                            } label: {
                                HStack {
                                    Text(link.title).lineLimit(2)
                                    Spacer()
                                    Image(systemName: "arrow.up.right")
                                }
                            }
                        }
                        Text("Odnośniki można otworzyć w zakładce połączenia. Pobieranie załączników nie jest jeszcze zweryfikowane.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            } // moduleDataAllowed: no stored rows from another /Me account may appear.
        }
        // Wide iPad lists no longer stretch school rows across the full display.
        // The compact view remains fully fluid, including Stage Manager resize.
        .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
            isRegularWidth: horizontalSizeClass == .regular, kind: .module)))
        .frame(maxWidth: .infinity)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(action: refreshThisModule) {
                    Label("Odśwież: \(module.title)", systemImage: "arrow.clockwise")
                }
                .disabled(!canRefreshModule)
                .accessibilityHint("Ręcznie pobiera dane JSON tylko dla tego modułu")
            }
        }
        .sheet(isPresented: $showDirectRecipientPicker) {
            if let currentList = portal.directRecipientList {
                DirectRecipientPickerView(snapshot: currentList)
                    .environmentObject(portal)
            } else {
                Text("Lista odbiorców nie jest już aktualna.")
            }
        }
        .confirmationDialog("Sprawdzono folder Wysłane?", isPresented: $showDirectReviewAcknowledgement,
                            titleVisibility: .visible) {
            Button("Tak, sprawdziłem — odblokuj formularz") { portal.acknowledgeDirectSendReview() }
            Button("Anuluj", role: .cancel) { }
        } message: {
            Text("Niepewny wynik może oznaczać, że wiadomość dotarła. Odblokowanie samo niczego nie wysyła; " +
                 "ponowna wysyłka może stworzyć duplikat.")
        }
        .confirmationDialog("Potwierdź wysłanie wiadomości", isPresented: $showDirectSendConfirmation,
                            titleVisibility: .visible) {
            Button("Wyślij wiadomość TERAZ") { portal.confirmDirectSend() }
            Button("Anuluj", role: .cancel) { portal.cancelPreparedDirectSend() }
        } message: {
            Text(portal.directSendPreview ?? "Wysyłka nie jest już przygotowana.")
        }
        .navigationTitle(module.title)
        .onChange(of: portal.store.verifiedAccountId) { previous, current in
            if DirectModuleScreenLifecycle.requiresAccountReset(previous: previous, current: current) {
                resetForVerifiedAccountChange()
            }
        }
        .onChange(of: portal.privacyShieldActive) { _, enabled in
            if DirectModuleScreenLifecycle.shouldClosePrivatePresentations(shieldEnabled: enabled) {
                closeSensitivePresentations()
            }
        }
        .fullScreenCover(item: $openedDirectMessage) { message in
            DirectMessageReaderView(message: message,
                authorizedAccountId: portal.store.verifiedAccountId ?? "")
                .environmentObject(portal)
        }
    }
}

/// Dedicated in-app message reader. No downloaded HTML is rendered as Web content.
/// The view deliberately keeps the original verified account boundary even if
/// another account becomes active while the sheet is open.
private struct DirectMessageReaderView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.dismiss) private var dismiss
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var textSize: DirectMessageReaderTextSize = .normal
    @State private var previewAttachmentURL: URL?
    let message: DirectMessage
    let authorizedAccountId: String

    private var hasAccess: Bool {
        DirectMessageReaderPolicy.canDisplay(
            message: message, verifiedAccountId: portal.store.verifiedAccountId,
            authorizedAccountId: authorizedAccountId,
            snapshot: portal.directMailboxes[message.mailbox],
            privacyShielded: portal.privacyShieldActive)
    }

    /// Mirror the transport's reader-specific in-flight locks; the retry
    /// action must not silently fail while another request owns the session.
    private var readerRequestBusy: Bool {
        portal.manualRefreshRunning != nil || portal.coreSyncBusy ||
        portal.directMessagesBusy != nil || portal.directMessageDetailBusy ||
        portal.directAttachmentBusy != nil || portal.directUnreadBusy ||
        portal.directSendBusy || portal.directRecipientBusy
    }

    private var canRetryDetail: Bool {
        DirectMessageReadRequestPolicy.canStart(
            hasAccess: hasAccess, operationBusy: readerRequestBusy)
    }

    /// A reply must use the same verified inbox and a safe sender ID.
    /// The transport still decides whether preparation actually succeeded.
    private func canPrepareReply(_ detail: DirectMessageDetail) -> Bool {
        DirectReplyPresentationPolicy.canOffer(
            detail: detail,
            snapshot: portal.directMailboxes[.inbox],
            verifiedAccountId: portal.store.verifiedAccountId,
            privacyShielded: portal.privacyShieldActive,
            operationBusy: readerRequestBusy,
            reviewRequired: portal.directSendReviewRequired)
    }

    private var displayedDetail: DirectMessageDetail? {
        guard hasAccess, let detail = portal.directMessageDetail,
              DirectMessageReaderPolicy.matches(detail: detail, message: message) else { return nil }
        return detail
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if !hasAccess {
                        Label("Dane wiadomości są zablokowane. Potwierdź bieżące konto.", systemImage: "lock.shield")
                            .foregroundStyle(.orange)
                    } else if let detail = displayedDetail {
                        Text(detail.subject).font(.title2.bold()).textSelection(.enabled)
                        Text("\(message.mailbox.isOutgoing ? "Do" : "Od"): \(detail.sender)")
                            .font(.subheadline).textSelection(.enabled)
                        if let date = detail.sentAt {
                            Text("Data: \(date)").font(.caption).foregroundStyle(.secondary)
                        }
                        Divider()
                        HStack {
                            Text("Wielkość tekstu").font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            Picker("Wielkość tekstu", selection: $textSize) {
                                ForEach(DirectMessageReaderTextSize.allCases) { option in
                                    Text(option.label).tag(option)
                                }
                            }.pickerStyle(.menu)
                        }
                        LazyVStack(alignment: .leading, spacing: 0) {
                            if detail.body.isEmpty {
                                Text("Serwer zwrócił pustą treść wiadomości.")
                                    .foregroundStyle(.secondary)
                            } else {
                                ForEach(Array(DirectMessageReaderPolicy.chunks(detail.body).enumerated()), id: \.offset) { _, chunk in
                                    Text(chunk)
                                        .font(.system(size: textSize.pointSize, relativeTo: .body))
                                        .textSelection(.enabled)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                        }
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
                        ShareLink(item: detail.body) {
                            Label("Kopiuj lub udostępnij treść", systemImage: "square.and.arrow.up")
                        }
                        .disabled(detail.body.isEmpty)
                        Text("Treść jest wyświetlana wyłącznie jako tekst. Zewnętrzne elementy HTML nie są uruchamiane.")
                            .font(.caption2).foregroundStyle(.secondary)
                        if detail.replyAllowed {
                            Button {
                                guard canPrepareReply(detail) else { return }
                                // The UI gate mirrors the portal's reply prerequisites.
                                // No navigation occurs when any prerequisite is missing.
                                portal.beginDirectReply(to: detail)
                                dismiss()
                            } label: {
                                Label("Odpowiedz — wróć do formularza wiadomości", systemImage: "arrowshape.turn.up.left")
                            }
                            .disabled(!canPrepareReply(detail))
                        }
                        if !detail.attachments.isEmpty {
                            Text("Załączniki (\(detail.attachments.count))").font(.headline)
                            if !detail.mailbox.supportsDirectAttachments {
                                Text("Archiwalne załączniki pobierz przez oficjalną stronę Synergii.")
                                    .font(.caption).foregroundStyle(.secondary)
                            } else {
                                ForEach(detail.attachments) { file in
                                    VStack(alignment: .leading, spacing: 6) {
                                        Label {
                                            Text(file.name).font(.subheadline).textSelection(.enabled)
                                        } icon: {
                                            Image(systemName: DirectAttachmentPresentation.kindSymbol(file.name))
                                        }
                                        Text(DirectAttachmentPresentation.sizeDescription(file.sizeBytes))
                                            .font(.caption2).foregroundStyle(.secondary)
                                        let attachmentKey = portal.directAttachmentKey(file, message: detail)
                                        if let localURL = portal.directAttachmentURLs[attachmentKey] {
                                            HStack(spacing: 12) {
                                                if DirectAttachmentPresentation.canPreview(file.name) {
                                                    Button {
                                                        guard hasAccess,
                                                              portal.directAttachmentURLs[attachmentKey] == localURL,
                                                              FileManager.default.fileExists(atPath: localURL.path) else { return }
                                                        previewAttachmentURL = localURL
                                                    } label: {
                                                        Label("Podgląd", systemImage: "eye")
                                                    }
                                                }
                                                ShareLink(item: localURL) {
                                                    Label("Zapisz / udostępnij", systemImage: "square.and.arrow.up")
                                                }
                                            }
                                            Button(role: .destructive) {
                                                previewAttachmentURL = nil
                                                portal.discardDirectMessageAttachment(file, in: detail)
                                            } label: {
                                                Label("Usuń kopię tymczasową", systemImage: "trash")
                                            }
                                            .disabled(portal.directAttachmentBusy != nil)
                                        } else if !DirectAttachmentPolicy.safeFileName(file.name) {
                                            Label("Nieprawidłowa nazwa załącznika. Pobieranie zablokowane.", systemImage: "exclamationmark.shield")
                                                .font(.caption).foregroundStyle(.orange)
                                        } else if DirectAttachmentPresentation.isTooLarge(file.sizeBytes) {
                                            Label("Załącznik przekracza limit pobierania 15 MB.", systemImage: "exclamationmark.triangle")
                                                .font(.caption).foregroundStyle(.orange)
                                        } else {
                                            Button {
                                                portal.downloadDirectMessageAttachment(file, in: detail)
                                            } label: {
                                                Label("Pobierz załącznik", systemImage: "arrow.down.doc")
                                            }
                                            .disabled(portal.directAttachmentBusy != nil ||
                                                portal.directMessagesBusy != nil || portal.directMessageDetailBusy)
                                            if portal.directAttachmentBusy == attachmentKey {
                                                ProgressView("Pobieranie tego pliku…")
                                            }
                                        }
                                    }
                                    .padding(.vertical, 6)
                                }
                            }
                        }
                        Text("Pliki pozostają tylko tymczasowo w aplikacji. Aby je zachować, użyj Zapisz / udostępnij. Podgląd dostępny jest wyłącznie dla obsługiwanych typów dokumentów; nie otwieramy HTML ani plików wykonywalnych.")
                            .font(.caption2).foregroundStyle(.secondary)
                        if !portal.directAttachmentStatus.isEmpty {
                            Text(portal.directAttachmentStatus).font(.caption).foregroundStyle(.secondary)
                        }
                    } else if portal.directMessageDetailBusy {
                        ProgressView("Odczyt pełnej treści…")
                    } else {
                        Text(portal.directMessageDetailStatus.isEmpty ?
                             "Pełna treść nie została pobrana. Sprawdź sesję i spróbuj ponownie." :
                             portal.directMessageDetailStatus)
                            .foregroundStyle(.secondary)
                        Button("Ponów odczyt treści") {
                            guard canRetryDetail else { return }
                            portal.refreshDirectMessageDetail(message)
                        }
                        .disabled(!canRetryDetail)
                    }
                }
                .padding(16)
                .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
                    isRegularWidth: horizontalSizeClass == .regular, kind: .messageReader)),
                       alignment: .leading)
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Wiadomość")
            .navigationBarTitleDisplayMode(.inline)
            .onChange(of: portal.store.verifiedAccountId) { _, account in
                if account != authorizedAccountId {
                    previewAttachmentURL = nil
                    dismiss()
                }
            }
            .onChange(of: portal.privacyShieldActive) { _, shielded in
                if shielded {
                    previewAttachmentURL = nil
                    dismiss()
                }
            }
            // Navigation or session re-verification may clear temporary files
            // without changing the last verified account identifier.
            .onChange(of: portal.directAttachmentURLs) { _, available in
                if let selected = previewAttachmentURL,
                   !available.values.contains(selected) {
                    previewAttachmentURL = nil
                }
            }
            .onChange(of: portal.directMessageDetail) { _, detail in
                if detail == nil { previewAttachmentURL = nil }
            }
            .quickLookPreview($previewAttachmentURL)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Zamknij") { dismiss() }
                }
            }
        }
    }
}

struct ConnectionView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    var initialModule: SchoolModule = .grades
    var openMessages: Bool = false
    @State private var selection: SchoolModule = .grades
    @State private var schoolLogin = ""
    @State private var schoolPassword = ""
    @State private var showPassword = false
    @State private var advancedExpanded = false
    @FocusState private var focused: Field?
    private enum Field: Hashable { case login, password }

    private func submit(alternative: Bool = false) {
        let value = schoolPassword
        schoolPassword = "" // never retain a submitted password in SwiftUI state
        focused = nil
        portal.beginNativeSchoolLogin(login: schoolLogin, password: value, alternative: alternative)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 7) {
                    Image(systemName: "lock.shield.fill")
                        .font(.system(size: 36)).foregroundStyle(.indigo)
                    Text("Zaloguj do Synergii")
                        .font(.largeTitle.bold())
                    Text("Wpisz login i hasło otrzymane od szkoły. To nie jest logowanie e-mailem do Konta LIBRUS.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 14) {
                    Text("Login szkolny").font(.headline)
                    TextField("Numer szkolny, np. 123456u", text: $schoolLogin)
                        .textContentType(.username)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled()
                        .focused($focused, equals: .login)
                        .submitLabel(.next)
                        .onSubmit { focused = .password }
                        .padding(14)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                    Text("Hasło szkolne").font(.headline)
                    HStack(spacing: 8) {
                        Group {
                            if showPassword {
                                TextField("Hasło", text: $schoolPassword)
                            } else {
                                SecureField("Hasło", text: $schoolPassword)
                            }
                        }
                        .textContentType(.password)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .focused($focused, equals: .password)
                        Button {
                            showPassword.toggle()
                        } label: {
                            Image(systemName: showPassword ? "eye.slash" : "eye")
                        }
                        .accessibilityLabel(showPassword ? "Ukryj hasło" : "Pokaż hasło")
                    }
                    .padding(14)
                    .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                    Button(action: { submit() }) {
                        HStack {
                            if portal.nativeLoginPhase.isBusy { ProgressView().tint(.white) }
                            Text("Zaloguj").fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity).frame(minHeight: 34)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(portal.nativeLoginPhase.isBusy ||
                              schoolLogin.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                              schoolPassword.isEmpty)

                    if portal.nativeLoginPhase == .failed {
                        Button("Użyj drugiego oficjalnego formularza") { submit(alternative: true) }
                            .disabled(schoolPassword.isEmpty || portal.nativeLoginPhase.isBusy)
                    }
                    if portal.nativeLoginPhase.isBusy {
                        Button("Anuluj") { portal.cancelNativeSchoolLogin() }
                            .buttonStyle(.bordered)
                    }
                    if portal.nativeLoginPhase == .needsVerification {
                        Button {
                            portal.verifyAccount()
                        } label: {
                            Label("Sprawdź połączenie z kontem", systemImage: "checkmark.shield")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding(18)
                .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 20))

                VStack(alignment: .leading, spacing: 10) {
                    Label("Stan połączenia", systemImage: "network")
                        .font(.headline)
                    Text(portal.nativeLoginMessage)
                        .font(.subheadline)
                        .foregroundStyle(portal.nativeLoginPhase == .failed ? Color.orange : Color.primary)
                    Text(portal.accountStatus).font(.caption).foregroundStyle(.secondary)
                    Text("Hasło jest używane jednorazowo do oficjalnego formularza HTTPS i nie jest zapisywane w aplikacji ani wysyłane na własny serwer. Sesję potwierdza tylko odpowiedź /Me.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding(16)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))

                DisclosureGroup("Narzędzia połączenia i diagnostyka", isExpanded: $advancedExpanded) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Dodatkowe narzędzia są opcjonalne. W zwykłym logowaniu nie musisz otwierać stron internetowych.")
                            .font(.caption).foregroundStyle(.secondary)
                        Button { portal.verifyAccount() } label: {
                            Label("Sprawdź sesję szkolną /Me", systemImage: "checkmark.shield")
                        }
                        Picker("Moduł", selection: $selection) {
                            ForEach(SchoolModule.allCases) { Text($0.title).tag($0) }
                        }
                        HStack(spacing: 12) {
                            Button { portal.goBack() } label: {
                                Label("Wstecz", systemImage: "chevron.left")
                            }.disabled(!portal.webView.canGoBack)
                            Button { portal.refresh() } label: {
                                Label("Odśwież", systemImage: "arrow.clockwise")
                            }
                        }
                        Button { portal.openSynergiaJournal() } label: {
                            Label("Otwórz dziennik (diagnostyka)", systemImage: "book")
                        }
                        HStack(spacing: 10) {
                            Button("Formularz szkolny") { portal.openSchoolLoginForm() }
                            Button("Formularz zapasowy") { portal.openAlternativeSchoolLoginForm() }
                        }.font(.caption)
                        if portal.webView.url != nil {
                            PortalWebView().environmentObject(portal)
                                .frame(minHeight: 450)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        Button { portal.capture(selection) } label: {
                            Label("Odczytaj bieżący moduł", systemImage: "square.and.arrow.down")
                        }
                        Button { portal.rememberCurrentModule(selection) } label: {
                            Label("Zatwierdź adres modułu", systemImage: "bookmark")
                        }
                        if portal.routes.route(for: selection) != nil {
                            Button { portal.rememberAdditionalPage(selection) } label: {
                                Label("Zatwierdź następną stronę", systemImage: "plus.rectangle.on.rectangle")
                            }
                        }
                        Text("Zatwierdzone adresy: \(portal.routes.pages(for: selection).count)")
                            .font(.caption)
                        if portal.routes.route(for: selection) != nil {
                            Button("Usuń zapamiętany adres", role: .destructive) {
                                do { try portal.routes.remove(selection) }
                                catch { portal.alert = error.localizedDescription }
                            }
                        }
                        Text(portal.diagnosticSummary).font(.caption2).textSelection(.enabled)
                        Text(portal.status).font(.caption2).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 12)
                }
                .font(.subheadline)
            }
            .padding(18)
            .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
                isRegularWidth: horizontalSizeClass == .regular, kind: .loginForm)))
            .frame(maxWidth: .infinity)
            // The same long-lived WebKit cookie store is mounted offscreen.
            // Only the native login UI is visible until advanced diagnostics are opened.
            .background(alignment: .bottom) {
                if !advancedExpanded {
                    PortalWebView().environmentObject(portal)
                        // A real viewport lets the official responsive login form load
                        // while the app still displays ONLY the native SwiftUI UI.
                        .frame(width: 375, height: 667)
                        .opacity(0.001)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }
            }
        }
        .navigationTitle("Połączenie")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            selection = initialModule
            if openMessages { portal.openMessagesInPortal() }
        }
        .onDisappear {
            schoolPassword = ""
            if portal.nativeLoginPhase.isBusy { portal.cancelNativeSchoolLogin() }
        }
    }
}

struct MoreView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    var body: some View {
        List {
            Section("Dziennik") {
                ForEach([SchoolModule.attendance, .calendar, .homework, .announcements, .documents]) { module in
                    NavigationLink(destination: ModuleView(module: module)) {
                        Label(module.title, systemImage: module.symbol)
                    }
                }
            }
            Section("Konto") {
                NavigationLink(destination: ConnectionView()) { Label("Połączenie z Synergią", systemImage: "network") }
                NavigationLink(destination: DownloadsView()) { Label("Pobrane załączniki", systemImage: "arrow.down.doc") }
                NavigationLink(destination: SettingsView()) { Label("Prywatność i ustawienia", systemImage: "gearshape") }
            }
        }
        .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
            isRegularWidth: horizontalSizeClass == .regular, kind: .settings)))
        .frame(maxWidth: .infinity)
        .navigationTitle("Więcej")
    }
}

struct SettingsView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var askToErase = false

    private func localStatus(for module: SchoolModule) -> String {
        let legacy = portal.store.snapshot(for: module) != nil ? "HTML" : "Brak"
        switch module {
        case .grades: return portal.directGradeStore.capturedAt != nil ? "JSON" : legacy
        case .attendance: return portal.directAttendanceStore.capturedAt != nil ? "JSON" : legacy
        case .homework, .calendar, .announcements, .documents:
            return portal.directOfflineFeedStore.feeds[module] != nil ? "JSON (stare)" : legacy
        case .messages: return portal.store.snapshot(for: module) != nil ? "HTML" : "Bez zapisu JSON"
        case .timetable: return legacy
        }
    }
    var body: some View {
        List {
            Section("Sesja Synergii") {
                Text(portal.accountStatus).font(.footnote)
                Button("Sprawdź teraz konto") { portal.verifyAccount() }
                    .disabled(portal.isBusy || portal.isSyncing || portal.coreSyncBusy)
                NavigationLink(destination: ConnectionView()) {
                    Label("Otwórz logowanie i połączenie", systemImage: "lock.shield")
                }
                Text("Po powrocie z tła dostęp do lokalnych danych wymaga ponownego potwierdzenia. Brak internetu nie oznacza wylogowania z serwera.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Powiadomienia o zmianach") {
                Toggle("Powiadomienia lokalne po ręcznym odświeżeniu", isOn:
                    Binding(get: { portal.localNotificationsEnabled },
                            set: { portal.setLocalNotifications($0) }))
                Text(portal.localNotificationsStatus).font(.caption).foregroundStyle(.secondary)
                Toggle("Oceny", isOn: Binding(
                    get: { portal.localNotificationPreferences.grades },
                    set: { portal.setLocalNotificationCategory(.grades, enabled: $0) }))
                Toggle("Frekwencja", isOn: Binding(
                    get: { portal.localNotificationPreferences.attendance },
                    set: { portal.setLocalNotificationCategory(.attendance, enabled: $0) }))
                Toggle("Wiadomości odebrane", isOn: Binding(
                    get: { portal.localNotificationPreferences.messages },
                    set: { portal.setLocalNotificationCategory(.messages, enabled: $0) }))
                Button("Sprawdź uprawnienia systemu") { portal.refreshLocalNotificationAuthorization() }
                Text("Wybór kategorii zapisuje się na tym urządzeniu. Wylogowanie z usunięciem danych " +
                     "kasuje również zgodę aplikacji; system może wymagać jej ponownego włączenia w Ustawieniach iOS.")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Tylko nowe lub zmienione wpisy po porównaniu dwóch odczytów tego samego konta. " +
                     "Bez nazwisk, treści wiadomości i wartości ocen. " +
                     "Brak sprawdzania w tle i automatycznych powiadomień przy zamkniętej aplikacji.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Dane i prywatność") {
                Label("Brak własnego serwera i konta pośredniczącego", systemImage: "checkmark.shield")
                Label("Sesja zapisywana w magazynie WebKit", systemImage: "iphone")
                Label("Oceny, frekwencja i cztery moduły JSON: chroniony zapis lokalny", systemImage: "lock.doc")
                Label("Wiadomości i szkice: tylko pamięć aplikacji", systemImage: "envelope.badge.shield.half.filled")
                Label("Brak automatycznego pobierania w tle", systemImage: "pause.circle")
            }
            Section("Dane na urządzeniu") {
                ForEach(SchoolModule.allCases) { module in
                    HStack {
                        Text(module.title)
                        Spacer()
                        Text(localStatus(for: module))
                        .foregroundStyle(.secondary)
                    }
                }
                HStack { Text("Zachowane moduły JSON"); Spacer(); Text("\(portal.directOfflineFeedStore.feeds.count)").foregroundStyle(.secondary) }
                Text("Zapis lokalny jest udostępniany dopiero po potwierdzeniu konta przez /Me i zawsze jako nieaktualny do ponownego pobrania.")
                    .font(.caption).foregroundStyle(.secondary)
                HStack { Text("Pobrane pliki"); Spacer(); Text("\(portal.downloads.items.count)").foregroundStyle(.secondary) }
                HStack { Text("Zapamiętane moduły"); Spacer(); Text("\(portal.routes.routes.count)").foregroundStyle(.secondary) }
                Button("Usuń lokalne dane, załączniki oraz cookies", role: .destructive) { askToErase = true }
                    .disabled(portal.isBusy)
            }
            Section("Ograniczenia") {
                Text("Odczyty i wysyłanie wiadomości pozostają niezweryfikowane na prawdziwym koncie. Wysyłanie wymaga osobnego potwierdzenia, a wynik niepewny nie jest automatycznie ponawiany. Brak obejścia logowania i synchronizacji w tle.")
                    .font(.footnote)
            }
        }
        .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
            isRegularWidth: horizontalSizeClass == .regular, kind: .settings)))
        .frame(maxWidth: .infinity)
        .navigationTitle("Ustawienia")
        .confirmationDialog("Usunąć zapisane moduły, załączniki i lokalną sesję WebKit?", isPresented: $askToErase) {
            Button("Usuń z urządzenia", role: .destructive) { portal.signOutAndClear() }
        }
    }
}


struct DownloadsView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    var body: some View {
        List {
            Section {
                Text("Pliki są pobierane tylko po kliknięciu łącza na oficjalnej stronie i zapisywane lokalnie. Nie wszystkie typy załączników zostały przetestowane.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Zapisane pliki") {
                if portal.downloads.items.isEmpty {
                    ContentUnavailableView("Brak załączników", systemImage: "doc", description: Text("Otwórz wiadomość w połączeniu z Synergią i wybierz załącznik."))
                } else {
                    ForEach(portal.downloads.items) { item in
                        HStack(spacing: 12) {
                            Image(systemName: "doc.fill").foregroundStyle(.indigo)
                            VStack(alignment: .leading) {
                                Text(item.displayName).lineLimit(2)
                                Text("\(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file)) · \(item.savedAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if let url = portal.downloads.file(for: item) {
                                ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                            }
                        }
                    }
                    .onDelete { offsets in
                        let current = portal.downloads.items
                        for index in offsets {
                            do { try portal.downloads.remove(current[index]) }
                            catch { portal.alert = "Nie udało się usunąć pliku: \(error.localizedDescription)" }
                        }
                    }
                }
            }
        }
        .frame(maxWidth: CGFloat(DirectAdaptiveNavigationPolicy.contentMaxWidth(
            isRegularWidth: horizontalSizeClass == .regular, kind: .settings)))
        .frame(maxWidth: .infinity)
        .navigationTitle("Załączniki")
    }
}
