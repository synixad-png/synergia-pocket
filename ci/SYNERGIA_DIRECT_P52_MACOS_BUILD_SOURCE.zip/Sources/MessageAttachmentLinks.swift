import Foundation

/// Link classification is only a local, provisional interpretation of one
/// captured message row. No link is fetched or downloaded here.
struct MessageRowLinks {
    let detail: PortalLink?
    let attachments: [PortalLink]
    let ambiguous: Bool
    let warnings: [String]
}

enum MessageLinkInspector {
    private static let fileExtensions: Set<String> = [
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt",
        "jpg", "jpeg", "png", "gif", "zip", "odt", "ods", "rtf"
    ]
    private static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "pl_PL"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    private static func isExplicitAttachment(_ link: CapturedRowLink, url: URL) -> Bool {
        let label = normalized(link.title)
        if label.contains("zalacznik") || label.contains("pobierz") ||
           label.contains("attachment") || label.contains("download") { return true }
        return fileExtensions.contains(url.pathExtension.lowercased())
    }
    static func inspect(table: CapturedTable, rowIndex: Int) -> MessageRowLinks {
        guard let rowLinks = table.rowLinks, rowLinks.indices.contains(rowIndex) else {
            return MessageRowLinks(detail: nil, attachments: [], ambiguous: false,
                warnings: ["Brak metadanych linków wiersza. Nie ustalono załączników."])
        }
        var safe: [(link: CapturedRowLink, url: URL)] = []
        var excluded = 0
        for link in rowLinks[rowIndex] {
            guard let url = URL(string: link.url), PortalPolicy.isAllowed(url),
                  url.fragment == nil, url.user == nil, url.password == nil,
                  !link.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                excluded += 1
                continue
            }
            safe.append((link, url))
        }
        // Multiple copies of one target in the same row are one target.
        var distinct: [(link: CapturedRowLink, url: URL)] = []
        var visited = Set<String>()
        for item in safe where visited.insert(item.url.absoluteString).inserted {
            distinct.append(item)
        }
        let attachments = distinct.filter { isExplicitAttachment($0.link, url: $0.url) }
        let details = distinct.filter { !isExplicitAttachment($0.link, url: $0.url) }
        let detail = details.count == 1 ? PortalLink(title: details[0].link.title, url: details[0].url.absoluteString) : nil
        let candidates = attachments.map { PortalLink(title: $0.link.title, url: $0.url.absoluteString) }
        var warnings = ["Załączniki to wyłącznie kandydaci wskazani przez tekst linku lub rozszerzenie; nie potwierdzono ich obecności na koncie Synergii."]
        if excluded > 0 { warnings.append("Odrzucono \(excluded) niebezpiecznych lub niepełnych odnośników.") }
        if details.count > 1 { warnings.append("Wiele możliwych odnośników do treści; nie wybrano żadnego.") }
        return MessageRowLinks(detail: detail, attachments: candidates,
            ambiguous: details.count > 1, warnings: warnings)
    }
}
