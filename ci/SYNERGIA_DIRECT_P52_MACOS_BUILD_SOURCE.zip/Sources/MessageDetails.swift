import Foundation

/// Mailbox labels are hints derived from the saved table caption, never server state.
enum LocalMailbox: String, CaseIterable, Identifiable {
    case inbox = "Odebrane", sent = "Wysłane", drafts = "Robocze", unknown = "Nieustalone"
    var id: String { rawValue }
    static func fromCaption(_ caption: String) -> Self {
        let t = SchoolTableParser.normalize(caption)
        if t.contains("odebran") || t.contains("skrzynka odbiorcza") { return .inbox }
        if t.contains("wyslan") || t.contains("nadane") { return .sent }
        if t.contains("robocz") || t.contains("szkic") { return .drafts }
        return .unknown
    }
}
struct LocalMessageDetail: Identifiable {
    let id: String
    let mailbox: LocalMailbox
    let sender: String
    let recipient: String?
    let subject: String
    let dateText: String?
    let body: String?
    let detailLink: PortalLink?
    let attachmentCandidates: [PortalLink]
}
struct LocalMessageResult {
    let items: [LocalMessageDetail]
    let warnings: [String]
}
enum MessageDetails {
    static func preview(snapshot: ModuleSnapshot) -> LocalMessageResult {
        guard snapshot.module == .messages else {
            return LocalMessageResult(items: [], warnings: ["To nie jest zapis modułu wiadomości."])
        }
        guard let tables = snapshot.tables else {
            return LocalMessageResult(items: [], warnings: ["Brak informacji o tabelach. Odczytaj moduł ponownie."])
        }
        let rule = SchoolTableParser.ColumnRule(required: [
            "sender": ["nadawca", "od"], "subject": ["temat", "tytul"]
        ], optional: ["recipient": ["odbiorca", "do"], "date": ["data", "wyslano"],
                      "body": ["tresc", "pelna tresc", "wiadomosc"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        let items = parsed.rows.compactMap { row -> LocalMessageDetail? in
            guard let sender = row.fields["sender"], let subject = row.fields["subject"],
                  sender.count <= 200, subject.count <= 300 else { return nil }
            let mailbox = row.tableIndex < tables.count ? LocalMailbox.fromCaption(tables[row.tableIndex].caption) : .unknown
            let links = row.tableIndex < tables.count
                ? MessageLinkInspector.inspect(table: tables[row.tableIndex], rowIndex: row.rowIndex)
                : MessageRowLinks(detail: nil, attachments: [], ambiguous: false, warnings: [])
            return LocalMessageDetail(id: row.id, mailbox: mailbox, sender: sender,
                recipient: row.fields["recipient"], subject: subject, dateText: row.fields["date"],
                body: row.fields["body"],
                detailLink: links.detail, attachmentCandidates: links.attachments)
        }
        return LocalMessageResult(items: items, warnings: parsed.warnings + [
            "Skrzynkę ustalono tylko na podstawie nagłówka tabeli; bez niego pozostaje nieustalona.",
            "Szczegóły i załączniki są rozdzielane tylko według jednoznacznych, bezpiecznych odnośników; nie pobieramy ich automatycznie.",
            "Pełna treść jest pokazywana wyłącznie, jeśli występuje jako osobna kolumna. Nie wdrożono wysyłania ani pobierania całej korespondencji."
        ])
    }
}
