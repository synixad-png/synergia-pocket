import Foundation

/// Offline, provisional list interpretation. No reading, replying or sending is claimed.
struct MessageCandidate: Identifiable {
    let id: String
    let sender: String
    let subject: String
    let dateText: String?
    let recipient: String?
    let previewText: String?
}

struct MessagePreview {
    let messages: [MessageCandidate]
    let warnings: [String]
}

enum MessageParser {
    private static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "pl_PL"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
    }
    private static let senders: Set<String> = ["nadawca", "od", "sender"]
    private static let subjects: Set<String> = ["temat", "tytul", "subject"]
    private static let dates: Set<String> = ["data", "wyslano", "date"]
    private static let recipients: Set<String> = ["odbiorca", "do", "recipient"]
    private static let previews: Set<String> = ["fragment", "podglad", "zajawka", "preview"]

    static func preview(snapshot: ModuleSnapshot) -> MessagePreview {
        guard let tables = snapshot.tables else {
            return MessagePreview(messages: [], warnings: ["Starszy zapis nie zawiera granic tabel. Wykonaj nowy odczyt."])
        }
        var messages: [MessageCandidate] = []
        var ignored = 0
        for (tableIndex, table) in tables.enumerated() {
            var header: (sender: Int, subject: Int, date: Int?, recipient: Int?, preview: Int?)?
            for (rowIndex, row) in table.rows.enumerated() {
                let cells = row.map(normalized)
                let s = cells.indices.filter { senders.contains(cells[$0]) }
                let t = cells.indices.filter { subjects.contains(cells[$0]) }
                if s.count == 1 && t.count == 1 && s[0] != t[0] {
                    let d = cells.indices.filter { dates.contains(cells[$0]) }
                    let r = cells.indices.filter { recipients.contains(cells[$0]) }
                    let p = cells.indices.filter { previews.contains(cells[$0]) }
                    header = (s[0], t[0], d.count == 1 ? d[0] : nil,
                              r.count == 1 ? r[0] : nil, p.count == 1 ? p[0] : nil)
                    continue
                }
                guard let h = header else { continue }
                guard row.indices.contains(h.sender), row.indices.contains(h.subject) else { ignored += 1; continue }
                let sender = row[h.sender].trimmingCharacters(in: .whitespacesAndNewlines)
                let subject = row[h.subject].trimmingCharacters(in: .whitespacesAndNewlines)
                guard !sender.isEmpty, !subject.isEmpty, sender.count <= 200, subject.count <= 300,
                      !senders.contains(normalized(sender)), !subjects.contains(normalized(subject)) else {
                    ignored += 1; continue
                }
                let date = h.date.flatMap { row.indices.contains($0) ? row[$0] : nil }
                let recipient = h.recipient.flatMap { row.indices.contains($0) ? row[$0] : nil }
                let preview = h.preview.flatMap { row.indices.contains($0) ? row[$0] : nil }
                messages.append(MessageCandidate(id: "\(snapshot.sourceURL)|\(tableIndex)|\(rowIndex)",
                    sender: sender, subject: subject, dateText: date, recipient: recipient, previewText: preview))
            }
        }
        var warnings = ["Podgląd wyłącznie rozpoznanych wierszy tabel. Nie jest to kompletna skrzynka wiadomości.",
                        "Podgląd treści jest dostępny tylko przy jednoznacznej kolumnie; pełny odczyt, odpowiedzi i wysyłanie NIE są zaimplementowane."]
        if ignored > 0 { warnings.append("Odrzucono \(ignored) niejednoznacznych wierszy.") }
        return MessagePreview(messages: messages, warnings: warnings)
    }
}
