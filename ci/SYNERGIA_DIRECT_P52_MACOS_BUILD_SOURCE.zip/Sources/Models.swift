import Foundation

enum SchoolModule: String, Codable, CaseIterable, Identifiable {
    case grades, timetable, attendance, calendar, homework, messages, announcements, documents
    var id: String { rawValue }
    var title: String {
        switch self {
        case .grades: return "Oceny"
        case .timetable: return "Plan lekcji"
        case .attendance: return "Frekwencja"
        case .calendar: return "Terminarz"
        case .homework: return "Zadania domowe"
        case .messages: return "Wiadomości"
        case .announcements: return "Ogłoszenia"
        case .documents: return "Dokumenty"
        }
    }
    var symbol: String {
        switch self {
        case .grades: return "graduationcap.fill"
        case .timetable: return "calendar"
        case .attendance: return "checkmark.circle"
        case .calendar: return "calendar.badge.clock"
        case .homework: return "pencil.line"
        case .messages: return "envelope.fill"
        case .announcements: return "megaphone"
        case .documents: return "folder.fill"
        }
    }
    var identifyingWords: [String] {
        switch self {
        case .grades: return ["ocen", "grades"]
        case .timetable: return ["plan lekcji", "plan zajęć", "timetable"]
        case .attendance: return ["frekwenc", "obecno", "nieobecno", "attendance"]
        case .calendar: return ["terminarz", "kalendarz", "calendar"]
        case .homework: return ["zadania domowe", "praca domowa", "homework"]
        case .messages: return ["wiadomo", "message", "skrzynka", "odebrane", "wysłane"]
        case .announcements: return ["ogłoszen", "announcement"]
        case .documents: return ["dokument", "załącznik", "pliki", "files"]
        }
    }
}

struct PortalRecord: Codable, Identifiable, Equatable {
    let id: UUID
    let fields: [String]
    init(fields: [String]) { id = UUID(); self.fields = fields }
}

struct PortalLink: Codable, Identifiable, Equatable {
    let id: UUID
    let title: String
    let url: String
    init(title: String, url: String) { id = UUID(); self.title = title; self.url = url }
}

struct ModuleSnapshot: Codable {
    let module: SchoolModule
    let capturedAt: Date
    let title: String
    let sourceURL: String
    let records: [PortalRecord]
    let links: [PortalLink]
    let excerpt: String
    var tables: [CapturedTable]? = nil
    enum CodingKeys: String, CodingKey { case module, capturedAt, title, sourceURL, records, links, excerpt, tables }
    init(module: SchoolModule, capturedAt: Date, title: String, sourceURL: String, records: [PortalRecord], links: [PortalLink], excerpt: String, tables: [CapturedTable]? = nil) {
        self.module = module; self.capturedAt = capturedAt; self.title = title; self.sourceURL = sourceURL; self.records = records; self.links = links; self.excerpt = excerpt; self.tables = tables
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        module = try c.decode(SchoolModule.self, forKey: .module)
        capturedAt = try c.decode(Date.self, forKey: .capturedAt)
        title = try c.decode(String.self, forKey: .title)
        sourceURL = try c.decode(String.self, forKey: .sourceURL)
        records = try c.decode([PortalRecord].self, forKey: .records)
        links = try c.decode([PortalLink].self, forKey: .links)
        excerpt = try c.decode(String.self, forKey: .excerpt)
        tables = try c.decodeIfPresent([CapturedTable].self, forKey: .tables)
    }
    var count: Int { records.count }
}

struct PageCapture: Decodable {
    let title: String
    let url: String
    let heading: String
    let rows: [[String]]
    let links: [CapturedLink]
    let excerpt: String
    let loginFormPresent: Bool?
    let documentReady: Bool?
    let isTruncated: Bool?
    let hasPagination: Bool?
    let tableCount: Int?
    let paginationLinks: [String]?
    let tables: [CapturedTable]?
}
struct CapturedRowLink: Codable, Equatable {
    let title: String
    let url: String
}
struct CapturedTable: Codable {
    let caption: String
    let rows: [[String]]
    /// Positional link metadata (one array per saved table row).
    /// Optional for compatibility with v0.14 and earlier local captures.
    let rowLinks: [[CapturedRowLink]]?
    init(caption: String, rows: [[String]], rowLinks: [[CapturedRowLink]]? = nil) {
        self.caption = caption
        self.rows = rows
        self.rowLinks = rowLinks
    }
}
struct CapturedLink: Decodable {
    let title: String
    let url: String
}

/// An allow-list for primary navigation. Third-party authentication redirects are
/// deliberately not enabled silently; validate their hosts before extending it.
enum PortalPolicy {
    static func isAllowed(_ url: URL) -> Bool {
        guard url.scheme?.lowercased() == "https", let h = url.host?.lowercased() else { return false }
        // The official school-login fallback uses librus.com.pl, not librus.pl.
        // Allow only the exact official hosts; never allow arbitrary *.com.pl.
        return h == "librus.pl" || h.hasSuffix(".librus.pl") ||
               h == "librus.com.pl" || h == "www.librus.com.pl"
    }
}
