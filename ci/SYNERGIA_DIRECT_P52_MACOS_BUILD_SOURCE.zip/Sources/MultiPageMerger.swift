import Foundation

enum MergeError: Error { case empty, moduleMismatch, repeatedURL, tooManyPages, incompleteApproval }

/// A batch is only saved after every explicitly approved page has been captured.
/// Equal rows are intentionally retained: two identical grades may be distinct entries.
enum MultiPageMerger {
    static func merge(_ pages: [ModuleSnapshot], module: SchoolModule) throws -> ModuleSnapshot {
        guard !pages.isEmpty else { throw MergeError.empty }
        guard pages.count <= 20 else { throw MergeError.tooManyPages }
        guard pages.allSatisfy({ $0.module == module }) else { throw MergeError.moduleMismatch }
        guard Set(pages.map(\.sourceURL)).count == pages.count else { throw MergeError.repeatedURL }
        let records = pages.flatMap(\.records)
        let tables = pages.flatMap { $0.tables ?? [] }
        // Links are metadata, not records. URL de-duplication does not affect grade counts.
        var knownLinks = Set<String>()
        let links = pages.flatMap(\.links).filter { knownLinks.insert($0.url).inserted }
        return ModuleSnapshot(module: module, capturedAt: Date(), title: pages[0].title,
            sourceURL: pages[0].sourceURL, records: records, links: links,
            excerpt: pages.map(\.excerpt).joined(separator: "\n"), tables: tables)
    }
}
