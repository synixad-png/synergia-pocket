import Foundation

/// The native credential screen submits only to the existing official school's
/// HTTPS login form. No password is stored in Keychain, UserDefaults, logs or JSON.
/// Authentication is NOT established by form submission; /Me must confirm it.
enum NativeSchoolLoginPhase: Equatable {
    case idle, loading, submitting, needsVerification, verified, failed
    var isBusy: Bool { self == .loading || self == .submitting }
}

enum NativeSchoolLoginPolicy {
    // The 2026 school-login entry is checked first. The historical, official
    // school-login form remains a bounded one-time fallback.
    static let primary = URL(string: "https://synergia.librus.pl/loguj/portalRodzina")!
    static let secondary = URL(string: "https://www.librus.com.pl/")!

    static func alternative(to attempted: URL?) -> URL? {
        guard let attempted else { return nil }
        if attempted == primary { return secondary }
        if attempted == secondary { return primary }
        return nil // No automatic navigation from any unrecognized address.
    }

    /// An error label safe to show on screen: it never includes request URLs,
    /// cookies, the school login, passwords or localized server messages.
    static func connectionIssue(_ error: Error) -> String {
        let e = error as NSError
        guard e.domain == NSURLErrorDomain else { return "Kod połączenia: \(e.code)" }
        switch e.code {
        case -1001: return "Przekroczono czas połączenia (-1001)"
        case -1003: return "Nie znaleziono serwera (-1003)"
        case -1004: return "Serwer nie przyjął połączenia (-1004)"
        case -1005: return "Połączenie zostało przerwane (-1005)"
        case -1009: return "Brak dostępu do internetu (-1009)"
        case -1200, -1202, -1203, -1204: return "Problem z bezpiecznym połączeniem HTTPS (\(e.code))"
        case -1022: return "iOS zablokował połączenie HTTPS (-1022)"
        default: return "Kod połączenia: \(e.code)"
        }
    }

    static func canInspect(_ url: URL?) -> Bool {
        guard let url, url.scheme?.lowercased() == "https", url.port == nil,
              url.user == nil, url.password == nil,
              let host = url.host?.lowercased() else { return false }
        if host == "www.librus.com.pl" || host == "librus.com.pl" {
            return url.path.isEmpty || url.path == "/"
        }
        return host == "synergia.librus.pl" &&
               (url.path.lowercased().hasPrefix("/loguj") ||
                url.path.lowercased().hasPrefix("/login"))
    }

    static func validate(login: String, password: String) -> String? {
        let trimmed = login.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty || trimmed.utf8.count > 128 ||
           login.contains("\n") || login.contains("\r") {
            return "Wpisz prawidłowy login szkolny (najczęściej cyfry)."
        }
        if password.isEmpty || password.utf8.count > 512 {
            return "Wpisz hasło szkolne."
        }
        return nil
    }

    /// Passes credentials only to a checked, existing form in the same HTTPS page.
    /// The official form retains its own CSRF fields and standard request URL.
    /// This does NOT invent an API endpoint or send credentials to our server.
    static func submissionScript(login: String, password: String) -> String? {
        guard validate(login: login, password: password) == nil,
              let payload = try? JSONSerialization.data(withJSONObject: [login.trimmingCharacters(in: .whitespacesAndNewlines), password]),
              let json = String(data: payload, encoding: .utf8) else { return nil }
        return #"""
        (() => {
          'use strict';
          const values = __CREDENTIALS__;
          const host = location.hostname.toLowerCase();
          if (location.protocol !== 'https:' ||
              !['www.librus.com.pl','librus.com.pl','synergia.librus.pl'].includes(host))
            return 'UNSAFE_ORIGIN';
          if (host === 'synergia.librus.pl' &&
              !/^\/(loguj|login)(\/|$)/i.test(location.pathname)) return 'UNSAFE_ORIGIN';
          if ((host === 'www.librus.com.pl' || host === 'librus.com.pl') &&
              location.pathname !== '/') return 'UNSAFE_ORIGIN';
          const passwords = [...document.querySelectorAll('input[type=password]')]
            .filter(el => !el.disabled && el.form);
          if (passwords.length !== 1) return 'FORM_NOT_FOUND';
          const pass = passwords[0], form = pass.form;
          if (!form || form.querySelectorAll('input[type=password]').length !== 1)
            return 'FORM_NOT_FOUND';
          const action = new URL(form.getAttribute('action') || location.href, location.href);
          if (action.protocol !== 'https:' || !['www.librus.com.pl','librus.com.pl','synergia.librus.pl'].includes(action.hostname.toLowerCase()) ||
              action.username || action.password || action.port) return 'UNSAFE_ACTION';
          const fields = [...form.querySelectorAll('input')]
            .filter(el => el !== pass && !el.disabled &&
              ['text','tel','number',''].includes((el.getAttribute('type') || '').toLowerCase()));
          const explicit = fields.filter(el => /(^|[_-])(login|username|user)([_-]|$)/i
              .test([el.name,el.id,el.getAttribute('autocomplete')].join(' ')));
          const user = explicit.length === 1 ? explicit[0] : fields.length === 1 ? fields[0] : null;
          if (!user || form.querySelector('input[type=email]') ||
              (user.getAttribute('autocomplete') || '').toLowerCase() === 'email')
            return 'NOT_SCHOOL_FORM';
          const apply = (el, value) => {
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            setter.call(el, value);
            el.dispatchEvent(new Event('input', {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
          };
          const btn = form.querySelector('button[type=submit],input[type=submit],button:not([type])');
          if (!form.requestSubmit && !btn) return 'NO_SUBMIT';
          apply(user, values[0]);
          apply(pass, values[1]);
          if (form.requestSubmit) form.requestSubmit(btn || undefined);
          else btn.click();
          return 'SUBMITTED';
        })();
        """#.replacingOccurrences(of: "__CREDENTIALS__", with: json)
    }
}
