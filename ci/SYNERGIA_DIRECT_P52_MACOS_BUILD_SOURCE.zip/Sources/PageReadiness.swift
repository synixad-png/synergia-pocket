import Foundation

/// JavaScript runs in the current WebKit page. No network calls, cookies or page text exported.
enum PageReadiness {
    static let script = #"""
// This is the body of WKWebView.callAsyncJavaScript (WebKit executes it asynchronously).
// DOM stability is only a heuristic. It never certifies correctness/completeness of Synergia data.
const MAX_MS = 8000;
const QUIET_MS = 650;
const CHECK_MS = 100;
const start = Date.now();
let lastMutation = start;
let observer;
function busy() {
  return document.readyState !== 'complete' ||
    !!document.querySelector('[aria-busy="true"], [role="progressbar"]');
}
try {
  observer = new MutationObserver(() => { lastMutation = Date.now(); });
  observer.observe(document.documentElement || document, {
    subtree: true, childList: true, characterData: true,
    attributes: true, attributeFilter: ['aria-busy', 'class', 'hidden']
  });
  return await new Promise(resolve => {
    const tick = () => {
      const now = Date.now();
      if (now - start >= MAX_MS) { resolve('timeout'); return; }
      if (!busy() && now - lastMutation >= QUIET_MS) { resolve('stable'); return; }
      setTimeout(tick, CHECK_MS);
    };
    tick();
  });
} finally {
  if (observer) observer.disconnect();
}
"""#
}
