import Foundation

/// Hints come from real, rendered pagination controls, not guessed endpoints.
/// A successful audit establishes only that *observed* links are approved.
struct PaginationAudit: Equatable {
    let discoveredCount: Int
    let missingApprovalCount: Int
    let invalidCount: Int
    let isBounded: Bool
    var hasUnapprovedPages: Bool { missingApprovalCount > 0 || invalidCount > 0 || !isBounded }
}

enum PaginationInspector {
    static let maximumPages = 20

    /// Disallow cross-origin pagination and fragments, avoid counting repeated hrefs.
    static func audit(observed: [String], approved: [String], origin: String) -> PaginationAudit {
        guard let root = URL(string: origin), PortalPolicy.isAllowed(root),
              let host = root.host else {
            return PaginationAudit(discoveredCount: 0, missingApprovalCount: 0,
                                   invalidCount: observed.count, isBounded: false)
        }
        func canonical(_ raw: String) -> String? {
            guard let url = URL(string: raw), PortalPolicy.isAllowed(url),
                  url.host?.lowercased() == host.lowercased(),
                  url.user == nil, url.password == nil else { return nil }
            var parts = URLComponents(url: url, resolvingAgainstBaseURL: false)
            parts?.fragment = nil
            return parts?.url?.absoluteString
        }
        let valid = observed.compactMap(canonical)
        let invalid = observed.count - valid.count
        let discovered = Set(valid)
        let confirmed = Set(approved.compactMap(canonical))
        return PaginationAudit(discoveredCount: discovered.count,
                               missingApprovalCount: discovered.subtracting(confirmed).count,
                               invalidCount: invalid,
                               isBounded: observed.count <= maximumPages && confirmed.count <= maximumPages)
    }
}
