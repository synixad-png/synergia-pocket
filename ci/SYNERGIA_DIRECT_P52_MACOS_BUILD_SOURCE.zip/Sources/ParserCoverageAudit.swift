import Foundation

/// Content-free local parser coverage inspection. Only a closed vocabulary of
/// column roles is reported; never export original header text or HTML.
struct ParserCoverageReport: Codable, Equatable {
    let version: Int
    let module: String
    let tableCount: Int
    let recognizedTables: Int
    let rowsConsidered: Int
    let rowsRejected: Int
    let recognizedRoles: [String]
    let structurallyComplete: Bool
    let warnings: [String]

    func formatted() -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        guard let data = try? encoder.encode(self), let text = String(data: data, encoding: .utf8) else {
            return "Nie udało się utworzyć raportu"
        }
        return text
    }
}

enum ParserCoverageAudit {
    // Explicit accepted header labels; no source text is copied into the report.
    private static let roles: [(String, Set<String>)] = [
        ("subject", ["przedmiot", "zajecia"]),
        ("grade", ["ocena", "oceny"]),
        ("weight", ["waga"]),
        ("date", ["data", "data wystawienia", "wyslano"]),
        ("category", ["kategoria", "rodzaj"]),
        ("comment", ["komentarz", "opis"]),
        ("semester", ["semestr", "okres"]),
        ("sender", ["nadawca", "od"]),
        ("recipient", ["odbiorca", "do"]),
        ("message_subject", ["temat", "tytul"]),
        ("lesson", ["lekcja", "nr lekcji"]),
        ("room", ["sala", "nr sali"]),
        ("teacher", ["nauczyciel", "prowadzacy"]),
        ("attendance", ["status", "frekwencja", "obecnosc"]),
        ("day", ["dzien", "dzien tygodnia"])
    ]
    private static func match(_ row: [String]) -> Set<String> {
        let values = row.map(SchoolTableParser.normalize)
        return Set(roles.compactMap { role, synonyms in
            values.contains(where: { synonyms.contains($0) }) ? role : nil
        })
    }
    private static func required(_ module: SchoolModule) -> Set<String> {
        switch module {
        case .grades: return ["subject", "grade"]
        case .messages: return ["sender", "message_subject"]
        case .timetable: return ["subject", "day"]
        case .attendance: return ["subject", "date", "attendance"]
        default: return []
        }
    }
    static func inspect(_ snapshot: ModuleSnapshot) -> ParserCoverageReport {
        let tables = snapshot.tables ?? []
        let needed = required(snapshot.module)
        var recognized = 0
        var considered = 0
        var rejected = 0
        var allRoles = Set<String>()
        for table in tables.prefix(40) {
            // Require a single unambiguous header row for a supported module.
            let matches = table.rows.prefix(12).enumerated().filter { _, row in
                let found = match(row)
                return !needed.isEmpty && needed.isSubset(of: found)
            }
            if matches.count == 1, let header = matches.first {
                recognized += 1
                allRoles.formUnion(match(header.element))
                for row in table.rows.dropFirst(header.offset + 1) {
                    considered += 1
                    if row.isEmpty || row.allSatisfy({ $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
                        rejected += 1
                    }
                }
            } else if !table.rows.isEmpty {
                // Never export unknown header values, even if they appear harmless.
                rejected += max(0, table.rows.count - 1)
            }
        }
        let warnings = [
            "Raport obejmuje wyłącznie strukturę lokalnego odczytu, bez danych osobowych.",
            "Nie potwierdza kompletności ani zgodności z rzeczywistą Synergią."
        ] + (tables.count > 40 ? ["Przekroczono limit 40 analizowanych tabel."] : [])
          + (recognized == 0 ? ["Nie znaleziono jednoznacznej tabeli dla tego modułu."] : [])
        return ParserCoverageReport(version: 1, module: snapshot.module.rawValue,
            tableCount: tables.count, recognizedTables: recognized,
            rowsConsidered: considered, rowsRejected: rejected,
            recognizedRoles: allRoles.sorted(),
            structurallyComplete: recognized > 0 && rejected == 0 && tables.count <= 40,
            warnings: warnings)
    }
}
