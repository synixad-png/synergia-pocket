import SwiftUI
import WebKit
import UserNotifications

@MainActor
final class SynergiaPortal: NSObject, ObservableObject, WKNavigationDelegate, WKDownloadDelegate, WKUIDelegate, UNUserNotificationCenterDelegate {
    @Published var status = "Nie połączono"
    @Published var pageTitle = ""
    @Published var isBusy = false
    @Published var alert: String?
    @Published var selectedModule: SchoolModule = .grades
    @Published var dataRevision = 0
    /// Jawne błędy ostatniego odczytu; nie odgadujemy stanu z treści komunikatu.
    @Published private(set) var failedDirectReads: Set<SchoolModule> = []
    /// Zapis odczytany w bieżącej zweryfikowanej sesji, a nie tylko z dysku.
    @Published private(set) var freshDirectReads: Set<SchoolModule> = []
    @Published private(set) var failedDirectMailboxes: Set<DirectMailbox> = []
    // Hide sensitive content in iOS app-switcher snapshots. A backgrounded
    // verified account is locked and must pass /Me again on foreground.
    @Published private(set) var privacyShieldActive = false
    private var backgroundSuspended = false
    private var resumeNeedsAccountVerification = false
    @Published private(set) var nativeLoginPhase: NativeSchoolLoginPhase = .idle
    @Published private(set) var nativeLoginMessage = "Wpisz login i hasło szkolne, nie adres e-mail."
    // Credentials are held only during loading; no keychain or disk persistence.
    private var pendingNativeLogin: (login: String, password: String)?
    // Only one automatic retry to another explicitly allow-listed official URL.
    // Keep a navigation identity so failures from an older canceled load cannot
    // terminate a new attempt. No passwords appear in any diagnostic message.
    private var nativeLoginNavigation: WKNavigation?
    private var nativeLoginAttemptURL: URL?
    private var nativeLoginFallbackUsed = false
    private var submittedNativeLogin = false
    private var loginRestorePolicy = DirectLoginRestorePolicy()
    private var sessionLifecycle = DirectSessionLifecyclePolicy()
    private var recheckAfterTrustedNavigation = false
    let store = LocalStore()
    let downloads = DownloadStore()
    let routes = ModuleRouteStore()
    let auditStore = SyncAuditStore()
    let directGradeStore = DirectGradeStore()
    let directAttendanceStore = DirectAttendanceStore()
    let directOfflineFeedStore = DirectOfflineFeedStore()
    let directOfflineTimetableStore = DirectOfflineTimetableStore()
    @Published private(set) var coreSyncBusy = false
    @Published private(set) var coreSyncStatus = "Nie wykonywano wspólnego odczytu JSON."
    @Published private(set) var coreSyncChanges: CoreSyncChanges?
    @Published private(set) var coreSyncEvidenceSummary = "Brak wcześniejszego porównania."
    @Published private(set) var localNotificationsEnabled = false
    @Published private(set) var localNotificationsStatus = "Powiadomienia lokalne wyłączone."
    @Published private(set) var localNotificationPreferences = DirectNotificationPreferences()
    private var notificationAuthorizationGate = DirectNotificationAuthorizationGate()
    private var notificationDebouncer = DirectNotificationDebouncer()
    private var notificationDispatchGate = DirectNotificationDispatchGate()
    private var notificationAccountGate = DirectNotificationAccountGate()
    private var coreSyncEpoch = UUID()
    private var coreSyncWorker: Task<Void, Never>?
    private var additionalFeedWorker: Task<Void, Never>?
    private var manualRefreshCoordinator = DirectManualRefreshCoordinator()
    @Published private(set) var manualRefreshRunning: DirectManualRefreshKind?
    @Published private(set) var manualRefreshStopping = false
    @Published private(set) var manualRefreshSummary = "Nie uruchamiano odświeżania zbiorczego."

    private func startManualRefresh(_ kind: DirectManualRefreshKind,
                                    owner: String) -> DirectManualRefreshTicket? {
        guard !backgroundSuspended, !privacyShieldActive, !sessionLifecycle.isClearing,
              !isBusy, !isSyncing, !coreSyncBusy,
              !directGradeBusy, !directAttendanceBusy, !directTimetableBusy,
              !directFeedBatchBusy, directFeedBusy == nil,
              directMessagesBusy == nil, !directMessageDetailBusy, !directUnreadBusy,
              directAttachmentBusy == nil, !directRecipientBusy, !directSendBusy,
              directHomeworkFileBusy == nil, directSchoolFileBusy == nil else {
            manualRefreshSummary = "Trwa inna operacja lub sesja wymaga ponownego sprawdzenia."
            return nil
        }
        guard let ticket = manualRefreshCoordinator.begin(kind, accountId: owner) else {
            manualRefreshSummary = "Odświeżanie jest już uruchomione lub trwa kończenie poprzedniego."
            return nil
        }
        manualRefreshRunning = kind
        manualRefreshStopping = false
        manualRefreshSummary = "Trwa: \(kind.label). Tylko na pierwszym planie; bez automatycznych prób."
        return ticket
    }

    private func completeManualRefresh(_ ticket: DirectManualRefreshTicket) {
        guard let receipt = manualRefreshCoordinator.finish(ticket) else { return }
        manualRefreshRunning = nil
        manualRefreshStopping = false
        let seconds = Int(receipt.seconds.rounded())
        switch receipt.outcome {
        case .completed:
            manualRefreshSummary = "Odczyt \(receipt.kind.label) zakończony po \(seconds) s. Sprawdź szczegóły — poszczególne moduły mogły zgłosić błędy."
        case .interrupted:
            manualRefreshSummary = "Odczyt \(receipt.kind.label) przerwany po \(seconds) s. Sprawdź status poszczególnych modułów; nie ponawiano żądań."
        }
    }

    /// Cancellation invalidates the epoch before any next await/commit.
    /// The coordinator remains locked until the prior async worker exits.
    private func markManualRefreshStopping(_ kind: DirectManualRefreshKind) {
        guard manualRefreshCoordinator.requestCancellation(of: kind) else { return }
        manualRefreshStopping = true
        manualRefreshSummary = kind == .approvedPages ?
            "Kończenie zapisanych stron. Już ukończone moduły mogą pozostać zapisane; bieżąca strona nie będzie zaakceptowana." :
            "Kończenie: \(kind.label). Bieżący zbiorczy odczyt nie będzie zaakceptowany."
    }

    func cancelManualRefresh() {
        guard let kind = manualRefreshRunning, !manualRefreshStopping else { return }
        markManualRefreshStopping(kind)
        switch kind {
        case .coreJSON:
            cancelCoreSync(reason: "Użytkownik przerwał zbiorczy odczyt JSON.")
            failedDirectReads.formUnion([.grades, .attendance, .messages])
            freshDirectReads.subtract([.grades, .attendance])
            failedDirectMailboxes.insert(.inbox)
        case .additionalJSON:
            directFeedEpoch = UUID()
            additionalFeedWorker?.cancel()
            directFeedBatchBusy = false
            for module in [SchoolModule.homework, .calendar, .announcements, .documents] {
                failedDirectReads.insert(module)
                freshDirectReads.remove(module)
                directFeedStatus[module] = "Przerwano ręcznie. Poprzedni zapis NIEAKTUALNY, bez automatycznego ponawiania."
            }
        case .approvedPages:
            stopSync("Użytkownik przerwał synchronizację zapisanych stron")
        }
    }
    // Wiadomości są w pamięci, bez nieszyfrowanego cache na dysku.
    @Published private(set) var directMailboxes: [DirectMailbox: DirectMailboxSnapshot] = [:]
    @Published private(set) var directMessagesBusy: DirectMailbox?
    @Published private(set) var directMessageDetailBusy = false
    @Published private(set) var directMessageDetail: DirectMessageDetail?
    @Published private(set) var directMessagesStatus: [DirectMailbox: String] = [:]
    @Published private(set) var directMessageDetailStatus = ""
    private var directMessagesEpoch = UUID()
    @Published private(set) var directAttachmentBusy: String?
    @Published private(set) var directAttachmentStatus = ""
    @Published private(set) var directAttachmentURLs: [String: URL] = [:]
    @Published private(set) var directUnreadCounts: DirectUnreadCounts?
    @Published private(set) var directUnreadStatus = ""
    @Published private(set) var directUnreadBusy = false
    // Wysyłanie jest możliwe tylko po wyraźnym wyborze odbiorcy z aktualnej
    // listy i po osobnym potwierdzeniu. Redagowane treści pozostają w RAM.
    @Published private(set) var directRecipientGroups: DirectRecipientGroupsSnapshot?
    @Published private(set) var directRecipientList: DirectRecipientListSnapshot?
    @Published private(set) var directSelectedGroup: DirectRecipientGroup?
    @Published private(set) var directSelectedRecipient: DirectRecipient?
    @Published private(set) var directReplyContext: DirectReplyContext?
    @Published var directDraftSubject = ""
    @Published var directDraftBody = ""
    @Published private(set) var directRecipientBusy = false
    @Published private(set) var directRecipientStatus = ""
    @Published private(set) var directSendBusy = false
    @Published private(set) var directSendStatus = ""
    /// RAM-only safety latch after a response that may represent a completed POST.
    @Published private(set) var directSendReviewRequired = false
    @Published private(set) var directSendPreview: String?
    private var preparedDirectDraft: DirectValidatedDraft?
    private var preparedDirectAccountEpoch: UUID?
    private var preparedDirectAccountId: String?
    // Dedicated folder only; these files never enter the persistent account cache.
    private let directAttachmentFolder = FileManager.default.temporaryDirectory
        .appendingPathComponent("SynergiaDirect_MessageAttachments", isDirectory: true)

    func directAttachmentKey(_ file: DirectMessageAttachment, message: DirectMessageDetail) -> String {
        "\(message.mailbox.rawValue):\(message.id):\(file.id)"
    }

    private func clearDirectAttachments() {
        directAttachmentBusy = nil
        directAttachmentURLs.removeAll()
        directAttachmentStatus = ""
        try? FileManager.default.removeItem(at: directAttachmentFolder)
    }
    @Published private(set) var directAttendanceBusy = false
    @Published private(set) var directAttendanceStatus = "Nie pobierano frekwencji JSON"
    @Published private(set) var directFeeds: [SchoolModule: DirectSchoolFeed] = [:]
    @Published private(set) var directFeedBusy: SchoolModule?
    @Published private(set) var directFeedStatus: [SchoolModule: String] = [:]
    private var directFeedEpoch = UUID()
    @Published private(set) var directFeedBatchBusy = false
    @Published private(set) var directFeedDeltas: [SchoolModule: DirectFeedDelta] = [:]
    @Published private(set) var directHomeworkFileBusy: String?
    @Published private(set) var directHomeworkFileStatus = ""
    @Published private(set) var directHomeworkFileURLs: [String: URL] = [:]
    private var directHomeworkFileEpoch = UUID()
    private let directHomeworkFileFolder = FileManager.default.temporaryDirectory
        .appendingPathComponent("SynergiaDirect_HomeworkAttachments", isDirectory: true)

    private func clearDirectHomeworkFiles() {
        directHomeworkFileEpoch = UUID()
        directHomeworkFileBusy = nil
        directHomeworkFileStatus = ""
        directHomeworkFileURLs.removeAll()
        try? FileManager.default.removeItem(at: directHomeworkFileFolder)
    }

    func downloadDirectHomeworkFile(_ file: DirectHomeworkFileReference, from entry: DirectSchoolFeedEntry) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard directHomeworkFileBusy == nil, directFeedBusy == nil, !directFeedBatchBusy,
              let feed = directFeeds[.homework],
              feed.verifiedAccountId == store.verifiedAccountId,
              let item = feed.records.first(where: { $0.id == entry.id }),
              item.homeworkFiles?.contains(file) == true else { return }
        directHomeworkFileBusy = file.key
        directHomeworkFileStatus = "Sprawdzanie konta i pobieranie załącznika…"
        let epoch = UUID(); directHomeworkFileEpoch = epoch
        let ownerEpoch = accountEpoch
        let feedEpoch = directFeedEpoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identityClient = SynergiaGatewayClient(webView: self.webView)
                let before = try DirectAccountIdentity.parse((try await identityClient.read(.me)).json)
                guard self.directHomeworkFileEpoch == epoch, self.accountEpoch == ownerEpoch,
                      self.directFeedEpoch == feedEpoch, before.id == feed.verifiedAccountId else {
                    throw DirectHomeworkFileError.accountChanged
                }
                let contents = try await SynergiaHomeworkFileClient(webView: self.webView).download(file)
                guard self.directHomeworkFileEpoch == epoch else { return }
                let after = try DirectAccountIdentity.parse((try await identityClient.read(.me)).json)
                guard self.directHomeworkFileEpoch == epoch, self.accountEpoch == ownerEpoch,
                      self.directFeedEpoch == feedEpoch, before == after,
                      self.store.verifiedAccountId == feed.verifiedAccountId,
                      self.directFeeds[.homework]?.records.first(where: { $0.id == item.id })?.homeworkFiles?.contains(file) == true else {
                    throw DirectHomeworkFileError.accountChanged
                }
                let occupied = self.directHomeworkFileURLs.values.reduce(0) { total, path in
                    total + ((try? FileManager.default.attributesOfItem(atPath: path.path)[.size] as? NSNumber)?.intValue ?? 0)
                }
                guard occupied + contents.count <= DirectAttachmentPolicy.maxSessionBytes else {
                    throw DirectHomeworkFileError.fileTooLarge
                }
                let directory = self.directHomeworkFileFolder.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let target = directory.appendingPathComponent(file.name, isDirectory: false)
                do {
                    try contents.write(to: target, options: [.atomic, .completeFileProtection])
                    var dir = directory
                    var attributes = URLResourceValues(); attributes.isExcludedFromBackup = true
                    try? dir.setResourceValues(attributes)
                    self.directHomeworkFileURLs[file.key] = target
                    self.directHomeworkFileStatus = "Pobrano załącznik. Możesz go zapisać przez Udostępnij."
                } catch {
                    try? FileManager.default.removeItem(at: directory)
                    throw error
                }
            } catch {
                guard self.directHomeworkFileEpoch == epoch else { return }
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? DirectHomeworkFileError) == .accountChanged ||
                    (error as? GatewayReadError) == .loginRequired {
                    self.clearDirectHomeworkFiles()
                    self.directHomeworkFileStatus = "Utrata lub zmiana konta. Pliki tymczasowe usunięte."
                    return
                }
                self.directHomeworkFileStatus = "Pobieranie nieudane: \(error.localizedDescription)"
            }
            if self.directHomeworkFileEpoch == epoch { self.directHomeworkFileBusy = nil }
        }
    }
    @Published private(set) var directSchoolFileBusy: String?
    @Published private(set) var directSchoolFileStatus = ""
    @Published private(set) var directSchoolFileURLs: [String: URL] = [:]
    private var directSchoolFileEpoch = UUID()
    private let directSchoolFileFolder = FileManager.default.temporaryDirectory
        .appendingPathComponent("SynergiaDirect_SchoolFiles", isDirectory: true)

    private func clearDirectSchoolFiles() {
        directSchoolFileEpoch = UUID()
        directSchoolFileBusy = nil
        directSchoolFileStatus = ""
        directSchoolFileURLs.removeAll()
        try? FileManager.default.removeItem(at: directSchoolFileFolder)
    }

    /// A school document is downloadable only from a verified SchoolFiles row.
    /// No file is made available until the student's identity is checked again
    /// after the download. An in-flight download is invalidated on logout.
    func downloadDirectSchoolFile(_ file: DirectSchoolFileReference, from entry: DirectSchoolFeedEntry) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard directSchoolFileBusy == nil,
              let feed = directFeeds[.documents],
              let item = feed.records.first(where: { $0.id == entry.id }),
              item.schoolFile == file,
              DirectSchoolDocumentsPresentation.uniqueDownloadReference(item, in: feed) == file,
              feed.verifiedAccountId == store.verifiedAccountId else { return }
        directSchoolFileBusy = file.id
        directSchoolFileStatus = "Pobieranie dokumentu i sprawdzanie konta…"
        let epoch = UUID(); directSchoolFileEpoch = epoch
        let originalAccountEpoch = accountEpoch
        let originalFeedEpoch = directFeedEpoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let initial = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directSchoolFileEpoch == epoch else { return }
                guard initial.id == feed.verifiedAccountId,
                      self.accountEpoch == originalAccountEpoch,
                      self.directFeedEpoch == originalFeedEpoch else {
                    throw DirectSchoolFileError.accountChanged
                }
                let downloader = SynergiaSchoolFileClient(webView: self.webView)
                let contents = try await downloader.download(file)
                guard self.directSchoolFileEpoch == epoch else { return }
                let final = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directSchoolFileEpoch == epoch else { return }
                guard initial == final, final.id == feed.verifiedAccountId,
                      self.store.verifiedAccountId == feed.verifiedAccountId,
                      self.accountEpoch == originalAccountEpoch,
                      self.directFeedEpoch == originalFeedEpoch else {
                    throw DirectSchoolFileError.accountChanged
                }
                let occupied = self.directSchoolFileURLs.values.reduce(0) { count, url in
                    count + ((try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.intValue ?? 0)
                }
                guard occupied + contents.count <= DirectAttachmentPolicy.maxSessionBytes else {
                    throw DirectSchoolFileError.fileTooLarge
                }
                let directory = self.directSchoolFileFolder.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let url = directory.appendingPathComponent(file.displayName, isDirectory: false)
                do {
                    try contents.write(to: url, options: [.atomic, .completeFileProtection])
                    var dir = directory
                    var values = URLResourceValues()
                    values.isExcludedFromBackup = true
                    try? dir.setResourceValues(values)
                    self.directSchoolFileURLs[file.id] = url
                    self.directSchoolFileStatus = "Dokument pobrany. Możesz go zapisać przez systemowe Udostępnij."
                } catch {
                    try? FileManager.default.removeItem(at: directory)
                    throw error
                }
            } catch {
                guard self.directSchoolFileEpoch == epoch else { return }
                self.directSchoolFileStatus = "Nie pobrano dokumentu: \(error.localizedDescription)"
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? DirectSchoolFileError) == .accountChanged ||
                    (error as? GatewayReadError) == .loginRequired {
                    self.clearDirectSchoolFiles()
                    self.directSchoolFileStatus = "Zmiana lub utrata konta — pliki tymczasowe usunięte."
                    return
                }
            }
            if self.directSchoolFileEpoch == epoch { self.directSchoolFileBusy = nil }
        }
    }
    private var directAttendanceEpoch = UUID()
    @Published var timetableChosenDate = Date()
    @Published private(set) var directTimetable: DirectTimetableWeek?
    @Published private(set) var directTimetableSubjects: [String: String] = [:]
    @Published private(set) var directTimetableTeachers: [String: String] = [:]
    @Published private(set) var directPlanChanges: DirectPlanChangesSnapshot?
    @Published private(set) var directPlanChangesStatus = "Nie pobierano historii zastępstw."
    @Published private(set) var directTimetableBusy = false
    @Published private(set) var directTimetableStatus = "Nie pobierano planu JSON."
    private var directTimetableEpoch = UUID()

    /// Only used after live /Me verification. A disk snapshot always stays STALE
    /// until this exact selected week has been fetched during the current session.
    func selectCachedTimetableWeek() {
        directTimetableEpoch = UUID()  // cancel an in-flight request for another week
        directTimetableBusy = false
        freshDirectReads.remove(.timetable)
        failedDirectReads.remove(.timetable)
        directTimetable = nil
        directPlanChanges = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        let monday = DirectTimetableParser.monday(containing: timetableChosenDate)
        guard !backgroundSuspended && !privacyShieldActive,
              let owner = store.verifiedAccountId,
              directOfflineTimetableStore.verifiedAccountId == owner else {
            directTimetableStatus = "Plan zablokowany do ponownego sprawdzenia konta."
            directPlanChangesStatus = "Brak dostępu do historii zmian."
            return
        }
        if let saved = directOfflineTimetableStore.snapshot(monday: monday) {
            displayCachedTimetable(saved)
        } else {
            directTimetableStatus = "Brak lokalnego zapisu dla tygodnia \(monday). Pobierz plan przez JSON."
            directPlanChangesStatus = "Nie pobierano historii zmian dla tego tygodnia."
        }
    }

    /// Session rejection in another JSON module also revokes a previously
    /// visible timetable, not only its on-disk cache.
    private func revokeDirectTimetableOnAccountFailure() {
        directTimetableEpoch = UUID()
        directTimetableBusy = false
        directTimetable = nil
        directPlanChanges = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        freshDirectReads.remove(.timetable)
        failedDirectReads.insert(.timetable)
        directTimetableStatus = "Plan zablokowany po utracie weryfikacji konta."
        directPlanChangesStatus = "Historia zmian planu zablokowana."
    }

    private func displayCachedTimetable(_ saved: DirectOfflineTimetableSnapshot) {
        directTimetable = saved.week
        directPlanChanges = saved.history
        directTimetableSubjects = saved.subjects
        directTimetableTeachers = saved.teachers
        directTimetableStatus = "Zapis offline (NIEAKTUALNY) dla tygodnia \(saved.week.monday): \(saved.week.entries.count) wpisów; " +
            "ostatni odczyt \(saved.week.fetchedAt.formatted(date: .abbreviated, time: .shortened))."
        directPlanChangesStatus = saved.history.map { "Zapisana historia (NIEAKTUALNA): \($0.forWeek(saved.week.monday).count) zmian w tygodniu." } ??
            "Historia zastępstw nie była dostępna w zapisanym odczycie."
    }
    @Published private(set) var directGradeBusy = false
    @Published private(set) var directGradeStatus = "Nie pobierano ocen przez JSON"
    private var directGradeEpoch = UUID()
    @Published private(set) var accountStatus = "Konto niezweryfikowane — dane lokalne zablokowane"
    private var accountEpoch = UUID()
    private var captureEpoch = UUID()

    private func clearDirectComposer() {
        directRecipientGroups = nil
        directRecipientList = nil
        directSelectedGroup = nil
        directSelectedRecipient = nil
        directReplyContext = nil
        directDraftSubject = ""
        directDraftBody = ""
        directRecipientBusy = false
        directRecipientStatus = ""
        directSendBusy = false
        directSendStatus = ""
        directSendReviewRequired = false
        cancelPreparedDirectSend()
    }

    func cancelPreparedDirectSend() {
        preparedDirectDraft = nil
        preparedDirectAccountEpoch = nil
        preparedDirectAccountId = nil
        directSendPreview = nil
    }

    /// Only after the user explicitly inspected Sent. Does not send or resend.
    func acknowledgeDirectSendReview() {
        guard directSendReviewRequired, !directSendBusy,
              store.verifiedAccountId != nil, !privacyShieldActive else { return }
        directSendReviewRequired = false
        cancelPreparedDirectSend()
        directSendStatus = "Odblokowano redagowanie po ręcznym sprawdzeniu Wysłanych. " +
            "Zachowano szkic; sprawdź jego treść przed każdą nową wysyłką."
    }

    private func composeDraft() throws -> DirectValidatedDraft {
        guard let account = store.verifiedAccountId else { throw DirectComposeError.staleSession }
        return try DirectMessageCompose.draft(recipient: directSelectedRecipient,
            listed: directRecipientList, accountId: account,
            subject: directDraftSubject, text: directDraftBody, reply: directReplyContext)
    }

    func beginDirectNewMessage() {
        guard !directSendBusy, !directRecipientBusy else { return }
        guard !directSendReviewRequired else {
            directSendStatus = DirectSendReviewPolicy.reviewRequiredMessage
            return
        }
        cancelPreparedDirectSend()
        directReplyContext = nil
        directSelectedRecipient = nil
        directDraftSubject = ""
        directDraftBody = ""
        directSendStatus = "Rozpoczęto nową wiadomość. Wybierz odbiorcę z aktualnej listy."
    }

    func beginDirectReply(to detail: DirectMessageDetail) {
        guard !directSendBusy, !directRecipientBusy, !directSendReviewRequired else {
            directSendStatus = directSendReviewRequired ? DirectSendReviewPolicy.reviewRequiredMessage :
                "Zakończ bieżącą operację przed przygotowaniem odpowiedzi."
            return
        }
        guard detail.mailbox == .inbox, detail.replyAllowed,
              let senderId = detail.senderId, DirectMessageParser.safeIdentifier(senderId),
              let snapshot = directMailboxes[.inbox],
              snapshot.messages.contains(where: { $0.id == detail.id }),
              snapshot.accountId == store.verifiedAccountId else {
            directSendStatus = "Nie można odpowiedzieć bez aktualnej, zweryfikowanej wiadomości z Odebranych."
            return
        }
        cancelPreparedDirectSend()
        directSelectedRecipient = nil
        directReplyContext = DirectReplyContext(originalMessageId: detail.id,
            originalSenderId: senderId, subject: detail.subject,
            recipientName: detail.sender, accountId: snapshot.accountId,
            messageSessionId: snapshot.messageSessionId ?? "")
        directDraftSubject = detail.subject.lowercased().hasPrefix("re:") ? detail.subject : "Re: " + detail.subject
        directDraftBody = ""
        directSendStatus = "Odpowiedź do: \(detail.sender). Wprowadź treść i potwierdź wysyłkę."
    }

    func selectDirectRecipient(_ recipient: DirectRecipient) {
        guard !directSendBusy, !directSendReviewRequired, let list = directRecipientList,
              list.accountId == store.verifiedAccountId,
              list.recipients.contains(recipient), recipient.available != false else { return }
        cancelPreparedDirectSend()
        directReplyContext = nil
        directSelectedRecipient = recipient
        directSendStatus = "Odbiorca: \(recipient.name)."
    }

    /// To wyłącznie przygotowanie podglądu. NIE wykonuje żądania POST.
    @discardableResult func prepareDirectSend() -> Bool {
        guard manualRefreshRunning == nil else { return false }
        guard !coreSyncBusy, !privacyShieldActive, !backgroundSuspended else { return false }
        guard !directSendReviewRequired else {
            directSendStatus = DirectSendReviewPolicy.reviewRequiredMessage
            return false
        }
        guard !directSendBusy, !directRecipientBusy,
              directMessagesBusy == nil, !directMessageDetailBusy,
              !directUnreadBusy, directAttachmentBusy == nil else {
            directSendStatus = "Poczekaj na zakończenie trwającej operacji."
            return false
        }
        do {
            let draft = try composeDraft()
            guard let account = store.verifiedAccountId else { throw DirectComposeError.staleSession }
            preparedDirectDraft = draft
            preparedDirectAccountEpoch = accountEpoch
            preparedDirectAccountId = account
            let destination = directReplyContext?.recipientName ?? directSelectedRecipient?.name ?? "Nieznany"
            directSendPreview = DirectSendReviewPolicy.preview(destination: destination, draft: draft)
            directSendStatus = "Sprawdź odbiorcę i temat; dopiero następne potwierdzenie wyśle wiadomość."
            return true
        } catch {
            cancelPreparedDirectSend()
            directSendStatus = error.localizedDescription
            return false
        }
    }

    /// Ten kod uruchamia dokładnie jeden POST. Każda niejednoznaczna odpowiedź
    /// wymaga samodzielnego sprawdzenia skrzynki Wysłane — zero automatycznych retry.
    func confirmDirectSend() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy, !privacyShieldActive, !backgroundSuspended, !directSendReviewRequired else { return }
        guard !directSendBusy, !directRecipientBusy, directMessagesBusy == nil,
              !directMessageDetailBusy, !directUnreadBusy, directAttachmentBusy == nil,
              let draft = preparedDirectDraft,
              let verifiedAccountId = preparedDirectAccountId,
              preparedDirectAccountEpoch == accountEpoch,
              verifiedAccountId == store.verifiedAccountId,
              (try? composeDraft()) == draft else {
            cancelPreparedDirectSend()
            directSendStatus = DirectComposeError.invalidConfirmation.localizedDescription
            return
        }
        cancelPreparedDirectSend()
        directSendBusy = true
        directSendStatus = "Sprawdzanie sesji przed wysłaniem…"
        let epoch = UUID()
        directMessagesEpoch = epoch
        let originalAccountEpoch = accountEpoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            var mayHaveDispatchedPOST = false
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first.id == verifiedAccountId, self.accountEpoch == originalAccountEpoch else {
                    throw DirectComposeError.staleSession
                }
                let client = SynergiaMessagesClient(webView: self.webView)
                let remoteSessionId = try await client.currentSessionAccountId()
                guard remoteSessionId == draft.messageSessionId else { throw DirectComposeError.staleSession }
                guard self.directMessagesEpoch == epoch else { return }
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last, last.id == verifiedAccountId,
                      self.accountEpoch == originalAccountEpoch else { throw DirectComposeError.staleSession }
                self.directSendStatus = "Wysyłanie jednego żądania…"
                // Ważne: od tego miejsca błąd sieciowy może oznaczać, że wiadomość dotarła.
                mayHaveDispatchedPOST = true
                let result = try await client.sendOnce(draft)
                guard self.directMessagesEpoch == epoch else { return }
                self.directSendReviewRequired = DirectSendReviewPolicy.requiresReview(result)
                self.directSendStatus = DirectSendReviewPolicy.status(result)
                switch result {
                case .sent:
                    self.directDraftSubject = ""
                    self.directDraftBody = ""
                    self.directReplyContext = nil
                    self.directSelectedRecipient = nil
                    self.directMailboxes.removeValue(forKey: .outbox)
                case .refused:
                    // No retry is performed; keep the RAM-only draft editable.
                    break
                case .uncertain:
                    // Retain the draft for inspection, but forbid another POST.
                    // No automatic retry, no automatic clearing of text.
                    break
                }
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if mayHaveDispatchedPOST {
                    self.directSendReviewRequired = true
                    self.directSendStatus = "STATUS NIEPEWNY: operacja została rozpoczęta, " +
                        "ale wynik nie jest znany. " + DirectSendReviewPolicy.reviewRequiredMessage
                } else {
                    self.directSendStatus = "NIE WYSŁANO — zatrzymano przed POST: \(error.localizedDescription)"
                    if error is DirectAccountIdentity.IdentityError || error is DirectComposeError {
                        self.lockDirectMessages()
                        self.directSendStatus = "Sesja/konto zmienione; wysyłka została zablokowana."
                        return
                    }
                }
            }
            if self.directMessagesEpoch == epoch { self.directSendBusy = false }
        }
    }

    func refreshDirectRecipientGroups() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy, !directSendReviewRequired else { return }
        guard !directSendBusy, !directRecipientBusy,
              directMessagesBusy == nil, !directMessageDetailBusy,
              directAttachmentBusy == nil, !directUnreadBusy else { return }
        directRecipientBusy = true
        directRecipientGroups = nil
        directRecipientList = nil
        directSelectedGroup = nil
        directSelectedRecipient = nil
        directReplyContext = nil
        cancelPreparedDirectSend()
        directRecipientStatus = "Pobieranie grup odbiorców i sprawdzanie konta…"
        let epoch = UUID(); directMessagesEpoch = epoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                let client = SynergiaMessagesClient(webView: self.webView)
                let remoteId = try await client.currentSessionAccountId()
                let json = try await client.recipientGroups()
                guard self.directMessagesEpoch == epoch else { return }
                let finalRemoteId = try await client.currentSessionAccountId()
                guard remoteId == finalRemoteId else { throw DirectComposeError.staleSession }
                let parsed = try DirectMessageCompose.groups(json, accountId: first.id,
                    messageSessionId: remoteId)
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last else { throw DirectComposeError.staleSession }
                self.directRecipientGroups = parsed
                self.directRecipientStatus = "Dostępne grupy: \(parsed.groups.count). Wybierz grupę."
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                self.directRecipientStatus = "Nie udało się pobrać grup: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directRecipientBusy = false }
        }
    }

    func refreshDirectRecipients(_ group: DirectRecipientGroup) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy, !directSendReviewRequired else { return }
        guard !directSendBusy, !directRecipientBusy,
              directMessagesBusy == nil, !directMessageDetailBusy,
              directAttachmentBusy == nil, !directUnreadBusy,
              let groups = directRecipientGroups,
              groups.accountId == store.verifiedAccountId,
              groups.groups.contains(group) else { return }
        directRecipientBusy = true
        directSelectedGroup = group
        directRecipientList = nil
        directSelectedRecipient = nil
        directReplyContext = nil
        cancelPreparedDirectSend()
        directRecipientStatus = "Pobieranie: \(group.name)…"
        let epoch = UUID(); directMessagesEpoch = epoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first.id == groups.accountId else { throw DirectComposeError.staleSession }
                let client = SynergiaMessagesClient(webView: self.webView)
                let remoteId = try await client.currentSessionAccountId()
                guard remoteId == groups.messageSessionId else { throw DirectComposeError.staleSession }
                let json = try await client.recipients(groupId: group.id)
                guard self.directMessagesEpoch == epoch else { return }
                let finalRemoteId = try await client.currentSessionAccountId()
                guard remoteId == finalRemoteId else { throw DirectComposeError.staleSession }
                let parsed = try DirectMessageCompose.recipients(json, group: group,
                    accountId: first.id, messageSessionId: remoteId)
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last else { throw DirectComposeError.staleSession }
                self.directRecipientList = parsed
                self.directRecipientStatus = "Pobrano \(parsed.recipients.count) odbiorców."
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if error is DirectComposeError {
                    self.directRecipientGroups = nil
                }
                self.directRecipientStatus = "Nie udało się pobrać odbiorców: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directRecipientBusy = false }
        }
    }

    private func lockDirectMessages() {
        clearDirectComposer()
        failedDirectMailboxes.removeAll()
        directUnreadCounts = nil
        directUnreadBusy = false
        directUnreadStatus = ""
        clearDirectAttachments()
        directMessagesEpoch = UUID()
        directMessagesBusy = nil
        directMessageDetailBusy = false
        directMessageDetail = nil
        directMailboxes.removeAll()
        directMessagesStatus.removeAll()
        directMessageDetailStatus = ""
    }

    /// Oficjalna nawigacja aktywuje niezależną domenę Wiadomości po stronie
    /// WebKit; nie wykonujemy automatycznie logowania ani nie pobieramy haseł.
    func openMessagesInPortal() {
        guard let url = URL(string: "https://synergia.librus.pl/wiadomosci3") else { return }
        webView.load(URLRequest(url: url))
    }

    /// Non-destructive read of the unread counter API. Counters are held only
    /// after the same student's identity is verified before and after the GET.
    func refreshDirectUnreadCounts() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard !directUnreadBusy, directMessagesBusy == nil,
              !directMessageDetailBusy, directAttachmentBusy == nil,
              !directSendBusy, !directRecipientBusy else { return }
        directUnreadBusy = true
        directUnreadCounts = nil
        directUnreadStatus = "Weryfikacja konta i liczników…"
        let epoch = UUID()
        directMessagesEpoch = epoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                if self.directMailboxes.values.contains(where: { $0.accountId != first.id }) {
                    self.directMailboxes.removeAll()
                    self.directMessageDetail = nil
                    self.clearDirectAttachments()
                }
                let messages = SynergiaMessagesClient(webView: self.webView)
                let counts = try await messages.unreadCounts()
                guard self.directMessagesEpoch == epoch else { return }
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                self.directUnreadCounts = counts
                self.directUnreadStatus = "Odczytano liczniki; brakujące kategorie pozostają nieustalone."
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? GatewayReadError) == .loginRequired ||
                    (error as? DirectMessagesTransportError) == .authorizationRequired {
                    self.lockDirectMessages()
                    self.directUnreadStatus = "Utracono lub zmieniono sesję. Liczniki zablokowane."
                    return
                }
                self.directUnreadCounts = nil
                self.directUnreadStatus = "Błąd liczników: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directUnreadBusy = false }
        }
    }

    /// Odczyt całej dostępnej skrzynki w obrębie udokumentowanego limitu 2000.
    /// Publikacja jest atomowa i dopiero po podwójnym potwierdzeniu tożsamości.
    func refreshDirectMessages(_ mailbox: DirectMailbox) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard directMessagesBusy == nil && !directMessageDetailBusy && directAttachmentBusy == nil && !directUnreadBusy && !directSendBusy && !directRecipientBusy else { return }
        clearDirectAttachments()
        directUnreadCounts = nil
        directUnreadStatus = ""
        let epoch = UUID()
        directMessagesEpoch = epoch
        directMessagesBusy = mailbox
        directMailboxes.removeValue(forKey: mailbox)
        directMessageDetail = nil
        directMessageDetailStatus = ""
        directMessagesStatus[mailbox] = "Weryfikacja konta i pobieranie wiadomości…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identityClient = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identityClient.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                // Unieważnij skrzynki innego konta przed dalszymi odczytami.
                if self.directMailboxes.values.contains(where: { $0.accountId != first.id }) {
                    self.directMailboxes.removeAll()
                    self.directMessageDetail = nil
                }
                let client = SynergiaMessagesClient(webView: self.webView)
                let remoteId = try await client.currentSessionAccountId()
                var pages: [DirectMessagePage] = []
                while pages.count < DirectMessageParser.maxPages {
                    guard self.directMessagesEpoch == epoch else { return }
                    let page = try await client.list(mailbox, page: pages.count + 1)
                    guard self.directMessagesEpoch == epoch else { return }
                    pages.append(page)
                    let cumulative = pages.reduce(0) { $0 + $1.messages.count }
                    if let total = page.total, cumulative >= total { break }
                    if page.messages.count < DirectMessageParser.pageSize { break }
                    if pages.count == DirectMessageParser.maxPages {
                        throw DirectMessageError.tooManyMessages
                    }
                }
                guard self.directMessagesEpoch == epoch else { return }
                let finalRemoteId = try await client.currentSessionAccountId()
                guard remoteId == finalRemoteId else { throw DirectComposeError.staleSession }
                let snapshot = try DirectMessageParser.merge(pages, mailbox: mailbox,
                    accountId: first.id, messageSessionId: remoteId)
                // Również przy wymianie sesji pomiędzy stronami nie publikujemy
                // danych innego dziecka lub konta.
                let last = try DirectAccountIdentity.parse((try await identityClient.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                self.directMailboxes[mailbox] = snapshot
                self.failedDirectMailboxes.remove(mailbox)
                self.failedDirectReads.remove(.messages)
                self.directMessagesStatus[mailbox] = "Pobrano \(snapshot.messages.count) wiadomości. " +
                    (snapshot.complete ? "Licznik odpowiedzi jest zgodny." :
                        "Pełna liczba wiadomości niepotwierdzona przez serwer.")
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? GatewayReadError) == .loginRequired ||
                    (error as? DirectMessagesTransportError).map({
                        if case .authorizationRequired = $0 { return true }; return false
                    }) == true {
                    self.lockDirectMessages()
                    self.directMessagesStatus[mailbox] = "Utracono lub zmieniono sesję. Dane zostały zablokowane."
                    return
                }
                self.directMailboxes.removeValue(forKey: mailbox)
                self.failedDirectMailboxes.insert(mailbox)
                self.failedDirectReads.insert(.messages)
                self.directMessagesStatus[mailbox] = "Odczyt nieudany: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directMessagesBusy = nil }
        }
    }

    /// Pełną treść pobieramy wyłącznie dla ID obecnego w zweryfikowanej skrzynce.
    func refreshDirectMessageDetail(_ message: DirectMessage) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard directMessagesBusy == nil && !directMessageDetailBusy && directAttachmentBusy == nil && !directUnreadBusy, !directSendBusy, !directRecipientBusy,
              let snapshot = directMailboxes[message.mailbox],
              snapshot.messages.contains(where: { $0.id == message.id }) else { return }
        clearDirectAttachments()
        let epoch = UUID()
        directMessagesEpoch = epoch
        directMessageDetailBusy = true
        directMessageDetail = nil
        directMessageDetailStatus = "Pobieranie pełnej treści…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first.id == snapshot.accountId else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                let client = SynergiaMessagesClient(webView: self.webView)
                let remoteId = try await client.currentSessionAccountId()
                guard remoteId == snapshot.messageSessionId else { throw DirectComposeError.staleSession }
                let detail = try await client.detail(message.mailbox, id: message.id)
                guard self.directMessagesEpoch == epoch else { return }
                let finalRemoteId = try await client.currentSessionAccountId()
                guard remoteId == finalRemoteId else { throw DirectComposeError.staleSession }
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last && last.id == snapshot.accountId else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                self.directMessageDetail = detail
                self.directMessageDetailStatus = "Treść odczytana. Załączniki można pobrać pojedynczo na żądanie."
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? GatewayReadError) == .loginRequired ||
                    (error as? DirectMessagesTransportError).map({
                        if case .authorizationRequired = $0 { return true }; return false
                    }) == true {
                    self.lockDirectMessages()
                    self.directMessageDetailStatus = "Utracono lub zmieniono sesję. Dane zostały zablokowane."
                    return
                }
                self.directMessageDetail = nil
                self.directMessageDetailStatus = "Odczyt treści nieudany: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directMessageDetailBusy = false }
        }
    }

    /// Download a chosen attachment to a protected, session-only temporary file.
    /// The archive is displayed only after /Me matches on both sides of transfer.
    func downloadDirectMessageAttachment(_ file: DirectMessageAttachment, in message: DirectMessageDetail) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard message.mailbox.supportsDirectAttachments else {
            directAttachmentStatus = "Załączniki archiwalne pobierz przez oficjalny serwis Synergii."
            return
        }
        guard directAttachmentBusy == nil, directMessagesBusy == nil,
              !directMessageDetailBusy, !directUnreadBusy, !directSendBusy, !directRecipientBusy,
              directMessageDetail == message,
              let snapshot = directMailboxes[message.mailbox],
              snapshot.messages.contains(where: { $0.id == message.id }),
              message.attachments.contains(file),
              DirectAttachmentPolicy.safeFileName(file.name) else { return }
        let key = directAttachmentKey(file, message: message)
        directAttachmentBusy = key
        directAttachmentStatus = "Weryfikacja konta i pobieranie załącznika…"
        let epoch = UUID()
        directMessagesEpoch = epoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first.id == snapshot.accountId else { throw DirectAttachmentError.accountChanged }
                let client = SynergiaMessagesClient(webView: self.webView)
                let contents = try await client.attachment(file, messageId: message.id)
                guard self.directMessagesEpoch == epoch else { return }
                let last = try DirectAccountIdentity.parse((try await identity.read(.me)).json)
                guard self.directMessagesEpoch == epoch else { return }
                guard first == last, last.id == snapshot.accountId else {
                    throw DirectAttachmentError.accountChanged
                }
                let existingBytes = self.directAttachmentURLs.values.reduce(0) { result, url in
                    let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.intValue ?? 0
                    return result + size
                }
                guard existingBytes + contents.count <= DirectAttachmentPolicy.maxSessionBytes else {
                    throw DirectAttachmentError.sizeLimit
                }
                let directory = self.directAttachmentFolder.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let dest = directory.appendingPathComponent(file.name, isDirectory: false)
                do {
                    try contents.write(to: dest, options: [.atomic, .completeFileProtection])
                    var values = URLResourceValues()
                    values.isExcludedFromBackup = true
                    var folder = directory
                    try? folder.setResourceValues(values)
                    self.directAttachmentURLs[key] = dest
                    self.directAttachmentStatus = "Załącznik gotowy. Użyj Udostępnij/Zapisz, aby zachować go poza aplikacją."
                } catch {
                    try? FileManager.default.removeItem(at: directory)
                    throw error
                }
            } catch {
                guard self.directMessagesEpoch == epoch else { return }
                if error is DirectAccountIdentity.IdentityError ||
                    (error as? DirectAttachmentError) == .accountChanged ||
                    (error as? GatewayReadError) == .loginRequired ||
                    (error as? DirectMessagesTransportError).map({
                        if case .authorizationRequired = $0 { return true }; return false
                    }) == true {
                    self.lockDirectMessages()
                    self.directAttachmentStatus = "Zmiana lub utrata sesji — dane i pliki tymczasowe usunięte."
                    return
                }
                self.directAttachmentStatus = "Nie udało się pobrać załącznika: \(error.localizedDescription)"
            }
            if self.directMessagesEpoch == epoch { self.directAttachmentBusy = nil }
        }
    }

    /// Delete one downloaded temporary attachment without clearing the account.
    /// Only a file created by this session inside the dedicated UUID directory
    /// may be removed. This never deletes an exported copy from the Files app.
    func discardDirectMessageAttachment(_ file: DirectMessageAttachment, in message: DirectMessageDetail) {
        guard !privacyShieldActive, directAttachmentBusy == nil,
              directMessageDetail == message,
              let snapshot = directMailboxes[message.mailbox],
              snapshot.accountId == store.verifiedAccountId,
              snapshot.messages.contains(where: { $0.id == message.id }),
              message.attachments.contains(file),
              let url = directAttachmentURLs[directAttachmentKey(file, message: message)] else { return }
        guard let parent = DirectAttachmentLocalFilePolicy.disposableDirectory(
            fileURL: url, filename: file.name, under: directAttachmentFolder) else {
            directAttachmentStatus = "Nie można usunąć pliku poza folderem tymczasowym aplikacji."
            return
        }
        do {
            try FileManager.default.removeItem(at: parent)
            directAttachmentURLs.removeValue(forKey: directAttachmentKey(file, message: message))
            directAttachmentStatus = "Usunięto tymczasową kopię załącznika. Kopie zapisane w Plikach pozostają bez zmian."
        } catch {
            directAttachmentStatus = "Nie udało się usunąć załącznika: \(error.localizedDescription)"
        }
    }

    /// On launch, reuse only a still-valid official WebKit session. A saved
    /// cookie alone never grants access to local account data.
    func restoreOfficialSessionAtLaunch() {
        guard !sessionLifecycle.isClearing, loginRestorePolicy.claimStartupVerification() else { return }
        verifyAccount()
        // If a user opens the embedded site while this /Me is in flight,
        // didStart invalidates its account epoch. Re-check once after the
        // first trusted landing rather than demanding another manual tap.
        recheckAfterTrustedNavigation = true
    }

    /// Explicit account authorization. A live /Me response, not HTML or cookies,
    /// controls visibility of account-scoped legacy snapshots and downloads.
    func verifyAccount() {
        // Only one /Me check may be active; never race an account erasure.
        guard !backgroundSuspended, sessionLifecycle.beginVerification() else { return }
        if manualRefreshRunning == .additionalJSON {
            markManualRefreshStopping(.additionalJSON)
            additionalFeedWorker?.cancel()
        }
        if isSyncing { stopSync("Zmiana lub ponowna weryfikacja konta") }
        cancelCoreSync()
        lockDirectMessages()
        failedDirectReads.removeAll()
        loginRestorePolicy.cancelPendingReturn()
        recheckAfterTrustedNavigation = false
        freshDirectReads.removeAll()
        let epoch = UUID()
        accountEpoch = epoch
        captureEpoch = UUID()
        directFeedEpoch = UUID()
        directFeedBatchBusy = false
        directFeedDeltas.removeAll()
        clearDirectHomeworkFiles()
        clearDirectSchoolFiles()
        directFeedBusy = nil
        directFeeds.removeAll()
        directOfflineTimetableStore.lock()
        directOfflineFeedStore.lock()
        directFeedStatus.removeAll()
        directAttendanceEpoch = UUID()
        directAttendanceBusy = false
        directAttendanceStore.lock()
        directTimetableEpoch = UUID()
        directTimetableBusy = false
        directTimetable = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        directPlanChanges = nil
        directPlanChangesStatus = "Nie pobierano historii zastępstw."
        // Reverification must revoke access to the prior grade snapshot immediately.
        // Also invalidate any grade request still running under an earlier session.
        directGradeEpoch = UUID()
        directGradeBusy = false
        directGradeStore.lock()
        directGradeStatus = "Weryfikowanie konta przed udostępnieniem ocen…"
        isBusy = false
        store.lock(); downloads.lock(); routes.lock(); auditStore.lock()
        accountStatus = "Weryfikowanie konta…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = try DirectAccountIdentity.parse(
                    (try await SynergiaGatewayClient(webView: self.webView).read(.me)).json)
                guard self.accountEpoch == epoch else { return }
                self.sessionLifecycle.finishVerification()
                let switchedWithinProcess = self.notificationAccountGate.verify(identity.id)
                let savedConsentMatchesOwner = DirectNotificationOwnerPolicy.mayActivate(
                    preferences: self.localNotificationPreferences,
                    boundAccount: DirectNotificationOwnerKeychain.read(), verifiedAccount: identity.id)
                if switchedWithinProcess ||
                   (self.localNotificationPreferences.enabled && !savedConsentMatchesOwner) {
                    // Even after app restart a sibling may not inherit the former owner's opt-in.
                    self.setLocalNotifications(false)
                    self.localNotificationsStatus = "Inne konto lub nieczytelny zapis zgody — włącz powiadomienia ponownie."
                }
                self.directAttendanceStore.unlock(accountId: identity.id)
                self.directGradeStore.unlock(accountId: identity.id)
                self.directOfflineFeedStore.unlock(accountId: identity.id)
                self.directOfflineTimetableStore.unlock(accountId: identity.id)
                self.directFeeds = self.directOfflineFeedStore.feeds
                for (module, feed) in self.directFeeds {
                    self.directFeedStatus[module] = "Wcześniejszy zapis lokalny (NIEAKTUALNY): \(feed.records.count) wpisów; ostatni odczyt \(feed.fetchedAt.formatted(date: .abbreviated, time: .shortened))."
                }
                self.store.unlock(accountId: identity.id)
                self.downloads.unlock(accountId: identity.id)
                self.routes.unlock(accountId: identity.id)
                self.auditStore.unlock(accountId: identity.id)
                self.accountStatus = "Konto zweryfikowane — lokalne dane udostępnione"
                if self.submittedNativeLogin {
                    self.nativeLoginPhase = .verified
                    self.nativeLoginMessage = "Konto szkolne potwierdzone przez /Me."
                    self.submittedNativeLogin = false
                }
                self.refreshLocalNotificationAuthorization()
                self.resumeNeedsAccountVerification = false
                self.privacyShieldActive = false
                self.selectCachedTimetableWeek()
                self.dataRevision += 1
            } catch {
                guard self.accountEpoch == epoch else { return }
                self.sessionLifecycle.finishVerification()
                self.directAttendanceStore.lock()
                self.directGradeStore.lock()
                self.directOfflineTimetableStore.lock()
                self.directOfflineFeedStore.lock()
                self.directFeeds.removeAll()
                self.store.lock(); self.downloads.lock(); self.routes.lock(); self.auditStore.lock()
                let issue: DirectConnectionIssue
                if let gateway = error as? GatewayReadError {
                    switch gateway {
                    case .noAuthenticatedSession, .loginRequired: issue = .loginRequired
                    case .forbidden: issue = .forbidden
                    case .serviceUnavailable(let status): issue = .http(status)
                    case .transport(let transport): issue = transport
                    default: issue = .invalidResponse
                    }
                } else {
                    issue = error is DirectAccountIdentity.IdentityError ? .invalidResponse : .network(error)
                }
                if issue == .loginRequired && DirectSynergiaEntry.isPublicPortal(self.webView.url) {
                    self.accountStatus = "Nie ma potwierdzonej sesji szkolnej Synergii. " +
                        "Otwórz dziennik Synergia (nie stronę informacyjną), " +
                        "zaloguj się kontem otrzymanym od szkoły i ponów sprawdzenie."
                } else {
                    self.accountStatus = "Konto niepotwierdzone — dane zablokowane. " + issue.message
                }
                if self.submittedNativeLogin {
                    self.nativeLoginPhase = .failed
                    self.nativeLoginMessage = "Nie udało się potwierdzić konta przez /Me: " + issue.message
                    self.submittedNativeLogin = false
                }
                self.resumeNeedsAccountVerification = false
                self.privacyShieldActive = false
            }
        }
    }


    /// Read-only grade sync. A live /Me identity must match both before and
    /// after every batch; old unscoped caches are never displayed.
    func refreshDirectGrades() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard !directGradeBusy else { return }
        guard let authorizedOwner = store.verifiedAccountId,
              !backgroundSuspended && !privacyShieldActive else {
            directGradeStatus = "Zweryfikuj konto i wróć do aplikacji przed odczytem ocen."
            return
        }
        directGradeBusy = true
        let epoch = UUID()
        directGradeEpoch = epoch
        let previousOwner = store.verifiedAccountId
        let previousVerifiedNames = directGradeStore.verifiedAccountId == previousOwner
            ? directGradeStore.teachers : [:]
        let ownerEpoch = accountEpoch
        directGradeStore.lock()
        directGradeStatus = "Weryfikacja konta i odczyt ocen…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            await self.runDirectGradeRefresh(authorizedOwner: authorizedOwner,
                previousOwner: previousOwner, previousVerifiedNames: previousVerifiedNames,
                ownerEpoch: ownerEpoch, epoch: epoch)
        }
    }

    // Split the verified grade batch from the Task closure: Xcode's Swift
    // type-checker timed out on the original monolithic closure (P28 CI log).
    // The exact read/identity/commit/catch code below is unchanged.
    private func runDirectGradeRefresh(authorizedOwner: String, previousOwner: String?,
                                       previousVerifiedNames: [String: String],
                                       ownerEpoch: UUID, epoch: UUID) async {
            var observedAccount: String?
            do {
                let client = SynergiaGatewayClient(webView: self.webView)
                let firstMe = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedAccount = firstMe.id
                guard DirectAccountCommitPolicy.permits(
                    verifiedAtStart: authorizedOwner,
                    verifiedNow: self.store.verifiedAccountId,
                    remoteBefore: firstMe.id, remoteAfter: firstMe.id,
                    accountEpochUnchanged: self.accountEpoch == ownerEpoch,
                    requestEpochUnchanged: self.directGradeEpoch == epoch,
                    foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive
                ) else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                let base = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Grades")!
                var current = base
                var pages: [[String: Any]] = []
                var visited = Set<String>()
                while true {
                    guard self.directGradeEpoch == epoch else { return }
                    guard pages.count < DirectGradePagination.maximumPages else { throw GradePagingError.tooManyPages }
                    guard visited.insert(current.absoluteString).inserted else { throw GradePagingError.repeatedPage }
                    let response = pages.isEmpty ? try await client.read(.grades) : try await client.readGradeContinuation(current)
                    pages.append(response.json)
                    guard let next = try DirectGradePagination.continuation(response.json, current: current, base: base) else { break }
                    current = next
                }
                // Some schools use only point/descriptive grades. An empty
                // standard Grades list without a total is ambiguous, so it is
                // never declared complete. Other families may still be read.
                let gradeRoot: [String: Any]
                var ambiguousEmptyStandard = false
                do {
                    gradeRoot = try DirectGradePagination.merge(pages, previousCount: 0)
                } catch DirectGradeCompletenessError.unexpectedEmptyReplacement {
                    guard pages.count == 1,
                          let records = pages[0]["Grades"] as? [[String: Any]], records.isEmpty else { throw DirectGradeCompletenessError.unexpectedEmptyReplacement }
                    gradeRoot = ["Grades": [[String: Any]]()]
                    ambiguousEmptyStandard = true
                }
                let comments = try await client.read(.gradeComments)
                let decoded = try SynergiaGradeRecords.decode(grades: gradeRoot, comments: comments.json)
                // A malformed category response cannot silently turn zero weights
                // or explicit exclusion from averages into made-up defaults.
                let categoryResponse = try await client.read(.gradeCategories)
                let categories = try SynergiaGradeCategories.decode(categoryResponse.json)
                let unknownCategories = SynergiaGradeCategories.unresolvedCategoryIds(decoded, categories: categories)
                let parsed = SynergiaGradeCategories.enrich(decoded, categories: categories)
                let subjectResponse = try await client.read(.subjects)
                let names = try SynergiaSubjects.decode(subjectResponse.json)
                try GradeReferenceIntegrity.validate(grades: parsed, subjects: names)
                // Resolve only explicit AddedBy, not the subject's teacher.
                // The previously verified account cache was already locked and
                // is read only after a successful first /Me check.
                let authors = try await client.readGradeAuthors(grades: parsed,
                    previous: firstMe.id == previousOwner ? previousVerifiedNames : [:])
                // Grades is not a complete grade book: descriptive, point,
                // text and behaviour marks are separate gateway resources.
                // Fetch every documented family before making an atomic snapshot.
                var freshSupplemental: [SupplementalGrade] = []
                var unavailableFamilySet = Set<SupplementalGradeFamily>()
                var unavailableFamilies: [String] = []
                for (family, resource) in [
                    (SupplementalGradeFamily.descriptive, SynergiaGatewayClient.Resource.descriptiveGrades),
                    (.points, .pointGrades),
                    (.text, .baseTextGrades),
                    (.behaviour, .behaviourPointGrades)
                ] {
                    guard self.directGradeEpoch == epoch else { return }
                    do {
                        let response = try await client.read(resource)
                        freshSupplemental += try SupplementalGrades.decode(family: family, root: response.json)
                    } catch GatewayReadError.forbidden {
                        unavailableFamilySet.insert(family)
                        unavailableFamilies.append(family.rawValue + " (403)")
                    } catch GatewayReadError.serviceUnavailable(let code) where code == 404 {
                        unavailableFamilySet.insert(family)
                        unavailableFamilies.append(family.rawValue + " (404)")
                    }
                }
                let finalMe = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard firstMe == finalMe && DirectAccountCommitPolicy.permits(
                    verifiedAtStart: authorizedOwner,
                    verifiedNow: self.store.verifiedAccountId,
                    remoteBefore: firstMe.id, remoteAfter: finalMe.id,
                    accountEpochUnchanged: self.accountEpoch == ownerEpoch,
                    requestEpochUnchanged: self.directGradeEpoch == epoch,
                    foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive
                ) else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                self.directGradeStore.unlock(accountId: finalMe.id)
                // A 403/404 is not proof that a previously fetched grade family
                // has become empty. Preserve only those families in this account's
                // previously verified snapshot, clearly reporting them as stale.
                try SupplementalSemesterCoverage.validateReplacement(
                    fresh: freshSupplemental, previous: self.directGradeStore.supplemental,
                    unavailable: unavailableFamilySet)
                let supplemental = GradeFamilySnapshot.reconcile(
                    fresh: freshSupplemental,
                    previous: self.directGradeStore.supplemental,
                    unavailable: unavailableFamilySet)
                // Compare against the same account's previous data, not another account.
                if ambiguousEmptyStandard {
                    // Never replace known normal grades with an ambiguous zero.
                    // Only allow a first snapshot when a separate grade source
                    // actually contains records; always label as unverified.
                    guard self.directGradeStore.grades.isEmpty, !supplemental.isEmpty else {
                        throw DirectGradeCompletenessError.unexpectedEmptyReplacement
                    }
                } else {
                    try DirectGradeCompleteness.validate(root: gradeRoot,
                        decodedCount: parsed.count, previousCount: self.directGradeStore.grades.count)
                }
                _ = try GradeSemesterCoverage.validateReplacement(
                    incoming: parsed, previous: self.directGradeStore.grades)
                _ = try GradeChangeAudit.compare(
                    previous: self.directGradeStore.grades, incoming: parsed)
                let observed = try GradeObservedChangeAudit.compare(
                    previous: self.directGradeStore.grades, current: parsed,
                    previousSupplemental: self.directGradeStore.supplemental,
                    currentSupplemental: supplemental, unavailable: unavailableFamilySet)
                // The first saved read is a baseline, not evidence of newly issued grades.
                let hadPreviousSnapshot = self.directGradeStore.capturedAt != nil
                try self.directGradeStore.replace(grades: parsed, subjects: names, accountId: finalMe.id, supplemental: supplemental, teachers: authors.names,
                        olderTeacherIds: authors.staleIds)
                self.failedDirectReads.remove(.grades)
                self.freshDirectReads.insert(.grades)
                self.directGradeStatus = "Odczyt JSON zapisany: \(parsed.count) ocen zwykłych i \(supplemental.count) innych wpisów z czterech zasobów. " +
                    (unknownCategories.isEmpty ? "Wszystkie odwołania do kategorii rozpoznane. " :
                     "Brak metadanych dla \(unknownCategories.count) kategorii. ") +
                    authors.summary +
                    GradePortfolioSemesterCoverage.report(standard: parsed, supplemental: supplemental).message +
                    " Porównanie zapisanych odczytów (bez potwierdzenia usunięć): " +
                    (hadPreviousSnapshot ? observed.summary :
                        "Pierwszy zweryfikowany odczyt jest punktem odniesienia; nie zgłaszano nowych ocen.") +
                    " Zasoby niedostępne (nie oznacza zero ocen): " +
                    (unavailableFamilies.isEmpty ? "brak wykrytych" : unavailableFamilies.joined(separator: ", ") + " — poprzednie wpisy tych typów zachowano jako NIEAKTUALNE") + ". " +
                    (ambiguousEmptyStandard ? "UWAGA: pusta lista Grades bez licznika; kompletność standardowych ocen NIEPOTWIERDZONA." : "")
                self.dataRevision += 1
            } catch {
                guard self.directGradeEpoch == epoch else { return }
                if DirectOfflineRecovery.mayRetain(
                    previouslyVerified: previousOwner != nil,
                    accountUnchanged: self.store.verifiedAccountId == previousOwner && self.accountEpoch == ownerEpoch,
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: observedAccount,
                    expectedAccount: previousOwner ?? "", failure: error), let owner = previousOwner {
                    self.directGradeStore.unlock(accountId: owner)
                } else { self.directGradeStore.lock() }
                self.failedDirectReads.insert(.grades)
                self.freshDirectReads.remove(.grades)
                self.directGradeStatus = "Nie zapisano ocen: \(error.localizedDescription). Zapis na dysku nie został zmieniony."
            }
            if self.directGradeEpoch == epoch { self.directGradeBusy = false }
    }


    /// This accessor is used in both single and batch refresh. It never returns
    /// a partial set of notice pages after any transport or identity failure.
    private func readVerifiedSchoolNotices(_ client: SynergiaGatewayClient,
                                           accountId: String, ownerEpoch: UUID,
                                           feedEpoch: UUID) async throws -> DirectSchoolFeed {
        var pages: [[String: Any]] = []
        for page in 1...DirectSchoolNoticePaging.maximumPages {
            try Task.checkCancellation()
            guard self.accountEpoch == ownerEpoch, self.directFeedEpoch == feedEpoch,
                  self.store.verifiedAccountId == accountId,
                  !self.backgroundSuspended && !self.privacyShieldActive else {
                throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
            }
            let response = try await client.readSchoolNoticesPage(page)
            guard self.accountEpoch == ownerEpoch, self.directFeedEpoch == feedEpoch,
                  self.store.verifiedAccountId == accountId else {
                throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
            }
            let count = try DirectSchoolNoticePaging.rowCount(response.json)
            pages.append(response.json)
            if count < DirectSchoolNoticePaging.pageSize { break }
        }
        return try DirectSchoolNoticePaging.merge(pages, accountId: accountId)
    }

    /// Explicit read only JSON feeds, scoped to verified /Me before AND after
    /// transport. In-memory only until a real payload and pagination are verified.
    func refreshDirectFeed(_ module: SchoolModule) {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard directFeedBusy == nil, !directFeedBatchBusy else { return }
        let resource: SynergiaGatewayClient.Resource
        do { resource = try DirectSchoolFeedParser.resource(for: module) }
        catch { directFeedStatus[module] = "Ten moduł nie jest obsługiwany."; return }
        directFeedBusy = module
        if module == .documents { clearDirectSchoolFiles() }
        if module == .homework { clearDirectHomeworkFiles() }
        let epoch = UUID(); directFeedEpoch = epoch
        let ownerEpoch = accountEpoch
        let previousOwner = store.verifiedAccountId
        directFeedStatus[module] = "Odczyt JSON i weryfikacja konta…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            var observedAccount: String?
            do {
                let client = SynergiaGatewayClient(webView: self.webView)
                let initial = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedAccount = initial.id
                guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch,
                      self.store.verifiedAccountId == initial.id else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                let feed: DirectSchoolFeed
                if module == .announcements {
                    feed = try await self.readVerifiedSchoolNotices(client, accountId: initial.id, ownerEpoch: ownerEpoch, feedEpoch: epoch)
                } else {
                    let response = try await client.read(resource)
                    feed = try DirectSchoolFeedParser.parse(response.json, module: module, accountId: initial.id)
                }
                guard self.directFeedEpoch == epoch else { return }
                let final = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch,
                      initial == final, self.store.verifiedAccountId == initial.id else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                let previous = self.directFeeds[module]
                try self.directOfflineFeedStore.replace(feed)
                self.directFeedDeltas[module] = previous.map { DirectFeedChangeAudit.compare(previous: $0, current: feed) }
                self.directFeeds[module] = feed
                self.failedDirectReads.remove(module)
                self.freshDirectReads.insert(module)
                self.directFeedStatus[module] = "Odczytano \(feed.records.count) wpisów. " +
                    (feed.completenessKnown ? "Licznik odpowiedzi jest zgodny." :
                     "Kompletność i stronicowanie niepotwierdzone.")
            } catch {
                guard self.directFeedEpoch == epoch else { return }
                // Never preserve even an old snapshot after an unverified
                // account transition; a 403 during the read is not proof
                // that the user stayed logged in as the same student.
                let current = try? DirectAccountIdentity.parse(
                    (try await SynergiaGatewayClient(webView: self.webView).read(.me)).json)
                guard self.directFeedEpoch == epoch else { return }
                let identityStillVerified = current?.id == self.store.verifiedAccountId &&
                    self.store.verifiedAccountId != nil && self.accountEpoch == ownerEpoch
                let retainOffline = DirectOfflineRecovery.mayRetain(
                    previouslyVerified: previousOwner != nil && previousOwner == self.directOfflineFeedStore.verifiedAccountId,
                    accountUnchanged: self.store.verifiedAccountId == previousOwner && self.accountEpoch == ownerEpoch,
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: current?.id ?? observedAccount,
                    expectedAccount: previousOwner ?? "", failure: error)
                if !identityStillVerified && !retainOffline || error is DirectAccountIdentity.IdentityError ||
                    (error as? GatewayReadError) == .loginRequired {
                    self.directFeeds.removeAll(); self.directFeedDeltas.removeAll()
                    self.directOfflineTimetableStore.lock()
                    self.revokeDirectTimetableOnAccountFailure()
                    self.directOfflineFeedStore.lock()
                    self.freshDirectReads.remove(module)
                    self.failedDirectReads.insert(module)
                    self.clearDirectSchoolFiles(); self.clearDirectHomeworkFiles()
                    self.directFeedStatus[module] = "Konto niezweryfikowane — dane zablokowane."
                } else {
                    // Do not interpret a transient read failure as deletion.
                    let cached = self.directFeeds[module] != nil
                    self.failedDirectReads.insert(module)
                    self.freshDirectReads.remove(module)
                    self.directFeedStatus[module] = "Odczyt nieudany (tryb offline po wcześniejszej weryfikacji): \(error.localizedDescription). " +
                        (cached ? "Pozostał wcześniejszy odczyt (NIEAKTUALNY); nie usuwano wpisów." : "Brak danych.")
                }
            }
            if self.directFeedEpoch == epoch { self.directFeedBusy = nil }
        }
    }

    /// Refresh all four JSON feeds with one before/after identity check.
    /// Partial failures leave earlier snapshots explicitly marked stale;
    /// successful feeds are published only after final account verification.
    func refreshAllDirectFeeds() {
        guard directFeedBusy == nil, !directFeedBatchBusy,
              let owner = store.verifiedAccountId, !owner.isEmpty else { return }
        guard let refreshTicket = startManualRefresh(.additionalJSON, owner: owner) else { return }
        let modules: [SchoolModule] = [.homework, .calendar, .announcements, .documents]
        directFeedBatchBusy = true
        clearDirectSchoolFiles(); clearDirectHomeworkFiles()
        let epoch = UUID(); directFeedEpoch = epoch
        let ownerEpoch = accountEpoch
        let previousOwner = store.verifiedAccountId
        for module in modules { directFeedStatus[module] = "Odświeżanie zbiorcze…" }
        additionalFeedWorker = Task { @MainActor [weak self] in
            guard let self else { return }
            defer {
                self.additionalFeedWorker = nil
                self.completeManualRefresh(refreshTicket)
            }
            var staged: [SchoolModule: DirectSchoolFeed] = [:]
            var failures: [SchoolModule: String] = [:]
            var observedAccount: String?
            do {
                let client = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedAccount = first.id
                guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch,
                      self.store.verifiedAccountId == first.id else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                for module in modules {
                    try Task.checkCancellation()
                    guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                    do {
                        let resource = try DirectSchoolFeedParser.resource(for: module)
                        if module == .announcements {
                            staged[module] = try await self.readVerifiedSchoolNotices(client, accountId: first.id, ownerEpoch: ownerEpoch, feedEpoch: epoch)
                        } else {
                            staged[module] = try DirectSchoolFeedParser.parse(
                                (try await client.read(resource)).json, module: module, accountId: first.id)
                        }
                    } catch {
                        // Authentication failures are fatal for the entire batch.
                        if (error as? GatewayReadError) == .loginRequired { throw error }
                        guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                        failures[module] = error.localizedDescription
                    }
                }
                guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                let last = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard self.directFeedEpoch == epoch, self.accountEpoch == ownerEpoch,
                      first == last, self.store.verifiedAccountId == first.id else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                for module in modules {
                    if let feed = staged[module] {
                        do { try self.directOfflineFeedStore.replace(feed) }
                        catch {
                            self.failedDirectReads.insert(module)
                            self.freshDirectReads.remove(module)
                            self.directFeedStatus[module] = "Nie zapisano odczytu lokalnego: \(error.localizedDescription). Wcześniejsze dane NIEAKTUALNE."
                            continue
                        }
                        self.directFeedDeltas[module] = self.directFeeds[module].map {
                            DirectFeedChangeAudit.compare(previous: $0, current: feed)
                        }
                        self.directFeeds[module] = feed
                        self.failedDirectReads.remove(module)
                        self.freshDirectReads.insert(module)
                        self.directFeedStatus[module] = "Odczytano \(feed.records.count) wpisów. " +
                            (feed.completenessKnown ? "Licznik zgodny." : "Kompletność niepotwierdzona.")
                    } else {
                        self.failedDirectReads.insert(module)
                        self.freshDirectReads.remove(module)
                        self.directFeedStatus[module] = "Nie odświeżono: \(failures[module] ?? "brak odpowiedzi"). " +
                            (self.directFeeds[module] != nil ? "Wcześniejsze dane NIEAKTUALNE." : "Brak danych.")
                    }
                }
            } catch {
                guard self.directFeedEpoch == epoch else { return }
                if DirectOfflineRecovery.mayRetain(
                    previouslyVerified: previousOwner != nil && previousOwner == self.directOfflineFeedStore.verifiedAccountId,
                    accountUnchanged: self.store.verifiedAccountId == previousOwner && self.accountEpoch == ownerEpoch,
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: observedAccount,
                    expectedAccount: previousOwner ?? "", failure: error) {
                    for module in modules {
                        self.failedDirectReads.insert(module)
                        self.freshDirectReads.remove(module)
                        self.directFeedStatus[module] = "Brak połączenia. Poprzednie dane pozostają NIEAKTUALNE; ponów odczyt po odzyskaniu sieci."
                    }
                    self.directFeedBatchBusy = false
                    return
                }
                self.directFeeds.removeAll(); self.directFeedDeltas.removeAll()
                self.directOfflineTimetableStore.lock()
                self.revokeDirectTimetableOnAccountFailure()
                self.directOfflineFeedStore.lock()
                self.freshDirectReads.subtract(modules)
                self.clearDirectSchoolFiles(); self.clearDirectHomeworkFiles()
                for module in modules {
                    self.directFeedStatus[module] = "Przerwano: nie można potwierdzić niezmienności konta. Dane ukryte."
                }
            }
            if self.directFeedEpoch == epoch { self.directFeedBatchBusy = false }
        }
    }

    /// A week is saved only after two agreeing live /Me reads; optional history
    /// and lookups may fail without inventing them. A prior cache remains STALE.
    func refreshDirectTimetable() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy, !directTimetableBusy else { return }
        guard let owner = store.verifiedAccountId,
              directOfflineTimetableStore.verifiedAccountId == owner,
              !backgroundSuspended && !privacyShieldActive else {
            directTimetableStatus = "Potwierdź konto przed pobraniem planu."
            return
        }
        let monday = DirectTimetableParser.monday(containing: timetableChosenDate)
        let epoch = UUID()
        let ownerEpoch = accountEpoch
        directTimetableEpoch = epoch
        directTimetableBusy = true
        freshDirectReads.remove(.timetable)
        directTimetable = nil
        directPlanChanges = nil
        directPlanChangesStatus = "Pobieranie historii zmian…"
        directTimetableSubjects = [:]
        directTimetableTeachers = [:]
        directTimetableStatus = "Pobieranie planu na tydzień od \(monday)…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            var observedRemoteAccount: String?
            do {
                let client = SynergiaGatewayClient(webView: self.webView)
                let first = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedRemoteAccount = first.id
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                guard first.id == owner else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                let raw = try await client.readTimetable(monday: monday)
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                let plan = try DirectTimetableParser.parse(raw.json, monday: monday, accountId: first.id)
                // Missing optional lookups never becomes fabricated subject/teacher names.
                let changesResult: Result<DirectPlanChangesSnapshot, Error>
                do {
                    let history = try await client.read(.planChanges)
                    changesResult = .success(try DirectPlanChangesParser.parse(history.json, accountId: first.id))
                } catch { changesResult = .failure(error) }
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                let subjects: [String: String]
                if let result = try? await client.read(.subjects),
                   let lookup = try? SynergiaSubjects.decode(result.json) { subjects = lookup }
                else { subjects = [:] }
                let teachers: [String: String]
                if let users = try? await client.read(.users),
                   let names = try? DirectGradeAuthors.decode(users.json) { teachers = names }
                else { teachers = [:] }
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                let last = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedRemoteAccount = last.id
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch,
                      first == last, last.id == owner,
                      self.store.verifiedAccountId == owner,
                      self.directOfflineTimetableStore.verifiedAccountId == owner else {
                    throw DirectAccountIdentity.IdentityError.conflictingIdentifiers
                }
                let history = try? changesResult.get()
                let snapshot = DirectOfflineTimetableSnapshot(week: plan, history: history,
                    subjects: subjects, teachers: teachers)
                var persistenceWarning = ""
                do { try self.directOfflineTimetableStore.replace(snapshot) }
                catch { persistenceWarning = " Nie udało się zapisać planu offline: \(error.localizedDescription)." }
                self.directTimetable = plan
                self.directTimetableSubjects = subjects
                self.directTimetableTeachers = teachers
                switch changesResult {
                case .success(let history):
                    self.directPlanChanges = history
                    self.directPlanChangesStatus = "Historia: \(history.count) zmian od początku roku; w wybranym tygodniu: \(history.forWeek(monday).count)."
                case .failure(let error):
                    self.directPlanChanges = nil
                    self.directPlanChangesStatus = "Historia zmian niedostępna: \(error.localizedDescription). Plan tygodniowy nadal jest odczytany."
                }
                self.failedDirectReads.remove(.timetable)
                self.freshDirectReads.insert(.timetable)
                self.directTimetableStatus = "Odczytano \(plan.entries.count) lekcji; wpisów równoległych godzin: \(plan.splitPeriods). " +
                    "Przydział ucznia do grup równoległych nie został potwierdzony." + persistenceWarning
            } catch {
                guard self.directTimetableEpoch == epoch, self.accountEpoch == ownerEpoch else { return }
                self.failedDirectReads.insert(.timetable)
                self.freshDirectReads.remove(.timetable)
                if DirectOfflineRecovery.mayRetain(
                    previouslyVerified: self.store.verifiedAccountId == owner &&
                        self.directOfflineTimetableStore.verifiedAccountId == owner,
                    accountUnchanged: self.accountEpoch == ownerEpoch,
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: observedRemoteAccount,
                    expectedAccount: owner, failure: error),
                   let saved = self.directOfflineTimetableStore.snapshot(monday: monday) {
                    self.displayCachedTimetable(saved)
                    self.directTimetableStatus += " Połączenie przerwane; zachowano wcześniejszy odczyt."
                } else {
                    self.directTimetable = nil
                    self.directPlanChanges = nil
                    self.directTimetableSubjects.removeAll()
                    self.directTimetableTeachers.removeAll()
                    self.directPlanChangesStatus = "Historia zmian niedostępna."
                    self.directTimetableStatus = "Nie pobrano planu: \(error.localizedDescription). Dane nie zostały uznane za aktualne."
                    if error is DirectAccountIdentity.IdentityError ||
                       (error as? GatewayReadError) == .loginRequired ||
                       (error as? GatewayReadError) == .noAuthenticatedSession {
                        // Revoke all modules, not just the timetable, if the
                        // remote identity cannot be trusted any longer.
                        self.verifyAccount()
                        return
                    }
                }
            }
            if self.directTimetableEpoch == epoch { self.directTimetableBusy = false }
        }
    }

    /// Explicit read-only attendance sync. Both identity checks must succeed
    /// in one operation, and no partial lookup is written to local storage.
    func refreshDirectAttendance() {
        guard manualRefreshRunning == nil else { return }
        guard !coreSyncBusy else { return }
        guard !directAttendanceBusy else { return }
        guard let authorizedOwner = store.verifiedAccountId,
              !backgroundSuspended && !privacyShieldActive else {
            directAttendanceStatus = "Zweryfikuj konto i wróć do aplikacji przed odczytem frekwencji."
            return
        }
        directAttendanceBusy = true
        let epoch = UUID()
        directAttendanceEpoch = epoch
        let previousOwner = store.verifiedAccountId
        let ownerEpoch = accountEpoch
        directAttendanceStore.lock()
        directAttendanceStatus = "Weryfikowanie konta i pobieranie frekwencji…"
        Task { @MainActor [weak self] in
            guard let self else { return }
            var observedAccount: String?
            do {
                let client = SynergiaGatewayClient(webView: self.webView)
                let initial = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                observedAccount = initial.id
                guard DirectAccountCommitPolicy.permits(
                    verifiedAtStart: authorizedOwner,
                    verifiedNow: self.store.verifiedAccountId,
                    remoteBefore: initial.id, remoteAfter: initial.id,
                    accountEpochUnchanged: self.accountEpoch == ownerEpoch,
                    requestEpochUnchanged: self.directAttendanceEpoch == epoch,
                    foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive
                ) else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                let attendance = try await client.read(.attendance)
                guard self.directAttendanceEpoch == epoch else { return }
                let types = try await client.read(.attendanceTypes)
                guard self.directAttendanceEpoch == epoch else { return }
                let lessons = try await client.read(.lessons)
                guard self.directAttendanceEpoch == epoch else { return }
                let parsed = try SynergiaAttendanceRecords.decode(
                    attendances: attendance.json, types: types.json, lessons: lessons.json)
                let subjectNames = try SynergiaSubjects.decode((try await client.read(.subjects)).json)
                guard self.directAttendanceEpoch == epoch else { return }
                let final = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard initial == final && DirectAccountCommitPolicy.permits(
                    verifiedAtStart: authorizedOwner,
                    verifiedNow: self.store.verifiedAccountId,
                    remoteBefore: initial.id, remoteAfter: final.id,
                    accountEpochUnchanged: self.accountEpoch == ownerEpoch,
                    requestEpochUnchanged: self.directAttendanceEpoch == epoch,
                    foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive
                ) else { throw DirectAccountIdentity.IdentityError.conflictingIdentifiers }
                // A non-empty record list isn't proof of complete coverage of lessons.
                self.directAttendanceStore.unlock(accountId: final.id)
                try DirectAttendanceCompleteness.validate(root: attendance.json,
                    decodedCount: parsed.count, previousCount: self.directAttendanceStore.records.count)
                try DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(
                    previous: self.directAttendanceStore.records, incoming: parsed)
                try self.directAttendanceStore.replace(records: parsed,
                    subjects: subjectNames, accountId: final.id)
                self.failedDirectReads.remove(.attendance)
                self.freshDirectReads.insert(.attendance)
                self.directAttendanceStatus = "Zapisano \(parsed.count) wpisów frekwencji. " +
                    "Nie jest to potwierdzenie obecności na wszystkich lekcjach."
                self.dataRevision += 1
            } catch {
                guard self.directAttendanceEpoch == epoch else { return }
                if DirectOfflineRecovery.mayRetain(
                    previouslyVerified: previousOwner != nil,
                    accountUnchanged: self.store.verifiedAccountId == previousOwner && self.accountEpoch == ownerEpoch,
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: observedAccount,
                    expectedAccount: previousOwner ?? "", failure: error), let owner = previousOwner {
                    self.directAttendanceStore.unlock(accountId: owner)
                } else { self.directAttendanceStore.lock() }
                self.failedDirectReads.insert(.attendance)
                self.freshDirectReads.remove(.attendance)
                self.directAttendanceStatus = "Nie zapisano frekwencji: \(error.localizedDescription)."
            }
            if self.directAttendanceEpoch == epoch { self.directAttendanceBusy = false }
        }
    }

    @Published var syncSummary = "Brak synchronizacji"
    @Published var isSyncing = false
    private var syncQueue: [SchoolModule] = []
    private var syncAccountId: String?
    private var pendingPages: [ModuleSnapshot] = []
    private var pageOffset = 0
    private var batchSawPagination = false
    private var batchPaginationLinks: [String] = []
    @Published private(set) var paginationNote = "Nie sprawdzano linków stronicowania."
    private var syncFailures: [String] = []
    private var syncCompleted = 0
    private var syncStartedAt = Date()
    private var syncResults: [SyncPageAudit] = []
    private var captureFailure: SyncPageStatus = .captureError
    private var captureReason = "Nie udało się odczytać strony."
    private var lastCapturePagination = false
    private var lastCaptureTruncation = false
    private var expectedNavigation: URL?
    private var pendingSyncNavigation: WKNavigation?
    private var syncEpoch = UUID() // Invalidates delayed readiness callbacks after cancellation.
    private var approvedPagesManualTicket: DirectManualRefreshTicket?
    @Published var lastReport: CaptureReport?
    @Published var lastDelta: SnapshotDelta?
    @Published var diagnosticSummary: String = "Nie wykonano odczytu diagnostycznego"
    private var downloadDestinations: [ObjectIdentifier: URL] = [:]
    private var downloadSource: [ObjectIdentifier: String] = [:]
    private var downloadNames: [ObjectIdentifier: String] = [:]
    private var downloadOwners: [ObjectIdentifier: String] = [:]
    private var downloadEpochs: [ObjectIdentifier: UUID] = [:]
    let webView: WKWebView

    override init() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: config)
        webView.allowsBackForwardNavigationGestures = true
        super.init()
        // Remove files left by an interrupted previous application process.
        try? FileManager.default.removeItem(at: directAttachmentFolder)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.delegate = self
        // Cold launch has no verified /Me identity. Remove old one-shot alerts
        // before any previous account could be presented to a different user.
        let appAlertIDs = DirectNotificationCategory.allCases.map(\.requestIdentifier)
        notificationCenter.removePendingNotificationRequests(withIdentifiers: appAlertIDs)
        notificationCenter.removeDeliveredNotifications(withIdentifiers: appAlertIDs)
        localNotificationPreferences = DirectNotificationPreferenceStorage.load()
        refreshLocalNotificationAuthorization()
    }

    /// No timer or background polling. This only invalidates local access
    /// while the app is not visible, then verifies the still-existing
    /// official WebKit session on return. It never enters a password.
    func scenePhaseChanged(to phase: ScenePhase) {
        switch phase {
        case .inactive:
            privacyShieldActive = true
        case .background:
            pendingNativeLogin = nil // Never retain a password in the background.
            nativeLoginNavigation = nil
            nativeLoginAttemptURL = nil
            if nativeLoginPhase.isBusy {
                nativeLoginPhase = .failed
                nativeLoginMessage = "Przerwano logowanie po przejściu aplikacji w tło."
            }
            privacyShieldActive = true
            // A startup /Me may still be pending while the store is locked.
            // Recheck on return even if it had not yet unlocked an account.
            let wasCheckingSession = sessionLifecycle.verificationInFlight
            sessionLifecycle.cancelVerification()
            guard !backgroundSuspended else { return }
            backgroundSuspended = true
            resumeNeedsAccountVerification = store.verifiedAccountId != nil || wasCheckingSession
            suspendVisibleAccountData()
        case .active:
            refreshLocalNotificationAuthorization()
            // A pending data/cookie purge must finish before another login.
            if sessionLifecycle.isClearing { privacyShieldActive = true; return }
            guard backgroundSuspended else {
                privacyShieldActive = false
                return
            }
            backgroundSuspended = false
            if resumeNeedsAccountVerification {
                // Keep the cover until live /Me has succeeded or failed.
                verifyAccount()
            } else {
                privacyShieldActive = false
            }
        @unknown default:
            privacyShieldActive = true
        }
    }

    private func suspendVisibleAccountData() {
        if manualRefreshRunning == .additionalJSON {
            markManualRefreshStopping(.additionalJSON)
            additionalFeedWorker?.cancel()
        }
        failedDirectReads.removeAll()
        freshDirectReads.removeAll()
        cancelCoreSync(reason: "Aplikacja przeszła w tło. Wymagana ponowna weryfikacja konta.")
        stopSync("Aplikacja przeszła w tło")
        lockDirectMessages() // Also clears drafts and downloaded message files.
        accountEpoch = UUID()
        captureEpoch = UUID()
        directGradeEpoch = UUID()
        directGradeBusy = false
        directGradeStore.lock()
        directAttendanceEpoch = UUID()
        directAttendanceBusy = false
        directAttendanceStore.lock()
        directTimetableEpoch = UUID()
        directTimetableBusy = false
        directTimetable = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        directPlanChanges = nil
        directPlanChangesStatus = "Plan wymaga ponownego odczytu po powrocie."
        directFeedEpoch = UUID()
        directFeedBusy = nil
        directFeedBatchBusy = false
        directFeedDeltas.removeAll()
        directFeeds.removeAll()
        directOfflineTimetableStore.lock()
        directOfflineFeedStore.lock()
        directFeedStatus.removeAll()
        clearDirectHomeworkFiles()
        clearDirectSchoolFiles()
        store.lock(); downloads.lock(); routes.lock(); auditStore.lock()
        isBusy = false
        accountStatus = "Aplikacja w tle — dane zablokowane do ponownego potwierdzenia konta."
    }

    /// Native sign-in uses the existing official form as the submission backend.
    /// The password is never stored, logged, or forwarded to any custom server.
    func beginNativeSchoolLogin(login: String, password: String, alternative: Bool = false) {
        guard !sessionLifecycle.isClearing, !backgroundSuspended else {
            nativeLoginPhase = .failed
            nativeLoginMessage = "Sesja jest czyszczona lub aplikacja działa w tle."
            return
        }
        if let issue = NativeSchoolLoginPolicy.validate(login: login, password: password) {
            nativeLoginPhase = .failed
            nativeLoginMessage = issue
            return
        }
        let target = alternative ? NativeSchoolLoginPolicy.secondary : NativeSchoolLoginPolicy.primary
        guard PortalPolicy.isAllowed(target), NativeSchoolLoginPolicy.canInspect(target) else {
            nativeLoginPhase = .failed
            nativeLoginMessage = "Adres formularza został zablokowany przez zasady bezpieczeństwa."
            return
        }
        pendingNativeLogin = (login, password)
        submittedNativeLogin = false
        nativeLoginFallbackUsed = false
        nativeLoginPhase = .loading
        nativeLoginMessage = "Łączenie z oficjalnym formularzem Synergii…"
        loginRestorePolicy.officialLoginOpened()
        loadNativeLoginForm(at: target)
    }

    private func loadNativeLoginForm(at address: URL) {
        nativeLoginAttemptURL = address
        nativeLoginNavigation = webView.load(URLRequest(url: address,
            cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15))
    }

    /// Retry a load that failed before the school form was submitted. If both
    /// official routes fail, show the safe network code instead of a generic
    /// message that can be mistaken for a rejected school password.
    private func recoverNativeLoginBeforeSubmission(reason: String) {
        guard pendingNativeLogin != nil else { return }
        let attempted = nativeLoginAttemptURL
        if !nativeLoginFallbackUsed,
           let alternative = NativeSchoolLoginPolicy.alternative(to: attempted),
           NativeSchoolLoginPolicy.canInspect(alternative),
           PortalPolicy.isAllowed(alternative) {
            nativeLoginFallbackUsed = true
            nativeLoginMessage = "Pierwszy formularz niedostępny (\(reason)). Sprawdzam drugi oficjalny adres…"
            nativeLoginPhase = .loading
            loadNativeLoginForm(at: alternative)
            return
        }
        pendingNativeLogin = nil
        nativeLoginNavigation = nil
        nativeLoginAttemptURL = nil
        nativeLoginPhase = .failed
        nativeLoginMessage = "Nie można otworzyć formularza Synergii (\(reason)). Hasło nie zostało wysłane. Sprawdź internet i szczegóły w diagnostyce."
    }

    private func recoverNativeLoginBeforeSubmission(_ error: Error) {
        recoverNativeLoginBeforeSubmission(reason: NativeSchoolLoginPolicy.connectionIssue(error))
    }

    func cancelNativeSchoolLogin() {
        pendingNativeLogin = nil
        nativeLoginNavigation = nil
        nativeLoginAttemptURL = nil
        submittedNativeLogin = false
        if nativeLoginPhase != .verified { nativeLoginPhase = .idle }
        nativeLoginMessage = "Przerwano próbę logowania. Hasło nie zostało zapisane."
    }

    /// Called only when WKWebView has actually loaded an allow-listed login page.
    private func submitNativeLoginFormIfPending() -> Bool {
        guard let attempt = pendingNativeLogin else { return false }
        guard NativeSchoolLoginPolicy.canInspect(webView.url) else {
            recoverNativeLoginBeforeSubmission(reason: "nieoczekiwane przekierowanie")
            return true
        }
        guard let script = NativeSchoolLoginPolicy.submissionScript(login: attempt.login, password: attempt.password) else {
            pendingNativeLogin = nil
            nativeLoginPhase = .failed
            nativeLoginMessage = "Nieprawidłowy format danych logowania."
            return true
        }
        // Keep the values only until the official form confirms whether it
        // exists. FORM_NOT_FOUND/NOT_SCHOOL_FORM cannot have submitted data and
        // may safely try the other official page once. Never retry after submit.
        nativeLoginPhase = .submitting
        nativeLoginMessage = "Przekazywanie danych do oficjalnego formularza Synergii…"
        webView.evaluateJavaScript(script) { [weak self] result, error in
            Task { @MainActor [weak self] in
                guard let self, self.nativeLoginPhase == .submitting else { return }
                guard error == nil, let code = result as? String else {
                    self.pendingNativeLogin = nil
                    self.nativeLoginNavigation = nil
                    self.nativeLoginAttemptURL = nil
                    // WebKit can cancel a JavaScript completion when form.submit
                    // starts navigation immediately. Do not declare login success;
                    // ask for the authenticated /Me response instead.
                    if self.webView.isLoading {
                        self.submittedNativeLogin = true
                        self.nativeLoginPhase = .needsVerification
                        self.nativeLoginMessage = "Sprawdź połączenie — strona rozpoczęła nawigację po wysłaniu formularza."
                    } else {
                        self.nativeLoginPhase = .failed
                        self.nativeLoginMessage = "Formularz nie przyjął automatycznego przesłania. Hasło nie jest przechowywane."
                    }
                    return
                }
                switch code {
                case "SUBMITTED":
                    self.pendingNativeLogin = nil
                    self.nativeLoginNavigation = nil
                    self.nativeLoginAttemptURL = nil
                    self.submittedNativeLogin = true
                    self.nativeLoginPhase = .needsVerification
                    self.nativeLoginMessage = "Formularz wysłany. Sprawdź sesję — samo wysłanie nie potwierdza zalogowania."
                case "NOT_SCHOOL_FORM", "FORM_NOT_FOUND", "NO_SUBMIT":
                    // The JS security policy returns these BEFORE form submission.
                    // A single attempt at the other verified login URL is safe.
                    self.recoverNativeLoginBeforeSubmission(reason: "formularz nieobsługiwany: \(code)")
                case "UNSAFE_ACTION", "UNSAFE_ORIGIN":
                    self.pendingNativeLogin = nil
                    self.nativeLoginNavigation = nil
                    self.nativeLoginAttemptURL = nil
                    self.nativeLoginPhase = .failed
                    self.nativeLoginMessage = "Zatrzymano logowanie: formularz odsyła poza zweryfikowane domeny."
                default:
                    self.pendingNativeLogin = nil
                    self.nativeLoginNavigation = nil
                    self.nativeLoginAttemptURL = nil
                    self.nativeLoginPhase = .failed
                    self.nativeLoginMessage = "Nie rozpoznano formularza szkolnego (\(code)). Hasła nie wysłano."
                }
            }
        }
        return true
    }

    /// Uses the official school-login page INSIDE this app's persistent WKWebView.
    /// Credentials are typed into the school's HTTPS form, not into app-owned fields;
    /// we never inspect, persist or forward the password or inject JavaScript into it.
    /// The only account proof is the server's /Me response after navigating back.
    func openSchoolLoginForm() {
        guard !sessionLifecycle.isClearing,
              PortalPolicy.isAllowed(DirectSynergiaEntry.schoolLoginURL) else { return }
        loginRestorePolicy.officialLoginOpened()
        status = "Otwieranie formularza szkolnego (login, nie e-mail). Wpisz dane otrzymane od szkoły."
        webView.load(URLRequest(url: DirectSynergiaEntry.schoolLoginURL,
                                cachePolicy: .reloadIgnoringLocalCacheData))
    }

    /// Backup only if the school's primary form is inaccessible. No third-party host.
    func openAlternativeSchoolLoginForm() {
        guard !sessionLifecycle.isClearing,
              PortalPolicy.isAllowed(DirectSynergiaEntry.backupSchoolLoginURL) else { return }
        loginRestorePolicy.officialLoginOpened()
        status = "Alternatywny oficjalny formularz logowania szkolnego; nie wpisuj hasła Konta LIBRUS."
        webView.load(URLRequest(url: DirectSynergiaEntry.backupSchoolLoginURL,
                                cachePolicy: .reloadIgnoringLocalCacheData))
    }

    /// Compatibility action: never send the user to the e-mail login portal.
    func openLoginPage() { openSchoolLoginForm() }

    /// Explicit return to the *school diary* in the same persistent WebKit session.
    /// Never treats the public portal or a cookie alone as proof of login.
    func openSynergiaJournal() {
        guard !sessionLifecycle.isClearing else { return }
        loginRestorePolicy.officialLoginOpened()
        status = "Otwieranie dziennika Synergia. Konto zostanie sprawdzone dopiero odpowiedzią serwera."
        webView.load(URLRequest(url: DirectSynergiaEntry.journalURL,
                                cachePolicy: .reloadIgnoringLocalCacheData))
    }

    var currentPageKind: String { DirectSynergiaEntry.origin(webView.url) }
    var isOnPublicPortal: Bool { DirectSynergiaEntry.isPublicPortal(webView.url) }

    func start() {
        guard !sessionLifecycle.isClearing, webView.url == nil else { return }
        webView.load(URLRequest(url: DirectSynergiaEntry.journalURL,
                                cachePolicy: .useProtocolCachePolicy))
    }
    func refresh() { if !sessionLifecycle.isClearing { webView.reload() } }
    func goBack() { if !sessionLifecycle.isClearing && webView.canGoBack { webView.goBack() } }
    func openTrustedLink(_ link: PortalLink) {
        guard !sessionLifecycle.isClearing else { return }
        guard let url = URL(string: link.url), PortalPolicy.isAllowed(url) else {
            alert = "Łącze prowadzi poza dozwoloną domenę. Nie otwarto go automatycznie."
            return
        }
        webView.load(URLRequest(url: url))
        status = "Otwieranie: \(link.title)"
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        sessionLifecycle.cancelVerification()
        cancelCoreSync()
        lockDirectMessages()
        // Navigation still revokes local data. Re-open it only after a trusted
        // landing and separate successful server-side /Me verification.
        if store.verifiedAccountId != nil && !isSyncing {
            recheckAfterTrustedNavigation = true
        }
        accountEpoch = UUID()
        captureEpoch = UUID()
        directFeedEpoch = UUID()
        directFeedBatchBusy = false
        directFeedDeltas.removeAll()
        clearDirectHomeworkFiles()
        clearDirectSchoolFiles()
        directFeedBusy = nil
        directFeeds.removeAll()
        directOfflineTimetableStore.lock()
        directOfflineFeedStore.lock()
        directFeedStatus.removeAll()
        isBusy = false
        store.lock(); downloads.lock(); routes.lock(); auditStore.lock()
        directAttendanceEpoch = UUID()
        directAttendanceBusy = false
        directAttendanceStore.lock()
        directTimetableEpoch = UUID()
        directTimetableBusy = false
        directTimetable = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        directPlanChanges = nil
        directPlanChangesStatus = "Nie pobierano historii zastępstw."
        accountStatus = "Nawigacja: potwierdź ponownie konto przed otwarciem zapisów"
        if !backgroundSuspended && !resumeNeedsAccountVerification { privacyShieldActive = false }
        directGradeEpoch = UUID()
        directGradeBusy = false
        directGradeStore.lock()
        directGradeStatus = "Nawigacja zmieniła sesję strony. Ponownie zweryfikuj konto przed odczytem ocen."
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        pageTitle = webView.title ?? "Synergia"
        status = "Strona otwarta: \(pageTitle)"
        if resumeNeedsAccountVerification && !backgroundSuspended {
            verifyAccount()
            return
        }
        if isSyncing && navigation === pendingSyncNavigation {
            pendingSyncNavigation = nil
            verifyIdentityForSyncPage()
            return
        }
        if pendingNativeLogin != nil, nativeLoginPhase == .loading,
           (nativeLoginNavigation == nil || navigation === nativeLoginNavigation),
           submitNativeLoginFormIfPending() { return }
        if submittedNativeLogin && nativeLoginPhase == .needsVerification,
           DirectLoginRestorePolicy.isTrustedLanding(webView.url) {
            verifyAccount()
            return
        }
        if submittedNativeLogin && nativeLoginPhase == .needsVerification,
           DirectSynergiaEntry.isPublicPortal(webView.url) {
            submittedNativeLogin = false
            nativeLoginPhase = .failed
            nativeLoginMessage = "Przekierowanie do Portalu Librus — nie ma potwierdzonego konta szkolnego."
        }
        if !isSyncing && !backgroundSuspended && !privacyShieldActive {
            let fromLogin = loginRestorePolicy.claimVerificationAfterReturn(to: webView.url)
            if fromLogin || (recheckAfterTrustedNavigation &&
                             DirectLoginRestorePolicy.isTrustedLanding(webView.url)) {
                recheckAfterTrustedNavigation = false
                verifyAccount()
            }
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as? URLError)?.code == .cancelled { return }
        status = "Błąd strony: " + DirectConnectionIssue.network(error).message
        if pendingNativeLogin != nil,
           (nativeLoginNavigation == nil || navigation === nativeLoginNavigation) {
            if nativeLoginPhase == .loading {
                recoverNativeLoginBeforeSubmission(error)
            } else if nativeLoginPhase == .submitting {
                pendingNativeLogin = nil
                nativeLoginPhase = .needsVerification
                nativeLoginMessage = "Przerwano połączenie podczas wysyłania formularza. Nie ponawiam hasła automatycznie; sprawdź sesję /Me."
            }
        }
        if isSyncing && navigation === pendingSyncNavigation {
            pendingSyncNavigation = nil
            stopSync("Błąd nawigacji: \(error.localizedDescription)")
        }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as? URLError)?.code == .cancelled { return }
        status = "Błąd połączenia: " + DirectConnectionIssue.network(error).message
        if pendingNativeLogin != nil,
           (nativeLoginNavigation == nil || navigation === nativeLoginNavigation) {
            if nativeLoginPhase == .loading {
                recoverNativeLoginBeforeSubmission(error)
            } else if nativeLoginPhase == .submitting {
                pendingNativeLogin = nil
                nativeLoginPhase = .needsVerification
                nativeLoginMessage = "Przerwano połączenie podczas wysyłania formularza. Nie ponawiam hasła automatycznie; sprawdź sesję /Me."
            }
        }
        if isSyncing && navigation === pendingSyncNavigation {
            pendingSyncNavigation = nil
            stopSync("Błąd połączenia: \(error.localizedDescription)")
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if PortalPolicy.isAllowed(url) {
            decisionHandler(action.shouldPerformDownload ? .download : .allow)
        }
        else {
            status = "Zablokowany adres poza Synergią: \(url.host ?? "nieznany")"
            if isSyncing { stopSync("Przekierowanie poza dopuszczoną domenę; synchronizacja przerwana.") }
            decisionHandler(.cancel)
        }
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        attach(download, source: navigationAction.request.url?.absoluteString ?? "")
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        attach(download, source: navigationResponse.response.url?.absoluteString ?? "")
    }

    private func attach(_ download: WKDownload, source: String) {
        let key = ObjectIdentifier(download)
        // The download is owned by the account verified when it starts.
        // Navigation, sign-out or a new account must not transfer ownership.
        if let account = downloads.verifiedAccountId, store.verifiedAccountId == account {
            downloadOwners[key] = account
            downloadEpochs[key] = accountEpoch
        }
        downloadSource[key] = source
        download.delegate = self
        status = "Pobieranie załącznika…"
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        guard let url = response.url, PortalPolicy.isAllowed(url) else {
            alert = "Pobieranie z nieznanej domeny zostało zablokowane."
            completionHandler(nil)
            return
        }
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString + ".download")
        downloadDestinations[ObjectIdentifier(download)] = dest
        downloadNames[ObjectIdentifier(download)] = suggestedFilename
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        let key = ObjectIdentifier(download)
        defer {
            downloadDestinations[key] = nil; downloadSource[key] = nil
            downloadNames[key] = nil; downloadOwners[key] = nil; downloadEpochs[key] = nil
        }
        guard let url = downloadDestinations[key] else { return }
        defer { try? FileManager.default.removeItem(at: url) }
        do {
            guard let owner = downloadOwners[key], let originalEpoch = downloadEpochs[key],
                  accountEpoch == originalEpoch,
                  downloads.verifiedAccountId == owner, store.verifiedAccountId == owner else {
                status = "Pobrany plik odrzucono: sesja lub konto zmieniły się w trakcie pobierania."
                return
            }
            let source = downloadSource[key] ?? ""
            let saved = try downloads.importDownload(from: url,
                suggestedFilename: downloadNames[key] ?? "załącznik",
                sourceURL: source)
            status = "Pobrano: \(saved.displayName)"
            dataRevision += 1
        } catch {
            alert = "Nie udało się zapisać pobranego pliku: \(error.localizedDescription)"
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        let key = ObjectIdentifier(download)
        if let url = downloadDestinations[key] { try? FileManager.default.removeItem(at: url) }
        downloadDestinations[key] = nil
        downloadSource[key] = nil
        downloadNames[key] = nil
        downloadOwners[key] = nil
        downloadEpochs[key] = nil
        alert = "Pobieranie nie powiodło się: \(error.localizedDescription)"
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // Keep legitimate target=_blank links inside the same WebKit session.
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url,
           PortalPolicy.isAllowed(url) { webView.load(URLRequest(url: url)) }
        return nil
    }

    /// Explicit single-page read. No scraping loop, session credential access, or undocumented API.
    func capture(_ module: SchoolModule) {
        guard store.verifiedAccountId != nil else {
            alert = "Najpierw zweryfikuj konto przyciskiem «Potwierdź konto»."
            return
        }
        capturePage(module, commit: true) { _, _ in }
    }

    private func capturePage(_ module: SchoolModule, commit: Bool = true, completion: @escaping (Bool, ModuleSnapshot?) -> Void) {
        guard !isBusy, let currentURL = webView.url,
              DirectSynergiaEntry.isDiaryModuleURL(currentURL, messages: module == .messages) else {
            alert = "Odczyt strony informacyjnej Librusa nie jest odczytem modułu Synergii. " +
                    "Przejdź do szkolnego dziennika i otwórz właściwą zakładkę."
            completion(false, nil)
            return
        }
        guard let capturedAccount = store.verifiedAccountId else {
            alert = "Najpierw zweryfikuj konto."
            completion(false, nil)
            return
        }
        let capturedEpoch = accountEpoch
        let capturedSyncEpoch = syncEpoch
        let readEpoch = UUID()
        captureEpoch = readEpoch
        captureFailure = .captureError
        captureReason = "Nie udało się odczytać strony."
        lastCapturePagination = false
        lastCaptureTruncation = false
        isBusy = true
        selectedModule = module
        let js = #"""
        (() => {
          const clean = s => String(s || '').replace(/\s+/g,' ').trim().slice(0,600);
          const allowed = u => { try { const v = new URL(u, location.href); return v.protocol === 'https:' && (v.hostname === 'librus.pl' || v.hostname.endsWith('.librus.pl')); } catch(e) { return false; } };
          const allTables = Array.from(document.querySelectorAll('table'));
          const tables = allTables.slice(0,40).map(table => ({
            caption: clean(table.querySelector('caption')?.innerText || ''),
            rows: Array.from(table.querySelectorAll('tr')).slice(0,1000).map(tr =>
              Array.from(tr.querySelectorAll('th,td')).map(c => clean(c.innerText)))
              .filter(a => a.some(Boolean)),
            rowLinks: Array.from(table.querySelectorAll('tr')).slice(0,1000)
              .filter(tr => Array.from(tr.querySelectorAll('th,td')).some(c => clean(c.innerText)))
              .map(tr => Array.from(tr.querySelectorAll('a[href]'))
                .filter(a => allowed(a.href))
                .slice(0,12)
                .map(a => ({title: clean(a.innerText || a.getAttribute('title') || a.getAttribute('aria-label') || ''), url:a.href})))
          }));
          const allRows = Array.from(document.querySelectorAll('table tr'));
          const rows = allRows
            .map(tr => Array.from(tr.querySelectorAll('th,td')).map(c => clean(c.innerText)))
            .filter(a => a.some(Boolean)).slice(0,1000);
          const allLinks = Array.from(document.querySelectorAll('a[href]'));
          const links = allLinks
            .filter(a => allowed(a.href))
            .map(a => ({title: clean(a.innerText || a.getAttribute('title') || a.download), url:a.href}))
            .filter(a => a.title.length > 0).slice(0,250);
          const paginationAnchors = Array.from(document.querySelectorAll(
            '.pagination a[href], [aria-label*="pagination" i] a[href], a[rel="next"], a[rel="prev"], a[aria-label*="następna" i], a[aria-label*="next" i]'));
          const paginationLinks = paginationAnchors.slice(0,21).map(a => a.href).filter(allowed);
          const heading = clean(Array.from(document.querySelectorAll('h1,h2,.page-header'))
            .map(x => x.innerText).join(' '));
          const body = clean((document.querySelector('main,[role="main"],#content,.container') || document.body).innerText).slice(0,600);
          return JSON.stringify({title: clean(document.title), url: location.href, heading, rows, tables, links, excerpt:body,
            loginFormPresent: !!document.querySelector('input[type="password"]'),
            documentReady: document.readyState === 'complete',
            tableCount: document.querySelectorAll('table').length, paginationLinks,
            isTruncated: allRows.length > 1000 || allLinks.length > 250 || allTables.length > 40 || paginationAnchors.length > 20 || allTables.some(t => t.querySelectorAll('tr').length > 1000),
            hasPagination: !!document.querySelector('[aria-label*="pagination" i],.pagination,[rel="next"],a[aria-label*="następna" i],a[aria-label*="next" i]')});
        })()
        """#
        webView.evaluateJavaScript(js) { [weak self] result, error in
            Task { @MainActor [weak self] in
                guard let self else { return }
                // An older callback cannot unlock or overwrite a newer capture.
                guard self.captureEpoch == readEpoch else { completion(false, nil); return }
                guard self.accountEpoch == capturedEpoch,
                      self.store.verifiedAccountId == capturedAccount,
                      self.webView.url == currentURL,
                      self.syncEpoch == capturedSyncEpoch else {
                    self.isBusy = false
                    completion(false, nil)
                    return
                }
                self.isBusy = false
                if let error {
                    self.alert = "Nie udało się odczytać strony: \(error.localizedDescription)"
                    completion(false, nil)
                    return
                }
                guard let raw = result as? String, let data = raw.data(using: .utf8),
                      let captured = try? JSONDecoder().decode(PageCapture.self, from: data) else {
                    self.alert = "Nie rozpoznano struktury bieżącej strony."
                    completion(false, nil)
                    return
                }
                guard captured.documentReady == true else {
                    self.captureFailure = .rejectedPartial
                    self.captureReason = "Strona nie zakończyła ładowania."
                    self.alert = "Strona nie zakończyła ładowania. Nie nadpisano wcześniejszego odczytu."
                    completion(false, nil)
                    return
                }
                guard captured.loginFormPresent != true else {
                    self.captureFailure = .loginRequired
                    self.captureReason = "Wykryto formularz logowania."
                    self.alert = "Strona zawiera formularz hasła. Nie zapisano danych — wymagane logowanie."
                    completion(false, nil)
                    return
                }
                guard captured.url == currentURL.absoluteString else {
                    self.captureFailure = .navigationError
                    self.captureReason = "Adres strony zmienił się podczas odczytu."
                    self.alert = "Strona zmieniła adres w trakcie odczytu. Przerwano zapis."
                    completion(false, nil)
                    return
                }
                self.diagnosticSummary = StructuralDiagnostics.from(captured).formatted()
                self.lastCapturePagination = captured.hasPagination == true
                let suggested = captured.paginationLinks ?? []
                let approvedURLs = self.routes.pages(for: module).map(\.url)
                let paginationAudit = PaginationInspector.audit(observed: suggested,
                    approved: approvedURLs, origin: captured.url)
                self.paginationNote = "Wykryte odnośniki stron: \(paginationAudit.discoveredCount); brak zatwierdzenia: \(paginationAudit.missingApprovalCount); nieprawidłowe: \(paginationAudit.invalidCount). To nie gwarantuje kompletności danych."
                if self.isSyncing { self.batchPaginationLinks.append(contentsOf: suggested) }
                self.lastCaptureTruncation = captured.isTruncated == true
                let warnings = CaptureAnalyzer.validate(captured, for: module)
                guard captured.isTruncated != true && (commit ? captured.hasPagination != true : true) else {
                    self.captureFailure = .rejectedPartial
                    self.captureReason = "Wykryto stronicowanie albo limit odczytu."
                    self.alert = "Wynik może być niekompletny (stronicowanie lub limit odczytu). Nie zastąpiono poprzednich danych."
                    completion(false, nil)
                    return
                }
                guard !warnings.contains(where: { $0.hasPrefix("Nagłówek lub adres") }) else {
                    self.captureFailure = .wrongModule
                    self.captureReason = "Nie potwierdzono tożsamości modułu."
                    self.alert = "Aktualna strona nie została rozpoznana jako «\(module.title)». Przejdź do tego modułu w Synergii i spróbuj ponownie."
                    completion(false, nil)
                    return
                }
                guard !captured.rows.isEmpty || !captured.links.isEmpty || !captured.excerpt.isEmpty else {
                    self.captureReason = "Brak czytelnych danych na stronie."
                    self.alert = "Brak danych możliwych do odczytania na obecnej stronie."
                    completion(false, nil)
                    return
                }
                let snapshot = ModuleSnapshot(module: module, capturedAt: Date(),
                    title: captured.title, sourceURL: captured.url,
                    records: captured.rows.map { PortalRecord(fields: $0) },
                    links: captured.links.map { PortalLink(title: $0.title, url: $0.url) },
                    excerpt: captured.excerpt, tables: captured.tables)
                do {
                    if commit {
                        guard self.store.verifiedAccountId != nil else {
                            self.alert = "Zmieniła się sesja. Odczyt odrzucony."
                            completion(false, nil)
                            return
                        }
                        let previous = self.store.snapshot(for: module)
                        let delta = previous.map { SnapshotComparator.compare(previous: $0, current: snapshot) }
                        try self.store.save(snapshot)
                        self.lastDelta = delta
                        self.lastReport = CaptureReport(module: module, sourceTitle: captured.title,
                            sourceURL: captured.url, rowCount: captured.rows.count,
                            linkCount: captured.links.count, warnings: warnings)
                        self.dataRevision += 1
                        self.status = "Zapisano pojedynczy odczyt «\(module.title)». Kompletność niezweryfikowana."
                    }
                    completion(true, snapshot)
                } catch {
                    self.captureReason = "Zapis lokalny nie powiódł się."
                    self.alert = "Odczyt wykonano, ale zapis lokalny nie powiódł się: \(error.localizedDescription)"
                    completion(false, nil)
                }
            }
        }
    }

    /// The user explicitly saves a module URL while looking at its genuine page.
    func rememberCurrentModule(_ module: SchoolModule) {
        guard let url = webView.url,
              DirectSynergiaEntry.isDiaryModuleURL(url, messages: module == .messages) else {
            alert = "Nie można zapamiętać strony Portalu Librus jako modułu. " +
                    "Otwórz właściwy dziennik Synergia i wejdź do wybranego modułu."
            return
        }
        // A successful diagnostic capture must precede route approval, to avoid
        // accidentally bookmarking the sign-in screen as a school module.
        let owner = routes.verifiedAccountId
        let epoch = accountEpoch
        capturePage(module, commit: false) { [weak self] ok, _ in
            guard let self, ok, self.accountEpoch == epoch,
                  self.routes.verifiedAccountId == owner, owner != nil else { return }
            do {
                try self.routes.remember(module: module, pageURL: url)
                self.status = "Zapamiętano lokalny adres modułu: \(module.title)."
            } catch { self.alert = error.localizedDescription }
        }
    }

    /// Authorize another page only after it is opened and the chosen module is recognized.
    func rememberAdditionalPage(_ module: SchoolModule) {
        guard !isSyncing, let currentURL = webView.url,
              DirectSynergiaEntry.isDiaryModuleURL(currentURL, messages: module == .messages) else {
            alert = "Dodatkowa strona musi należeć do danego modułu dziennika Synergia, nie do Portalu Librus."
            return
        }
        guard routes.route(for: module) != nil else {
            alert = "Najpierw zapamiętaj główny adres modułu."
            return
        }
        // Do not overwrite the existing snapshot merely to approve another URL.
        let owner = routes.verifiedAccountId
        let epoch = accountEpoch
        capturePage(module, commit: false) { [weak self] accepted, _ in
            guard let self, accepted, self.accountEpoch == epoch,
                  self.routes.verifiedAccountId == owner, owner != nil else { return }
            do { try self.routes.appendPage(module: module, pageURL: currentURL)
                self.status = "Zatwierdzono dodatkową stronę dla «\(module.title)»."
            } catch { self.alert = error.localizedDescription }
        }
    }

    /// Foreground-only sequence. Runs when user explicitly taps Synchronizuj.
    /// It never fetches arbitrary endpoints or silently follows third-party redirects.
    func syncApprovedModules() {
        guard !isSyncing && !isBusy else { return }
        // Do not synchronize bookmarks from an unverified or stale account.
        guard let account = store.verifiedAccountId,
              routes.verifiedAccountId == account,
              downloads.verifiedAccountId == account,
              auditStore.verifiedAccountId == account else {
            alert = "Najpierw potwierdź konto Synergii przed synchronizacją."
            return
        }
        let approved = SchoolModule.allCases.filter { routes.route(for: $0) != nil }
        guard !approved.isEmpty else {
            alert = "Nie zapisano żadnych adresów modułów. Najpierw otwórz i zapamiętaj każdy moduł w Synergii."
            return
        }
        guard let ticket = startManualRefresh(.approvedPages, owner: account) else { return }
        approvedPagesManualTicket = ticket
        // An in-progress navigation can otherwise complete during the first sync step.
        webView.stopLoading()
        syncEpoch = UUID()
        syncAccountId = account
        syncQueue = approved
        syncFailures = []
        syncCompleted = 0
        syncStartedAt = Date()
        syncResults = []
        pendingPages = []
        pageOffset = 0
        batchSawPagination = false
        batchPaginationLinks = []
        isSyncing = true
        syncSummary = "Rozpoczęto: 0/\(approved.count)"
        openNextSyncPage()
    }

    func stopSync(_ reason: String = "Przerwano przez użytkownika") {
        guard isSyncing else { return }
        if manualRefreshRunning == .approvedPages { markManualRefreshStopping(.approvedPages) }
        let remaining = syncQueue.filter { module in !syncResults.contains(where: { $0.module == module }) }
        for module in remaining {
            syncResults.append(SyncPageAudit(module: module, status: .interrupted,
                checkedAt: Date(), storedRows: 0, detectedPagination: false,
                clippedByLimit: false, explanation: "Przerwano synchronizację."))
        }
        syncEpoch = UUID()
        isSyncing = false
        webView.stopLoading()
        pendingPages = []
        pageOffset = 0
        batchSawPagination = false
        batchPaginationLinks = []
        syncQueue = []
        expectedNavigation = nil
        pendingSyncNavigation = nil
        finishAudit(interrupted: true)
        syncAccountId = nil
        syncSummary = "\(reason). Zapisano \(syncCompleted) modułów. \(syncFailures.joined(separator: "; "))"
        if let ticket = approvedPagesManualTicket {
            approvedPagesManualTicket = nil
            completeManualRefresh(ticket)
        }
    }

    private func openNextSyncPage() {
        guard isSyncing else { return }
        guard let module = syncQueue.first else {
            isSyncing = false
            expectedNavigation = nil
            pendingSyncNavigation = nil
            pendingPages = []
            pageOffset = 0
            batchSawPagination = false
            batchPaginationLinks = []
            finishAudit(interrupted: false)
            syncAccountId = nil
            syncSummary = "Zakończono. Zapisano \(syncCompleted) modułów; błędy: \(syncFailures.count). Kompletność danych niezweryfikowana."
            if let ticket = approvedPagesManualTicket {
                approvedPagesManualTicket = nil
                completeManualRefresh(ticket)
            }
            return
        }
        let approvedPages = routes.pages(for: module)
        guard pageOffset < approvedPages.count,
              let url = URL(string: approvedPages[pageOffset].url),
              DirectSynergiaEntry.isDiaryModuleURL(url, messages: module == .messages) else {
            syncFailures.append("\(module.title): błędny adres")
            syncResults.append(SyncPageAudit(module: module, status: .navigationError,
                checkedAt: Date(), storedRows: 0, detectedPagination: false,
                clippedByLimit: false, explanation: "Błędny zapamiętany adres."))
            batchPaginationLinks = []
            syncQueue.removeFirst()
            openNextSyncPage()
            return
        }
        selectedModule = module
        expectedNavigation = url
        status = "Synchronizuję: \(module.title), strona \(pageOffset + 1)/\(approvedPages.count)"
        pendingSyncNavigation = webView.load(URLRequest(url: url))
    }

    /// Verify the live account after every navigation. A changed account aborts
    /// the entire batch, rather than persisting a mixture of users' pages.
    private func verifyIdentityForSyncPage() {
        guard isSyncing else { return }
        let epoch = syncEpoch
        let navEpoch = accountEpoch
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                let identity = try DirectAccountIdentity.parse(
                    (try await SynergiaGatewayClient(webView: self.webView).read(.me)).json)
                guard self.isSyncing && self.syncEpoch == epoch && self.accountEpoch == navEpoch else { return }
                if let established = self.syncAccountId, established != identity.id {
                    self.stopSync("Konto zmienione podczas synchronizacji; nie zapisano kolejnych modułów.")
                    return
                }
                self.syncAccountId = identity.id
                self.directOfflineFeedStore.unlock(accountId: identity.id)
                self.directOfflineTimetableStore.unlock(accountId: identity.id)
                self.directFeeds = self.directOfflineFeedStore.feeds
                self.freshDirectReads.subtract(DirectOfflineFeedCache.modules)
                for (module, feed) in self.directFeeds {
                    self.directFeedStatus[module] = "Wcześniejszy zapis (NIEAKTUALNY): \(feed.records.count) wpisów."
                }
                self.directAttendanceStore.unlock(accountId: identity.id)
                self.directGradeStore.unlock(accountId: identity.id)
                self.store.unlock(accountId: identity.id)
                self.downloads.unlock(accountId: identity.id)
                self.routes.unlock(accountId: identity.id)
                self.auditStore.unlock(accountId: identity.id)
                self.accountStatus = "Konto potwierdzone dla tej strony synchronizacji"
                self.selectCachedTimetableWeek()
                self.waitForStableSyncPage()
            } catch {
                guard self.isSyncing && self.syncEpoch == epoch else { return }
                self.stopSync("Nie można zweryfikować konta podczas synchronizacji.")
            }
        }
    }

    /// A finished navigation is not proof that client-side tables have finished rendering.
    /// Observe DOM mutations only on the currently approved page, without fetching extra URLs.
    private func waitForStableSyncPage() {
        guard isSyncing, let module = syncQueue.first,
              let wanted = expectedNavigation, webView.url == wanted else {
            stopSync("Zmiana strony przed analizą gotowości — poprzednie dane bez zmian.")
            return
        }
        let epoch = syncEpoch
        status = "Czekam na stabilizację strony: \(module.title)"
        webView.callAsyncJavaScript(PageReadiness.script, arguments: [:], in: nil, in: .page) { [weak self] result in
            Task { @MainActor [weak self] in
                guard let self, self.isSyncing, self.syncEpoch == epoch,
                      self.syncQueue.first == module, self.webView.url == wanted else { return }
                switch result {
                case .success(let value):
                    guard let outcome = value as? String, outcome == "stable" else {
                        self.captureFailure = .rejectedPartial
                        self.captureReason = "Dynamiczny dokument nie osiągnął stabilności."
                        self.rejectUnstablePage(module: module, detail: "Upłynął limit oczekiwania na stabilizację DOM.")
                        return
                    }
                    self.finishSynchronizedPage()
                case .failure:
                    self.captureFailure = .captureError
                    self.captureReason = "Błąd obserwacji dynamicznego dokumentu."
                    self.rejectUnstablePage(module: module, detail: "Nie powiodła się obserwacja zmian DOM.")
                }
            }
        }
    }

    private func rejectUnstablePage(module: SchoolModule, detail: String) {
        syncFailures.append(module.title)
        syncResults.append(SyncPageAudit(module: module, status: captureFailure,
            checkedAt: Date(), storedRows: 0, detectedPagination: false,
            clippedByLimit: false,
            explanation: "Nie zapisano modułu: \(detail) Poprzedni odczyt bez zmian."))
        pendingPages = []
        pageOffset = 0
        batchSawPagination = false
        batchPaginationLinks = []
        syncQueue.removeFirst()
        openNextSyncPage()
    }

    private func finishSynchronizedPage() {
        guard isSyncing, !isBusy, let module = syncQueue.first,
              let wanted = expectedNavigation, let actual = webView.url else { return }
        guard PortalPolicy.isAllowed(actual), actual == wanted else {
            stopSync("Nieoczekiwane przekierowanie — poprzednie dane pozostały bez zmian")
            return
        }
        let capturedSyncEpoch = syncEpoch
        let capturedAccountEpoch = accountEpoch
        let capturedOwner = syncAccountId
        let capturedPageOffset = pageOffset
        expectedNavigation = nil
        capturePage(module, commit: false) { [weak self] success, candidate in
            guard let self, self.isSyncing,
                  self.syncEpoch == capturedSyncEpoch,
                  self.accountEpoch == capturedAccountEpoch,
                  self.syncQueue.first == module,
                  self.pageOffset == capturedPageOffset,
                  let capturedOwner,
                  self.store.verifiedAccountId == capturedOwner,
                  self.auditStore.verifiedAccountId == capturedOwner else { return }
            guard success, let candidate else {
                self.syncFailures.append(module.title)
                self.syncResults.append(SyncPageAudit(module: module,
                    status: self.captureFailure, checkedAt: Date(), storedRows: 0,
                    detectedPagination: self.lastCapturePagination,
                    clippedByLimit: self.lastCaptureTruncation,
                    explanation: "Nie zaakceptowano strony \(self.pageOffset + 1). Dane modułu nie zostały nadpisane. \(self.captureReason)"))
                self.pendingPages = []
                self.pageOffset = 0
                self.batchSawPagination = false
                self.batchPaginationLinks = []
                self.syncQueue.removeFirst()
                self.openNextSyncPage()
                return
            }
            self.pendingPages.append(candidate)
            self.batchSawPagination = self.batchSawPagination || self.lastCapturePagination
            self.pageOffset += 1
            if self.pageOffset < self.routes.pages(for: module).count {
                self.openNextSyncPage()
                return
            }
            let pages = self.pendingPages
            let paginationAudit = PaginationInspector.audit(observed: self.batchPaginationLinks,
                approved: self.routes.pages(for: module).map(\.url), origin: pages[0].sourceURL)
            let requiresAdditionalApproval = self.batchSawPagination && pages.count == 1
            self.pendingPages = []
            self.pageOffset = 0
            self.batchSawPagination = false
            self.batchPaginationLinks = []
            do {
                if paginationAudit.hasUnapprovedPages { throw MergeError.incompleteApproval }
                if requiresAdditionalApproval { throw MergeError.incompleteApproval }
                let integrity = BatchIntegrityAudit.inspect(pages, module: module)
                guard integrity.accepted else { throw MergeError.incompleteApproval }
                let combined = try MultiPageMerger.merge(pages, module: module)
                let previous = self.store.snapshot(for: module)
                try self.store.save(combined) // One atomic file replacement per module.
                self.lastDelta = previous.map { SnapshotComparator.compare(previous: $0, current: combined) }
                self.dataRevision += 1
                self.syncCompleted += 1
                self.syncResults.append(SyncPageAudit(module: module, status: .savedPage,
                    checkedAt: Date(), storedRows: combined.records.count,
                    detectedPagination: pages.count > 1,
                    clippedByLimit: false,
                    explanation: "Zapisano atomowo \(pages.count) zatwierdzonych stron. Nie gwarantuje to wszystkich stron serwisu."))
            } catch {
                self.syncFailures.append(module.title)
                self.syncResults.append(SyncPageAudit(module: module, status: .rejectedPartial,
                    checkedAt: Date(), storedRows: 0, detectedPagination: pages.count > 1,
                    clippedByLimit: false, explanation: "Nie udało się scalić lub zapisać danych; poprzedni zapis bez zmian."))
            }
            self.syncQueue.removeFirst()
            self.syncSummary = "Zapisano modułów: \(self.syncCompleted), pozostało: \(self.syncQueue.count)"
            self.openNextSyncPage()
        }
    }

    private func finishAudit(interrupted: Bool) {
        let run = SyncRunAudit(startedAt: syncStartedAt, finishedAt: Date(),
            pages: syncResults, interrupted: interrupted)
        // A report belongs only to the account verified throughout the run.
        guard let account = syncAccountId,
              store.verifiedAccountId == account,
              auditStore.verifiedAccountId == account else { return }
        do { try auditStore.save(run) }
        catch { alert = "Nie udało się zapisać lokalnego raportu synchronizacji." }
    }

    func signOutAndClear() {
        // Ignore duplicate taps and block session restoration during async purge.
        guard sessionLifecycle.beginCleanup() else { return }
        privacyShieldActive = true
        if manualRefreshRunning == .additionalJSON {
            markManualRefreshStopping(.additionalJSON)
            additionalFeedWorker?.cancel()
        }
        cancelCoreSync()
        UNUserNotificationCenter.current().removeAllDeliveredNotifications()
        lockDirectMessages()
        notificationAuthorizationGate.cancel()
        notificationDebouncer.reset()
        notificationAccountGate.reset()
        DirectNotificationOwnerKeychain.clear()
        localNotificationPreferences = DirectNotificationPreferences()
        DirectNotificationPreferenceStorage.clear()
        localNotificationsEnabled = false
        localNotificationsStatus = "Powiadomienia lokalne wyłączone po usunięciu danych."
        resumeNeedsAccountVerification = false
        loginRestorePolicy.cancelPendingReturn()
        recheckAfterTrustedNavigation = false
        // Także dane JSON wyłącznie w pamięci muszą zniknąć natychmiast.
        directFeedEpoch = UUID()
        directFeedBatchBusy = false
        directFeedDeltas.removeAll()
        clearDirectHomeworkFiles()
        clearDirectSchoolFiles()
        directFeedBusy = nil
        directFeeds.removeAll()
        directOfflineTimetableStore.lock()
        directOfflineFeedStore.lock()
        directFeedStatus.removeAll()
        stopSync("Wylogowano lokalnie")
        accountEpoch = UUID()
        captureEpoch = UUID()
        directAttendanceEpoch = UUID()
        directAttendanceBusy = false
        directAttendanceStore.lock()
        directTimetableEpoch = UUID()
        directTimetableBusy = false
        directTimetable = nil
        directTimetableSubjects.removeAll()
        directTimetableTeachers.removeAll()
        directPlanChanges = nil
        directPlanChangesStatus = "Nie pobierano historii zastępstw."
        store.lock(); downloads.lock(); routes.lock(); auditStore.lock()
        pendingNativeLogin = nil
        submittedNativeLogin = false
        nativeLoginPhase = .idle
        accountStatus = "Konto wylogowane — dane lokalne zablokowane"
        directGradeEpoch = UUID() // invalidate in-flight JSON reads
        directGradeBusy = false
        isBusy = true
        webView.configuration.websiteDataStore.removeData(
            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast
        ) { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                do {
                    try self.store.erase()
                    try self.directGradeStore.erase()
                    try self.directAttendanceStore.erase()
                    try self.directOfflineFeedStore.erase()
                    try self.directOfflineTimetableStore.erase()
                    self.directAttendanceStatus = "Usunięto lokalną frekwencję JSON"
                    self.directGradeStatus = "Usunięto lokalne oceny JSON"
                    try self.downloads.erase()
                    try self.routes.erase()
                    try self.auditStore.erase()
                    self.lastReport = nil
                    self.lastDelta = nil
                    self.diagnosticSummary = "Nie wykonano odczytu diagnostycznego"
                    self.dataRevision += 1
                }
                catch { self.alert = "Nie udało się usunąć wszystkich lokalnych danych: \(error.localizedDescription)" }
                self.webView.loadHTMLString("", baseURL: nil)
                self.isBusy = false
                self.status = "Usunięto cookies WebKit i podjęto próbę wyczyszczenia lokalnych danych. Nie jest to wylogowanie z serwera."
                self.sessionLifecycle.finishCleanup()
                if !self.backgroundSuspended { self.privacyShieldActive = false }
            }
        }
    }

    // MARK: - One account-scoped, manually triggered core JSON synchronization

    /// Refreshes the *actual* iOS authorization status at startup, foreground
    /// return and on explicit request. A saved switch alone never grants permission.
    func refreshLocalNotificationAuthorization() {
        // A persisted toggle alone never authorizes another account after restart.
        guard DirectNotificationOwnerPolicy.mayActivate(
            preferences: localNotificationPreferences,
            boundAccount: DirectNotificationOwnerKeychain.read(),
            verifiedAccount: store.verifiedAccountId) else {
            localNotificationsEnabled = false
            if !localNotificationPreferences.enabled {
                localNotificationsStatus = "Powiadomienia wyłączone. Włącz je po weryfikacji konta."
            } else {
                localNotificationsStatus = "Zgoda wymaga weryfikacji tego samego konta."
            }
            return
        }
        // The system permission prompt may briefly change ScenePhase; do not
        // invalidate its own pending completion with a foreground refresh.
        guard let ticket = notificationAuthorizationGate.beginStatusCheck() else { return }
        UNUserNotificationCenter.current().getNotificationSettings { [weak self] settings in
            Task { @MainActor [weak self] in
                guard let self, self.notificationAuthorizationGate.acceptStatusCheck(ticket) else { return }
                let allowed = settings.authorizationStatus == .authorized ||
                    settings.authorizationStatus == .provisional
                self.localNotificationsEnabled = self.localNotificationPreferences.enabled && allowed
                if self.localNotificationPreferences.enabled && !allowed {
                    // Permission revoked in iOS Settings. Fail closed until user opts in again.
                    self.localNotificationPreferences.enabled = false
                    DirectNotificationOwnerKeychain.clear()
                    DirectNotificationPreferenceStorage.save(self.localNotificationPreferences)
                    self.notificationDispatchGate.invalidate()
                    UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
                    UNUserNotificationCenter.current().removeAllDeliveredNotifications()
                }
                self.localNotificationsStatus = self.localNotificationsEnabled
                    ? "Włączone: wybrane kategorie, tylko po ręcznej synchronizacji."
                    : "Wyłączone lub brak zgody iOS. Sprawdź uprawnienia w Ustawieniach systemu."
            }
        }
    }

    func setLocalNotifications(_ enabled: Bool) {
        if !enabled {
            notificationDispatchGate.invalidate()
            notificationAuthorizationGate.cancel()
            DirectNotificationOwnerKeychain.clear()
            localNotificationPreferences.enabled = false
            DirectNotificationPreferenceStorage.save(localNotificationPreferences)
            localNotificationsEnabled = false
            localNotificationsStatus = "Powiadomienia lokalne wyłączone."
            UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
            UNUserNotificationCenter.current().removeAllDeliveredNotifications()
            notificationDebouncer.reset()
            return
        }
        guard let verifiedOwner = store.verifiedAccountId, !backgroundSuspended,
              !privacyShieldActive else {
            localNotificationsStatus = "Najpierw zweryfikuj konto w Synergii."
            return
        }
        let ownerEpoch = accountEpoch
        let ticket = notificationAuthorizationGate.beginUserRequest()
        localNotificationsStatus = "Oczekiwanie na zgodę iOS…"
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] granted, error in
            Task { @MainActor [weak self] in
                guard let self, self.notificationAuthorizationGate.acceptUserRequest(ticket) else { return }
                guard DirectNotificationPromptPolicy.canBind(
                    verifiedOwner: verifiedOwner,
                    currentVerifiedOwner: self.store.verifiedAccountId,
                    accountEpochUnchanged: self.accountEpoch == ownerEpoch,
                    enteredBackground: self.backgroundSuspended) else {
                    self.localNotificationsEnabled = false
                    self.localNotificationPreferences.enabled = false
                    DirectNotificationPreferenceStorage.save(self.localNotificationPreferences)
                    self.localNotificationsStatus = "Sesja zmieniła się podczas pytania o zgodę. Włącz ponownie."
                    return
                }
                let bound = granted && error == nil && DirectNotificationOwnerKeychain.bind(verifiedOwner)
                self.localNotificationsEnabled = bound
                self.localNotificationPreferences.enabled = bound
                DirectNotificationPreferenceStorage.save(self.localNotificationPreferences)
                self.localNotificationsStatus = bound
                    ? "Włączone: wybrane kategorie, tylko po ręcznej synchronizacji."
                    : "Nie uzyskano zgody iOS lub nie udało się bezpiecznie zapisać ustawień."
            }
        }
    }

    func setLocalNotificationCategory(_ kind: DirectNotificationCategory, enabled: Bool) {
        // Invalidate any OS add that started before this preference change.
        notificationDispatchGate.invalidate()
        localNotificationPreferences.set(kind, enabled: enabled)
        DirectNotificationPreferenceStorage.save(localNotificationPreferences)
        if !enabled {
            let center = UNUserNotificationCenter.current()
            center.removePendingNotificationRequests(withIdentifiers: [kind.requestIdentifier])
            center.removeDeliveredNotifications(withIdentifiers: [kind.requestIdentifier])
        }
    }

    private func cancelCoreSync(reason: String = "Wspólny odczyt przerwany wskutek zmiany sesji.") {
        notificationDispatchGate.invalidate()
        if manualRefreshRunning == .coreJSON { markManualRefreshStopping(.coreJSON) }
        coreSyncEpoch = UUID()
        coreSyncWorker?.cancel()
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        coreSyncBusy = false
        coreSyncChanges = nil
        coreSyncEvidenceSummary = "Brak wiarygodnego wyniku porównania."
        coreSyncStatus = reason
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let notificationID = notification.request.identifier
        Task { @MainActor [weak self] in
            guard let self, self.localNotificationsEnabled,
                  !self.backgroundSuspended, !self.privacyShieldActive,
                  let owner = self.store.verifiedAccountId,
                  DirectNotificationOwnerPolicy.mayActivate(
                    preferences: self.localNotificationPreferences,
                    boundAccount: DirectNotificationOwnerKeychain.read(),
                    verifiedAccount: owner),
                  DirectNotificationCategory.allCases.contains(where: {
                    $0.requestIdentifier == notificationID &&
                    self.localNotificationPreferences.permits($0)
                  }) else {
                // Even a late OS delivery must remain silent after logout,
                // disabled consent, disabled category or account replacement.
                completionHandler([])
                return
            }
            completionHandler([.banner, .sound])
        }
    }

    private func deliverCoreNotifications(_ plan: CoreLocalNotificationPlan) {
        guard localNotificationsEnabled, !backgroundSuspended, !privacyShieldActive,
              let owner = store.verifiedAccountId else { return }
        let requested = localNotificationPreferences.categories(from: plan)
        guard !requested.isEmpty else { return }
        // Recheck system authorization immediately before scheduling. The
        // callback may arrive after logout, app backgrounding or account change.
        let syncTicket = coreSyncEpoch
        let accountTicket = accountEpoch
        let permissionTicket = notificationAuthorizationGate.generation
        let dispatchEpoch = notificationDispatchGate.epoch
        UNUserNotificationCenter.current().getNotificationSettings { [weak self] settings in
            Task { @MainActor [weak self] in
                guard let self,
                      self.localNotificationsEnabled,
                      !self.backgroundSuspended, !self.privacyShieldActive,
                      self.coreSyncEpoch == syncTicket,
                      self.accountEpoch == accountTicket,
                      self.notificationAuthorizationGate.generation == permissionTicket,
                      self.notificationDispatchGate.epoch == dispatchEpoch,
                      !self.notificationAuthorizationGate.requestInProgress,
                      self.store.verifiedAccountId == owner,
                      DirectNotificationOwnerPolicy.mayActivate(
                        preferences: self.localNotificationPreferences,
                        boundAccount: DirectNotificationOwnerKeychain.read(),
                        verifiedAccount: owner) else { return }
                let allowed = settings.authorizationStatus == .authorized ||
                    settings.authorizationStatus == .provisional
                guard allowed else {
                    self.localNotificationsEnabled = false
                    self.localNotificationPreferences.enabled = false
                    DirectNotificationOwnerKeychain.clear()
                    DirectNotificationPreferenceStorage.save(self.localNotificationPreferences)
                    self.notificationDispatchGate.invalidate()
                    UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
                    UNUserNotificationCenter.current().removeAllDeliveredNotifications()
                    self.localNotificationsStatus = "Zgoda iOS wygasła — powiadomienia wyłączone."
                    return
                }
                let candidates = requested.filter {
                    self.localNotificationPreferences.permits($0) &&
                    !self.notificationDispatchGate.isPending($0)
                }
                let scheduledAt = Date()
                let selected = self.notificationDebouncer.eligible(candidates, at: scheduledAt)
                let center = UNUserNotificationCenter.current()
                for kind in selected {
                    guard let dispatchToken = self.notificationDispatchGate.begin(kind) else { continue }
                    let title: String, body: String
                    switch kind {
                    case .grades:
                        title = "Oceny"
                        body = "Wykryto nowe lub zmienione oceny po ręcznej synchronizacji."
                    case .attendance:
                        title = "Frekwencja"
                        body = "Wykryto nowe lub zmienione wpisy frekwencji."
                    case .messages:
                        title = "Wiadomości"
                        body = "Wykryto nowe wiadomości odebrane."
                    }
                    let content = UNMutableNotificationContent()
                    content.title = title
                    content.body = body
                    content.sound = .default
                    // No student identity, grades, sender, text or account ID in notification.
                    let id = kind.requestIdentifier
                    // A stable ID prevents queued/delivered duplicates of a category.
                    center.removePendingNotificationRequests(withIdentifiers: [id])
                    center.removeDeliveredNotifications(withIdentifiers: [id])
                    let request = UNNotificationRequest(identifier: id, content: content,
                        trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false))
                    center.add(request) { [weak self] error in
                        Task { @MainActor [weak self] in
                            guard let self else { return }
                            let stillCurrent = self.notificationDispatchGate.finish(
                                kind, token: dispatchToken, startedIn: dispatchEpoch)
                            let stillPermitted = self.localNotificationsEnabled &&
                                !self.backgroundSuspended && !self.privacyShieldActive &&
                                self.accountEpoch == accountTicket &&
                                self.store.verifiedAccountId == owner &&
                                self.localNotificationPreferences.permits(kind) &&
                                DirectNotificationOwnerPolicy.mayActivate(
                                    preferences: self.localNotificationPreferences,
                                    boundAccount: DirectNotificationOwnerKeychain.read(),
                                    verifiedAccount: owner)
                            if error != nil || !stillCurrent || !stillPermitted {
                                // Covers an async add finishing after account change,
                                // consent revocation, disabled category or background.
                                center.removePendingNotificationRequests(withIdentifiers: [id])
                                center.removeDeliveredNotifications(withIdentifiers: [id])
                                if error != nil && stillCurrent && stillPermitted {
                                    self.notificationDebouncer.releaseFailed(kind, at: scheduledAt)
                                    let errorCode = (error as NSError?)?.code ?? -1
                                    self.localNotificationsStatus =
                                        "iOS nie zapisał powiadomienia (kod \(errorCode)). " +
                                        "Możesz ponowić ręczne odświeżenie."
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /// In-memory staging; no fetched record is published before final /Me.
    /// Individual module failures leave the previous account-scoped cache intact.
    /// Does NOT run in the background or fabricate deletion events.
    func synchronizeCoreModules() {
        guard !coreSyncBusy, !directGradeBusy, !directAttendanceBusy,
              directMessagesBusy == nil, !directUnreadBusy, !directMessageDetailBusy,
              directAttachmentBusy == nil, directHomeworkFileBusy == nil,
              directSchoolFileBusy == nil, directFeedBusy == nil,
              !directRecipientBusy, !directSendBusy, !directFeedBatchBusy, !isSyncing, !isBusy,
              let owner = store.verifiedAccountId, !owner.isEmpty,
              directGradeStore.verifiedAccountId == owner,
              directAttendanceStore.verifiedAccountId == owner else {
            coreSyncStatus = "Najpierw potwierdź konto; zakończ inne odczyty."
            return
        }
        guard let refreshTicket = startManualRefresh(.coreJSON, owner: owner) else { return }
        let oldGrades = directGradeStore.grades
        let oldAttendance = directAttendanceStore.records
        let hadGradesBaseline = directGradeStore.capturedAt != nil
        let hadAttendanceBaseline = directAttendanceStore.capturedAt != nil
        let oldInbox = directMailboxes[.inbox]
        let ownerEpoch = accountEpoch
        let epoch = UUID(); coreSyncEpoch = epoch
        coreSyncBusy = true
        coreSyncChanges = nil
        coreSyncEvidenceSummary = "Brak wiarygodnego wyniku porównania."
        coreSyncStatus = "Sprawdzanie konta…"
        coreSyncWorker = Task { @MainActor [weak self] in
            guard let self else { return }
            defer {
                self.coreSyncWorker = nil
                self.completeManualRefresh(refreshTicket)
            }
            await self.runCoreSync(owner: owner, ownerEpoch: ownerEpoch, epoch: epoch,
                oldGrades: oldGrades, oldAttendance: oldAttendance,
                hadGradesBaseline: hadGradesBaseline, hadAttendanceBaseline: hadAttendanceBaseline,
                oldInbox: oldInbox)
        }
    }

    // Extracted from one huge Task closure to avoid the Xcode Swift compiler
    // type-check expression limit. The original branches and data writes are intact.
    private func runCoreSync(owner: String, ownerEpoch: UUID, epoch: UUID,
                             oldGrades: [DirectGrade], oldAttendance: [DirectAttendance],
                             hadGradesBaseline: Bool, hadAttendanceBaseline: Bool,
                             oldInbox: DirectMailboxSnapshot?) async {
            let client = SynergiaGatewayClient(webView: self.webView)
            let mailboxClient = SynergiaMessagesClient(webView: self.webView)
            var gradesStage: (rows: [DirectGrade], supplemental: [SupplementalGrade],
                subjects: [String: String], authors: DirectGradeAuthorResolution, reliable: Bool,
                unavailable: Set<SupplementalGradeFamily>)?
            var attendanceStage: (rows: [DirectAttendance], subjects: [String: String])?
            var inboxStage: DirectMailboxSnapshot?
            var messagesAccount: String?
            var errorLabels: [String] = []
            func stillCurrent() -> Bool {
                self.coreSyncEpoch == epoch && self.accountEpoch == ownerEpoch &&
                self.store.verifiedAccountId == owner &&
                self.directGradeStore.verifiedAccountId == owner &&
                self.directAttendanceStore.verifiedAccountId == owner
            }
            do {
                let first = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard first.id == owner, stillCurrent() else { throw CoreSyncComparisonError.differentAccount }

                self.coreSyncStatus = "Pobieranie ocen i ich kategorii…"
                do {
                    let base = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Grades")!
                    var current = base
                    var pages: [[String: Any]] = []
                    var visited = Set<String>()
                    while true {
                        guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                        guard pages.count < DirectGradePagination.maximumPages else { throw GradePagingError.tooManyPages }
                        guard visited.insert(current.absoluteString).inserted else { throw GradePagingError.repeatedPage }
                        pages.append((pages.isEmpty ? try await client.read(.grades) : try await client.readGradeContinuation(current)).json)
                        guard let next = try DirectGradePagination.continuation(pages[pages.count - 1], current: current, base: base) else { break }
                        current = next
                    }
                    var ambiguousEmptyNormal = false
                    let merged: [String: Any]
                    do {
                        merged = try DirectGradePagination.merge(pages, previousCount: oldGrades.count)
                    } catch DirectGradeCompletenessError.unexpectedEmptyReplacement {
                        guard pages.count == 1,
                              let items = pages[0]["Grades"] as? [[String: Any]], items.isEmpty,
                              oldGrades.isEmpty else { throw DirectGradeCompletenessError.unexpectedEmptyReplacement }
                        merged = ["Grades": [[String: Any]]()]
                        ambiguousEmptyNormal = true
                    }
                    let comments = try await client.read(.gradeComments)
                    let decoded = try SynergiaGradeRecords.decode(grades: merged, comments: comments.json)
                    let categories = try SynergiaGradeCategories.decode((try await client.read(.gradeCategories)).json)
                    let rows = SynergiaGradeCategories.enrich(decoded, categories: categories)
                    let subjects = try SynergiaSubjects.decode((try await client.read(.subjects)).json)
                    try GradeReferenceIntegrity.validate(grades: rows, subjects: subjects)
                    if !ambiguousEmptyNormal {
                        try DirectGradeCompleteness.validate(root: merged,
                            decodedCount: rows.count, previousCount: oldGrades.count)
                    }
                    _ = try GradeSemesterCoverage.validateReplacement(incoming: rows, previous: oldGrades)
                    _ = try GradeChangeAudit.compare(previous: oldGrades, incoming: rows)
                    let authors = try await client.readGradeAuthors(grades: rows,
                        previous: self.directGradeStore.teachers)
                    var supplemental: [SupplementalGrade] = []
                    var unavailable = Set<SupplementalGradeFamily>()
                    for (family, resource) in [
                        (SupplementalGradeFamily.descriptive, SynergiaGatewayClient.Resource.descriptiveGrades),
                        (.points, .pointGrades), (.text, .baseTextGrades), (.behaviour, .behaviourPointGrades)
                    ] {
                        guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                        do { supplemental += try SupplementalGrades.decode(family: family, root: (try await client.read(resource)).json) }
                        catch GatewayReadError.forbidden { unavailable.insert(family) }
                        catch GatewayReadError.serviceUnavailable(let status) where status == 404 { unavailable.insert(family) }
                    }
                    try SupplementalSemesterCoverage.validateReplacement(
                        fresh: supplemental, previous: self.directGradeStore.supplemental,
                        unavailable: unavailable)
                    let mergedSupplemental = GradeFamilySnapshot.reconcile(fresh: supplemental,
                        previous: self.directGradeStore.supplemental, unavailable: unavailable)
                    // A previously observed non-standard mark must not vanish
                    // because an individual family returned only a partial list.
                    let familyDelta = try DirectCoreSyncAudit.compareSupplemental(
                        previous: self.directGradeStore.supplemental, current: mergedSupplemental)
                    guard familyDelta.missing == 0 else { throw DirectGradeCompletenessError.unexpectedEmptyReplacement }
                    if ambiguousEmptyNormal && mergedSupplemental.isEmpty {
                        throw DirectGradeCompletenessError.unexpectedEmptyReplacement
                    }
                    gradesStage = (rows, mergedSupplemental, subjects, authors,
                        unavailable.isEmpty && !ambiguousEmptyNormal, unavailable)
                    if !unavailable.isEmpty { errorLabels.append("Niektóre typy ocen niedostępne (zachowano poprzednie).") }
                } catch {
                    if (error as? GatewayReadError) == .loginRequired ||
                       (error as? CoreSyncComparisonError) == .differentAccount { throw error }
                    errorLabels.append("Oceny: \(error.localizedDescription)")
                }
                guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }

                self.coreSyncStatus = "Pobieranie frekwencji…"
                do {
                    let attendance = try await client.read(.attendance)
                    let types = try await client.read(.attendanceTypes)
                    let lessons = try await client.read(.lessons)
                    let rows = try SynergiaAttendanceRecords.decode(attendances: attendance.json,
                        types: types.json, lessons: lessons.json)
                    try DirectAttendanceCompleteness.validate(root: attendance.json,
                        decodedCount: rows.count, previousCount: oldAttendance.count)
                    let subjects = try SynergiaSubjects.decode((try await client.read(.subjects)).json)
                    _ = try DirectCoreSyncAudit.compareAttendance(previous: oldAttendance, current: rows)
                    try DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(
                        previous: oldAttendance, incoming: rows)
                    attendanceStage = (rows, subjects)
                } catch {
                    if (error as? GatewayReadError) == .loginRequired { throw error }
                    errorLabels.append("Frekwencja: \(error.localizedDescription)")
                }
                guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }

                self.coreSyncStatus = "Pobieranie odebranych wiadomości…"
                do {
                    let remoteId = try await mailboxClient.currentSessionAccountId()
                    messagesAccount = remoteId
                    var pages: [DirectMessagePage] = []
                    while pages.count < DirectMessageParser.maxPages {
                        guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                        let page = try await mailboxClient.list(.inbox, page: pages.count + 1)
                        pages.append(page)
                        let count = pages.reduce(0) { $0 + $1.messages.count }
                        if let total = page.total, count >= total { break }
                        if page.messages.count < DirectMessageParser.pageSize { break }
                        if pages.count == DirectMessageParser.maxPages { throw DirectMessageError.tooManyMessages }
                    }
                    let after = try await mailboxClient.currentSessionAccountId()
                    guard remoteId == after else { throw CoreSyncComparisonError.differentAccount }
                    inboxStage = try DirectMessageParser.merge(pages, mailbox: .inbox,
                        accountId: owner, messageSessionId: remoteId)
                } catch {
                    if error is CoreSyncComparisonError { throw error }
                    errorLabels.append("Wiadomości: \(error.localizedDescription). Otwórz Wiadomości w Synergii, jeśli sesja wygasła.")
                }
                guard stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                let last = try DirectAccountIdentity.parse((try await client.read(.me)).json)
                guard first == last, last.id == owner, stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                if let remoteId = messagesAccount, inboxStage != nil {
                    let after = try await mailboxClient.currentSessionAccountId()
                    guard remoteId == after, stillCurrent() else { throw CoreSyncComparisonError.differentAccount }
                }

                // Commit only after verification. Each error is isolated to its module.
                var changes = CoreSyncChanges(newGrades: 0, editedGrades: 0,
                    newAttendance: 0, editedAttendance: 0, newMessages: 0,
                    disappearedGrades: 0, disappearedAttendance: 0, disappearedMessages: 0)
                var gradeReliable = false, attendanceReliable = false, inboxReliable = false
                var gradeChangeExplanation = ""
                if let g = gradesStage {
                    do {
                        let delta = try DirectCoreSyncAudit.compareGrades(previous: oldGrades, current: g.rows)
                        let other = try DirectCoreSyncAudit.compareSupplemental(
                            previous: self.directGradeStore.supplemental, current: g.supplemental)
                        guard delta.missing == 0, other.missing == 0 else {
                            throw DirectGradeCompletenessError.unexpectedEmptyReplacement
                        }
                        let observed = try GradeObservedChangeAudit.compare(
                            previous: oldGrades, current: g.rows,
                            previousSupplemental: self.directGradeStore.supplemental,
                            currentSupplemental: g.supplemental, unavailable: g.unavailable)
                        let explanation = hadGradesBaseline ? observed.summary :
                            "Pierwszy zapis ocen jest punktem odniesienia, nie zgłoszeniem nowych ocen."
                        try self.directGradeStore.replace(grades: g.rows, subjects: g.subjects,
                            accountId: owner, supplemental: g.supplemental, teachers: g.authors.names,
                            olderTeacherIds: g.authors.staleIds)
                        gradeChangeExplanation = g.reliable ? explanation :
                            "Oceny: odczyt częściowy; nie zgłoszono nowych lub zmienionych ocen."
                        changes = CoreSyncChanges(
                            newGrades: hadGradesBaseline ? observed.observedNew : 0,
                            editedGrades: hadGradesBaseline ? observed.observedEdited : 0,
                            newAttendance: changes.newAttendance, editedAttendance: changes.editedAttendance,
                            newMessages: changes.newMessages, disappearedGrades: delta.missing,
                            disappearedAttendance: changes.disappearedAttendance,
                            disappearedMessages: changes.disappearedMessages)
                        gradeReliable = g.reliable && delta.missing == 0 && other.missing == 0
                        self.failedDirectReads.remove(.grades)
                        self.freshDirectReads.insert(.grades)
                        self.directGradeStatus = "Synchronizacja ocen: \(g.rows.count) wpisów zwykłych; kompletność konta nadal niepotwierdzona."
                    } catch {
                        self.failedDirectReads.insert(.grades)
                        self.freshDirectReads.remove(.grades)
                        errorLabels.append("Zapis ocen: \(error.localizedDescription)")
                    }
                } else {
                    self.failedDirectReads.insert(.grades)
                    self.freshDirectReads.remove(.grades)
                }
                if let a = attendanceStage {
                    do {
                        let delta = try DirectCoreSyncAudit.compareAttendance(previous: oldAttendance, current: a.rows)
                        try self.directAttendanceStore.replace(records: a.rows,
                            subjects: a.subjects, accountId: owner)
                        changes = CoreSyncChanges(newGrades: changes.newGrades, editedGrades: changes.editedGrades,
                            newAttendance: hadAttendanceBaseline ? delta.added : 0,
                            editedAttendance: hadAttendanceBaseline ? delta.edited : 0,
                            newMessages: changes.newMessages, disappearedGrades: changes.disappearedGrades,
                            disappearedAttendance: delta.missing, disappearedMessages: changes.disappearedMessages)
                        attendanceReliable = delta.missing == 0
                        self.failedDirectReads.remove(.attendance)
                        self.freshDirectReads.insert(.attendance)
                        self.directAttendanceStatus = "Synchronizacja frekwencji: \(a.rows.count) wpisów. Nie jest to oficjalny procent obecności."
                    } catch {
                        self.failedDirectReads.insert(.attendance)
                        self.freshDirectReads.remove(.attendance)
                        errorLabels.append("Zapis frekwencji: \(error.localizedDescription)")
                    }
                } else {
                    self.failedDirectReads.insert(.attendance)
                    self.freshDirectReads.remove(.attendance)
                }
                if let inbox = inboxStage {
                    if let previous = oldInbox, previous.accountId == owner,
                       let delta = try? DirectCoreSyncAudit.compareInbox(previous: previous, current: inbox) {
                        changes = CoreSyncChanges(newGrades: changes.newGrades, editedGrades: changes.editedGrades,
                            newAttendance: changes.newAttendance, editedAttendance: changes.editedAttendance,
                            newMessages: delta.added, disappearedGrades: changes.disappearedGrades,
                            disappearedAttendance: changes.disappearedAttendance,
                            disappearedMessages: delta.missing)
                        inboxReliable = delta.missing == 0
                    }
                    self.directMailboxes[.inbox] = inbox
                    self.failedDirectMailboxes.remove(.inbox)
                    self.failedDirectReads.remove(.messages)
                    self.directMessagesStatus[.inbox] = "Synchronizacja odebranych: \(inbox.messages.count) wiadomości." +
                        (inbox.complete ? " Odczyt kompletny według licznika." : " Kompletność niepotwierdzona.")
                } else {
                    self.failedDirectMailboxes.insert(.inbox)
                    self.failedDirectReads.insert(.messages)
                }
                // P41: do not display tentative deltas as trustworthy new records.
                // Values with a missing baseline, incomplete read or missing IDs
                // may be diagnostics, but must never cause a user-facing alert.
                let gradeEvidence = DirectSyncChangeEvidence.evaluate(name: "Oceny",
                    baseline: hadGradesBaseline, fetched: gradesStage != nil,
                    complete: gradeReliable, observedAdded: changes.newGrades,
                    observedChanged: changes.editedGrades, absent: changes.disappearedGrades)
                let attendanceEvidence = DirectSyncChangeEvidence.evaluate(name: "Frekwencja",
                    baseline: hadAttendanceBaseline, fetched: attendanceStage != nil,
                    complete: attendanceReliable, observedAdded: changes.newAttendance,
                    observedChanged: changes.editedAttendance, absent: changes.disappearedAttendance)
                let messageEvidence = DirectSyncChangeEvidence.evaluate(name: "Odebrane",
                    baseline: oldInbox != nil, fetched: inboxStage != nil,
                    complete: inboxReliable, observedAdded: changes.newMessages,
                    observedChanged: 0, absent: changes.disappearedMessages)
                let safeChanges = CoreSyncChanges(
                    newGrades: gradeEvidence.added, editedGrades: gradeEvidence.changed,
                    newAttendance: attendanceEvidence.added, editedAttendance: attendanceEvidence.changed,
                    newMessages: messageEvidence.added,
                    disappearedGrades: gradeEvidence.absentUnconfirmed,
                    disappearedAttendance: attendanceEvidence.absentUnconfirmed,
                    disappearedMessages: messageEvidence.absentUnconfirmed)
                self.coreSyncChanges = safeChanges
                self.coreSyncEvidenceSummary = [gradeEvidence.description,
                    attendanceEvidence.description, messageEvidence.description].joined(separator: " ")
                let plan = CoreLocalNotificationPlan.make(consent: self.localNotificationsEnabled,
                    accountMatched: stillCurrent(), hadGradesBaseline: hadGradesBaseline,
                    hadAttendanceBaseline: hadAttendanceBaseline, hadInboxBaseline: oldInbox != nil,
                    gradesReliable: gradeEvidence.mayNotify, attendanceReliable: attendanceEvidence.mayNotify,
                    inboxReliable: messageEvidence.mayNotify, changes: safeChanges)
                self.deliverCoreNotifications(plan)
                self.coreSyncStatus = "Wiarygodnie zaobserwowane: nowe oceny \(safeChanges.newGrades), zmienione \(safeChanges.editedGrades); " +
                    "nowa frekwencja \(safeChanges.newAttendance), zmieniona \(safeChanges.editedAttendance); " +
                    "nowe wiadomości \(safeChanges.newMessages). " +
                    (gradeChangeExplanation.isEmpty ? "" : gradeChangeExplanation + " ") +
                    (errorLabels.isEmpty ? "Bez błędów odczytu. " : "Częściowe błędy: " + errorLabels.joined(separator: " | ") + ". ") +
                    "Brak wpisu nie oznacza usunięcia; aktualizacje wymagają ręcznego uruchomienia."
                self.dataRevision += 1
            } catch {
                guard self.coreSyncEpoch == epoch else { return }
                if DirectOfflineRecovery.mayRetain(
                    previouslyVerified: true,
                    accountUnchanged: stillCurrent(),
                    isForeground: !self.backgroundSuspended && !self.privacyShieldActive,
                    observedRemoteAccount: nil, expectedAccount: owner, failure: error) {
                    self.failedDirectReads.formUnion([.grades, .attendance, .messages])
                    self.failedDirectMailboxes.insert(.inbox)
                    self.freshDirectReads.subtract([.grades, .attendance])
                    self.coreSyncChanges = nil
                    self.coreSyncEvidenceSummary = "Brak wiarygodnego wyniku porównania."
                    self.coreSyncStatus = "Przerwano przez brak sieci. Zapis tego konta jest NIEAKTUALNY; spróbuj ręcznie ponownie."
                    self.coreSyncBusy = false
                    return
                }
                self.directGradeStore.lock(); self.directAttendanceStore.lock()
                self.directOfflineTimetableStore.lock()
                self.revokeDirectTimetableOnAccountFailure()
                self.directOfflineFeedStore.lock(); self.directFeeds.removeAll()
                self.freshDirectReads.removeAll()
                self.lockDirectMessages(); self.store.lock()
                self.coreSyncChanges = nil
                self.coreSyncEvidenceSummary = "Brak wiarygodnego wyniku porównania."
                self.coreSyncStatus = "Zablokowano synchronizację: nie można potwierdzić niezmienności konta lub sesji. Zweryfikuj konto ponownie."
            }
            if self.coreSyncEpoch == epoch { self.coreSyncBusy = false }
    }

}

struct PortalWebView: UIViewRepresentable {
    @EnvironmentObject var portal: SynergiaPortal
    func makeUIView(context: Context) -> WKWebView { portal.webView }
    func updateUIView(_ view: WKWebView, context: Context) {}
}
