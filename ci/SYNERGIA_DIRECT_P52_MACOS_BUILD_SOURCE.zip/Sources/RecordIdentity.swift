import Foundation

/// Only in-row, first-party HTTPS hyperlinks can be used as *candidates* for a
/// stable record key. A link is not proof of the server's identity semantics.
enum RecordIdentity {
    static func uniqueLink(in table: CapturedTable, rowIndex: Int) -> CapturedRowLink? {
        guard let links = table.rowLinks, links.indices.contains(rowIndex) else { return nil }
        let safe = links[rowIndex].filter { item in
            guard let url = URL(string: item.url), PortalPolicy.isAllowed(url) else { return false }
            // Fragments do not identify a distinct message/grade.
            return url.fragment == nil && !item.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        let distinct = Dictionary(grouping: safe, by: \.url)
        guard distinct.count == 1, let link = distinct.values.first?.first else { return nil }
        return link
    }
}

struct GradeIdentityReport {
    let recognized: Int
    let linkedCandidates: Int
    let ambiguousLinks: Int
    let withoutLink: Int
    let warnings: [String]
}

enum GradeIdentityAudit {
    static func review(snapshot: ModuleSnapshot) -> GradeIdentityReport {
        guard snapshot.module == .grades, let tables = snapshot.tables else {
            return GradeIdentityReport(recognized: 0, linkedCandidates: 0,
                ambiguousLinks: 0, withoutLink: 0,
                warnings: ["Brak zgodnego z modułem zapisu tabel ocen."])
        }
        let parsed = GradeParser.preview(snapshot: snapshot)
        var linkCounts: [String: Int] = [:]
        var withLink = 0
        for grade in parsed.grades {
            // The row index is 1-based in GradeCandidate. The table index is
            // encoded in the provisional identifier, NOT a stable identifier.
            let components = grade.id.components(separatedBy: "|")
            guard let tableIndex = components.dropLast(3).last.flatMap(Int.init),
                  tables.indices.contains(tableIndex),
                  let link = RecordIdentity.uniqueLink(in: tables[tableIndex], rowIndex: grade.sourceRow - 1) else { continue }
            withLink += 1
            linkCounts[link.url, default: 0] += 1
        }
        let ambiguous = linkCounts.values.reduce(0) { $0 + ($1 > 1 ? $1 : 0) }
        return GradeIdentityReport(recognized: parsed.grades.count,
            linkedCandidates: withLink - ambiguous, ambiguousLinks: ambiguous,
            withoutLink: parsed.grades.count - withLink,
            warnings: ["Odnośniki w wierszach są jedynie kandydatami identyfikatora.",
                       "Bez potwierdzenia formatu przez Synergię nie generujemy zdarzeń «nowa ocena» ani powiadomień."])
    }
}
