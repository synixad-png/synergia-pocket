import Foundation

/// Strict preview parsing: the application does not infer missing columns.
/// No HTML captured from a real Synergia account has been verified yet.
enum SchoolTableParser {
    static func normalize(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "pl_PL"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
    }

    struct ColumnRule {
        let required: [String: Set<String>]
        let optional: [String: Set<String>]
    }
    struct ParsedRow: Identifiable {
        let id: String
        let fields: [String: String]
        let caption: String
        let tableIndex: Int
        let rowIndex: Int
    }
    struct Result {
        let rows: [ParsedRow]
        let discarded: Int
        let matchingTables: Int
        let warnings: [String]
    }
    static func parse(snapshot: ModuleSnapshot, rule: ColumnRule) -> Result {
        guard let tables = snapshot.tables else {
            return Result(rows: [], discarded: 0, matchingTables: 0, warnings: ["Starszy zapis nie zawiera granic tabel; odczytaj stronę ponownie."])
        }
        var parsed: [ParsedRow] = []
        var discarded = 0
        var matching = 0
        for (tableIndex, table) in tables.enumerated() {
            var positions: [String: Int]? = nil
            for (rowIndex, row) in table.rows.enumerated() {
                let normalized = row.map(normalize)
                var candidate: [String: Int] = [:]
                var ambiguous = false
                for (field, headers) in rule.required.merging(rule.optional, uniquingKeysWith: { a, _ in a }) {
                    let matches = normalized.indices.filter { headers.contains(normalized[$0]) }
                    if matches.count > 1 { ambiguous = true }
                    if matches.count == 1 { candidate[field] = matches[0] }
                }
                if !ambiguous && rule.required.keys.allSatisfy({ candidate[$0] != nil }) && Set(candidate.values).count == candidate.count {
                    positions = candidate
                    matching += 1
                    continue
                }
                guard let positions else { continue }
                var fields: [String: String] = [:]
                for (field, index) in positions where row.indices.contains(index) {
                    let value = row[index].trimmingCharacters(in: .whitespacesAndNewlines)
                    if !value.isEmpty { fields[field] = value }
                }
                if !rule.required.keys.allSatisfy({ fields[$0] != nil }) || fields.values.contains(where: { $0.count > 400 }) {
                    discarded += 1
                    continue
                }
                // Avoid treating a second header row as ordinary data.
                if rule.required.contains(where: { pair in
                    guard let value = fields[pair.key] else { return false }
                    return pair.value.contains(normalize(value))
                }) { discarded += 1; continue }
                parsed.append(ParsedRow(id: "\(snapshot.sourceURL)|\(tableIndex)|\(rowIndex)",
                                        fields: fields, caption: table.caption,
                                        tableIndex: tableIndex, rowIndex: rowIndex))
            }
        }
        var warnings = ["Wstępny odczyt tabel HTML — brak potwierdzenia struktury na prawdziwym koncie.",
                        "Nie potwierdzono kompletności ani obsługi wszystkich podstron."]
        if matching == 0 { warnings.append("Nie znaleziono jednoznacznej tabeli z wymaganymi nagłówkami.") }
        if discarded > 0 { warnings.append("Pominięto \(discarded) niejednoznacznych wierszy.") }
        return Result(rows: parsed, discarded: discarded, matchingTables: matching, warnings: warnings)
    }
}

struct TimetableEntry: Identifiable {
    let id: String
    let day: String
    let lesson: String
    let subject: String
    let startTime: String?
    let endTime: String?
    let room: String?
    let teacher: String?
}
struct TimetablePreview {
    let entries: [TimetableEntry]
    let warnings: [String]
}
enum TimetableParser {
    static func preview(snapshot: ModuleSnapshot) -> TimetablePreview {
        let rule = SchoolTableParser.ColumnRule(required: [
            "day": ["dzien", "dzien tygodnia"], "subject": ["przedmiot", "zajecia"]
        ], optional: [
            "lesson": ["lekcja", "nr lekcji", "numer lekcji"],
            "start": ["od", "poczatek", "godzina od"], "end": ["do", "koniec", "godzina do"],
            "room": ["sala", "nr sali"], "teacher": ["nauczyciel", "prowadzacy"]
        ])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        let entries = parsed.rows.compactMap { row -> TimetableEntry? in
            guard let day = row.fields["day"], let subject = row.fields["subject"],
                  day.count <= 40, subject.count <= 140 else { return nil }
            return TimetableEntry(id: row.id, day: day, lesson: row.fields["lesson"] ?? "—",
                                  subject: subject, startTime: row.fields["start"], endTime: row.fields["end"],
                                  room: row.fields["room"], teacher: row.fields["teacher"])
        }
        return TimetablePreview(entries: entries, warnings: parsed.warnings)
    }
}

struct AttendanceEntry: Identifiable {
    let id: String
    let dateText: String
    let subject: String
    let status: String
    let lesson: String?
}
struct AttendancePreview {
    let entries: [AttendanceEntry]
    let unknownStatusCount: Int
    let warnings: [String]
}
enum AttendanceParser {
    private static let recognizedStatuses: Set<String> = [
        "obecnosc", "obecny", "obecna", "nieobecnosc", "nieobecny", "nieobecna",
        "nieobecnosc usprawiedliwiona", "usprawiedliwiona", "spoznienie", "spozniony", "spozniona",
        "zwolnienie", "zwolniony", "zwolniona"
    ]
    static func preview(snapshot: ModuleSnapshot) -> AttendancePreview {
        let rule = SchoolTableParser.ColumnRule(required: [
            "date": ["data", "dzien"], "subject": ["przedmiot", "zajecia"],
            "status": ["status", "frekwencja", "obecnosc", "rodzaj"]
        ], optional: ["lesson": ["lekcja", "nr lekcji"]])
        let parsed = SchoolTableParser.parse(snapshot: snapshot, rule: rule)
        var unknown = 0
        let entries = parsed.rows.compactMap { row -> AttendanceEntry? in
            guard let date = row.fields["date"], let subject = row.fields["subject"],
                  let status = row.fields["status"] else { return nil }
            guard recognizedStatuses.contains(SchoolTableParser.normalize(status)) else { unknown += 1; return nil }
            return AttendanceEntry(id: row.id, dateText: date, subject: subject,
                                   status: status, lesson: row.fields["lesson"])
        }
        var warnings = parsed.warnings
        if unknown > 0 { warnings.append("Pominięto \(unknown) pozycji z nierozpoznanym statusem frekwencji.") }
        return AttendancePreview(entries: entries, unknownStatusCount: unknown, warnings: warnings)
    }
}
