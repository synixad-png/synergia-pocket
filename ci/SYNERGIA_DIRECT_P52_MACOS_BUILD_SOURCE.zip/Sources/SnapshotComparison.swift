import Foundation

/// Only a structural local comparison. A changed row is NOT proof of a new grade
/// or message: sorting, editing and duplicate values can all change rows.
struct SnapshotDelta: Codable {
    let module: SchoolModule
    let comparedAt: Date
    let previousCapture: Date
    let currentCapture: Date
    let oldRows: Int
    let newRows: Int
    let addedRowOccurrences: Int
    let removedRowOccurrences: Int
    let comparable: Bool
    let explanation: String
}

enum SnapshotComparator {
    private static func signature(_ row: [String]) -> String {
        // Include cell boundaries and multiplicities; do not put row contents in reports.
        row.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .map { "\($0.utf8.count):\($0)" }.joined(separator: "|")
    }
    private static func counts(_ rows: [[String]]) -> [String: Int] {
        var result: [String: Int] = [:]
        for row in rows { result[signature(row), default: 0] += 1 }
        return result
    }
    static func compare(previous: ModuleSnapshot, current: ModuleSnapshot) -> SnapshotDelta {
        let previousTables = previous.tables ?? []
        let currentTables = current.tables ?? []
        let sameShape = previousTables.count == currentTables.count &&
            zip(previousTables, currentTables).allSatisfy { pair in
                pair.0.caption == pair.1.caption && pair.0.rows.first == pair.1.rows.first
            }
        let comparable = previous.module == current.module && previous.sourceURL == current.sourceURL &&
            !previousTables.isEmpty && sameShape
        let oldRows = previousTables.flatMap(\.rows)
        let newRows = currentTables.flatMap(\.rows)
        guard comparable else {
            return SnapshotDelta(module: current.module, comparedAt: Date(),
                previousCapture: previous.capturedAt, currentCapture: current.capturedAt,
                oldRows: oldRows.count, newRows: newRows.count,
                addedRowOccurrences: 0, removedRowOccurrences: 0, comparable: false,
                explanation: "Nieporównywalne strony lub układ tabel. Brak wniosku o nowych wpisach.")
        }
        let before = counts(oldRows), after = counts(newRows)
        let added = after.reduce(0) { $0 + max(0, $1.value - (before[$1.key] ?? 0)) }
        let removed = before.reduce(0) { $0 + max(0, $1.value - (after[$1.key] ?? 0)) }
        return SnapshotDelta(module: current.module, comparedAt: Date(),
            previousCapture: previous.capturedAt, currentCapture: current.capturedAt,
            oldRows: oldRows.count, newRows: newRows.count,
            addedRowOccurrences: added, removedRowOccurrences: removed, comparable: true,
            explanation: "Porównano wystąpienia wierszy HTML. Zmiany nie oznaczają automatycznie nowych ocen ani wiadomości; mogą wynikać z edycji lub sortowania.")
    }
}

/// Non-identifying structural diagnostics; intentionally excludes text,
/// titles, URLs, subject names, link destinations and HTML.
struct StructuralDiagnostics: Codable {
    let version: Int
    let tables: Int
    let tableColumnCounts: [[Int]]
    let rows: Int
    let links: Int
    let ready: Bool
    let truncated: Bool
    let paginationDetected: Bool
    let loginFormDetected: Bool
    static func from(_ capture: PageCapture) -> StructuralDiagnostics {
        StructuralDiagnostics(version: 1,
            tables: capture.tables?.count ?? 0,
            tableColumnCounts: (capture.tables ?? []).prefix(40).map { table in
                Array(table.rows.prefix(10).map(\.count))
            },
            rows: capture.rows.count, links: capture.links.count,
            ready: capture.documentReady == true,
            truncated: capture.isTruncated == true,
            paginationDetected: capture.hasPagination == true,
            loginFormDetected: capture.loginFormPresent == true)
    }
    func formatted() -> String {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        guard let data = try? encoder.encode(self), let result = String(data: data, encoding: .utf8) else { return "Błąd tworzenia raportu" }
        return result
    }
}
