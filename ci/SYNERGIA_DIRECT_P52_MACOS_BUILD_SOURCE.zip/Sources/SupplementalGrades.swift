import Foundation
import CoreFoundation

// Sources documented as separate from Grades in the observed Synergia gateway.
// Every record retains its family, avoiding collisions between numeric Ids.
// This decoder does not infer unsupported grade fields or claim server completeness.
enum SupplementalGradeFamily: String, Codable, CaseIterable {
    case descriptive = "DescriptiveGrades"
    case points = "PointGrades"
    case text = "BaseTextGrades"
    case behaviour = "BehaviourGrades/Points"
}

struct SupplementalGrade: Codable, Equatable, Identifiable {
    let family: SupplementalGradeFamily
    let sourceId: String
    let subjectId: String?
    let value: String
    let semester: Int?
    let addedAt: String?
    var id: String { family.rawValue + ":" + sourceId }
}

enum SupplementalGradeError: Error, Equatable {
    case missingCollection(String)
    case invalidRecord(String)
    case duplicateIdentity(String)
    case incompleteResponse(String)
    case invalidTotal(String)
}

enum SupplementalGrades {
    private static func identifier(_ raw: Any?) -> String? {
        if let s = raw as? String, !s.isEmpty { return s }
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
           number.doubleValue.isFinite, number.doubleValue.rounded() == number.doubleValue {
            return number.stringValue
        }
        return nil
    }

    private static func nestedId(_ raw: Any?) -> String? {
        guard let dictionary = raw as? [String: Any] else { return nil }
        return identifier(dictionary["Id"])
    }

    private static func semesterValue(_ raw: Any?, record: String) throws -> Int? {
        guard let raw, !(raw is NSNull) else { return nil }
        guard let n = raw as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
              n.doubleValue.isFinite, n.doubleValue.rounded() == n.doubleValue,
              n.doubleValue >= Double(Int.min), n.doubleValue <= Double(Int.max) else {
            throw SupplementalGradeError.invalidRecord(record)
        }
        return n.intValue
    }

    static func decode(family: SupplementalGradeFamily, root: [String: Any]) throws -> [SupplementalGrade] {
        guard let items = root["Grades"] as? [[String: Any]] else {
            throw SupplementalGradeError.missingCollection(family.rawValue)
        }
        // Do not store the first page as a complete family when the server
        // explicitly advertises more records. Unknown paging forms are rejected,
        // not guessed. Absent metadata does not prove completeness.
        for key in ["Next", "NextPage", "NextPageUrl", "next"] {
            guard let next = root[key], !(next is NSNull) else { continue }
            if let text = next as? String,
               text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { continue }
            if let number = next as? NSNumber,
               CFGetTypeID(number) == CFBooleanGetTypeID(), !number.boolValue { continue }
            throw SupplementalGradeError.incompleteResponse(family.rawValue)
        }
        var expectedTotal: Int?
        for key in ["TotalCount", "Total"] {
            guard let raw = root[key], !(raw is NSNull) else { continue }
            let parsed: Int?
            if let n = raw as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
               n.doubleValue.isFinite, n.doubleValue.rounded() == n.doubleValue,
               n.doubleValue >= 0, n.doubleValue <= Double(Int.max) {
                parsed = n.intValue
            } else if let text = raw as? String, let n = Int(text), n >= 0 {
                parsed = n
            } else { parsed = nil }
            guard let total = parsed, total == items.count,
                  expectedTotal == nil || expectedTotal == total else {
                throw SupplementalGradeError.invalidTotal(family.rawValue)
            }
            expectedTotal = total
        }
        var seen = Set<String>()
        return try items.map { item in
            guard let id = identifier(item["Id"]) else {
                throw SupplementalGradeError.invalidRecord(family.rawValue + ":Id")
            }
            guard seen.insert(id).inserted else {
                throw SupplementalGradeError.duplicateIdentity(family.rawValue + ":" + id)
            }
            let value: String
            switch family {
            case .descriptive:
                // Map, not Grade, is the displayed value for descriptive grades.
                guard let displayed = item["Map"] as? String else {
                    throw SupplementalGradeError.invalidRecord(family.rawValue + ":Map")
                }
                value = displayed
            case .points:
                guard let displayed = item["Grade"] as? String else {
                    throw SupplementalGradeError.invalidRecord(family.rawValue + ":Grade")
                }
                value = displayed
            case .text:
                guard let displayed = item["Grade"] as? String else {
                    throw SupplementalGradeError.invalidRecord(family.rawValue + ":Grade")
                }
                value = displayed
            case .behaviour:
                // BehaviourGrade.Id must be resolved with BehaviourGrades/Types;
                // never render an unverified scale number as a grade name.
                guard let behaviourID = nestedId(item["BehaviourGrade"]) else {
                    throw SupplementalGradeError.invalidRecord(family.rawValue + ":BehaviourGrade.Id")
                }
                value = "Typ zachowania ID " + behaviourID
            }
            let subjectId = nestedId(item["Subject"])
            if family != .behaviour && subjectId == nil {
                throw SupplementalGradeError.invalidRecord(family.rawValue + ":Subject.Id")
            }
            let semester = try semesterValue(item["Semester"], record: family.rawValue + ":" + id)
            let date = (item["AddDate"] as? String) ?? (item["Date"] as? String)
            return SupplementalGrade(family: family, sourceId: id,
                                     subjectId: subjectId, value: value,
                                     semester: semester, addedAt: date)
        }
    }
}
