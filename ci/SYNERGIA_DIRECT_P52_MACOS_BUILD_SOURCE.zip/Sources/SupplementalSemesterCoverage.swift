import Foundation

/// A successful response from one grade family is not automatically a complete
/// view of either semester. Never erase previously observed identities unless
/// an authoritative deletion mechanism is introduced and verified.
enum SupplementalSemesterCoverageError: LocalizedError, Equatable {
    case duplicateIdentity(String)
    case missingPrevious(family: SupplementalGradeFamily, count: Int)
    case freshForUnavailableFamily(SupplementalGradeFamily)

    var errorDescription: String? {
        switch self {
        case .duplicateIdentity:
            return "Powtórzone identyfikatory dodatkowych ocen. Poprzedni zapis został zachowany."
        case .missingPrevious(let family, let count):
            return "W odczycie \(family.rawValue) brak \(count) wcześniej zapisanych ocen. Nie nadpisano niepotwierdzonego semestru."
        case .freshForUnavailableFamily:
            return "Niespójny wynik odczytu dodatkowych ocen. Zapis został zablokowany."
        }
    }
}

enum SupplementalSemesterCoverage {
    static func validateReplacement(fresh: [SupplementalGrade],
                                    previous: [SupplementalGrade],
                                    unavailable: Set<SupplementalGradeFamily>) throws {
        var freshIDs = Set<String>()
        for grade in fresh {
            guard freshIDs.insert(grade.id).inserted else {
                throw SupplementalSemesterCoverageError.duplicateIdentity(grade.id)
            }
            guard !unavailable.contains(grade.family) else {
                throw SupplementalSemesterCoverageError.freshForUnavailableFamily(grade.family)
            }
        }
        var oldIDs = Set<String>()
        for grade in previous {
            guard oldIDs.insert(grade.id).inserted else {
                throw SupplementalSemesterCoverageError.duplicateIdentity(grade.id)
            }
        }
        // A moved semester with the same family-scoped ID remains the same grade.
        // A family returning 403/404 retains its previous data unchanged.
        for family in SupplementalGradeFamily.allCases where !unavailable.contains(family) {
            let missing = previous.filter { $0.family == family && !freshIDs.contains($0.id) }
            if !missing.isEmpty {
                throw SupplementalSemesterCoverageError.missingPrevious(family: family, count: missing.count)
            }
        }
    }
}

struct GradePortfolioSemesterReport: Equatable {
    let standard: GradeSemesterReport
    let supplemental: GradeSemesterReport

    var message: String {
        let ordinary = "Zwykłe: I \(standard.firstCount), II \(standard.secondCount), inne/bez semestru \(standard.unspecifiedCount + standard.otherSemesterCount)."
        let additional = "Pozostałe rodziny: I \(supplemental.firstCount), II \(supplemental.secondCount), inne/bez semestru \(supplemental.unspecifiedCount + supplemental.otherSemesterCount)."
        return ordinary + " " + additional + " Kompletność żadnego semestru nie jest potwierdzona przez serwer."
    }
}

enum GradePortfolioSemesterCoverage {
    static func report(standard: [DirectGrade], supplemental: [SupplementalGrade]) -> GradePortfolioSemesterReport {
        let extra = GradeSemesterReport(
            firstCount: supplemental.filter { $0.semester == 1 }.count,
            secondCount: supplemental.filter { $0.semester == 2 }.count,
            unspecifiedCount: supplemental.filter { $0.semester == nil }.count,
            otherSemesterCount: supplemental.filter { $0.semester != nil && $0.semester != 1 && $0.semester != 2 }.count)
        return GradePortfolioSemesterReport(standard: GradeSemesterCoverage.report(standard), supplemental: extra)
    }
}
