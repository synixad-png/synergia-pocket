import Foundation

/// Local diagnostic status only. Success means one HTML page was captured, not
/// that a school module contains every record in the official system.
enum SyncPageStatus: String, Codable {
    case savedPage = "Zapisano stronę"
    case rejectedPartial = "Niepełny odczyt"
    case loginRequired = "Wymagane logowanie"
    case wrongModule = "Inny moduł"
    case navigationError = "Błąd nawigacji"
    case captureError = "Błąd odczytu"
    case skipped = "Nie wykonano"
    case interrupted = "Przerwano"
}

struct SyncPageAudit: Codable, Identifiable {
    let module: SchoolModule
    let status: SyncPageStatus
    let checkedAt: Date
    let storedRows: Int
    let detectedPagination: Bool
    let clippedByLimit: Bool
    let explanation: String
    var id: String { module.rawValue }
    /// An accepted page is not proof of a complete gradebook or inbox.
    var pageSaved: Bool { status == .savedPage }
    var moduleCompletenessVerified: Bool { false }
}

struct SyncRunAudit: Codable {
    let startedAt: Date
    let finishedAt: Date
    let pages: [SyncPageAudit]
    let interrupted: Bool
    var savedPages: Int { pages.filter(\.pageSaved).count }
    var failedPages: Int { pages.count - savedPages }
}

@MainActor
final class SyncAuditStore: ObservableObject {
    @Published private(set) var lastRun: SyncRunAudit?
    private let root: URL
    private(set) var verifiedAccountId: String?
    init(root: URL? = nil) {
        self.root = root ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        // Legacy unscoped report is never loaded.
    }
    private func accountFile(_ id: String) -> URL {
        AccountPartition.directory(for: id, under: root.appendingPathComponent("sync-audit-accounts", isDirectory: true))
            .appendingPathComponent("last-run.json")
    }
    func lock() { verifiedAccountId = nil; lastRun = nil }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        if let data = try? Data(contentsOf: accountFile(accountId)) {
            lastRun = try? JSONDecoder().decode(SyncRunAudit.self, from: data)
        }
    }
    enum StoreError: Error { case accountNotVerified }
    func save(_ run: SyncRunAudit) throws {
        guard let account = verifiedAccountId else { throw StoreError.accountNotVerified }
        let file = accountFile(account)
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        let encoded = try JSONEncoder().encode(run)
        try encoded.write(to: file, options: [.atomic, .completeFileProtection])
        lastRun = run
    }
    func erase() throws {
        lock()
        let scoped = root.appendingPathComponent("sync-audit-accounts", isDirectory: true)
        if FileManager.default.fileExists(atPath: scoped.path) { try FileManager.default.removeItem(at: scoped) }
        let legacy = root.appendingPathComponent("synergia-sync-audit.json")
        if FileManager.default.fileExists(atPath: legacy.path) { try FileManager.default.removeItem(at: legacy) }
    }
}
