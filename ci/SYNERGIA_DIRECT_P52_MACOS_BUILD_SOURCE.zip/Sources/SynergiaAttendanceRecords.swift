import Foundation
import CoreFoundation

// The JSON shape is documented from observed gateway/api/2.0 responses.
// Ids may be numeric or strings (e.g. t41685); no inference from numeric type IDs.
struct DirectAttendance: Codable, Identifiable, Equatable {
    let id: String
    let date: String
    let lessonNumber: Int?
    let semester: Int?
    let lessonId: String
    let subjectId: String?
    let typeId: String
    let typeName: String
    let isPresenceKind: Bool
}

enum AttendanceDecodeError: Error, Equatable {
    case malformedRoot(String)
    case malformedRecord(Int)
    case duplicateRecord(String)
    case duplicateReference(String)
    case missingAttendanceType(String)
}

extension AttendanceDecodeError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .malformedRoot(let key):
            return "Nieprawidłowa lista danych frekwencji (\(key)). Nie zapisano odczytu."
        case .malformedRecord(let index):
            return "Nieprawidłowy wpis frekwencji nr \(index + 1). Nie zapisano odczytu."
        case .duplicateRecord:
            return "Odczyt frekwencji zawiera powtórzony identyfikator wpisu. Nie zapisano odczytu."
        case .duplicateReference:
            return "Odczyt frekwencji zawiera powtórzony identyfikator słownika. Nie zapisano odczytu."
        case .missingAttendanceType:
            return "Nie udało się wiarygodnie ustalić typu frekwencji. Nie zapisano odczytu."
        }
    }
}

enum SynergiaAttendanceRecords {
    private static func identifier(_ raw: Any?) -> String? {
        if let string = raw as? String,
           !string.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return string }
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            let value = number.doubleValue
            guard value.isFinite && value.rounded() == value else { return nil }
            return number.stringValue
        }
        return nil
    }
    private static func reference(_ raw: Any?) -> String? {
        guard let dict = raw as? [String: Any] else { return nil }
        return identifier(dict["Id"])
    }
    /// The gateway sometimes represents lesson and semester numbers as strings.
    /// Reject booleans, fractions and malformed values instead of silently turning them into 0/1.
    private static func positiveNumber(_ raw: Any?) -> Int? {
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            let value = number.doubleValue
            if value.isFinite && value >= 1 && value <= Double(Int.max) && value.rounded() == value {
                return number.intValue
            }
        }
        if let string = raw as? String, !string.isEmpty,
           string.utf8.allSatisfy({ (48...57).contains($0) }),
           let value = Int(string), value > 0 { return value }
        return nil
    }
    // JSON booleans are CFBoolean; `as? Bool` also bridges NSNumber(0/1),
    // which could silently misclassify a status supplied with the wrong type.
    private static func jsonBoolean(_ raw: Any?) -> Bool? {
        guard let number = raw as? NSNumber,
              CFGetTypeID(number) == CFBooleanGetTypeID() else { return nil }
        return number.boolValue
    }
    private struct AttendanceType {
        let name: String
        let isPresenceKind: Bool
    }

    static func decode(attendances: [String: Any], types: [String: Any],
                       lessons: [String: Any]) throws -> [DirectAttendance] {
        guard let rows = attendances["Attendances"] as? [[String: Any]] else {
            throw AttendanceDecodeError.malformedRoot("Attendances")
        }
        guard let typeRows = types["Types"] as? [[String: Any]] else {
            throw AttendanceDecodeError.malformedRoot("Types")
        }
        guard let lessonRows = lessons["Lessons"] as? [[String: Any]] else {
            throw AttendanceDecodeError.malformedRoot("Lessons")
        }
        var typeLookup: [String: AttendanceType] = [:]
        var knownTypeIds = Set<String>()
        for row in typeRows {
            guard let id = identifier(row["Id"]) else { continue }
            // Detect duplicates even if one row has malformed metadata. Otherwise
            // a conflicting definition could be silently ignored.
            guard knownTypeIds.insert(id).inserted else {
                throw AttendanceDecodeError.duplicateReference("Type: " + id)
            }
            guard let name = row["Name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  let present = jsonBoolean(row["IsPresenceKind"]) else { continue }
            typeLookup[id] = AttendanceType(name: name, isPresenceKind: present)
        }
        // Lessons maps lesson Id -> Subject.Id. An unresolved subject remains nil;
        // never fabricate a subject from a timetable's position.
        var subjectsByLesson: [String: String] = [:]
        var knownLessonIds = Set<String>()
        for row in lessonRows {
            guard let id = identifier(row["Id"]) else { continue }
            guard knownLessonIds.insert(id).inserted else { throw AttendanceDecodeError.duplicateReference("Lesson: " + id) }
            subjectsByLesson[id] = reference(row["Subject"])
        }
        var seen = Set<String>()
        var result: [DirectAttendance] = []
        result.reserveCapacity(rows.count)
        for (index, row) in rows.enumerated() {
            guard let id = identifier(row["Id"]),
                  let date = row["Date"] as? String,
                  !date.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  let lessonId = reference(row["Lesson"]),
                  let typeId = reference(row["Type"]) else {
                throw AttendanceDecodeError.malformedRecord(index)
            }
            guard seen.insert(id).inserted else { throw AttendanceDecodeError.duplicateRecord(id) }
            guard let type = typeLookup[typeId] else {
                // If we cannot resolve a status, do not show an invented presence/absence.
                throw AttendanceDecodeError.missingAttendanceType(typeId)
            }
            let lessonNo = positiveNumber(row["LessonNo"])
            let semester = positiveNumber(row["Semester"])
            result.append(DirectAttendance(id: id, date: date, lessonNumber: lessonNo,
                semester: semester, lessonId: lessonId,
                subjectId: subjectsByLesson[lessonId], typeId: typeId,
                typeName: type.name, isPresenceKind: type.isPresenceKind))
        }
        return result
    }
}
