import SwiftUI

@main
struct SynergiaDirectApp: App {
    @StateObject private var portal = SynergiaPortal()
    var body: some Scene {
        WindowGroup { MainView().environmentObject(portal) }
    }
}
