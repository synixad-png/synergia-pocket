import Foundation
import WebKit

// Direct, read-only JSON transport, using the user's existing WebKit session.
// This does not access credentials or private browser storage outside the
// authenticated Synergia cookie jar. No server owned by this app is involved.
// Access to undocumented endpoints must be revalidated on a real account.
enum GatewayReadError: Error, LocalizedError, Equatable {
    case noAuthenticatedSession
    case forbidden
    case loginRequired
    case serviceUnavailable(Int)
    case invalidResponse
    case unexpectedHost
    case invalidContinuation
    case responseTooLarge
    case transport(DirectConnectionIssue)

    var errorDescription: String? {
        switch self {
        case .noAuthenticatedSession, .loginRequired: return DirectConnectionIssue.loginRequired.message
        case .forbidden: return DirectConnectionIssue.forbidden.message
        case .serviceUnavailable(let status): return DirectConnectionIssue.http(status).message
        case .invalidResponse, .invalidContinuation: return DirectConnectionIssue.invalidResponse.message
        case .unexpectedHost: return "Żądanie zostało zablokowane — nieznana domena."
        case .responseTooLarge: return "Serwer zwrócił zbyt dużo danych. Nie nadpisano lokalnego zapisu."
        case .transport(let issue): return issue.message
        }
    }
}

struct GatewayResponse {
    let endpoint: String
    let json: [String: Any]
}

private final class NoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

@MainActor
final class SynergiaGatewayClient {
    private let cookieStore: WKHTTPCookieStore
    private let session: URLSession
    private let redirectDelegate: NoRedirects?
    private static let baseURL = URL(string: "https://synergia.librus.pl/gateway/api/2.0/")!

    init(webView: WKWebView) {
        self.cookieStore = webView.configuration.websiteDataStore.httpCookieStore
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        let delegate = NoRedirects()
        self.redirectDelegate = delegate
        self.session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
    }

    private func cookies() async -> [HTTPCookie] {
        await withCheckedContinuation { continuation in
            cookieStore.getAllCookies { continuation.resume(returning: $0) }
        }
    }

    // Strict endpoint allow-list: user input never becomes a request path.
    enum Resource: String {
        case grades = "Grades"
        case descriptiveGrades = "DescriptiveGrades"
        case pointGrades = "PointGrades"
        case baseTextGrades = "BaseTextGrades"
        case behaviourPointGrades = "BehaviourGrades/Points"
        case gradeComments = "Grades/Comments"
        case gradeCategories = "Grades/Categories"
        case subjects = "Subjects"
        case attendance = "Attendances"
        case attendanceTypes = "Attendances/Types"
        case lessons = "Lessons"
        case classrooms = "Classrooms"
        case users = "Users"
        // Verified names from the gateway's resource list. HomeWorks is the agenda;
        // HomeWorkAssignments holds the student's actual homework.
        case homework = "HomeWorks"
        case homeworkAssignments = "HomeWorkAssignments"
        case schoolFiles = "SchoolFiles"
        case planChanges = "Calendars/Substitutions"
        case timetables = "Timetables"
        case schoolNotices = "SchoolNotices"
        case me = "Me"
    }

    func read(_ resource: Resource) async throws -> GatewayResponse {
        let url = Self.baseURL.appendingPathComponent(resource.rawValue)
        return try await readValidated(url, resource: resource)
    }

    /// SchoolNotices page/limit are independently evidenced by the client API.
    /// There is no arbitrary URL or user-controlled request path.
    func readSchoolNoticesPage(_ page: Int) async throws -> GatewayResponse {
        guard (1...DirectSchoolNoticePaging.maximumPages).contains(page) else {
            throw GatewayReadError.invalidContinuation
        }
        var components = URLComponents(url: Self.baseURL.appendingPathComponent(Resource.schoolNotices.rawValue),
                                       resolvingAgainstBaseURL: false)
        components?.queryItems = [URLQueryItem(name: "page", value: String(page)),
                                  URLQueryItem(name: "limit", value: String(DirectSchoolNoticePaging.pageSize))]
        guard let url = components?.url else { throw GatewayReadError.invalidContinuation }
        return try await readValidated(url, resource: .schoolNotices)
    }

    /// Explicitly supported query for the selected ISO school week.
    /// Unlike grade continuation, no arbitrary server-provided URL is accepted.
    func readTimetable(monday: String) async throws -> GatewayResponse {
        guard DirectTimetableParser.isMonday(monday) else { throw GatewayReadError.invalidContinuation }
        var components = URLComponents(url: Self.baseURL.appendingPathComponent(Resource.timetables.rawValue),
                                       resolvingAgainstBaseURL: false)
        components?.queryItems = [URLQueryItem(name: "weekStart", value: monday)]
        guard let url = components?.url else { throw GatewayReadError.invalidContinuation }
        return try await readValidated(url, resource: .timetables)
    }

    /// A bounded author lookup, only for Ids already referenced by fetched Grades.
    /// No user-controlled paths or arbitrary server links are allowed.
    func readUser(id: String) async throws -> GatewayResponse {
        guard DirectGradeAuthors.requestableUserId(id) else {
            throw GatewayReadError.invalidContinuation
        }
        let path = Self.baseURL.appendingPathComponent(Resource.users.rawValue)
            .appendingPathComponent(id)
        return try await readValidated(path, resource: .users, userId: id)
    }

    /// Resolves only explicit AddedBy IDs. All names from a previous read
    /// are retained only after the caller has verified the same account.
    func readGradeAuthors(grades: [DirectGrade], previous: [String: String]) async throws -> DirectGradeAuthorResolution {
        guard grades.contains(where: { $0.teacherId != nil }) else {
            return DirectGradeAuthors.reconcile(grades: grades, current: [:], previous: previous)
        }
        var current: [String: String] = [:]
        do {
            current = try DirectGradeAuthors.decode((try await read(.users)).json)
        } catch GatewayReadError.loginRequired { throw GatewayReadError.loginRequired }
        catch GatewayReadError.noAuthenticatedSession { throw GatewayReadError.noAuthenticatedSession }
        catch GatewayReadError.transport(let issue) where issue == .loginRequired { throw GatewayReadError.loginRequired }
        catch { /* An unsupported list shape or forbidden Users list is optional. */ }
        // Avoid hundreds of sequential requests on large gradebooks.
        let needed = DirectGradeAuthors.missingIds(grades, users: current)
            .filter(DirectGradeAuthors.requestableUserId).prefix(24)
        for id in needed {
            do {
                let name = try DirectGradeAuthors.decodeSingle((try await readUser(id: id)).json,
                    requestedId: id)
                if let name, !name.isEmpty { current[id] = name }
            } catch GatewayReadError.loginRequired { throw GatewayReadError.loginRequired }
            catch GatewayReadError.noAuthenticatedSession { throw GatewayReadError.noAuthenticatedSession }
            catch GatewayReadError.forbidden { break }
            catch GatewayReadError.transport(let issue) where issue == .loginRequired { throw GatewayReadError.loginRequired }
            catch GatewayReadError.transport { break }
            catch GatewayReadError.serviceUnavailable(let code) where code == 429 || code == 503 { break }
            catch { /* Missing/invalid single record is never a fabricated name. */ }
        }
        return DirectGradeAuthors.reconcile(grades: grades, current: current, previous: previous)
    }

    // Only for paging Grades. The server must explicitly supply the next URL;
    // the client never invents page numbers, offsets, tokens or query parameters.
    func readGradeContinuation(_ url: URL) async throws -> GatewayResponse {
        guard GatewayJSONPolicy.safeContinuationQuery(url) else {
            throw GatewayReadError.invalidContinuation
        }
        return try await readValidated(url, resource: .grades)
    }

    private func readValidated(_ url: URL, resource: Resource, userId: String? = nil) async throws -> GatewayResponse {
        let basePath = Self.baseURL.appendingPathComponent(resource.rawValue)
        let permitted: URL
        if let userId {
            guard resource == .users, DirectGradeAuthors.requestableUserId(userId) else {
                throw GatewayReadError.invalidContinuation
            }
            permitted = basePath.appendingPathComponent(userId)
        } else { permitted = basePath }
        guard url.scheme == "https", url.host?.lowercased() == "synergia.librus.pl",
              url.port == nil, url.user == nil, url.password == nil,
              url.fragment == nil, url.path == permitted.path else {
            throw GatewayReadError.invalidContinuation
        }
        if userId != nil && url.query != nil { throw GatewayReadError.invalidContinuation }
        if url.query != nil && resource != .grades && resource != .schoolNotices && resource != .timetables {
            throw GatewayReadError.invalidContinuation
        }
        if resource == .grades && url.query != nil && !GatewayJSONPolicy.safeContinuationQuery(url) {
            throw GatewayReadError.invalidContinuation
        }
        if resource == .schoolNotices, url.query != nil {
            guard let fields = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems,
                  fields.count == 2, fields[0].name == "page", fields[1].name == "limit",
                  let rawPage = fields[0].value, let page = Int(rawPage),
                  (1...DirectSchoolNoticePaging.maximumPages).contains(page),
                  rawPage == String(page), fields[1].value == String(DirectSchoolNoticePaging.pageSize)
            else { throw GatewayReadError.invalidContinuation }
        }
        if resource == .timetables {
            guard let fields = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems,
                  fields.count == 1, fields[0].name == "weekStart",
                  let week = fields[0].value, DirectTimetableParser.isMonday(week) else {
                throw GatewayReadError.invalidContinuation
            }
        }
        let allCookies = await cookies()
        let applicable = GatewayJSONPolicy.applicableCookies(allCookies, to: url)
        guard !applicable.isEmpty else { throw GatewayReadError.noAuthenticatedSession }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpShouldHandleCookies = false
        request.setValue(HTTPCookie.requestHeaderFields(with: applicable)["Cookie"], forHTTPHeaderField: "Cookie")
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw GatewayReadError.transport(DirectConnectionIssue.network(error))
        }
        guard let http = response as? HTTPURLResponse,
              http.url?.scheme == "https", http.url?.host?.lowercased() == "synergia.librus.pl",
              http.url?.path == permitted.path,
              http.url == url else { throw GatewayReadError.invalidResponse }
        switch http.statusCode {
        case 200: break
        case 401: throw GatewayReadError.loginRequired
        case 403: throw GatewayReadError.forbidden
        case 301, 302, 303, 307, 308:
            throw GatewayReadError.transport(DirectConnectionIssue.redirect(
                status: http.statusCode, location: http.value(forHTTPHeaderField: "Location"), from: url))
        case 408, 429, 503: throw GatewayReadError.transport(.http(http.statusCode))
        default: throw GatewayReadError.serviceUnavailable(http.statusCode)
        }
        guard GatewayJSONPolicy.withinJSONLimit(bodyBytes: data.count,
                expectedBytes: http.expectedContentLength) else { throw GatewayReadError.responseTooLarge }
        guard GatewayJSONPolicy.isJSONContentType(http.value(forHTTPHeaderField: "Content-Type")),
              let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
            throw GatewayReadError.invalidResponse
        }
        return GatewayResponse(endpoint: resource.rawValue, json: object)
    }

}
