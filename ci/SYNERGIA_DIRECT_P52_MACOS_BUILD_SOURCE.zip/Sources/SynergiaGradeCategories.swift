import Foundation
import CoreFoundation

// Category metadata from the Grades/Categories resource. Null
// CountToTheAverage has the documented default true; explicit false
// must not be lost. Weight=0 is a meaningful value, never replaced by 1.
struct DirectGradeCategory: Codable, Equatable {
    let id: String
    let name: String
    let weight: Double?
    let countsToAverage: Bool?
}

enum GradeCategoryError: Error, Equatable {
    case missingRoot
    case invalidRecord(Int)
    case duplicateIdentity(String)
    case invalidWeight(Int)
    case invalidCountingFlag(Int)
}

enum SynergiaGradeCategories {
    private static func identifier(_ raw: Any?) -> String? {
        if let text = raw as? String, !text.isEmpty { return text }
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            return number.stringValue
        }
        return nil
    }

    private static func weight(_ raw: Any?, index: Int) throws -> Double? {
        guard let raw, !(raw is NSNull) else { return nil }
        if let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            let value = number.doubleValue
            guard value.isFinite, value >= 0 else { throw GradeCategoryError.invalidWeight(index) }
            return value
        }
        if let text = raw as? String, let value = Double(text), value.isFinite, value >= 0 { return value }
        throw GradeCategoryError.invalidWeight(index)
    }

    private static func counts(_ row: [String: Any], index: Int) throws -> Bool? {
        guard let raw = row["CountToTheAverage"] else { return nil }
        if raw is NSNull { return true }
        guard let number = raw as? NSNumber, CFGetTypeID(number) == CFBooleanGetTypeID() else {
            throw GradeCategoryError.invalidCountingFlag(index)
        }
        return number.boolValue
    }

    static func decode(_ root: [String: Any]) throws -> [String: DirectGradeCategory] {
        guard let rows = root["Categories"] as? [[String: Any]] else { throw GradeCategoryError.missingRoot }
        var categories: [String: DirectGradeCategory] = [:]
        for (index, row) in rows.enumerated() {
            guard let id = identifier(row["Id"]), let name = row["Name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw GradeCategoryError.invalidRecord(index)
            }
            guard categories[id] == nil else { throw GradeCategoryError.duplicateIdentity(id) }
            categories[id] = DirectGradeCategory(id: id, name: name,
                weight: try weight(row["Weight"], index: index),
                countsToAverage: try counts(row, index: index))
        }
        return categories
    }

    // Does not guess missing categories. The caller can show category ID and
    // explicitly report unmatched references instead of silently inventing metadata.
    static func enrich(_ grades: [DirectGrade], categories: [String: DirectGradeCategory]) -> [DirectGrade] {
        grades.map { grade in
            var updated = grade
            if let id = grade.categoryId, let category = categories[id] {
                updated.categoryName = category.name
                updated.weight = category.weight
                updated.countsToAverage = category.countsToAverage
            }
            return updated
        }
    }

    static func unresolvedCategoryIds(_ grades: [DirectGrade], categories: [String: DirectGradeCategory]) -> [String] {
        Array(Set(grades.compactMap(\.categoryId).filter { categories[$0] == nil })).sorted()
    }
}
