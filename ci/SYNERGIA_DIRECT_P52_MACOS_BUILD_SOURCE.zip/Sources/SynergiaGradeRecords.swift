import Foundation
import CoreFoundation

// JSON structure verified against the public 2026 Synergia API field notes.
// Correctness on the user's account still requires authorized integration tests.
struct DirectGrade: Codable, Equatable, Identifiable {
    let id: String
    let subjectId: String
    let categoryId: String?
    let value: String
    let semester: Int?
    let addedAt: String?
    let commentTexts: [String]
    // Optional: older account-scoped caches remain decodable.
    var categoryName: String? = nil
    // Optional for backward compatibility with previous account-scoped snapshots.
    var teacherId: String? = nil
    var weight: Double? = nil
    var countsToAverage: Bool? = nil
}

enum DirectGradeDecodeError: Error, Equatable {
    case malformedRoot
    case duplicateIdentity(String)
    case missingReference(String)
    case invalidSemester(String)
    case malformedComments
    case missingCommentReference(String)
    case malformedGradeComments(String)
    case malformedCategory(String)
    case invalidGradeValue(String)
    case invalidAddedDate(String)
    case malformedTeacherReference(String)
}

enum SynergiaGradeRecords {
    private static func id(_ raw: Any?) -> String? {
        if let s = raw as? String, !s.isEmpty { return s }
        if let n = raw as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
           n.doubleValue.isFinite, n.doubleValue.rounded() == n.doubleValue { return n.stringValue }
        return nil
    }
    private static func reference(_ raw: Any?) -> String? {
        guard let dictionary = raw as? [String: Any] else { return nil }
        return id(dictionary["Id"])
    }
    static func decode(grades: [String: Any], comments: [String: Any]?) throws -> [DirectGrade] {
        guard let rawGrades = grades["Grades"] as? [[String: Any]] else { throw DirectGradeDecodeError.malformedRoot }
        let rawComments: [[String: Any]]
        if let comments {
            guard let entries = comments["Comments"] as? [[String: Any]] else {
                throw DirectGradeDecodeError.malformedComments
            }
            rawComments = entries
        } else { rawComments = [] }
        var commentLookup: [String: String] = [:]
        do {
            for comment in rawComments {
                guard let cid = id(comment["Id"]), let text = comment["Text"] as? String, commentLookup[cid] == nil else {
                    throw DirectGradeDecodeError.malformedComments
                }
                commentLookup[cid] = text
            }
        }
        var seen = Set<String>()
        return try rawGrades.map { item in
            guard let gradeID = id(item["Id"]),
                  let subjectID = reference(item["Subject"]),
                  let value = item["Grade"] as? String else { throw DirectGradeDecodeError.missingReference("Id / Subject.Id / Grade") }
            guard !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw DirectGradeDecodeError.invalidGradeValue(gradeID)
            }
            guard seen.insert(gradeID).inserted else { throw DirectGradeDecodeError.duplicateIdentity(gradeID) }
            // Wrong date types must not be silently treated as an absent date.
            let addedAt: String?
            if let rawDate = item["AddDate"], !(rawDate is NSNull) {
                guard let date = rawDate as? String,
                      !date.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    throw DirectGradeDecodeError.invalidAddedDate(gradeID)
                }
                addedAt = date
            } else {
                addedAt = nil
            }
            // Distinguish an absent/explicitly null optional field from a broken
            // JSON shape. A malformed list must not silently erase comments.
            let rawRefs: [Any]
            if let raw = item["Comments"], !(raw is NSNull) {
                guard let refs = raw as? [Any] else {
                    throw DirectGradeDecodeError.malformedGradeComments(gradeID)
                }
                rawRefs = refs
            } else { rawRefs = [] }
            // An invalid category reference cannot be interpreted as the grade
            // having no category; that would hide its weight and averaging flag.
            let categoryID: String?
            if let rawCategory = item["Category"], !(rawCategory is NSNull) {
                guard let category = reference(rawCategory) else {
                    throw DirectGradeDecodeError.malformedCategory(gradeID)
                }
                categoryID = category
            } else { categoryID = nil }
            let texts = try rawRefs.map { raw -> String in
                guard let cid = reference(raw) ?? id(raw), let text = commentLookup[cid] else {
                    throw DirectGradeDecodeError.missingCommentReference(gradeID)
                }
                return text
            }
            let semester: Int?
            if let raw = item["Semester"], !(raw is NSNull) {
                // Reject malformed semester instead of quietly treating it as unspecified.
                // Accept integral numeric values only; their meaning is reported, not guessed.
                if let number = raw as? NSNumber,
                   CFGetTypeID(number) != CFBooleanGetTypeID(),
                   number.doubleValue.isFinite,
                   number.doubleValue.rounded() == number.doubleValue,
                   number.doubleValue >= Double(Int.min),
                   number.doubleValue <= Double(Int.max) {
                    semester = number.intValue
                } else { throw DirectGradeDecodeError.invalidSemester(gradeID) }
            } else { semester = nil }
            var grade = DirectGrade(id: gradeID, subjectId: subjectID,
                 categoryId: categoryID, value: value,
                 semester: semester, addedAt: addedAt, commentTexts: texts)
            // Published integrations associate a grade's AddedBy reference with
            // a user. Never infer the teacher from the subject or timetable.
            if let rawAuthor = item["AddedBy"], !(rawAuthor is NSNull) {
                guard let authorId = reference(rawAuthor) else {
                    throw DirectGradeDecodeError.malformedTeacherReference(gradeID)
                }
                grade.teacherId = authorId
            }
            return grade
        }
    }
}
