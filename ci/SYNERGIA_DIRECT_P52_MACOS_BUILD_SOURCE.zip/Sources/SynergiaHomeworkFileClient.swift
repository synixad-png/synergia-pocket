import Foundation
import WebKit

private final class HomeworkNoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

/// One explicit user-initiated download. Does not send cookies to sandbox.librus.pl.
/// No background downloads, automatic account login, or untrusted redirects.
@MainActor
final class SynergiaHomeworkFileClient {
    private let cookies: WKHTTPCookieStore
    private let delegate: HomeworkNoRedirects
    private let session: URLSession

    init(webView: WKWebView) {
        cookies = webView.configuration.websiteDataStore.httpCookieStore
        delegate = HomeworkNoRedirects()
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
    }

    func download(_ file: DirectHomeworkFileReference) async throws -> Data {
        let origin = try DirectHomeworkFilePolicy.downloadURL(file)
        let available: [HTTPCookie] = await withCheckedContinuation { continuation in
            cookies.getAllCookies { continuation.resume(returning: $0) }
        }
        let matching = available.filter { cookie in
            let domain = cookie.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            return (domain == "synergia.librus.pl" || domain == "librus.pl") &&
                cookie.isSecure && origin.path.hasPrefix(cookie.path) &&
                (cookie.expiresDate.map { $0 > Date() } ?? true)
        }
        guard !matching.isEmpty else { throw DirectHomeworkFileError.accountChanged }
        let deadline = Date().addingTimeInterval(150)
        // A key can be revoked by the sandbox before it becomes ready.
        // A fresh ticket from Synergia is obtained at most three times.
        for round in 0..<3 {
            try Task.checkCancellation()
            guard Date() < deadline else { throw DirectHomeworkFileError.notReady }
            var request = URLRequest(url: origin, cachePolicy: .reloadIgnoringLocalCacheData,
                                     timeoutInterval: 25)
            request.httpMethod = "GET"
            request.httpShouldHandleCookies = false
            request.setValue(HTTPCookie.requestHeaderFields(with: matching)["Cookie"], forHTTPHeaderField: "Cookie")
            let (body, reply) = try await session.data(for: request)
            guard body.count <= 64_000, let http = reply as? HTTPURLResponse,
                  http.url == origin else { throw DirectHomeworkFileError.invalidResponse }
            if http.statusCode == 401 || http.statusCode == 403 ||
               (http.statusCode == 200 && http.value(forHTTPHeaderField: "Location") == nil) {
                throw DirectHomeworkFileError.accountChanged
            }
            guard [302, 303].contains(http.statusCode),
                  let location = http.value(forHTTPHeaderField: "Location") else {
                throw DirectHomeworkFileError.invalidResponse
            }
            let ticket = try DirectHomeworkFilePolicy.ticket(location)
            switch ticket {
            case .getFile(let url):
                return try await downloadGetFile(page: url, deadline: deadline)
            case .singleUseKey(let page, let key):
                if let result = try await downloadWithKey(page: page, key: key, deadline: deadline) {
                    return result
                }
                if round == 2 { throw DirectHomeworkFileError.notReady }
            }
        }
        throw DirectHomeworkFileError.notReady
    }

    private func smallWaitingPage(_ page: URL) async throws {
        var req = URLRequest(url: page, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        req.httpShouldHandleCookies = false
        let (stream, response) = try await session.bytes(for: req)
        guard let http = response as? HTTPURLResponse, http.url == page,
              http.statusCode == 200, http.expectedContentLength <= 128_000 else {
            throw DirectHomeworkFileError.invalidResponse
        }
        var count = 0
        for try await _ in stream {
            count += 1
            if count > 128_000 { throw DirectHomeworkFileError.invalidResponse }
        }
    }

    private func readFile(_ url: URL, referer: URL) async throws -> Data? {
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        req.httpMethod = "GET"
        req.httpShouldHandleCookies = false
        req.setValue(referer.absoluteString, forHTTPHeaderField: "Referer")
        let (bytes, response) = try await session.bytes(for: req)
        guard let http = response as? HTTPURLResponse, http.url == url else {
            throw DirectHomeworkFileError.invalidResponse
        }
        let type = http.value(forHTTPHeaderField: "Content-Type")?.lowercased()
        if http.statusCode == 200 && (type?.contains("text/html") == true ||
                                      type?.contains("application/xhtml") == true) {
            return nil // Waiting page is not an attachment.
        }
        guard DirectHomeworkFilePolicy.fileResponseOK(status: http.statusCode, type: type,
                                                      size: http.expectedContentLength) else {
            throw DirectHomeworkFileError.invalidResponse
        }
        var data = Data()
        for try await byte in bytes {
            if data.count >= DirectHomeworkFilePolicy.maxBytes { throw DirectHomeworkFileError.fileTooLarge }
            data.append(byte)
        }
        guard !data.isEmpty else { throw DirectHomeworkFileError.emptyFile }
        return data
    }

    private func downloadGetFile(page: URL, deadline: Date) async throws -> Data {
        try await smallWaitingPage(page)
        let target = page.appendingPathComponent("get")
        guard target.scheme == "https", target.host == "sandbox.librus.pl",
              target.query == nil, target.path == page.path + "/get" else {
            throw DirectHomeworkFileError.untrustedRedirect
        }
        for attempt in 0..<15 {
            try Task.checkCancellation()
            guard Date() < deadline else { throw DirectHomeworkFileError.notReady }
            if let data = try await readFile(target, referer: page) { return data }
            if attempt < 14 { try await Task.sleep(nanoseconds: 2_000_000_000) }
        }
        throw DirectHomeworkFileError.notReady
    }

    /// Nil means the particular single-use key failed: caller can request
    /// another ticket, never by blindly retrying a POST to a different host.
    private func downloadWithKey(page: URL, key: String, deadline: Date) async throws -> Data? {
        try await smallWaitingPage(page)
        let statusURL = try DirectHomeworkFilePolicy.keyURL(action: "CSCheckKey")
        for attempt in 0..<15 {
            try Task.checkCancellation()
            guard Date() < deadline else { throw DirectHomeworkFileError.notReady }
            var request = URLRequest(url: statusURL, cachePolicy: .reloadIgnoringLocalCacheData,
                                     timeoutInterval: 15)
            request.httpMethod = "POST"
            request.httpShouldHandleCookies = false
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.setValue(page.absoluteString, forHTTPHeaderField: "Referer")
            request.httpBody = Data("singleUseKey=\(key)".utf8)
            let (raw, answer) = try await session.data(for: request)
            guard let http = answer as? HTTPURLResponse, http.url == statusURL,
                  http.statusCode == 200, raw.count <= 16_000 else { return nil }
            guard let dictionary = (try? JSONSerialization.jsonObject(with: raw)) as? [String: Any],
                  let state = dictionary["status"] as? String else { return nil }
            if state == "ready" {
                let url = try DirectHomeworkFilePolicy.keyURL(action: "CSDownload", key: key)
                guard let data = try await readFile(url, referer: page) else {
                    throw DirectHomeworkFileError.invalidResponse
                }
                return data
            }
            if state != "not_downloaded_yet" { return nil }
            if attempt < 14 {
                let seconds: UInt64 = attempt < 3 ? 3 : 10
                try await Task.sleep(nanoseconds: seconds * 1_000_000_000)
            }
        }
        throw DirectHomeworkFileError.notReady
    }
}
