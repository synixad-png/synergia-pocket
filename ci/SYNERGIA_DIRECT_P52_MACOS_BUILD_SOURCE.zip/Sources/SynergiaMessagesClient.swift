import Foundation
import WebKit

/// Osobny klient domeny Wiadomości. Odczyt GET oraz wysyłanie jednym POST
/// wyłącznie po ręcznym potwierdzeniu. Nie przechowuje haseł, nie przekazuje
/// cookies obcym domenom ani nie śledzi przekierowań.
enum DirectMessagesTransportError: Error, LocalizedError, Equatable {
    case bootstrapRequired, invalidRequest, invalidResponse, responseTooLarge
    case authorizationRequired, forbidden, unavailable(Int), transport(DirectConnectionIssue)

    var errorDescription: String? {
        switch self {
        case .bootstrapRequired:
            return "Najpierw otwórz Wiadomości w oficjalnej Synergii, aby uruchomić sesję drugiej domeny."
        case .invalidRequest: return "Zablokowano nieprawidłowy adres żądania."
        case .invalidResponse: return "Serwer zwrócił nieznaną odpowiedź."
        case .responseTooLarge: return "Odpowiedź serwera jest zbyt duża."
        case .authorizationRequired: return "Sesja Wiadomości wygasła. Otwórz oficjalną Synergię."
        case .forbidden: return "Brak dostępu do Wiadomości (403)."
        case .unavailable(let code): return DirectConnectionIssue.http(code).message
        case .transport(let issue): return issue.message
        }
    }
}

private final class MessagesNoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

@MainActor
final class SynergiaMessagesClient {
    private let cookieStore: WKHTTPCookieStore
    private let session: URLSession
    private let delegate: MessagesNoRedirects
    private static let apiBase = URL(string: "https://wiadomosci.librus.pl/api/")!

    init(webView: WKWebView) {
        cookieStore = webView.configuration.websiteDataStore.httpCookieStore
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        delegate = MessagesNoRedirects()
        session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
    }

    private func authorizedRequest(_ path: String, query: [URLQueryItem] = [],
                                   method: String = "GET") async throws -> URLRequest {
        let url = Self.apiBase.appendingPathComponent(path)
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        if !query.isEmpty { components?.queryItems = query }
        guard let target = components?.url,
              target.scheme == "https", target.host == "wiadomosci.librus.pl",
              target.port == nil, target.user == nil, target.password == nil,
              target.fragment == nil, target.path == url.path,
              target.path.hasPrefix(Self.apiBase.path),
              method == "GET" || method == "POST" else {
            throw DirectMessagesTransportError.invalidRequest
        }
        let cookies: [HTTPCookie] = await withCheckedContinuation { continuation in
            cookieStore.getAllCookies { continuation.resume(returning: $0) }
        }
        let applicable = cookies.filter { cookie in
            let domain = cookie.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            return (domain == "wiadomosci.librus.pl" || domain == "librus.pl") &&
                cookie.isSecure && target.path.hasPrefix(cookie.path) &&
                (cookie.expiresDate.map { $0 > Date() } ?? true)
        }
        guard applicable.contains(where: {
            $0.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".")) == "wiadomosci.librus.pl"
        }) else { throw DirectMessagesTransportError.bootstrapRequired }
        var req = URLRequest(url: target, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        req.httpMethod = method
        req.httpShouldHandleCookies = false
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue(HTTPCookie.requestHeaderFields(with: applicable)["Cookie"], forHTTPHeaderField: "Cookie")
        return req
    }

    private func requestPayload(_ path: String, query: [URLQueryItem] = []) async throws -> Any {
        let req = try await authorizedRequest(path, query: query)
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: req)
        } catch {
            throw DirectMessagesTransportError.transport(DirectConnectionIssue.network(error))
        }
        guard let http = response as? HTTPURLResponse,
              http.url?.host == "wiadomosci.librus.pl", http.url?.scheme == "https",
              http.url?.path == req.url?.path else { throw DirectMessagesTransportError.invalidResponse }
        switch http.statusCode {
        case 200: break
        case 401: throw DirectMessagesTransportError.authorizationRequired
        case 403: throw DirectMessagesTransportError.forbidden
        case 301, 302, 303, 307, 308:
            let issue = DirectConnectionIssue.redirect(status: http.statusCode,
                location: http.value(forHTTPHeaderField: "Location"), from: req.url!)
            if issue == .loginRequired { throw DirectMessagesTransportError.authorizationRequired }
            throw DirectMessagesTransportError.transport(issue)
        case 408, 429, 503: throw DirectMessagesTransportError.transport(.http(http.statusCode))
        default: throw DirectMessagesTransportError.unavailable(http.statusCode)
        }
        guard data.count <= 4_000_000 else { throw DirectMessagesTransportError.responseTooLarge }
        guard http.value(forHTTPHeaderField: "Content-Type")?.lowercased().contains("json") == true,
              let payload = try? JSONSerialization.jsonObject(with: data),
              payload is [String: Any] || payload is [[String: Any]] else {
            throw DirectMessagesTransportError.invalidResponse
        }
        return payload
    }

    private func request(_ path: String, query: [URLQueryItem] = []) async throws -> [String: Any] {
        guard let dictionary = try await requestPayload(path, query: query) as? [String: Any] else {
            throw DirectMessagesTransportError.invalidResponse
        }
        return dictionary
    }

    /// Czytamy /me przed POST, aby sprawdzić aktualną sesję domeny Wiadomości.
    /// Odbiorcy i tożsamość ucznia są dodatkowo weryfikowani przez Portal.
    func currentSessionAccountId() async throws -> String {
        let json = try await request("me")
        // W zależności od podwersji endpoint może zwrócić data lub pola root.
        let record = (json["data"] as? [String: Any]) ?? json
        let identifier: String?
        if let raw = record["accountId"] as? String { identifier = raw }
        else if let n = record["accountId"] as? NSNumber { identifier = n.stringValue }
        else { identifier = nil }
        guard let id = identifier, DirectMessageParser.safeIdentifier(id) else {
            throw DirectMessagesTransportError.invalidResponse
        }
        return id
    }

    /// JEDEN POST po dwustopniowej akcji użytkownika. Nigdy nie ponawiaj po
    /// timeout/5xx/niejednoznacznym HTTP: wiadomość mogła zostać dostarczona.
    func sendOnce(_ draft: DirectValidatedDraft) async throws -> DirectSendResult {
        let path = draft.originalMessageId == nil ? "messages" : "messages/reply"
        var req = try await authorizedRequest(path, method: "POST")
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: DirectMessageCompose.payload(draft))
        do {
            let (data, response) = try await session.data(for: req)
            guard let http = response as? HTTPURLResponse,
                  http.url?.scheme == "https", http.url?.host == "wiadomosci.librus.pl",
                  http.url?.path == req.url?.path else {
                return .uncertain("Nieznana odpowiedź po wysyłce. Sprawdź Wysłane.")
            }
            return DirectSendResponse.evaluate(status: http.statusCode, data: data)
        } catch {
            return .uncertain("Połączenie zostało przerwane po rozpoczęciu wysyłki. Sprawdź Wysłane; nie wysyłaj ponownie bez sprawdzenia.")
        }
    }

    func recipientGroups() async throws -> [String: Any] {
        try await request("receivers/types", query: [URLQueryItem(name: "includeClass", value: "true")])
    }

    func recipients(groupId: String) async throws -> [String: Any] {
        guard DirectMessageParser.safeIdentifier(groupId) else { throw DirectMessagesTransportError.invalidRequest }
        return try await request("receivers/groups/school-employees", query: [
            URLQueryItem(name: "receiverType", value: groupId)
        ])
    }

    /// Pobieranie wyłącznie po bezpośredniej akcji użytkownika. HTTP GET do API
    /// pobiera tymczasowy, podpisany adres. Drugi GET nie zawiera ciasteczek ani
    /// nagłówków Synergii i nie podąża za przekierowaniami.
    func attachment(_ file: DirectMessageAttachment, messageId: String) async throws -> Data {
        guard DirectMessageParser.safeIdentifier(messageId),
              DirectMessageParser.safeIdentifier(file.id),
              DirectAttachmentPolicy.safeFileName(file.name) else {
            throw DirectMessagesTransportError.invalidRequest
        }
        if let size = file.sizeBytes, size > DirectAttachmentPolicy.maxBytes {
            throw DirectAttachmentError.sizeLimit
        }
        let json = try await request("attachments/\(file.id)/messages/\(messageId)")
        let ticketURL = try DirectAttachmentPolicy.ticket(json)
        let url = try DirectAttachmentPolicy.actualFileURL(ticketURL)
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
        req.httpMethod = "GET"
        req.httpShouldHandleCookies = false
        req.setValue("application/octet-stream, */*", forHTTPHeaderField: "Accept")
        req.setValue(ticketURL.absoluteString, forHTTPHeaderField: "Referer")
        let (bytes, response) = try await session.bytes(for: req)
        guard let http = response as? HTTPURLResponse,
              http.statusCode == 200, http.url == url,
              http.expectedContentLength <= Int64(DirectAttachmentPolicy.maxBytes) else {
            throw DirectAttachmentError.badResponse
        }
        if let mime = http.value(forHTTPHeaderField: "Content-Type")?.lowercased(),
           mime.contains("text/html") || mime.contains("application/xhtml") || mime.contains("application/json") {
            throw DirectAttachmentError.badResponse
        }
        var result = Data()
        for try await byte in bytes {
            if result.count >= DirectAttachmentPolicy.maxBytes { throw DirectAttachmentError.sizeLimit }
            result.append(byte)
        }
        guard !result.isEmpty else { throw DirectAttachmentError.emptyFile }
        // Login redirects may occasionally be delivered as 200/octet-stream.
        // Do not present an HTML sign-in/error page as the requested attachment.
        guard !DirectAttachmentPolicy.looksLikeHTML(result) else {
            throw DirectAttachmentError.badResponse
        }
        return result
    }

    func unreadCounts() async throws -> DirectUnreadCounts {
        let json = try await request("inbox/unreadMessagesCount")
        return try DirectUnreadCountParser.parse(json)
    }

    func list(_ mailbox: DirectMailbox, page: Int) async throws -> DirectMessagePage {
        guard (1...DirectMessageParser.maxPages).contains(page) else {
            throw DirectMessagesTransportError.invalidRequest
        }
        let json = try await requestPayload("\(mailbox.rawValue)/messages", query: [
            URLQueryItem(name: "page", value: String(page)),
            URLQueryItem(name: "limit", value: String(DirectMessageParser.pageSize))
        ])
        return try DirectMessageParser.list(json, mailbox: mailbox)
    }

    func detail(_ mailbox: DirectMailbox, id: String) async throws -> DirectMessageDetail {
        guard DirectMessageParser.safeIdentifier(id) else { throw DirectMessagesTransportError.invalidRequest }
        let json = try await request("\(mailbox.rawValue)/messages/\(id)")
        return try DirectMessageParser.detail(json, mailbox: mailbox, requestedId: id)
    }
}
