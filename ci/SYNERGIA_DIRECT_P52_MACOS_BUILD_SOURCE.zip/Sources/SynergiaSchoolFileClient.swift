import Foundation
import WebKit

private final class SchoolFilesNoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

/// Runs only after a deliberate tap. A strict redirect boundary separates
/// Synergia's cookies from its signed sandbox link. Neither request may
/// follow arbitrary HTTP redirects.
@MainActor
final class SynergiaSchoolFileClient {
    private let cookieStore: WKHTTPCookieStore
    private let delegate: SchoolFilesNoRedirects
    private let session: URLSession

    init(webView: WKWebView) {
        cookieStore = webView.configuration.websiteDataStore.httpCookieStore
        delegate = SchoolFilesNoRedirects()
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
    }

    func download(_ file: DirectSchoolFileReference) async throws -> Data {
        let initialURL = try DirectSchoolFilePolicy.documentURL(file)
        let allCookies: [HTTPCookie] = await withCheckedContinuation { continuation in
            cookieStore.getAllCookies { continuation.resume(returning: $0) }
        }
        let applicable = allCookies.filter { cookie in
            let domain = cookie.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
            return (domain == "synergia.librus.pl" || domain == "librus.pl") &&
                cookie.isSecure && initialURL.path.hasPrefix(cookie.path) &&
                (cookie.expiresDate.map { $0 > Date() } ?? true)
        }
        guard !applicable.isEmpty else { throw DirectSchoolFileError.accountChanged }
        var request = URLRequest(url: initialURL, cachePolicy: .reloadIgnoringLocalCacheData,
                                 timeoutInterval: 30)
        request.httpShouldHandleCookies = false
        request.httpMethod = "GET"
        request.setValue(HTTPCookie.requestHeaderFields(with: applicable)["Cookie"],
                         forHTTPHeaderField: "Cookie")
        let (_, response) = try await session.data(for: request)
        guard let redirect = response as? HTTPURLResponse,
              redirect.url == initialURL, redirect.statusCode == 302 || redirect.statusCode == 303,
              let rawLocation = redirect.value(forHTTPHeaderField: "Location") else {
            throw DirectSchoolFileError.invalidResponse
        }
        let ticket = try DirectSchoolFilePolicy.redirectTicket(rawLocation)
        let target = try DirectSchoolFilePolicy.actualDownloadURL(ticket)
        // Librus's GetFile endpoint is an HTML waiting page. Open it first,
        // without Synergia cookies, to initialize the transfer.
        var warm = URLRequest(url: ticket, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        warm.httpMethod = "GET"
        warm.httpShouldHandleCookies = false
        warm.setValue(ticket.absoluteString, forHTTPHeaderField: "Referer")
        let (waitingPage, warmResponse) = try await session.bytes(for: warm)
        guard let warmHTTP = warmResponse as? HTTPURLResponse,
              warmHTTP.url == ticket, warmHTTP.statusCode == 200,
              warmHTTP.expectedContentLength <= 128_000 else {
            throw DirectSchoolFileError.invalidResponse
        }
        var warmSize = 0
        for try await _ in waitingPage {
            warmSize += 1
            if warmSize > 128_000 { throw DirectSchoolFileError.invalidResponse }
        }

        var download = URLRequest(url: target, cachePolicy: .reloadIgnoringLocalCacheData,
                                  timeoutInterval: 30)
        download.httpMethod = "GET"
        download.httpShouldHandleCookies = false
        download.setValue(ticket.absoluteString, forHTTPHeaderField: "Referer")
        download.setValue("application/octet-stream, */*", forHTTPHeaderField: "Accept")
        // No Synergia Cookie, Authorization, or OAuth headers on the sandbox request.
        // On HTML waiting pages retry for a bounded 30 seconds, not indefinitely.
        let until = Date().addingTimeInterval(32)
        for attempt in 0..<15 {
            try Task.checkCancellation()
            let (stream, fileResponse) = try await session.bytes(for: download)
            guard let http = fileResponse as? HTTPURLResponse, http.url == target else {
                throw DirectSchoolFileError.invalidResponse
            }
            let type = http.value(forHTTPHeaderField: "Content-Type")?.lowercased()
            if http.statusCode == 200,
               (type?.contains("text/html") == true || type?.contains("application/xhtml") == true) {
                // The document isn't ready yet. Never save the waiting page as a file.
                if attempt == 14 || Date() >= until { throw DirectSchoolFileError.invalidResponse }
                try await Task.sleep(nanoseconds: 2_000_000_000)
                continue
            }
            guard DirectSchoolFilePolicy.validFileResponse(
                status: http.statusCode, contentType: type,
                length: http.expectedContentLength) else {
                throw DirectSchoolFileError.invalidResponse
            }
            var result = Data()
            for try await byte in stream {
                if result.count >= DirectSchoolFilePolicy.maxBytes { throw DirectSchoolFileError.fileTooLarge }
                result.append(byte)
            }
            guard !result.isEmpty else { throw DirectSchoolFileError.emptyFile }
            return result
        }
        throw DirectSchoolFileError.invalidResponse
    }
}
