import Foundation
import CoreFoundation

enum SynergiaSubjectError: Error, Equatable { case malformedRoot, duplicateIdentity(String), invalidIdentifier }

enum SynergiaSubjects {
    static func decode(_ root: [String: Any]) throws -> [String: String] {
        guard let entries = root["Subjects"] as? [[String: Any]] else { throw SynergiaSubjectError.malformedRoot }
        var subjects: [String: String] = [:]
        for entry in entries {
            let id: String?
            if let number = entry["Id"] as? NSNumber {
                guard CFGetTypeID(number) != CFBooleanGetTypeID(), number.doubleValue.isFinite,
                      number.doubleValue.rounded() == number.doubleValue else {
                    throw SynergiaSubjectError.invalidIdentifier
                }
                id = number.stringValue
            } else if let text = entry["Id"] as? String {
                id = text.isEmpty ? nil : text
            } else {
                id = nil
            }
            guard let id, !id.isEmpty, let name = entry["Name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }
            guard subjects[id] == nil else { throw SynergiaSubjectError.duplicateIdentity(id) }
            subjects[id] = name
        }
        return subjects
    }
}
