# SYNERGIA DIRECT v0.31 — etap 28

**66% wykonano / 34% pozostało** · stały harmonogram 36 zadań w `HARMONOGRAM_STALY.md`.

Zakończone w tym etapie w dostępnej części: zadanie 12 „Frekwencja — statusy” 75% → 90%; klasyfikacja nie rozstrzyga wniosków i oczekujących statusów jako usprawiedliwionych, a dane i historyczne testy pozostają zachowane. Dokumentacja: `RAPORT_PAKIET_28_STATUSY_FREKWENCJI.md`.

**Pozostało:** sprawdzenie znaczenia statusów szkoły w rzeczywistej Synergii i test interaktywny iPhone; brak Xcode/IPA.
**Dalej:** zadanie 13 „Frekwencja — daty, lekcje i przedmioty”.
