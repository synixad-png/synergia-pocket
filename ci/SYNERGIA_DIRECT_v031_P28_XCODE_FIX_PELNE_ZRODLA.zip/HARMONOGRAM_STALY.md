# SYNERGIA DIRECT v0.31 — STAŁY HARMONOGRAM 36 ZADAŃ

**Stan po pakiecie 28: 66% wykonano / 34% pozostało** (szacunek zaokrąglony, łączny bez zmiany po zaokrągleniu). Zmiana wyłącznie zadania nr 12: 75% → 90% (+15 pp); pozostałe 35 pozycji bez zmian.

Ważne: procent całego projektu pozostaje historycznym szacunkiem, nie średnią arytmetyczną. Testy urządzeń ograniczone do iPhone; nazwa zadania nr 31 pozostaje historyczna. Bez kompilacji iOS, nowego IPA oraz testu żywej Synergii.

| Nr | Stały etap / zadanie | Pakiet 27 | Pakiet 28 | Zmiana |
|---:|---|---:|---:|---:|
| 1 | Komunikacja — logowanie | 90% | 90% | +0 pp |
| 2 | Komunikacja — klient JSON | 90% | 90% | +0 pp |
| 3 | Komunikacja — izolacja kont | 95% | 95% | +0 pp |
| 4 | Komunikacja — sesja | 95% | 95% | +0 pp |
| 5 | Komunikacja — błędy i paginacja | 90% | 90% | +0 pp |
| 6 | Oceny — oba semestry | 90% | 90% | +0 pp |
| 7 | Oceny — kategorie, wagi i średnie | 95% | 95% | +0 pp |
| 8 | Oceny — komentarze i szczegóły | 95% | 95% | +0 pp |
| 9 | Oceny — przedmioty i nauczyciele | 95% | 95% | +0 pp |
| 10 | Oceny — wykrywanie zmian | 90% | 90% | +0 pp |
| 11 | Frekwencja — odczyt JSON | 90% | 90% | +0 pp |
| 12 | Frekwencja — statusy | 75% | 90% | +15 pp |
| 13 | Frekwencja — daty, lekcje, przedmioty | 75% | 75% | +0 pp |
| 14 | Frekwencja — statystyki | 90% | 90% | +0 pp |
| 15 | Wiadomości — skrzynki | 80% | 80% | +0 pp |
| 16 | Wiadomości — pełna treść | 70% | 70% | +0 pp |
| 17 | Wiadomości — wysyłanie i odpowiedzi | 55% | 55% | +0 pp |
| 18 | Wiadomości — załączniki | 80% | 80% | +0 pp |
| 19 | Inne moduły — plan lekcji | 75% | 75% | +0 pp |
| 20 | Inne moduły — terminarz | 90% | 90% | +0 pp |
| 21 | Inne moduły — zadania domowe | 90% | 90% | +0 pp |
| 22 | Inne moduły — ogłoszenia | 90% | 90% | +0 pp |
| 23 | Inne moduły — dokumenty | 90% | 90% | +0 pp |
| 24 | Synchronizacja — odświeżanie | 65% | 65% | +0 pp |
| 25 | Synchronizacja — wykrywanie zmian | 70% | 70% | +0 pp |
| 26 | Synchronizacja — offline | 95% | 95% | +0 pp |
| 27 | Synchronizacja — powiadomienia lokalne | 85% | 85% | +0 pp |
| 28 | Interfejs iOS — ekran główny | 82% | 82% | +0 pp |
| 29 | Interfejs iOS — ekrany modułów | 75% | 75% | +0 pp |
| 30 | Interfejs iOS — czytelność | 85% | 85% | +0 pp |
| 31 | Interfejs iOS — iPhone / iPad | 45% | 45% | +0 pp |
| 32 | Interfejs iOS — ustawienia i konta | 72% | 72% | +0 pp |
| 33 | Testy i wydanie — jednostkowe i regresja | 50% | 50% | +0 pp |
| 34 | Testy i wydanie — żywa Synergia | 0% | 0% | +0 pp |
| 35 | Testy i wydanie — urządzenia | 0% | 0% | +0 pp |
| 36 | Testy i wydanie — kompilacja i IPA | 0% | 0% | +0 pp |

**Niezmienione ograniczenia:** brak potwierdzenia prawdziwych odpowiedzi serwera iOS/Live; wszelkie puste lub niejednoznaczne słowniki typów odrzucane bez zastępowania stanów frekwencji; nadal brak oficjalnej frekwencji procentowej.
