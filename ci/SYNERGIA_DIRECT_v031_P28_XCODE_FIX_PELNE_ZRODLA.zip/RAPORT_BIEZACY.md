# SYNERGIA DIRECT v0.31 — raport po pakiecie 28

**66% wykonano / 34% pozostało** (szacunek) · 36 niezmiennych zadań. Zadanie 12: 75% → 90% (+15 pp); pozostałe bez zmian.

Wdrożono bardziej zachowawcze rozpoznawanie usprawiedliwionych i nieusprawiedliwionych nieobecności na podstawie jednoznacznych nazw statusów. Nie klasyfikujemy wniosków ani nierozpatrzonych usprawiedliwień jako zaakceptowanych. Zachowano `IsPresenceKind` i niezmienione rozliczanie wpisów bez oficjalnych procentów frekwencji.

Testy offline i regresje: `bash Tests/run_batch28_offline.sh`. Brak rzeczywistych testów konta Synergii/iPhone, brak Xcode build i brak IPA w źródłach. Zewnętrzny GitHub Actions macos-15-intel może wygenerować osobne, starsze IPA (pakiet 18), lecz nie oznacza to testu bieżącego pakietu 28.

Następne zadanie: nr 13 — daty, lekcje i przedmioty frekwencji (75%).
