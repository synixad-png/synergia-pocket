# SYNERGIA DIRECT v0.31 pakiet 28 — poprawki kompilacji Xcode

Baza: rzeczywisty pakiet 28, w 100% zachowane źródła wszystkich modułów z wyjątkiem **LocalStore.swift** i **Portal.swift**, których błędy Xcode wykazano w logach próby builda historycznego pakietu 18 na macos-15-intel. Zastosowano wyłącznie dwie poprawki:

1. `LocalStore.swift`: przy inicjalizacji przypisanie do `self.directory`, a nie do parametru `directory` typu URL?.
2. `Portal.swift`: przeniesiono ciało bardzo dużej domkniętej funkcji `Task` synchronizacji modułów do prywatnej metody asynchronicznej `runCoreSync` bez zamiany kolejności operacji i zabezpieczeń sesji. Ma to zapobiec błędowi Xcode „the compiler is unable to type-check this expression in reasonable time”.

Zachowano oryginalny `project.yml` oraz testy. Zaktualizowano tylko jeden test kontroli granic, by dopuszczał *te dwie dodatkowe, jawne poprawki* i nadal odrzucał inne zmiany. Wersja nadal v0.31 / pakiet 28; nie przeniesiono starszego pakietu 18 jako podstawy aplikacji.

**Ważne:** sam Linux `swiftc -frontend -parse` nie zastępuje kompilacji Xcode na macOS. Dopiero GitHub Actions potwierdzi, czy pozostają inne błędy kompilatora. Nie odnotowywać PASS builda Xcode bez wyniku Actions.
