# Diagnoza nieudanej kompilacji SYNERGIA DIRECT IPA — GitHub Actions 2026-11-05

**Repozytorium:** `synixad-png/synergia-pocket` (prywatne), gałąź jednorazowego workflow `ci/synergia-direct-ipa-20261105`.

**Run:** https://github.com/synixad-png/synergia-pocket/actions/runs/42078764294

- GitHub API: `status=completed`, `conclusion=failure`.
- Job `ios-build`, ID `127425924349`, label `macos-15`.
- Godziny API UTC: `created_at=2026-11-05T17:52:01Z`, `started_at=2026-11-05T17:52:01Z`, `completed_at=2026-11-05T18:11:57Z`.
- `runner_id=0`, pusta `runner_name`, `steps=[]`, brak zarejestrowanych kroków checkout/XcodeGen/Xcode.
- Endpoint czasu rozliczanego: `billable.MACOS.total_ms=0`, `jobs=1`; `run_duration_ms=1_204_000`.
- Log zadania przez oficjalny endpoint GitHub Actions był niedostępny (odpowiedź 404 BlobNotFound).

**Wniosek potwierdzony:** workflow zakończył się niepowodzeniem, lecz brak jakiejkolwiek wykonanej pracy na runnerze macOS. Nie ma dowodu, że błąd był spowodowany Swift/Xcode lub kodem aplikacji. Powód, dla którego GitHub nie uruchomił runnera, **nie jest znany**; ograniczenia rozliczeń, uprawnień lub dostępności są możliwościami, nie potwierdzoną diagnozą.

**Dalszy sensowny krok diagnostyczny:** sprawdzić w GitHubie ustawienia `Settings > Actions` i rozliczeń/budgetów dla prywatnych repozytoriów oraz ostrzeżenia na ekranie run. W przypadku kolejnej próby najlepiej uruchomić ją dopiero po potwierdzeniu przydzielania macOS runnera. Nie tworzono nowego runu bez polecenia.
