# SYNERGIA DIRECT v0.31 — domknięcie walidacji łańcucha stron

Zmiana: DirectGradePagination.merge odrzuca niedokończony łańcuch stron (ostatnia strona nadal wskazuje Next) i nieudokumentowane przerwy (pośrednia strona nie wskazuje kolejnej). Wcześniejsze reguły ograniczeń domeny, zasobu i liczników pozostają.

Poprawiono dotychczasowy test Node.js: poprawny surowy literał Swift nie ma wcięcia przed zamykającym cudzysłowem. Zmieniono tylko ekstrakcję JS w teście, nie produkcyjny kod WebKit.

Weryfikacja: 20/20 samodzielnych testów Swift PASS; Node.js PASS; parse wszystkich plików Swift PASS; python verify_source_boundaries.py PASS; archiwum ZIP CRC PASS.

Nie przeprowadzono kompilacji aplikacji iOS, testów XCTest na iOS ani testu na rzeczywistym koncie Synergii. Brak potwierdzonej wiedzy o pełnym schemacie Synergii pozostaje ograniczeniem.
