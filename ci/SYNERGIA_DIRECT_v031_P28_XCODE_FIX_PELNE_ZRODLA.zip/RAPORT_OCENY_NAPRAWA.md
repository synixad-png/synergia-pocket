# SYNERGIA DIRECT — naprawa integralności ocen (bez kompilacji iOS)

- `verifyAccount()` teraz natychmiast unieważnia aktywny odczyt ocen i blokuje poprzedni snapshot; ponownie odblokowuje go wyłącznie po świeżym, udanym `/Me`.
- Odczyt dodatkowych typów ocen nie usuwa wcześniejszych wpisów, gdy serwer zwróci 403 lub 404. Zachowane wpisy są jednoznacznie opisane w komunikacie jako **NIEAKTUALNE**.
- Gdy zasób zwróci prawidłową pustą listę, starsze wpisy tego typu są usuwane — brak danych i brak dostępu są rozróżnione.
- Bez weryfikacji na koncie nie można potwierdzić pełnej liczby ocen w obu semestrach ani używanych aktualnie endpointów.
- Nie kompilowano aplikacji iOS, nie wygenerowano IPA.
