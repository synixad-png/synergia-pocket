# SYNERGIA DIRECT — pakiet 10: lokalne powiadomienia, opt-in i wiązanie konta

## Baza i zakres

Kontynuacja dokładnie kodu pakietu 9, bez zmian nazwy wersji v0.31 i bez nowych zadań w harmonogramie. Jedno ukończone funkcjonalnie zadanie: rozbudowa lokalnych powiadomień po RĘCZNEJ synchronizacji ocen, frekwencji i odebranych wiadomości.

## Realne zmiany w źródłach

- `DirectNotificationPolicy.swift`: zapis preferencji ze schematem v1, wyłączenie domyślne, osobne przełączniki kategorii, ograniczenie ponownego wyświetlenia w odstępie 20 s, odrzucanie niepoprawnych preferencji, kontrola życia asynchronicznych zapytań o zgodę i testowalna reguła przypisania powiadomień do konta.
- `DirectNotificationOwnerKeychain.swift`: identyfikator konta wyłącznie w *lokalnym Keychain iOS*, chroniony polityką `WhenUnlockedThisDeviceOnly`. Nie ma nazwisk, ocen, treści ani haseł w pliku preferencji. Przy utracie dostępu do Keychain zgoda aplikacji zostaje zablokowana (fail closed). Po migracji ze starszej wersji użytkownik może musieć ponownie wyrazić zgodę.
- `Portal.swift`: przy starcie i po powrocie sprawdza rzeczywiste uprawnienia iOS; po zgodnym `/Me` powiązanie zgody musi pasować do bieżącego konta; zmiana konta wyłącza powiadomienia i usuwa wiązanie. Osobne potwierdzenie użytkownika wywołuje systemowe `requestAuthorization`. Callback jest kontrolowany numerem generacji, tożsamością i zmianą sesji; przejściowe `.inactive` podczas systemowego okna zgody nie unieważnia decyzji, lecz realny background już tak. Wylogowanie i wyłączenie kategorii usuwa zaległe/dostarczone powiadomienia.
- `MainView.swift`: trzy osobne przełączniki ocen, frekwencji i wiadomości, stan zgody systemowej i możliwość ręcznego odświeżenia statusu, informacja o braku monitorowania w tle.
- Dyspozycja następuje tylko przy wiarygodnym porównaniu dwóch odczytów tego samego konta i po sprawdzeniu faktycznej autoryzacji. Kategorie mają neutralne komunikaty bez osobowych szczegółów. Nie ma powiadomień o pierwszym odczycie ani o znikających rekordach, bo nie dowodzi to usunięcia.

## Testy źródeł

- 748/748 wcześniejszych testów logiki Foundation-only **PASS** (`run_batch9_offline.sh`).
- 235/235 nowych testów reguł powiadomień **PASS**, w tym 8×8 kombinacji selekcji i zdarzeń, UserDefaults, obce konto po ponownym uruchomieniu, brak dostępu do Keychain, asynchroniczne zgody, początkowy stan wyłączony i odstęp antyduplikacyjny.
- 57/57 kontroli statycznych granic interfejsu i bezpieczeństwa **PASS**.
- Składnia Swift Sources/*.swift **PASS**; test nie sprawdza typowania SwiftUI, Security.framework czy UserNotifications na urządzeniu.

## Ograniczenia, dalszy krok i uczciwość zakresu

- **Brak** kompilacji iOS, IPA, uruchomienia na urządzeniu, testów autoryzacji powiadomień z rzeczywistym iOS i testów żywej Synergii. Nie twierdzimy, że dostarczanie powiadomień na iPhonie jest potwierdzone.
- Zmiany pojawiają się **tylko po ręcznej synchronizacji**, podczas gdy aplikacja działa i konto zostało zweryfikowane. Nie ma monitorowania po zamknięciu aplikacji ani push z serwera.
- Użytkownik musi włączyć zarówno przełącznik w aplikacji, jak i udzielić zgody systemowej. Po zmianie konta trzeba ponownie opt-in.
- Powiadomienia: **45% → 85% (+40 pp)**, czyli wykonano 72,7% wcześniej brakującej części zadania. Nie podnosimy do 100% bez weryfikacji iOS.
- Etap Synchronizacja: 65% → 75%; cały projekt 51% → **52%**, pozostaje **48%**. Liczby są ostrożnym szacunkiem zakresu, nie wynikiem pomiaru jakości gotowej aplikacji.
