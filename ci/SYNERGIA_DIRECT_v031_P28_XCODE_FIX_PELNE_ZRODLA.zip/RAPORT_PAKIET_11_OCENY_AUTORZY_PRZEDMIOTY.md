# RAPORT PAKIETU 11 — AUTORZY OCEN I PRZEDMIOTY

## Wykonane zmiany

1. `Sources/SynergiaGatewayClient.swift`: ścisła ścieżka tylko `https://synergia.librus.pl/gateway/api/2.0/Users/{id}`, bez query i fragmentu, tylko do 12 cyfr dodatniego identyfikatora. Nie są przyjmowane linki użytkownika ani linki zwrócone przez nieznany serwer. Najpierw odczyt listy `Users`; w razie braków do 24 odczytów pojedynczego użytkownika, przy błędzie 403 lub problemie sieciowym bez dalszej lawiny żądań. Błąd logowania nie jest ukrywany.
2. `Sources/DirectGradeAuthors.swift`: odczyt `User.Id` musi dokładnie odpowiadać żądanemu ID; odrzucane bool i nieprawidłowe nazwy. Dopasowanie TYLKO przez `Grades[].AddedBy.Id` — nie przez domniemany nauczyciel/przedmiot.
3. `Sources/Portal.swift`: to samo rozwiązywanie w ręcznym pobieraniu ocen oraz zbiorczej synchronizacji. Nazwy z wcześniejszego zapisu są używane tylko po zgodnym `/Me` i wyłącznie dla wskazanych w bieżących ocenach autorów. Ostateczne zapisanie wyników następuje po drugiej weryfikacji konta.
4. `Sources/DirectGradeStore.swift`: przetrzymywanie i odtwarzanie listy ID autorów, których nazwy pochodzą ze starszego potwierdzonego zapisu. Dalsze konto ani wylogowanie nie otrzymuje cudzych danych; plik lokalny pozostaje pod osłoną Data Protection i hashem ID konta.
5. `Sources/SynergiaSubjects.swift`: odrzucanie boolean i ułamkowych `Subject.Id` zamiast fałszywego przypisywania nazwy do identyfikatora.
6. `Sources/MainView.swift`: filtr przedmiotów działa dla standardowych ocen i dodatkowych rodzin; opisowe i punktowe wpisy wyświetlają dostępny przedmiot. Wyświetlanie „Autor wpisu”, wyraźna adnotacja „z wcześniejszego odczytu”, „autor nieustalony” tam, gdzie brak danych, obsługa starego filtra po zmianie konta. Liczniki ocen uwzględniają filtr.

## Testy wykonane

- Poprzednie pakiety 1–9: **748/748** PASS; pakiet 10 powiadomienia **235/235** PASS. Ze względu na limit jednorazowego skryptu uruchomione osobno; nie ukryto przerwania pełnego skryptu.
- Nowe testy Foundation-only: `grade_author_resolution_standalone.swift` **74/74** PASS oraz `grade_subjects_boundary_standalone.swift` **38/38** PASS. Łącznie **1095/1095** z historycznymi przypadkami.
- `verify_batch11_boundaries.py`: **43/43** PASS; wszystkie wcześniejsze `verify_*boundaries.py` oraz `verify_source_boundaries.py` PASS.
- `swiftc -frontend -parse Sources/*.swift`: PASS. Brak pełnej analizy semantycznej SwiftUI, brak builda iOS.
- ZIP CRC i manifest SHA-256 sprawdzane podczas przygotowywania paczki.

## Ograniczenia

Nie mamy dostępu do rzeczywistej sesji użytkownika. Endpoint `Users/{id}` jest oparty na znanej strukturze API, lecz brak weryfikacji jego dostępności dla aktualnego konta użytkownika; 403 pozostawia imię i nazwisko nieustalone lub opisane jako wcześniejszy odczyt. `AddedBy` oznacza **autora wpisu**, niekoniecznie prowadzącego lekcję. Procent **90%** to ocena implementacji bez testów iOS; nie jest to stwierdzenie pełnej zgodności z Synergią. Nie kompilowano, nie podpisywano i nie tworzono IPA.
