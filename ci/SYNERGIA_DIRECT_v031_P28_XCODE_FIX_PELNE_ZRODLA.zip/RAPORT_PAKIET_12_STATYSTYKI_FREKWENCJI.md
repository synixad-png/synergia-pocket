# SYNERGIA DIRECT v0.31 — pakiet 12: statystyki frekwencji

Data: 05.11.2026. Baza: **pełne źródła pakietu 11**, bez zmiany numeru wersji. Zmiany ograniczone do analiz i widoku frekwencji, parsera jej numerów pomocniczych oraz odpowiadających im testów. Nie modyfikowano istniejącego formatu lokalnych zapisów ani mechanizmów ocen, wiadomości, planu czy powiadomień.

## Zrealizowany zakres

1. `Sources/DirectAttendanceAnalytics.swift`: nowy typowany mechanizm zestawień `przedmiot × semestr`, miesiąc kalendarzowy, typ obecności szkolnej, pełne liczniki statusów. Rozpoznaje osobno wpisy bez przedmiotu, semestru, godziny lub prawidłowej daty. Wykrywa też powtórzone pozycje tej samej daty i godziny **diagnostycznie, bez scalania lub usuwania** (mogą to być grupy albo korekty wpisów), oraz rozbieżne definicje jednego typu. Normalizuje różnice wielkości liter w nazwach statusów, nie zmieniając kwalifikacji `IsPresenceKind` z serwera.
2. `Sources/DirectAttendanceStatistics.swift`: wspólne reguły klasyfikacji opóźnień i usprawiedliwień, walidacja daty gregoriańskiej `YYYY-MM-DD` i normalizacja liczby unikatowych dni. Wpis bez danych nie staje się obecnością.
3. `Sources/SynergiaAttendanceRecords.swift`: obsługa pomocniczych pól `LessonNo` i `Semester` także jako ciąg cyfr; odrzucanie booleanów, ułamków i niepoprawnych numerów zamiast przypisywania ich do innego semestru/lekcji. Pozostawiono ścisłe wymaganie znanego typu frekwencji `Attendances/Types`.
4. `Sources/DirectAttendanceAnalyticsView.swift` i `Sources/MainView.swift`: rzeczywiście podłączona analiza; 4 niezależne filtry (semestr, przedmiot, miesiąc, status), reset przy zmianie konta, przekroje miesięczne/przedmiotowo-semestralne i wykaz typów szkolnych. Wyświetlenie do 80 najnowszych pozycji i ostrzeżenie o dalszych wpisach; odrębny komunikat dla pustego lokalnego zapisu.
5. **Nie wyliczono oficjalnego ani orientacyjnego procentu obecności**, ponieważ API `Attendances` może zawierać tylko część lekcji, a brak wpisu nie dowodzi obecności. Cały czas prezentowane są wyłącznie liczniki wpisów rzeczywiście zwróconych przez serwer; nazwy statusów mogą rozstrzygać usprawiedliwienie tylko pomocniczo, nie na podstawie niepotwierdzonych identyfikatorów.

## Weryfikacja wykonana

- `Tests/attendance_analytics_standalone.swift`: **219/219** testów Foundation-only PASS, m.in. kalendarz, daty nieprawidłowe i przestępne, porównania statusów, 100 przekrojów filtrów, sumy wszystkich grup, typy niestandardowe oraz dekodowanie przykładowych odpowiedzi Gateway, łącznie z ID `t41685`.
- Dotychczasowe pakiety 1–9: **748/748** PASS; pakiet 10: **235/235** PASS; pakiet 11: **74/74 + 38/38** PASS. Łącznie **1314/1314** testów logiki offline. Uruchomiono zestawy osobno po przekroczeniu limitu pełnego skryptu, bez udawania zakończenia przerwanego przebiegu.
- `Tests/verify_batch12_boundaries.py`: **42/42** statycznych kontroli integracji i ochrony PASS. Uaktualniono starszą kontrolę z pakietu 2, aby weryfikowała przeniesiony do nowego komponentu interfejs zamiast wymagać nieaktualnej lokalizacji tekstu. Sprawdzono również niezmienione testy innych modułów.
- `swiftc -frontend -parse Sources/*.swift`: PASS — test składni, **NIE** pełny typecheck SwiftUI.
- Po utworzeniu archiwum: ZIP CRC, manifest SHA-256 i testy nowego modułu na plikach czysto rozpakowanych.

## Ocena postępu i ograniczenia

Statystyki frekwencji **60% → 90%** (+30 pp, co odpowiada 75% uprzednio pozostałego zakresu tego zadania). Rozliczenie całości projektu: **54% wykonano, 46% pozostało**, szacunek. Pozostałe 10 pp statystyk wymaga typowania i testu UI w Xcode/iOS oraz porównania z danymi rzeczywistego konta Synergii. Nie jest znana kompletność frekwencji na konkretnym koncie. Zgodnie z poleceniem **nie kompilowano iOS, nie generowano IPA i nie uruchamiano aplikacji na urządzeniu**.
