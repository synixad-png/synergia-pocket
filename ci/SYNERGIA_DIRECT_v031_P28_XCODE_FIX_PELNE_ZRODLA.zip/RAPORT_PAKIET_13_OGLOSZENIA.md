# SYNERGIA DIRECT v0.31 — pakiet 13: ogłoszenia

Data: 05.11.2026. **Dokładna baza: pełne źródła pakietu 12** (plik `SYNERGIA_DIRECT_v0_31_PAKIET12_STATYSTYKI_FREKWENCJI_PELNE_ZRODLA_BEZ_IPA.zip`). Nie zwiększano numeru wersji dla niepotwierdzonej na iOS implementacji. Zmieniono tylko moduł ogłoszeń, integrację jego odczytu, warstwę ochrony zapisu, testy i raporty.

## Zrealizowano

- Nowy `Sources/DirectSchoolNotices.swift`: status z `WasRead` wyłącznie gdy jest booleanem; przy brakującym polu stan pozostaje nieznany. `StartDate`, `EndDate`, `CreationDate`, treść z `Content` i identyfikator referencji `AddedBy.Id` bez zgadywania nazwiska autora. Odpowiedź HTML zostaje zamieniona na **nieaktywny tekst**, z usunięciem skryptów, ramek, SVG, stylów, znaczników i dekodowaniem podstawowych encji. Treść i pola mają ograniczenia długości.
- `Sources/DirectSchoolNoticesView.swift` plus `Sources/MainView.swift`: osobny widok ogłoszeń, wyszukiwarka po tytule i treści, filtry przeczytane/nieprzeczytane, daty publikacji i dodania, wyraźny status nieznany, komunikat o danych starszego formatu, dostępny tekst możliwy do zaznaczenia. **Nie wysyła się żądania oznaczenia jako przeczytane**; UI nie sugeruje, że otwarcie zmieniło stan na serwerze.
- `Sources/SynergiaGatewayClient.swift`: wąsko dozwolony odczyt GET `SchoolNotices?page=N&limit=50` dla N=1..5. Host, ścieżka i query są sprawdzane; nie wykonuje się dowolnych adresów z serwera. Nazwy pól i parametry potwierdzono w publicznym kodzie `librus-rs` (https://docs.rs/librus-rs/latest/src/librus_rs/structs/announcements.rs.html i https://docs.rs/librus-rs/latest/src/librus_rs/lib.rs.html). Biblioteka jest nieoficjalna, dlatego zgodność na konkretnym koncie nie została potwierdzona.
- `Sources/Portal.swift`: oba tryby pobierania (jeden moduł i zbiorczy) korzystają z tego samego, maksymalnie 5-stronicowego odczytu; wymagana jest zgodność zweryfikowanego konta `/Me` przed i po odczycie i weryfikacja epoki sesji między stronami. Błędne/duplikowane ID, awaria strony albo zmiana konta nie prowadzą do opublikowania częściowego nowego odczytu.
- `Sources/DirectSchoolFeeds.swift`, `Sources/DirectOfflineFeedCache.swift`, `Sources/DirectFeedChangeAudit.swift`: opcjonalne, kompatybilne wstecz metadane ogłoszenia w rekordach, walidacja po odtworzeniu offline i śledzenie aktualizacji pola `WasRead`. Zapis konta pozostaje izolowany. Stan kompletności wyznaczany jest tylko przez **serwerowy** licznik `Total/total/TotalCount`; z samej długości krótkiej strony nie wyprowadza się globalnej liczby wpisów.

## Weryfikacja

- `Tests/notices_standalone.swift`: **129/129 PASS**; w tym 100 wielkości wyników stronicowania, walidacja tożsamości, odrzucanie duplikatów, fragmentów HTML aktywnego, niepoprawnych statusów, zgodność ze starym JSON offline, separacja kont i audyt zmian `WasRead`.
- `Tests/verify_batch13_boundaries.py`: **36/36 PASS**; sprawdza dozwolone zakresy odczytu, ochronę epok konta, brak automatycznych zmian odczytu oraz zachowanie pozostałych modułów.
- Regresja bazowa pakietu 2 **PASS**, pakietu 4 **PASS**, bezpośrednia kontrola odtwarzania offline **62/62 PASS** + **41/41 kontroli**, statystyki pakietu 12 **219/219 PASS**, audyt pakietu 11 **74/74** autorów + **38/38** przedmiotów; kontrola powiadomień pakietu 10 PASS. Pełny rekurencyjny skrypt pakietu 8 przekroczył limit, dlatego nie jest raportowany jako ukończony; istotne testy offline zostały uruchomione oddzielnie.
- `swiftc -frontend -parse Sources/*.swift`: PASS (tylko składnia, nie kompilacja SwiftUI iOS). Paczka ZIP sprawdzana pod kątem CRC/manifestu, nowe testy uruchamiane także z czystego rozpakowania.

## Co pozostało

**Ogłoszenia: 90% wykonano, 10% pozostało.** Do potwierdzenia rzeczywisty wygląd i interakcje w Xcode/iOS, pełne działanie `page/limit` i `WasRead` na koncie użytkownika oraz zgodność licznika z portalem. Bez tych testów nie można uznać 100% ani gwarantować kompletności listy; ograniczenie do 250 rekordów jest świadomym bezpiecznym limitem odczytu, nie granicą zasobów konta. Nie uruchomiono kompilacji aplikacji ani nie utworzono IPA. Następny moduł po zakończeniu weryfikacji bieżącego zadania: **terminarz** ze stałego harmonogramu.
