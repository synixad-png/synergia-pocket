# SYNERGIA DIRECT v0.31 — pakiet 14: Terminarz

Data: 05.11.2026. **Dokładna baza: v0.31 pakiet 13**, nie nowy projekt. Kod aplikacji nadal bazuje na SwiftUI + WKWebView oraz istniejącym, izolowanym transporcie JSON. Brak wydania IPA — zgodnie z wytyczną użytkownika.

## Zrealizowany zakres

1. Zachowano bez zmian mapowanie: **Terminarz = HomeWorks**, **Zadania domowe = HomeWorkAssignments**. Ich danych nie mieszano. Potwierdzenie rozróżnienia w publicznym, nieoficjalnym projekcie `librus-synergia` (CHANGELOG, listy zasobów), https://github.com/MichalZaniewicz/ha-librus-synergia/blob/main/CHANGELOG.md. Nie dokonywano żadnych nowatorskich odczytów niezbadanych endpointów, nie dodawano synchronizacji z zewnętrznym kalendarzem.
2. `Sources/DirectSchoolAgenda.swift`: osobne, opcjonalne, kompatybilne wstecz metadane wydarzeń, odczytywane **wyłącznie** z pól odpowiedzi `HomeWorks`: `Date`, opcjonalne `EndDate`, `Content`, `Category.Name`, `Category.Id`, `Subject.Name`, `Subject.Id`, `LessonNo`. Jeżeli pole nie jest obecne lub ma zły typ, nie przypisuje się mu wartości. Kod nie zgaduje kategorii, nauczyciela ani przedmiotu. Data jest weryfikowana w kalendarzu gregoriańskim, także lata przestępne, bez normalizacji dnia 30 lutego. Rozpoznany czas po dacie jest ignorowany — UI przedstawia dzień, nie niepotwierdzoną godzinę.
3. `Sources/DirectSchoolAgendaView.swift`: osobny interfejs Terminarza z wyszukiwaniem po tytule/treści/przedmiocie/kategorii, filtrem wszystkie/nadchodzące/minione/bez daty oraz grupowaniem chronologicznym. Wyświetla etykiety kategorii tylko gdy serwer podał nazwę, w innym wypadku informuje o braku nazwy. Opis HTML jest konwertowany do nieaktywnego tekstu przez istniejący parser; HTML nie trafia do WKWebView. Nieznane daty nie są automatycznie uznawane za wydarzenia dzisiejsze. Wybory użytkownika nie zmieniają zapisanych danych.
4. `Sources/DirectSchoolFeeds.swift`, `Sources/MainView.swift`, `Sources/DirectOfflineFeedCache.swift` i `Sources/DirectFeedChangeAudit.swift`: połączenie parsera i widoku z istniejącym przepływem konta (`/Me` przed/po odczycie), izolowane kodowanie/dekodowanie offline, wykrywanie zmian pól terminarza. Starszy zapis JSON bez opcjonalnego pola `agenda` nadal działa. W pozostałych modułach zachowano wcześniejsze wejścia i reguły.
5. Zgodnie z zachowaniem bezpieczeństwa poprzednich pakietów aplikacja nie twierdzi, że odpowiedź `HomeWorks` jest kompletna bez potwierdzonego serwerowego licznika. Nie wdrożono paginacji/zakresów dat, których semantyki nie zweryfikowano dla tego zasobu.

## Weryfikacja wykonana w środowisku roboczym Linux

- `bash Tests/run_batch14_incremental_offline.sh`: **4499/4499 PASS** testów logiki, data (12 lat × 12 miesięcy × 31 potencjalnych dni), filtrowanie, sortowanie, metadane i kodowanie offline; **19/19 PASS** dodatkowych statycznych kontroli ograniczeń; kontrola parsowania wszystkich plików źródłowych Swift PASS.
- `bash Tests/run_batch13_incremental_offline.sh`: regresja pakietu 13 **PASS** (129/129 testów + 36/36 kontroli).
- `bash Tests/run_batch2_offline.sh`: regresja pakietu 2 **PASS**.
- `bash Tests/run_batch4_offline.sh`: regresja pakietu 4 **PASS**.
- `bash Tests/run_batch11_incremental_offline.sh`: regresja pakietu 11 **PASS**.
- `bash Tests/run_batch12_incremental_offline.sh`: regresja pakietu 12 **PASS**.
- Bezpośredni test `offline_recovery_standalone.swift` z rzeczywistym kodem cache i store: **62/62 PASS**; statyczna kontrola pakietu 8 **41/41 PASS**.
- Pełne rekurencyjne `run_batch8_offline.sh` i `run_batch10_offline.sh` **przerwano limitem czasu**; nie raportujemy ich jako PASS. Wyizolowano powiązane testy offline.

## Czego nie potwierdzono

- Nie skompilowano aplikacji na iOS, nie wykonano semantycznego typechecku SwiftUI w Xcode ani testów ekranu na urządzeniu.
- Nie sprawdzono rzeczywistych `HomeWorks` na koncie rodzica/ucznia, pełnej liczby wydarzeń, wartości kategorii, ewentualnych stronicowań oraz zgodności z widokiem w Synergii. Nie twierdzimy, że wszystkie wydarzenia z konta są już pobierane.
- Uwaga: publiczne źródła są **nieoficjalne**. Terminarz w Synergii bywa szerszy niż sam zasób `HomeWorks`; nie dorabiano arbitralnych innych endpointów.

## Stan harmonogramu

**Terminarz: 55% → 90% (+35 pp)**: nowy kod, testy i izolacja danych zrealizowane; pozostałe 10 pp to rzeczywisty test konta/urządzenia i ewentualne korekty oparte o wyniki. **Projekt: orientacyjnie 55% → 56% (+1 pp), 44% pozostało**. Etap 5 z 54% → 61% (+7 pp). Pozostałe 35 zadań bez zmiany postępu. Nie zmieniono wersji v0.31 i nie wygenerowano IPA.
