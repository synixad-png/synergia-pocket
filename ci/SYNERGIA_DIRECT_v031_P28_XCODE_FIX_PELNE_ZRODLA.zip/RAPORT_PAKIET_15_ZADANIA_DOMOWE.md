# SYNERGIA DIRECT v0.31 — pakiet 15: zadania domowe

Data: 05.11.2026. **Baza: rzeczywista paczka v0.31 pakiet 14**, nie projekt demonstracyjny. Nie uruchamiano Xcode ani kompilacji IPA.

## Zmiana funkcjonalna

1. `Sources/DirectHomeworkAssignments.swift`: osobny, opcjonalny, typowany odczyt `HomeWorkAssignments` (nigdy `HomeWorks`, który pozostaje Terminarzem). Etykieta **termin** pochodzi jedynie z `DueDate` lub `Deadline`, nigdy z niejednoznacznego `Date`. Publikację pokazuje się jedynie po `addedOnDate` lub `CreationDate`. Treść `Text` albo `Description` jest konwertowana do biernego tekstu; `Category.Name` i `Subject.Name` pojawiają się wyłącznie wtedy, gdy rzeczywiście wystąpią w odpowiedzi. Nie wylicza się przedmiotu z osoby nauczyciela, nie domniemywa statusu oddania zadania ani sposobu odsyłania rozwiązania.
2. `Sources/DirectHomeworkAssignmentsView.swift`: wyszukiwarka tekstu, przedmiotu, kategorii i nazw załączników; filtrowanie wszystkie / na dziś i później / po terminie / bez terminu; grupowanie po dacie; czytelna prezentacja danych i braków. **Po terminie** jest wyłącznie filtrem dat, nie wskaźnikiem „nieodrobione”. Widok nie umożliwia odesłania pracy do Synergii. Istniejące `DirectHomeworkFileReference` i pobieranie/udostępnianie załączników zachowano. Lista załączników `nil` nadal oznacza **nieznaną**, `[]` zaś **potwierdzoną pustą**, jeśli rzeczywiście taką zwrócił serwer.
3. `Sources/DirectSchoolFeeds.swift`: przypięto wyłącznie do `.homework` nowe opcjonalne metadane, oczyszczono nagłówek z HTML. Pozostałe moduły mają `homework == nil`; stare dane JSON z brakiem klucza wciąż dekodują się.
4. `Sources/DirectOfflineFeedCache.swift` i `Sources/DirectFeedChangeAudit.swift`: dodano walidację optional `homework` w przypisanej do konta pamięci offline, sprawdzanie dat i długości oraz uwzględnienie zmiany metadanych w audycie. Nie naruszano istniejącej blokady między kontami ani nie uznaje się braku wpisu za potwierdzone usunięcie.
5. `Sources/MainView.swift`: odrębny ekran zadań, analogicznie do istniejących widoków Terminarza i Ogłoszeń. Dokumenty nadal mają własną obsługę plików, a oceny i wiadomości nie są modyfikowane.
6. Wykryto i zaktualizowano zależności kompilacji czystych testów Foundation-only w `Tests/run_batch2_offline.sh`, `run_batch4_offline.sh`, `run_batch8_offline.sh`, `run_batch13_incremental_offline.sh`, `run_batch14_incremental_offline.sh` do nowego pliku modelu. Nie zmieniono zakresu ich asercji.

## Weryfikacja na Linux

- `bash Tests/run_batch15_incremental_offline.sh`: **4506/4506 przypadków PASS** (w tym 12 lat × 12 miesięcy × 31 dni, granice dat, filtry, treść, załączniki, konta, cache, zmiany), dodatkowe **22/22 kontrolne PASS**. Parser składni wszystkich plików Swift PASS.
- Regresje przyrostowe pakietów **11, 12, 13, 14 PASS**.
- `bash Tests/run_batch2_offline.sh` PASS.
- Testy wyizolowane z pakietu 4: **21/21** (załączniki), **16/16** (zmiany), **33/33** (granice) PASS. Pełny skrypt `run_batch4_offline.sh` **przekroczył limit czasu** w łańcuchu starszych zadań; nie zgłaszamy jego pełnego PASS.
- Test odtwarzania offline wyizolowany z pakietu 8: **62/62** plus kontrole granic **41/41 PASS**. Pełnego długiego skryptu pakietu 8 nie zaliczono.
- Nie przeprowadzono ani kompilacji aplikacji iOS, ani semantycznego typechecku SwiftUI w Xcode, ani testu uruchomienia na iPhonie, ani odczytu z żywego konta Synergii. Realne występowanie i znaczenie opcjonalnych pól `DueDate`, `Deadline`, `CreationDate`, `Category.Name` i `Subject.Name` nie jest potwierdzone dla konta użytkownika, dlatego brak pola nie jest uzupełniany domysłem. Oficjalny opis produktu potwierdza istnienie terminów, kategorii i przedmiotów w UI, lecz nie kontrakt gateway JSON.

## Harmonogram

Zadanie **Zadania domowe 70% → 90% (+20 pp)**: kod i testy przenośne w zleconym zakresie, pozostało rzeczywiste sprawdzenie JSON oraz iOS. Cały projekt **szacunkowo 56% → 57% (+1 pp)**, **43% pozostaje**. Lista 36 zadań bez zmiany w `HARMONOGRAM_STALY.md`. Numer wersji aplikacji nadal **v0.31**; zmieniono wyłącznie numer paczki źródeł. Nie tworzono IPA.
