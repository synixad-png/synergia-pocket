# SYNERGIA DIRECT v0.31 — pakiet 16: Dokumenty

Data: 05.11.2026. **Baza: rzeczywiste źródła pakietu 15**, bez nowej aplikacji demonstracyjnej i bez zmiany v0.31. Nowa funkcja dotyczy wyłącznie SchoolFiles / Dokumenty.

## Zmiany

1. `Sources/DirectSchoolDocuments.swift`: opcjonalny typowany odczyt `addedOnDate` (tylko prawidłowa data) i biernego `fileStatus`, bez domniemywania prawa do pobrania; rozszerzenie nazwy jest tylko wskazówką z nazwy, NIE dowodem rzeczywistego MIME. Nie rozpoznaje innych, niepotwierdzonych pól.
2. `Sources/DirectSchoolDocumentsView.swift`: osobny ekran dokumentów, wyszukiwanie, filtr dostępności zweryfikowanego linku, filtr rozszerzenia, sortowanie według nazwy lub potwierdzonej daty dodania; czytelne metadane i komunikaty o brakach. Przycisk pobierania i systemowe udostępnianie pozostają ręczne. Nie otwiera się skryptów ani linków z HTML.
3. `Sources/DirectSchoolFeeds.swift`: metadane dokumentu przypisane **wyłącznie** do `.documents`; pozostałe moduły otrzymują `nil`. Pole jest opcjonalne w `Codable` — starszy zapis nie traci zgodności.
4. `Sources/Portal.swift`: przed uruchomieniem dotychczasowego pobierania sprawdzany jest dodatkowo niepowtarzalny identyfikator dokumentu na liście bieżącego odczytu. Powtórzony ID powoduje blokadę pobierania; oba rekordy pozostają widoczne. Nadal obowiązują pierwotne restrykcje domen/ścieżek, limitu 15 MB, identyfikacji konta przed i po i usuwania plików tymczasowych.
5. `Sources/DirectOfflineFeedCache.swift` i `Sources/DirectFeedChangeAudit.swift`: walidacja nowych danych offline oraz detekcja zmian ich wartości. Nie zmienia się izolacja kont, zasady blokady podczas wylogowania i ochrona danych.
6. `Sources/MainView.swift`: dedykowany widok zamiast ogólnej listy. Pozostawiono bez zmian dotychczasowe widoki ogłoszeń, terminarza, zadań domowych oraz funkcje ocen, wiadomości i frekwencji.
7. W starszych skryptach testowych dodano nowy plik Foundation do listy zależności. W `Tests/verify_batch3_boundaries.py` zmieniono dwie asercje sprawdzające stare położenie przycisku pobierania: teraz sprawdzają jego rzeczywiste położenie i warunek dostępu. **Nie usunięto ochrony ani nie zmieniono zachowania klienta sieciowego.**

## Testy przeprowadzone w tej sesji (Swift 6.2.1 / Linux)

- `bash Tests/run_batch16_incremental_offline.sh`: **70/70** testów Foundation (metadane, nieznane wartości, sanitacja HTML, daty, rozszerzenia, wyszukiwanie i sortowanie, duplikaty ID, granice modułów, konta, stary format cache, aktualizacja metadanych); dodatkowe **22/22** kontrole kodu i parsowanie składni Sources/*.swift — PASS.
- `bash Tests/run_batch15_incremental_offline.sh`, `run_batch14_incremental_offline.sh`, `run_batch13_incremental_offline.sh`, `run_batch2_offline.sh` — PASS (wcześniejsze testy).
- Bezpośrednie testy `school_files_standalone.swift`: **25/25 PASS**; `feed_delta_standalone.swift`: **16/16 PASS**; `offline_recovery_standalone.swift`: **62/62 PASS**.
- `Tests/verify_batch3_boundaries.py` **32/32 PASS**, `Tests/verify_batch4_boundaries.py` **33/33 PASS**, `Tests/verify_batch8_boundaries.py` **41/41 PASS**.
- Pełnego łańcucha skryptu `run_batch4_offline.sh` po naprawieniu testu statycznego NIE ponowiono do końca; wykonano jego bezpośrednio istotne testy i kontrole osobno. Nie przedstawiać tego jako zaliczonego całego pakietu 4.

## Niezależne ograniczenia

**NIE** uruchamiano Xcode, `xcodebuild`, aplikacji iOS ani IPA. Nie przeprowadzono interaktywnego testu na iPhonie, nie sprawdzono pobierania na prawdziwym koncie Synergii, ani rzeczywistego schematu SchoolFiles w koncie użytkownika. Brak dostępu do takiej sesji oznacza, że nie można potwierdzić działania pełnego łańcucha sieciowego. Testy Foundation nie zastępują kompilacji iOS, a przebieg w środowisku macOS pozostaje niezweryfikowany.

## Harmonogram

Zadanie 23: **Dokumenty 70% → 90% (+20 pp)** (wdrożono i przetestowano weryfikowalne elementy bez urządzenia). Pozostałe 35 zadań bez zmiany. Szacunkowy łączny postęp zgodny z poprzednim raportowaniem **57% → 58%**, pozostało **42%**. Nie zmieniono listy 36 zadań. Dalsze 10% w dokumentach wymaga weryfikacji na realnej Synergii i iOS; inne zadania pozostają otwarte zgodnie z harmonogramem.
