# SYNERGIA DIRECT v0.31 — pakiet 17: logowanie i odtwarzanie sesji

Data: 05.11.2026. Baza: pełne rzeczywiste źródła pakietu 16. Nie podnoszono wersji aplikacji. Zmiana obejmuje wyłącznie logowanie i weryfikację tożsamości po nawigacji; dane innych modułów pozostają bez zmian.

## Zmiany w kodzie

1. `Sources/DirectLoginRestorePolicy.swift` — nowa, testowalna polityka jednorazowego sprawdzenia sesji przy uruchomieniu i po powrocie z oficjalnego logowania. Nie zawiera danych uwierzytelniających, tokenów, cookies ani hasła. Odrzuca nieoficjalne domeny i strony logowania/wylogowania; na stronie docelowej jedynie zleca sprawdzenie `/Me`.
2. `Sources/Portal.swift` — `restoreOfficialSessionAtLaunch()` sprawdza serwerowe `/Me` z użyciem istniejących cookies WebKit, bez uruchamiania strony logowania; po kliknięciu oficjalnego logowania zapamiętuje tylko oczekiwanie na bezpieczny powrót. Po załadowaniu dozwolonej strony Synergii automatycznie wznawia odczyt `/Me`. Przy nawigacji z uprzednio zweryfikowanego konta dane są nadal blokowane, następnie wznawiane dopiero po ponownej weryfikacji `/Me`. Obsłużono również wyścig między kontrolą sesji przy uruchomieniu a pierwszą nawigacją; dodatkowe zapytanie jest jednorazowe.
3. `Sources/MainView.swift` — pojedyncze wywołanie automatycznej weryfikacji przy pierwszym otwarciu aplikacji i krótka informacja o ograniczeniu: ponowne logowanie jest wymagane, jeśli serwerowa sesja wygasła.
4. Zachowano `WKWebsiteDataStore.default()`, blokady cache, unieważnianie epok kont, ręczny przycisk „Potwierdź konto”, start na oficjalnej stronie, ochronę tła i urządzenia oraz oddzielny tor synchronizacji. Nie zapisano danych logowania ani nie dołączono narzędzi obchodzenia sesji.
5. W `Tests/login_restore_standalone.swift`, `Tests/verify_batch17_boundaries.py` oraz `Tests/run_batch17_incremental_offline.sh` dodano testy polityki, kontroli granic i powtórnej parsowalności kodu.

## Testy (Swift 6.2.1 / Linux)

- 254/254 testów logiki jednorazowej weryfikacji i akceptacji docelowego URL — PASS.
- 28/28 kontroli kodu pakietu 17 — PASS.
- `bash Tests/run_batch16_incremental_offline.sh` — 70/70 testów dokumentów i 22/22 granice — PASS.
- `bash Tests/run_batch2_offline.sh`, `run_batch11_incremental_offline.sh`, `run_batch12_incremental_offline.sh`, `run_batch15_incremental_offline.sh`, `run_batch14_incremental_offline.sh`, `run_batch13_incremental_offline.sh` — PASS.
- Bezpośrednie testy `DirectConnectionIssue` — 40/40 PASS; kontrole tła i prezentacji konta pakietów 6/7 oraz offline pakietu 8 — PASS.
- `swiftc -frontend -parse Sources/*.swift` — PASS. Nie oznacza to kompilacji aplikacji na iOS.

## Granice weryfikacji

Nie testowano prawdziwego serwerowego logowania Librus, nie sprawdzono trwania sesji po restarcie na iPhonie, weryfikacji `Me` w czasie rzeczywistym ani pełnego buildu Xcode. Nie ma możliwości zagwarantować utrzymywania sesji po jej serwerowym wygaśnięciu, ani obchodzenia 2FA. Automatyczne sprawdzenie nie jest automatycznym zalogowaniem bez ważnej sesji. Nie utworzono IPA.

## Harmonogram

Zadanie nr 1 „Komunikacja — logowanie”: **75% → 90% (+15 pp)**, pozostałe 35 zadań bez zmian. Szacunkowo **58% → 59%** projektu, pozostało **41%**. Brakujące 10% zadania 1 wymaga testu realnej sesji na urządzeniu; następne zadanie do realizacji w ustalonym harmonogramie to nr 2 „Klient JSON” (80%).
