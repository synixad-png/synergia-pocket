# SYNERGIA DIRECT v0.31 — PAKIET 18: KLIENT JSON

Data: 05.11.2026. Baza: pełne realne źródła pakietu 17. Nie podnoszono wersji. Modyfikowano wyłącznie `Sources/SynergiaGatewayClient.swift` oraz dodano `Sources/GatewayJSONPolicy.swift`; poprzednie implementacje pozostały bajtowo takie same.

## Rzeczywiście wykonane zmiany

1. **Zakres cookies** — zamiast prostego prefiksu ścieżki i obcięcia kropki z domeny stosowana jest ścisła semantyka `HTTPCookie.domain` Apple (host-only vs domena zaczynająca się od kropki) i granicy segmentów ścieżki. Nie wysyłamy cookies host-only dla `librus.pl` do `synergia.librus.pl` ani ciasteczek `/gateway2` do `/gateway`. Wymagane są HTTPS, zgodna domena i ważny secure cookie. Źródła semantyki: Apple HTTPCookie.domain oraz RFC 6265 (sekcja 5.1.4).
2. **Prawdziwy JSON MIME** — przyjmowane są `application/json` oraz podtypy `application/*+json`; odrzucany HTML nawet jeśli ciąg `json` znajduje się w komentarzu nagłówka. Błędny JSON / niezgodny obiekt kończy się `GatewayReadError.invalidResponse` zamiast surowego błędu deserializacji.
3. **Rozmiar** — oprócz faktycznej wielkości Data jest sprawdzany deklarowany rozmiar (`expectedContentLength`). Ograniczenie 4 000 000 bajtów obowiązuje dla obu. Nadal używany jest `URLSession.data(for:)`: deklarowany rozmiar nie jest limitem sieciowego streamu; nie należy tego tak przedstawiać.
4. **Adres odpowiedzi** — HTTPResponse.url musi równać się URL wysłanego GET, także z parametrami. Pozostają wyłączone przekierowania oraz stała lista zasobów.
5. **Stronicowanie** — `readGradeContinuation` wymaga bezpiecznych, niepustych i niepowtarzających się parametrów z jawnego URL serwera; maksymalnie 8 parametrów i 2048 bajtów query. Nie wymyślano nazw parametrów API, nowych endpointów ani nowych ścieżek.
6. Nie modyfikowano `Portal.swift`, `MainView.swift`, `SynergiaMessagesClient.swift` ani żadnych poprzednich parserów, cache i zabezpieczeń kont.

## Testy bez kompilacji iOS

- **PASS**: `bash Tests/run_batch18_incremental_offline.sh` — 68/68 przypadków polityki cookie/path/MIME/length/query i 24/24 kontrole granic, parsowanie całego kodu Swift, plus pakiety 17 i 16 (254/254, 28/28, 70/70, 22/22).
- **PASS**: `bash Tests/run_batch2_offline.sh` — starszy zestaw bazowy.
- **PASS**: `bash Tests/run_batch11_incremental_offline.sh`, `run_batch12_incremental_offline.sh`, `run_batch13_incremental_offline.sh`, `run_batch14_incremental_offline.sh`, `run_batch15_incremental_offline.sh`.
- **PASS**: 15 oddzielnych statycznych kontroli pakietów 3–17.
- **NIEZALICZONY**: jeden pełny łańcuch `run_batch7_offline.sh` nie zakończył się podczas próby, dlatego nie deklarujemy pełnej regresji historycznej. Stosowne kontrole pakietu 7 uruchomione odrębnie przeszły.
- **BRAK**: natywna kompilacja Xcode, testy iPhone/iPad, rzeczywiste cookies WebKit i serwerowe odpowiedzi API. Testy Foundation/Linux i parser nie zastępują tych weryfikacji.

## Następny krok

Zadanie nr 2 „Klient JSON” **80% → 90% (+10 pp)** w ramach zakresu możliwego do testowania offline. Pozostałe 10% wymaga rzeczywistej integracji. Szacunek projektu **59% → 60%**, pozostało **40%**. Wszystkie pozostałe zadania bez zmiany. Następne wg stałej kolejności: zadanie nr 3 — Izolacja kont (90%). **Nie kompilowano ani nie tworzono IPA.**
