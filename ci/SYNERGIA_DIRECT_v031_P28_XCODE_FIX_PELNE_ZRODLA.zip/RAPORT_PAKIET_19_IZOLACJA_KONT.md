# SYNERGIA DIRECT v0.31 — PAKIET 19: IZOLACJA KONT

**Baza:** pełne źródła pakietu 18. Zmodyfikowano wyłącznie `Sources/Portal.swift`; dodano `Sources/DirectAccountCommitPolicy.swift` i testy. Zachowano niezmienione 36 zadań i wersję v0.31.

## Zweryfikowana rozbieżność

Przed zmianą `refreshDirectGrades()` i `refreshDirectAttendance()` potwierdzały zgodność identyfikatora w pierwszym i ostatnim `/Me`, lecz nie wymagały, by identyfikator był ten sam, co już zweryfikowany lokalny właściciel. Te pojedyncze odczyty sprawdzały również głównie epokę żądania, bez pełnego sprawdzenia epoki konta, pierwszego i obecnego właściciela oraz przejścia aplikacji w tło przed zapisem. Mogło to dopuścić zapis wyniku do nieoczekiwanej partycji po przełączeniu konta w zewnętrznej sesji WebKit (niepotwierdzone praktycznie — to wynik analizy ścieżki kodu).

## Poprawka

1. Odmowa rozpoczęcia pojedynczego odczytu ocen lub frekwencji, jeśli lokalne konto nie jest zweryfikowane albo aplikacja ma aktywną osłonę prywatności / jest w tle.
2. Bezpośrednio po pierwszym `/Me` i bezpośrednio przed odblokowaniem partycji danych po ostatnim `/Me` musi przejść `DirectAccountCommitPolicy.permits`: ten sam ID konta przy starcie, obecnie, w pierwszym i ostatnim `/Me`, stała epoka konta i żądania, widoczna aplikacja.
3. Nie zmieniono klienta API, logowania, samego cache, parsowania ocen/frekwencji, wysyłania wiadomości ani `.github/workflows/ios.yml`.

## Testy

- `Tests/run_batch19_incremental_offline.sh`: 3212/3212 permutacji właściciela/epok/widoczności i 14/14 kontroli granic, składnia wszystkich źródeł Swift PASS.
- Regresja pakietów 18, 17, 16 wykonywana łańcuchowo w skrypcie: 68/68 + 24/24, 254/254 + 28/28, 70/70 + 22/22 — PASS.
- Brak natywnej kompilacji iOS dla pakietu 19. Brak testów rzeczywistego WebKit i konta Synergii. GitHub Actions kompiluje osobno pakiet 18; wynik wymaga odczytania z GitHub.

## Postęp

Zadanie 3: 90%→95% (+5 pp). Łączny wynik po zaokrągleniu: **60%** (bez zmiany), do końca **40%**. Niedomknięte 5% zadania wynika z braku żywego testu zmiany kont/sesji na iOS, nie z niedokończonej logiki offline. Kolejne: zadanie nr 4 „Sesja” (88%).
