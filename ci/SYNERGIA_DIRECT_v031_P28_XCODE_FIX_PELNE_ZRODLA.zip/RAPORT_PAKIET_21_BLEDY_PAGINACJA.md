# Raport techniczny pakietu 21 — błędy i paginacja (v0.31)

## Zmiana
- `Sources/DirectGradePagination.swift`: `continuation` sprawdza nie tylko domenę, ścieżkę i HTTPS, ale też poprawność serwerowego query przez istniejącą `GatewayJSONPolicy.safeContinuationQuery`. Nie generuje własnych nieudokumentowanych parametrów paginacji.
- Wykrywa `Next` wskazujący bieżącą stronę **przed** kolejnym HTTP GET.
- `merge` zapamiętuje adresy stron pośrednich i odmawia scalenia łańcucha wracającego do już odwiedzonej strony.
- Osiem wariantów `GradePagingError` ma polskie opisy `LocalizedError`, używane przez istniejącą obsługę błędów widoku.
- Ochrona kompletnych ocen (licznik, identyfikatory, limit stron, brak cichego nadpisania) pozostała bez zmian; zakres zmian tylko w jednym istniejącym pliku Swift.

## Testy
- `Tests/grade_paging_safety_standalone.swift`: 32/32 PASS.
- `Tests/verify_batch21_boundaries.py`: 14/14 PASS.
- `bash Tests/run_batch21_incremental_offline.sh`: PASS; testy regresji od pakietu 20 w dół do pakietu 16 oraz wymagane podzestawy historyczne PASS.
- `swiftc -frontend -parse Sources/*.swift`: PASS (test składni Swift; bez SDK iOS).
- Testów na natywnym Xcode, iPhone oraz żywej Synergii nie wykonano.

## Ograniczenia
- Rzeczywisty serwer może stosować inną postać kontynuacji. Nie zamieniamy nieznanych parametrów w zgadywane linki. W przypadku odrzucenia adresu zachowujemy poprzednie dane, zamiast publikować niepełną listę.
- Nie uruchomiono kolejnej kompilacji IPA.
