# SYNERGIA DIRECT v0.31 — pakiet 22: semestry i testowanie wyłącznie iPhone

## Rzeczywiste zmiany
1. `Sources/SupplementalSemesterCoverage.swift` (nowy): identyfikatory z czterech dodatkowych rodzin ocen chronione przed zniknięciem po skróconym odczycie; przesunięcie tej samej oceny między semestrami nie jest uznawane za usunięcie. Rodzina 403/404 zachowuje poprzedni stan. Zbiorcze liczniki pokazują semestr I, II i nieoznaczone/niestandardowe osobno w ocenach normalnych i innych.
2. `Sources/SupplementalGrades.swift`: odpowiedź z aktywnym `Next` albo błędnym/jawnym niespójnym `TotalCount`/`Total` blokuje zmianę magazynu; brak licznika nadal nie jest dowodem kompletności.
3. `Sources/Portal.swift`: nowa walidacja uruchamiana przed zapisem zarówno w ręcznym odświeżaniu ocen, jak i w zbiorczym synchronizowaniu, z zachowaniem weryfikacji konta. Wpisy z nieosiągalnych rodzin są zachowywane.
4. `Sources/MainView.swift`, `Sources/GradeSemesterPresentation.swift`: status semestrów obejmuje wszystkie rodziny; licznik w zwykłej liście jest jawnie podpisany jako liczba ocen zwykłych, nie wszystkich.
5. `.github/workflows/ios.yml` i `Tests/IOS_DEVICE_TEST_PLAN.md`: polityka testów urządzeń wyłącznie na iPhonie, bez iPada. Dotychczasowy workflow jest ręczny i build-only, nie uruchamia żadnego symulatora. Samo wsparcie aplikacji dla iPada nadal istnieje w `TARGETED_DEVICE_FAMILY: 1,2`. Nie uruchamiano workflow.

## Wyniki
- `Tests/semester_portfolio_standalone.swift`: 25/25 PASS na Linux/Foundation.
- `Tests/verify_batch22_boundaries.py`: 18/18 PASS.
- `Tests/verify_iphone_only_ci.py`: 8/8 PASS (kontrola statyczna zakresu; nie jest to test urządzenia).
- `swiftc -frontend -parse Sources/*.swift`: PASS (składnia, nie kompilacja iOS).
- `bash Tests/run_batch22_incremental_offline.sh`: PASS wraz z poprzednimi pakietami 16–21.
- Czyste rozpakowanie i powtórny przebieg testów + CRC/SHA-256: PASS.

## Granice weryfikacji
- Żaden z procentów nie dowodzi pełnego odczytu obu semestrów na realnym koncie; nie sprawdzono bezpośrednio Synergii, iPhone’a ani Xcode.
- Nie dodano nieznanych endpointów, semestrów wywiedzionych z dat ani wymyślonych wartości.
- Przy uprawnionym usunięciu wcześniejszej oceny polityka konserwatywna może odrzucić aktualizację, aby nie utracić danych bez potwierdzonej przyczyny. Takie usunięcia wymagają osobnej weryfikacji.
- Nie wykonano kompilacji IPA. Brak runnera w poprzedniej próbie GitHub Actions nie był skutkiem testowania iPada (tam nie wykonano żadnych kroków).
