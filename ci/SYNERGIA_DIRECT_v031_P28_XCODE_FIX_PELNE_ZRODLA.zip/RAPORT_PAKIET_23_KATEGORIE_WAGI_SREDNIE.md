# SYNERGIA DIRECT v0.31 — pakiet 23: kategorie, wagi i średnie

## Przyczyna i rzeczywiste modyfikacje
- Dotychczasowe `totalWeight += weight` oraz `weighted += value * weight` mogły dawać Infinity/NaN przy sumie kilku bardzo dużych, lecz skończonych wag. Nowa średnia normalizuje wagi przez największą dodatnią wagę w grupie. Nie zaokrągla wag, nie interpretuje plusów/minusów i nie nadaje brakującym wagom wartości domyślnych.
- Wcześniej powtórzony identyfikator w lokalnym zbiorze mógł zawyżyć średnią. Teraz każda grupa zawierająca powtórzoną tożsamość ma wynik nieustalony. Powtórzenie między semestrami/przedmiotami także zostaje oznaczone.
- UI pokazuje liczbę ocen wliczonych, jawnie niewliczonych i nierozstrzygniętych, zachowując podpis „orientacyjne” i dotychczasowe ograniczenie do dwóch oznaczonych semestrów.
- Modyfikowano tylko `Sources/GradeWeightedAverage.swift`, `Sources/MainView.swift` plus dodano testy/dokumentację. Pozostały 81 plików źródłowych Swift pozostają bajtowo identyczne z pakietem 22.

## Walidacja
- `Tests/grade_weighted_average_safe_standalone.swift`: 25/25 PASS, skrajne wagi, wykluczenia, powtórzone ID i nierozstrzygnięte pola.
- `Tests/grade_mean_standalone.swift`: 11/11 PASS (starsze przypadki).
- `Tests/verify_batch23_boundaries.py`: 17/17 PASS, kontrola wybranych warunków, 36 niezmienionych pozycji harmonogramu i 81 SHA-256 chronionych źródeł.
- `swiftc -frontend -parse Sources/*.swift`: PASS, tylko parser Swift, nie build iOS.
- `bash Tests/run_batch23_incremental_offline.sh`: PASS włączając historyczne regresje do pakietu 22.
- Czysty ZIP, CRC, manifest SHA-256 i testy po rozpakowaniu: PASS.

## Granice
- Brak prawdziwych danych serwera do potwierdzenia tego, co szkoła wlicza do oficjalnej średniej. Algorytm nie zastępuje oficjalnej średniej Synergii.
- Nie wykonano kompilacji iOS ani testów urządzenia. Nie tworzono ani nie uruchamiano nowego IPA.
