# SYNERGIA DIRECT v0.31 — pakiet 24: szczegóły i komentarze ocen

## Wykonane
- Baza: rzeczywiste źródła pakietu 23. W `MainView.swift` po kliknięciu oceny otwiera się osobny ekran `DirectGradeDetailView` z pełną wartością, przedmiotem, semestrem, datą, kategorią, wagą, informacją o wliczaniu do średniej, autorem oraz wszystkimi komentarzami.
- Komentarze są wyświetlane bez obcinania, ze znakami nowej linii i możliwością zaznaczenia tekstu. Dwa komentarze o identycznej treści są prezentowane oddzielnie. Brak komentarzy i tekst pusty są rozróżniane.
- Nowy `GradeDetailAccess` ponownie sprawdza konto weryfikowane, właściciela magazynu, identyfikator oceny i tarczę prywatności **przy odczycie szczegółów**. Widok nie przechowuje starego `DirectGrade` po przełączeniu konta albo wylogowaniu.
- Świadomie nie zmieniano formatu danych, API, parsera komentarzy, synchronizacji, lokalnego magazynu ani pozostałych modułów. Zmodyfikowano tylko `Sources/MainView.swift`, dodano `Sources/DirectGradeDetailView.swift`, `Sources/GradeDetailAccess.swift`, testy i raporty.

## Weryfikacja
- `Tests/grade_details_access_standalone.swift`: 18/18 PASS, w tym zmiana konta, wylogowanie, zasłona prywatności, brak rekordu, identyczne i długie komentarze.
- Starszy `Tests/grade_details_standalone.swift`: 14/14 PASS.
- Pozostałe testy referencji, średnich, semestrów, autorów i przedmiotów uruchomiono ze źródeł pakietu 24 (wyniki zapisane w `TESTY_PAKIET24.log`).
- `swiftc -frontend -parse Sources/*.swift`: PASS — tylko parser języka Swift, nie typowanie projektu SwiftUI dla iOS.
- `Tests/verify_batch24_boundaries.py`: 20/20 kontroli, 36/36 pozycji harmonogramu i SHA-256 niezmienionych źródeł.
- Test z czysto rozpakowanego archiwum, CRC ZIP, manifest SHA-256: wyniki w raporcie wydania.

## Ograniczenia
- Nie wykonano kompilacji w Xcode, testu na iPhonie ani rzeczywistej Synergii. Działanie na urządzeniu pozostaje niepotwierdzone.
- Wcześniejsze testy pinujące dosłownie stary `MainView.swift` nie są miarodajne dla nowego ekranu, dlatego uruchomiono związane z ocenami testy funkcjonalne i nową kontrolę granic zamiast ogłaszać pełną starą regresję.
- Nie uruchomiono kolejnej kompilacji IPA; polecenie użytkownika wymaga tylko sprawdzenia wyniku istniejącego workflow na samym końcu.

## Postęp
- Zadanie 8 „Oceny — komentarze i szczegóły”: 70% → 95% (+25 pp); pozostały test iOS i żywej Synergii.
- Cały projekt: szacunkowo 64%, pozostało 36% (zmiana +1 pp po zaokrągleniu). Harmonogram 36 zadań bez zmian nazw i kolejności.
- Następne zadanie: nr 9 „Oceny — przedmioty i nauczyciele”, obecnie 90%.
