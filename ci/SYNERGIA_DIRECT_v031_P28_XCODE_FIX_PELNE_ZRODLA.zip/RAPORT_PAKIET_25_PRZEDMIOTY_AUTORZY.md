# SYNERGIA DIRECT v0.31 — pakiet 25: przedmioty i autorzy ocen

## Wykonano
- Bazą są pełne źródła pakietu 24. Dodano `Sources/GradeSubjectAuthorAudit.swift`, który kontroluje powiązania każdego standardowego wpisu oceny z nazwą przedmiotu oraz jawnym `AddedBy`.
- Model rozdziela autorów z zapisanego odczytu, nazwy przywrócone z wcześniejszego odczytu zweryfikowanego konta, jawne ID bez rozpoznanego nazwiska oraz brak pola `AddedBy`. Nie utożsamia autora wpisu z nauczycielem prowadzącym przedmiot.
- `Sources/MainView.swift`: po wyborze semestru/przedmiotu widoczny jest podsumowujący audyt powiązań ocen w tym filtrze, z ostrzeżeniem o brakujących polach.
- `Sources/DirectGradeDetailView.swift`: jednolity opis autora wpisu z oznaczeniem nazwy odziedziczonej z wcześniejszego odczytu. Brak autorstwa nie jest dopowiadany.
- Bez zmian formatu JSON i pamięci podręcznej, parsowania ocen, połączenia sieciowego, uprawnień i dotychczasowych modułów.

## Weryfikacja
- `Tests/grade_subject_author_audit_standalone.swift`: 49/49 testów Foundation — PASS.
- Kontrola składni Swift, zgodność niezmienionych źródeł z pakietem 24, wszystkie 36 pozycji harmonogramu oraz starsze testy ocen: wyniki w `TESTY_PAKIET25.log`.
- Starsza kontrola statyczna pakietu 24 wymaga dosłownej listy poprzednich plików Swift i nie może być zaliczona na pakiecie 25. Zastępuje ją nowa kontrola z zamrożonymi hashami pakietu 24.
- Weryfikacja ZIP/CRC/SHA-256 po czystym rozpakowaniu i test uruchomiony ze źródeł: w raporcie końcowym.

## Ograniczenia
- Autor wpisu `AddedBy` nie musi być nauczycielem prowadzącym przedmiot. Brak aktualnego wpisu w `/Users` nie oznacza, że użytkownik nim nie jest.
- Brak Xcode na macOS, testów żywej Synergii i testów na iPhonie — nie można potwierdzić zachowania UI w rzeczywistym środowisku.
- Nie uruchomiono nowej kompilacji IPA; status wcześniejszej próby zostanie sprawdzony osobno.

## Postęp i następne zadanie
- Zadanie nr 9: 90% → 95% (+5 pp). Projekt 64% zrealizowano, 36% pozostało (bez zmiany po zaokrągleniu).
- Dalej zadanie nr 10 — wykrywanie zmian ocen (65%).
