# SYNERGIA DIRECT — pakiet 26: wykrywanie zmian ocen

## Wykonano
- Zachowano pełne źródła pakietu 25. Dodano `Sources/GradeObservedChangeAudit.swift` jako Foundation-only model porównania dwóch, już zweryfikowanych odczytów tego samego konta.
- Model rozdziela nowo zauważone identyfikatory, zmiany treści zwykłych ocen, przeniesienia pomiędzy semestrami, zmianę samej metadanej kategorii oraz zmiany ocen z czterech dodatkowych zasobów. Zachowuje oddzielne identyfikatory per rodzina i wykrywa zduplikowane ID.
- Zmiana nazwy, wagi i flagi średniej przy niezmienionej treści wpisu jest raportowana jako *metadata-only*, nie jako zmiana wystawionej oceny. Nie powoduje to powiadomienia o zmienionej ocenie.
- Brakujące wpisy są wyłącznie brakującymi w odczycie, nie oznaczają potwierdzonego usunięcia. Niedostępne rodziny (403/404) są wyłączane z porównania i oznaczane jako nieodczytane.
- `Sources/Portal.swift`: włączono nowy audyt do ręcznego odświeżania oraz zbiorczej synchronizacji. Wynik jest publikowany dopiero po pomyślnym zapisie, a pierwsza synchronizacja stanowi bazę porównania, nie „nowe” oceny. Dotychczasowe mechanizmy powiadomień, kontroli właściciela i epok, ochrony przed ubytkiem ocen, dziennika błędów i zweryfikowanego `/Me` pozostają zachowane. W `CoreSyncChanges` nowo zaobserwowane oceny i edycje są liczone na podstawie rzeczywistej treści zamiast opisowych metadanych.

## Testy
- `Tests/grade_observed_changes_standalone.swift`: 201/201 asercji Foundation — PASS.
- `Tests/grade_change_audit_standalone.swift`: 12/12 historycznych asercji — PASS.
- `Tests/verify_batch26_boundaries.py`: 24/24 punktów integralności, zakresu zmian, izolacji konta i danych — PASS.
- Pozostałe regresje modelu autorów, ocen, szczegółów, średnich i obu semestrów: `Tests/run_batch26_offline.sh` — PASS.
- `swiftc -frontend -parse Sources/*.swift` — PASS; nie jest to typowanie lub kompilacja iOS.
- Manifest, ZIP CRC, bajtowe hashe i świeże rozpakowanie wraz z ponownym uruchomieniem testów — osobno potwierdzone podczas pakowania.

## Zakres ograniczeń
- Nie możemy twierdzić, że wykryto *oficjalną* zmianę w Synergii: porównujemy tylko odczyty już dopuszczone przez walidację; serwer może ujawniać niepełny widok.
- Nie wykonywano logowania do rzeczywistej Synergii, kompilacji Xcode ani interaktywnego testu iPhone. Nie tworzono nowego IPA; stan wcześniejszego workflow jest sprawdzany po zakończeniu prac.
- 90% zadania nr 10 oznacza ukończenie implementacji offline i testów jednostkowych; ostatnie 10% wymaga zweryfikowanego iPhone’a oraz realnych odczytów konta.

## Postęp
- Oceny — wykrywanie zmian: 65% → 90% (+25 pp).
- Cały projekt: szacunkowo 64% → 65% (+1 pp), pozostało 35%.
- Następne: zadanie 11 — frekwencja, odczyt JSON (80%).
