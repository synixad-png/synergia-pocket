# SYNERGIA DIRECT v0.31 — raport techniczny pakietu 27

## Cel i zakres

Kontynuacja nierozpoczętych testów nie jest wydawana jako nowy numer aplikacji: bazą nadal jest v0.31, źródła pakietu 26. Realizacja wyłącznie zadania nr 11 „Frekwencja — odczyt JSON”. Stan 80% → 90% (+10 punktów procentowych). Wszystkie pozostałe zadania zachowują poprzednie procenty i zakres.

## Wykonane zmiany kodu

**Jedyny zmieniony istniejący plik Swift:** `Sources/SynergiaAttendanceRecords.swift`.

1. `IsPresenceKind` jest odczytywane wyłącznie jako prawdziwa logiczna wartość JSON (`CFBoolean`). Foundation/Swift potrafi konwertować `NSNumber(0)`/`NSNumber(1)` do `Bool`, dlatego dotychczasowe `as? Bool` przyjmowało błędne serwerowe typy i mogło źle oznaczać obecność albo nieobecność. Teraz błędny typ wpisu nie jest klasyfikowany i odczyt nie zastępuje zapisu konta.
2. Liczbowe identyfikatory obecności, słowników typów i referencji lekcji muszą być skończonymi liczbami całkowitymi. Ciągi ID mogą nadal mieć litery (np. `t41685`), nie są przerabiane na liczby. Odrzucane są ID będące `Bool`, ułamkami, `NaN` i pustymi spacjami.
3. Wykrywanie zdublowanych identyfikatorów słownika typów następuje nawet wtedy, gdy jeden ze zdublowanych wpisów ma wadliwą nazwę lub flagę. Nie wolno arbitralnie wybrać jednego z dwóch sprzecznych opisów typu.
4. Nieprawidłowe wpisy frekwencji i brak słownikowego typu skutkują czytelnym błędem w języku polskim, nie cichą zamianą wyniku. Puste pole daty (same białe znaki) jest uznawane za brak daty; nie zgadujemy daty lekcji.

**Zachowane mechanizmy:** obydwie ścieżki odczytu (`refreshDirectAttendance` i synchronizacja zbiorcza) używają tego samego parsera. Nadal obowiązują weryfikacja konta przed i po pobraniu, ochrona wcześniejszej zapisanej frekwencji przed niepełnym odczytem, nierozpoznany przedmiot pozostaje `nil`, szkolne własne typy zachowują swoje nazwy i prawdziwą flagę obecności, dane w spoczynku zachowują pełną ochronę iOS.

## Kontrola i testy

- `Tests/attendance_json_integrity_standalone.swift`: **139/139 PASS** (przypadki syntetyczne, także przez faktyczne `JSONSerialization`; nie jest to żywa Synergia).
- `Tests/attendance_analytics_standalone.swift`: **219/219 PASS**, w tym nieznane statusy i daty, grupowanie na semestry/miesiące.
- `Tests/attendance_stats_standalone.swift`: **22/22 PASS**.
- `Tests/verify_batch12_boundaries.py`: **42/42 PASS**; `verify_batch2_boundaries.py`: **17/17 PASS**.
- `Tests/verify_batch27_boundaries.py`: **24/24 PASS** i pełna weryfikacja **36/36** niezmienionych zadań harmonogramu; dokładnie jeden plik źródeł Swift zmieniony, konfiguracja iPhone bez zmian.
- `Tests/run_batch4_offline.sh`: pełny historyczny zestaw funkcjonalny dokumentów, wiadomości i plików oraz checks — **PASS** (historyczny skrypt raportuje 295 własnych przypadków). Nie sumować bezpośrednio wyników różnych skryptów jako unikalnych przypadków, bo częściowo się pokrywają.
- Dwie stare kontrole tekstowe: `verify_message_boundaries.py` i `verify_attachment_and_unread_boundaries.py` miały nieaktualne wzorce kolejności instrukcji po wprowadzeniu bezpiecznego `sessionLifecycle` w pakietach wcześniejszych niż 26. W pakiecie 26 obie zwracały fałszywe negatywy. W pakiecie 27 poprawiono WYŁĄCZNIE te testy tak, aby **nadal wymagane były** `cancelCoreSync`, `lockDirectMessages`, blokada podczas `verifyAccount`, nawigacji i wylogowania oraz czyszczenie powiadomień przed zwolnieniem blokady; kod sesji i wiadomości pozostaje niezmieniony.
- Składnia źródeł Swift na Linux: PASS, nie zastępuje `xcodebuild` ani uruchomienia iOS.
- Test po czystym rozpakowaniu ZIP, CRC ZIP, SHA256 wszystkich plików i porównanie wszystkich źródeł z bazą pakietu 26: wyniki potwierdzone w końcowym teście opakowania.

## Ograniczenia

**Nie wiem**, czy wszystkie możliwe odpowiedzi rzeczywistego API szkolnego zostały obsłużone; w tym środowisku nie ma połączonej aktywnej sesji Synergii. Brak możliwości potwierdzenia działania na urządzeniu. Brak kompilacji Xcode i nowego IPA (zgodnie z poleceniem, tylko okresowe sprawdzenie starszej próby na GitHubie). Nazwa zadania 31 nadal brzmi „iPhone / iPad”, mimo że zakres testów dotyczy wyłącznie iPhone.

## Co dalej

Zadanie nr 12 „Frekwencja — statusy” (75%). Należy analizować rozróżnienie obecności, spóźnień i usprawiedliwień bez klasyfikowania na podstawie numerów typów; potwierdzenie semantyki na rzeczywistych danych wymaga iPhone i Synergii.
