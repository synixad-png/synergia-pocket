# SYNERGIA DIRECT v0.31 — pakiet 28 — statusy frekwencji

## Zakres, baza i wynik

Baza: rzeczywiste źródła pakietu 27 (v0.31), bez rekonstrukcji projektu. Zadanie nr 12 „Frekwencja — statusy”: 75% → 90% (+15 pp). Pozostałe 35 pozycji harmonogramu bez zmian. Historyczny szacunkowy postęp projektu: 66% wykonano / 34% pozostało.

## Potwierdzony błąd i korekta

Dotychczas `DirectAttendanceStatus.excuse` rozpoznawał jako **usprawiedliwioną** każdą nieobecność, której nazwa zawierała ogólny rdzeń `usprawiedliw`, np. „Do usprawiedliwienia”, „Oczekuje na usprawiedliwienie”, „Brak usprawiedliwienia”. Nie potwierdza to rozpatrzenia nieobecności.

- W `Sources/DirectAttendanceStatistics.swift` klasyfikator jest ostrożniejszy: pozytywne, jednoznaczne określenia stanu (`usprawiedliwion*`, skrót końcowy `uspr.`) oznaczają usprawiedliwione wg nazwy; jawne formy `nieusprawiedliwion*` i `nieuspr.` oznaczają nieusprawiedliwione wg nazwy. Wnioski, statusy w toku, informacje o braku usprawiedliwienia i dowolne własne nazwy szkół pozostają **nierozstrzygnięte**. Brak zgadywania na podstawie numerycznego ID.
- W `Sources/DirectAttendanceAnalyticsView.swift` użytkownik widzi objaśnienie, że klasyfikacja usprawiedliwienia wynika jedynie z jednoznacznej nazwy, a nie urzędowej decyzji serwera.
- Pole `IsPresenceKind` pozyskane z JSON pozostaje jedynym źródłem podziału na obecność i nieobecność, z zachowaniem ścisłej walidacji CFBoolean z pakietu 27. Własne szkolne typy i nieznane statusy zachowują oryginalne brzmienie, identyfikatory i liczniki. Nie wyliczono oficjalnego procentu frekwencji.

## Testy

- Nowe `Tests/attendance_status_semantics_standalone.swift`: 182/182 PASS, uwzględnia jednoznaczne oraz wnioskowane/oczekujące statusy, flagę obecności z serwera, zachowanie sum i filtry w analityce.
- Dotychczasowe: JSON 139/139 PASS; analityka 219/219 PASS; statusy/liczniki 22/22 PASS.
- `Tests/verify_batch2_boundaries.py`: 17/17 PASS; `Tests/verify_batch12_boundaries.py`: 42/42 PASS; `Tests/verify_batch28_boundaries.py`: 14/14 PASS, wraz z dokładnym SHA256 wszystkich niezmienianych plików Swift i nieruszonym `project.yml`.
- Kontrola składni wszystkich `Sources/*.swift` na Linux oraz kontrola archiwum po czystym rozpakowaniu — wyniki w finalnym raporcie pakowania.

**Ograniczenia:** brak żywego konta Synergii, brak potwierdzonych słowników typów konkretnej szkoły, brak interaktywnych testów iPhone i pełnego Xcode build. Dlatego pozostałe 10% zadania wymagają testów na rzeczywistych danych. Nie twierdzimy, że rozpoznane nazwy są oficjalnym schematem statusów szkolnych. Wersja wciąż v0.31. Nie dodawano IPA do paczki.

## GitHub IPA

Na osobnej gałęzi `ci/synergia-direct-ipa-20261105` zmieniono wyłącznie `runs-on: macos-15` na `runs-on: macos-15-intel` (commit `46d678dd0f5bad5349a3f0c4e31374807e7b2265`). Nowe uruchomienie: https://github.com/synixad-png/synergia-pocket/actions/runs/42094811996 . Kompilacja dotyczy historycznego pakietu 18, a bieżący pakiet 28 pozostaje wyłącznie lokalną paczką źródeł. Aktualny status GitHub należy odczytać na końcu realizacji; nie utożsamiać zakolejkowania z gotowym IPA.

## Dalej

Zadanie nr 13 — Frekwencja: daty, lekcje i przedmioty (75%). Zachować zamrożone mechanizmy, wdrożyć i sprawdzić pełny zakres możliwy bez dostępu do live; nie przechodzić do innych modułów przed zakończeniem pracy nad zadaniem 13 w granicach dostępnej weryfikacji.
