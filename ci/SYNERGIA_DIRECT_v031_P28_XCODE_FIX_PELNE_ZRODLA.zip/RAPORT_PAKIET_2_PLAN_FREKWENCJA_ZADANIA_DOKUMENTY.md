# SYNERGIA DIRECT v0.31 — pakiet 2, 05.11.2026

## Źródła
Porównanie z niezależną biblioteką `MichalZaniewicz/librus-synergia` (pliki `docs/endpoints.md` i `docs/messages.md`) potwierdziło działające nazwy zasobów na koncie testowym autora, NIE na koncie użytkownika. Repozytorium: https://github.com/MichalZaniewicz/librus-synergia

## Zmienione pliki
- `Sources/SynergiaGatewayClient.swift` — dopisane udokumentowane zasoby, walidacja jednego `weekStart` do planu.
- `Sources/DirectSchoolFeeds.swift` — poprawne przypisanie `HomeWorkAssignments` i `HomeWorks`, dodana lista `SchoolFiles`.
- `Sources/Portal.swift` — bezpośredni plan, sesja konta przed/po, anulowanie stanów na wszystkich trzech granicach oraz czyszczenie danych po wylogowaniu.
- `Sources/MainView.swift` — plan, lista dokumentów, podsumowanie statystyk frekwencji.
- `Sources/DirectAttendanceStatistics.swift` (nowy) — statystyki otrzymanych rekordów.
- `Sources/DirectTimetable.swift` (nowy) — parser tygodnia w formacie date→slot→group.

## Gwarancje i ograniczenia
1. **Frekwencja:** `IsPresenceKind` jest źródłem statusu obecność/nieobecność. Rozpoznanie spóźnień i usprawiedliwień po nazwach ma charakter pomocniczy; nie jest oficjalnym statusem. Brak wpisu nie uprawnia do obliczenia rzeczywistej frekwencji.
2. **Plan:** dany dzień może mieć dwie lub więcej lekcji równoległych. Aplikacja pokazuje je wszystkie, bo nie ma potwierdzenia grupy ucznia. Brak nazw po nieudanym odczycie `Subjects` jest jawny, a nie zgadywany.
3. **Zadania vs terminarz:** wcześniej były błędnie połączone z `HomeWorks` / `Agenda`. Obecnie `HomeWorkAssignments` służy do zadań, a `HomeWorks` do terminarza. Parser nie nazywa pustego `Data` bez licznika pełną listą.
4. **Dokumenty:** wyświetlany jest spis z `SchoolFiles`, NIE ma jeszcze bezpośredniego pobierania załączników z tej listy. Nie przekazujemy niezweryfikowanego `downloadUrl` do przeglądarki ani do serwera zewnętrznego.
5. **Bezpieczeństwo sesji:** plan i odczyty źródeł w pamięci są unieważniane przy wylogowaniu, zmianie nawigacji i ponownej weryfikacji. Odczyt planu publikuje dane tylko po zgodnym `Me` przed i po, i nie zapisuje ich na dysku.

## Testowanie
Uruchomiono na Linuksie istniejące 160 testów Swift bez iOS, oraz nowe zestawy:
- `Tests/attendance_stats_standalone.swift` — 22/22 PASS;
- `Tests/feed_mapping_standalone.swift` — 14/14 PASS;
- `Tests/timetable_standalone.swift` — 16/16 PASS;
- `Tests/verify_batch2_boundaries.py` — 17/17 PASS;
- `swiftc -frontend -parse Sources/*.swift` — PASS.

Łącznie **212/212 przypadków testów logiki** (160 + 22 + 14 + 16) oraz istniejące i nowe kontrole statyczne. To NIE jest `xcodebuild`, NIE jest pełne typecheckowanie modułów SwiftUI ani test faktycznej łączności iOS / Synergia. Nie kompilowano i nie przygotowywano IPA.
