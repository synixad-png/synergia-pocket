# SYNERGIA DIRECT v0.31 — pakiet 3, dokumenty i historia zastępstw

## Baza i źródła

Baza: dokładnie ZIP z pakietu 2 `SYNERGIA_DIRECT_v0_31_DUZY_PAKIET_PLAN_FREKWENCJA_ZADANIA_DOKUMENTY_ZRODLA_BEZ_IPA.zip`. Nie zastępowano projektu demonstracją. Dokumentacja referencyjna (nie oferty oficjalnego API): `MichalZaniewicz/librus-synergia`, `docs/endpoints.md`, `src/librus_synergia/client.py`; potwierdzenia na jego kontach z października 2026, nie na koncie użytkownika.

## Zmiany w kodzie

1. `Sources/DirectSchoolFiles.swift`: jednoznaczne rozpoznanie `SchoolFiles.Data[].id`, `displayName` i `downloadUrl`; akceptacja tylko dokładnej ścieżki `/pliki_szkoly/pobierz/<id>` z tym samym identyfikatorem; zablokowane nieprawidłowe i niebezpieczne linki, nazwy plików i przekierowania.
2. `Sources/SynergiaSchoolFileClient.swift`: pobranie ręczne z ciasteczkami TYLKO na oficjalnym hoście Synergii; zablokowane automatyczne przekierowania; obsługa dokumentowanego 302/303 do `sandbox.librus.pl/GetFile/...`, strona oczekiwania, `/get`, prób ograniczonych do 15 i ok. 32 s, limit 15 MB na plik. Sesyjne ciasteczka NIE są przekazywane do sandbox. Brak gwarancji zgodności z każdym serwerowym mechanizmem pobierania bez testu na koncie.
3. `Sources/Portal.swift` oraz `Sources/MainView.swift`: przycisk pobrania przy zatwierdzonym dokumencie, bezpieczny zapis tymczasowy z ochroną pliku, systemowe udostępnianie, limity 60 MB dla sesji, ponowna weryfikacja `/Me` po pobraniu, unieważnienie przy zmianie konta, nawigacji, ponownym odczycie dokumentów i wylogowaniu.
4. `Sources/DirectPlanChanges.swift`: parser `Calendars/Substitutions` z rozdzieleniem oryginalnego i nowego terminu/przedmiotu/nauczyciela/sali; odwołania, przesunięcia, zastępstwa i nieustalony typ; unikalność ID, walidacja daty, brak zgadywania przydziału ucznia do równoległych grup. `Sources/SynergiaGatewayClient.swift` zawiera ściśle określoną nazwę endpointu.
5. `Portal.swift` i `MainView.swift`: historia zmian powiązana z wybranym tygodniem, opcjonalny słownik nauczycieli z `Users`; brak historii lub niedostępne `Users` nie powodują ukrycia rozpoznanego tygodniowego planu. Dane czyszczone przy wylogowaniu.

## Testy i ich granice

`bash Tests/run_batch3_offline.sh`: **258/258** przypadków logiki offline:
- 160 poprzednich przypadków wiadomości/ocen;
- 22 statystyki frekwencji;
- 18 zgodność źródeł i wpisów dokumentów;
- 16 plan tygodniowy;
- 17 historia zmian planu;
- 25 polityka pobierania dokumentów.

`python3 Tests/verify_batch3_boundaries.py`: **32/32** kontroli tekstowych granic kodu, do tego dotychczasowe kontrole statyczne i `swiftc -frontend -parse Sources/*.swift`.

Nie wykonano pełnego sprawdzenia typów SwiftUI/WebKit, `xcodebuild`, interaktywnego iOS ani testu danych w prawdziwej Synergii. Nie można twierdzić, że pliki na pewno pobierają się na iPhonie, że historia zastępstw jest kompletna na koncie użytkownika, ani że obsługa plików większych niż 15 MB działa. Nie wykonywano kompilacji iOS ani nie wygenerowano IPA.

## Następny etap

Obsługa załączników do zadań domowych, pozostałe wymagane moduły, synchronizacja i testy integracyjne po zakończeniu wdrożeń; utrzymać dotychczasowy harmonogram i mechanizmy ochrony danych.
