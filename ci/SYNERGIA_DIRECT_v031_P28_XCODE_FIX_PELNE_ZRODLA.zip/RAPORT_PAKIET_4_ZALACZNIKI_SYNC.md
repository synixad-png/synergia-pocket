# SYNERGIA DIRECT v0.31 — raport pakietu 4 (05.11.2026)

## Zakres faktycznie wykonany

1. **Załączniki do zadań domowych:** referencje z `HomeWorkAssignments[].HomeworkAssigmentFiles` (zachowano pisownię pola Synergii), weryfikacja pary `homeworkId-fileId` i źródłowego URL `HomeWorkAssignments/Attachment/...`. Nieznana lista pozostaje nieznana, nie jest utożsamiana z pustą.
2. **Pobieranie plików:** po kliknięciu użytkownika `https://synergia.librus.pl/homework/downloadFile/<fileId>` z ciasteczkami wyłącznie z Synergii; bez automatycznych przekierowań, tylko `sandbox.librus.pl`: `GetFile/<ticket>` (strona oczekiwania → `/get`) i `index.php?action=CSTryToDownload&singleUseKey=...` (POST `CSCheckKey` do uzyskania `ready`, potem GET `CSDownload`). Do 3 biletów, do 15 kontroli na bilet, limit sesji nominalnie 150 sekund oraz limit pliku 15 MB. Nie uznaje HTML/JSON ani pustej odpowiedzi za plik. Nie dołącza cookies Synergii do żądań sandbox. Potwierdza `/Me` ponownie przed zapisaniem pliku z ochroną iOS, usuwa dane tymczasowe po zmianie sesji lub wylogowaniu; systemowy ShareLink do zapisania pliku.
3. **Zbiorcze odświeżanie czterech źródeł:** przycisk w widoku zadań/terminarza/ogłoszeń/dokumentów. Zebrane wyniki publikowane dopiero po drugim `/Me`. Pojedyncze błędy nie usuwają wcześniej udanego odczytu, lecz jawnie oznaczają go jako nieaktualny. Utrata konta blokuje wszystkie dane tych czterech modułów. Oddzielne odświeżenie modułu także ponownie weryfikuje konto przy błędzie.
4. **Porównanie odczytów:** serwerowe `Id` używane do identyfikacji wpisów niezależnie od kolejności. Rozpoznawane nowe i zmienione; brakujące **nigdy nie są określane jako faktycznie usunięte**, nawet gdy licznik odpowiedzi zgadza się z liczbą wpisów. Przy braku lub powtórzonym ID porównanie odrzucane.
5. **Regresje:** zachowano wcześniejsze źródła ocen, frekwencji, wiadomości, planu i szkolnych dokumentów; zmieniono jedynie `DirectSchoolFeeds`, `Portal`, `MainView`, skrypt testowy i dodano nowe źródła/testy.

## Wyniki weryfikacji

- `bash Tests/run_batch4_offline.sh`: **295/295** przypadków logiki offline (w tym 258 wcześniejszych + 21 nowego modułu załączników + 16 porównywania wpisów).
- `Tests/verify_batch4_boundaries.py`: **33/33** statyczne kontrole granic i bezpieczeństwa kodu. Wcześniejsze kontrole również przeszły.
- `swiftc -frontend -parse Sources/*.swift`: **PASS** — kontrola **składni**, nie pełna kompilacja iOS lub typowanie SwiftUI/WebKit.
- **Nie testowano** prawdziwego serwera Synergii, sesji konta, pobierania rzeczywistego załącznika, zachowania arkusza ShareLink na iPhonie ani działania w tle. Poprawność pobierania na prawdziwym koncie pozostaje niepotwierdzona.
- **Nie wykonywano** `xcodebuild`, nie zbudowano IPA ani aplikacji urządzeniowej.

## Potwierdzone podstawy techniczne / ograniczenia

Mechanizm pobierania oparto na opisanym i przetestowanym przez autorów biblioteki `MichalZaniewicz/librus-synergia` przepływie z `docs/endpoints.md` i `src/librus_synergia/client.py`, bez kopiowania kodu. Dane opisujące API są nieoficjalne i mogą się zmienić. Wywołania w rzeczywistej sesji mogą wymagać dalszej korekty. Kompletność list/stronicowania nie jest potwierdzona; dla danych z brakiem `Total` nie deklarujemy pełnego pobrania. Weryfikację API pozostawiono na końcowe testy na decyzję użytkownika.

## Co dalej

Pracować dalej nad pozostałymi zadaniami z niezmiennego harmonogramu — zwłaszcza obsługą zmian danych w ocenach i wiadomościach, local notifications, trybem offline i docelowym interfejsem iOS. Nie kompilować ani nie generować IPA bez wyraźnego polecenia użytkownika.
