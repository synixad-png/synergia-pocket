# SYNERGIA DIRECT v0.31 — PAKIET 5: WSPÓLNA SYNCHRONIZACJA I POWIADOMIENIA

Data: 2026-11-05. Baza: kompletna paczka pakietu 4 (`SYNERGIA_DIRECT_v0_31_PAKIET4_ZALACZNIKI_ZADAN_SYNCHRONIZACJA_PELNE_ZRODLA_BEZ_IPA.zip`). Numer wersji zachowany; nie budowano aplikacji iOS ani IPA.

## Wykonano

1. Jeden ręcznie uruchamiany przebieg pobierania JSON z trzech modułów: oceny (w tym rodziny: zwykłe, opisowe, punktowe, tekstowe i zachowanie), frekwencja oraz skrzynka Odebrane. Poprzedni przycisk synchronizacji zatwierdzonych stron HTML i synchronizacja czterech osobnych feedów zostały zachowane.
2. Zweryfikowanie tożsamości `/Me` przed pobraniem i po wszystkich odczytach; oddzielna kontrola sesji domeny Wiadomości przed i po pobieraniu listy. Przełączenie konta lub nawigacja unieważnia w toku odczyty, a etapowe wyniki nie są publikowane przed końcową weryfikacją.
3. Porównanie wpisów według stabilnego ID; brak w nowym odczycie nie jest potwierdzonym usunięciem. Standardowe i dodatkowe oceny oraz frekwencja nie są zastępowane, gdy znikają wcześniej zapisane ID. Błąd jednego z modułów pozostawia poprzedni zapis jako dotychczasowy, nie przedstawia go jako zaktualizowanego.
4. Pierwszy odczyt to punkt odniesienia, nie zestaw „nowych” ocen/obecności. Powiadomienia dla wiadomości tylko po dwóch kompletnych listach z tego samego konta.
5. Ustawienie powiadomień lokalnych w SwiftUI, domyślnie wyłączone. Zgoda iOS wymagana po aktywacji przez użytkownika. Powiadomienia są ogólne i nie zawierają nazwisk, wartości ocen, treści wiadomości ani identyfikatorów użytkowników. Tylko po ręcznej synchronizacji — nie w tle. Podczas wylogowania czyszczone są też powiadomienia w centrum iOS.
6. Blokada równoległej wysyłki/odczytu/pobierania z tych samych modułów w trakcie wspólnej synchronizacji. Poprawiono wcześniejszą ścieżkę frekwencji, by nie gubiła wpisów bez potwierdzenia.

## Potwierdzone testami offline

- `Tests/run_batch5_offline.sh`: 337/337 testów logiki w Swift (295 poprzednich + 42 nowe), PASS.
- `Tests/verify_batch5_boundaries.py`: 28/28 kontroli reguł bezpieczeństwa źródeł, PASS.
- `swiftc -frontend -parse Sources/*.swift`: PASS, kontrola SKŁADNI, nie typecheck aplikacji iOS.
- `Tests/verify_message_boundaries.py` i `Tests/verify_attachment_and_unread_boundaries.py` zaktualizowano o nową, bezpieczniejszą kolejność unieważniania operacji; sprawdzają także usuwanie powiadomień przed czyszczeniem wiadomości. Poprzednie testy zachowane.

## Ograniczenia i prace pozostałe

- Brak testów na prawdziwym koncie Synergii: nie znamy zachowania aktualnej sesji, kompletności list ocen ani rzeczywistej dostępności modułów dla konta użytkownika.
- Brak kompilacji iOS, typecheck SwiftUI/UIKit/WebKit/UserNotifications, uruchomienia na iPhonie i wysłania rzeczywistych powiadomień przez system iOS. Brak IPA zgodnie z instrukcją użytkownika.
- Powiadomienia wyłącznie po uruchomieniu synchronizacji podczas otwartej aplikacji, nie w tle. System iOS może odmówić uprawnienia lub nie wyświetlić alertu zgodnie z ustawieniami.
- Zmiany nie są stwierdzonymi, oficjalnymi usunięciami. Zależność od prywatnego API Synergii pozostaje ryzykiem.
- Pozostaje dokończenie kolejnych zadań stałego harmonogramu oraz testy integracyjne, które użytkownik odłożył na później.

## Kolejne zadanie

W obrębie niezmiennego harmonogramu: dopracowanie obsługi wygaśnięcia sesji, stabilności pracy klienta JSON i pozostałych braków w interfejsie; dopiero po zakończeniu implementacji, na polecenie użytkownika, kompilacja iOS/IPA.
