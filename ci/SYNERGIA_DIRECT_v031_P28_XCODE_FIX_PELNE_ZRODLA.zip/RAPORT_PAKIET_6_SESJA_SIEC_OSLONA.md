# SYNERGIA DIRECT v0.31 — PAKIET 6: sesja, sieć, prywatność iOS

**Wykonano (źródła Swift, bez kompilacji iOS):**

1. `Sources/DirectConnectionIssue.swift`: jawna klasyfikacja HTTP 401, 403, 408, 429, 503, błędów sieciowych i limitów czasu; odróżnianie niedostępności modułu od utraty sesji. Rozpoznawanie przekierowania logowania wyłącznie dla trzech oficjalnych domen Librusa — bez podążania za linkiem.
2. `Sources/SynergiaGatewayClient.swift` i `Sources/SynergiaMessagesClient.swift`: komunikaty użytkownika opisujące konkretną przyczynę niepowodzenia, zamiast generowanych przez system niejasnych błędów. Nie wdrożono automatycznego ponawiania POST ani wpisywania haseł. Brak kodu, który podążałby za przekierowaniem na obcą domenę.
3. `Sources/Portal.swift`: po przejściu do tła blokada dostępu do lokalnych danych konta, unieważnienie trwających odczytów, wyczyszczenie wiadomości i plików tymczasowych. Po powrocie z tła tylko wcześniejsze zweryfikowane konto przechodzi ponowny odczyt `/Me`; nieudana próba nie odsłania lokalnych danych. Poprawiono sposób sygnalizowania błędów nawigacji WebKit.
4. `Sources/MainView.swift`: jednolite osłonięcie ekranu w fazie `.inactive` i `.background` (ochrona podglądu w przełączniku aplikacji), wyświetlenie statusu sesji, przycisk „Sprawdź aktywną sesję”, przejście do oficjalnego logowania, instrukcja w Ustawieniach.
5. Zachowano wszystkie istniejące zasady wysyłania wiadomości (jedno żądanie POST po potwierdzeniu; niepowtarzanie przy niepewnym wyniku), oceny, frekwencję, plan, zadania, dokumenty, zapis kont i powiadomienia.

**Weryfikacja:** `bash Tests/run_batch6_offline.sh` — 377/377 testów logiki Foundation-only (337 poprzednich + 40 nowych), 35/35 nowych kontroli statycznych oraz odziedziczone kontrole starszych pakietów. Parsowanie składni `swiftc -frontend -parse Sources/*.swift` ukończone. Te testy NIE potwierdzają działania iOS/WebKit ani realnej Synergii.

**Brak dowodów:** nie wykonano typecheck całej aplikacji na SDK iOS, kompilacji Xcode, działania na iPhonie/iPadzie, reautoryzacji realnej sesji ani nawigacji OAuth na żywym koncie. Nie twierdzimy, że ochrona przełącznika aplikacji i ponowne odblokowanie działają na urządzeniu bez testu.

**Pozostało i kolejny krok:** zakończyć brakujące ekrany/obsługę modułów i w miarę możliwości ujednolicić stan offline; następnie przeprowadzić kompilację i test na urządzeniu dopiero na wyraźne polecenie użytkownika. Weryfikację prawdziwego konta odłożono zgodnie z decyzją użytkownika. Brak mechanizmu serwerowych powiadomień w tle; nie ma obejścia CAPTCHA/2FA.

**Wydanie:** bazą pozostaje v0.31. Wyłącznie pełne źródła i testy, żadnego IPA ani plików wykonywalnych iOS.
