# Pakiet 7 — spójne stany danych JSON i aktualność lokalnych zapisów

**Baza:** pełne źródła pakietu 6 (`v0.31`), bez tworzenia demonstracji, bez zmiany numeru wersji.

## Wykonano w całości w źródłach
1. `Sources/DirectModuleReadPresentation.swift` — jeden testowalny bez SwiftUI model ośmiu stanów. Nie wolno utożsamiać braku odczytu, pustej listy bez licznika i autorytatywnego zera. Weryfikacja identyfikatora konta ma pierwszeństwo przed każdym stanem; niedopasowanie usuwa z prezentacji liczby i daty.
2. `Sources/DirectReadStatusPanel.swift` — współdzielony panel SwiftUI z czytelnym tytułem, opisem, liczbą rekordów, datą i scaloną etykietą VoiceOver. Nie wykorzystuje HTML, nie uruchamia kodu stron ani nie odsłania danych ucznia w nagłówkach.
3. `Sources/MainView.swift` — wspólny panel w ośmiu ekranach; indywidualne stany załadowanych lub błędnych skrzynek; agregacja wszystkich skrzynek, nie tylko Odebranych; objaśnienie niezależnego historycznego odczytu HTML.
4. `Sources/Portal.swift` — `failedDirectReads` i `failedDirectMailboxes` aktualizowane przy udanych i błędnych żądaniach, również przy zbiorczym odświeżeniu; `freshDirectReads` dla zapisów ocen/frekwencji odróżnia dane z wcześniejszej sesji od odczytu z bieżącej. Reset po zmianie konta i przejściu w tło. Nie ma automatycznych ponowień POST.
5. `Tests/direct_read_state_standalone.swift`, `Tests/verify_batch7_boundaries.py`, `Tests/run_batch7_offline.sh` — testy decyzji UI, ochrony konta, niepotwierdzonych zer, nieaktualnych zapisów i spójności integracji.

## Testy i ograniczenia
- Cała wcześniejsza regresja: **377/377** testów Foundation-only PASS.
- Nowy model: **273/273** przypadki PASS.
- Nowe kontrole źródeł: **28/28** PASS; poprzedni audyt: **35/35** PASS.
- Parsowanie składni wszystkich plików Swift: PASS; weryfikacja integralności ZIP: PASS.
- To NIE jest kompilacja ani typowanie SwiftUI na iOS. **Nie ma dowodu, że aplikacja uruchamia się na iPhonie.**
- Rzeczywista struktura odpowiedzi Synergii na koncie użytkownika nadal niezweryfikowana. Kompletność ocen/wiadomości pozostaje niepotwierdzona, nawet gdy licznik pojedynczego zasobu jest zgodny.
- Powiadomienia nie są serwerowe ani niezawodnie wykonywane w tle; nie zmieniono tej granicy.

**Pozostało:** test na iOS i realnym koncie, poprawki wynikające z niego oraz następne zadania stałego harmonogramu. **Nie tworzono IPA i nie kompilowano iOS.**
