# Pakiet 8 — chroniony zapis JSON i bezpieczne odtwarzanie po utracie sieci

**Baza:** SYNERGIA DIRECT v0.31 pakiet 7; stały harmonogram 36 zadań; jedna natywna aplikacja SwiftUI, bez serwera pośredniczącego. Wersji nie podnoszono. **Nie kompilowano iOS i nie tworzono IPA.**

## Co rzeczywiście wdrożono

1. `DirectOfflineFeedCache.swift`: niezależny, testowalny kodek JSON z wersją schematu, przypisaniem do konta i modułu oraz walidacją rekordów, rozmiaru (2,5 MB na moduł), liczników, identyfikatorów, daty i bezpiecznych załączników.
2. `DirectOfflineFeedStore.swift`: zapis czterech modułów (`HomeWorkAssignments` / zadania, `HomeWorks` / terminarz, `SchoolNotices` / ogłoszenia, `SchoolFiles` / dokumenty) w partycji konta z niejawnie haszowaną nazwą folderu (`AccountPartition`, SHA-256). Zapis atomowy i `completeFileProtection` w iOS; folder wyłączany z kopii zapasowych. Odczyt wyłącznie po pozytywnym `/Me`. Uszkodzony moduł jest ignorowany niezależnie od pozostałych. Zwykły odczyt nie może odsłonić danych przed weryfikacją sesji.
3. `Portal.swift`: odblokowanie i oznaczenie lokalnego zapisu jako **NIEAKTUALNEGO** po `/Me`; zapis nowej odpowiedzi dopiero po końcowym porównaniu tożsamości. Tryb awaryjny zachowuje starsze dane tego SAMEGO konta po utracie sieci w nieprzerwanej, uprzednio zweryfikowanej sesji. Błędy autoryzacji, obce konto, nawigacja oraz przejście w tło blokują dostęp. Wspólna synchronizacja i odczyty ocen/frekwencji rozpoznają krótkie przerwy sieciowe. Dotychczasowe moduły Wiadomości pozostają bez trwałego zapisu JSON ze względów prywatności.
4. `MainView.swift`: ekran główny ma ręczny przycisk ponownego odczytu czterech modułów JSON; ustawienia wyświetlają rodzaj lokalnego zapisu dla każdego modułu. Stan przywróconych danych nie jest nazywany bieżącym odczytem. Na iPhonie nie dodano żadnego ukrytego automatycznego logowania ani skanowania w tle.
5. `DirectSchoolFeeds.swift`, `DirectHomeworkFiles.swift`, `DirectSchoolFiles.swift`: `Codable` dla istniejących struktur, bez modyfikacji znaczenia pól serwera. Bezpieczna ponowna walidacja lokalnych nazw plików przy odtwarzaniu.

## Co oznacza tryb offline

- **W trwającej, wcześniej zweryfikowanej sesji na pierwszym planie:** przy błędzie transportowym (`offline`, `timedOut`, `interrupted`) można zachować wcześniejsze dane, ale jako NIEAKTUALNE; nie wykonuje się powtórnej wysyłki wiadomości ani nie wyprowadza usunięć z braków wpisów.
- **Po zamknięciu aplikacji, przejściu w tło, zmianie konta lub logowaniu:** zapis jest zabezpieczony i niewidoczny do kolejnej udanej odpowiedzi `/Me`. Nie ma odblokowania na zimno bez internetu. To świadome ograniczenie zabezpieczające dane ucznia, nie pełny offline-login.
- **Ponowne połączenie:** użytkownik potwierdza konto i ręcznie odświeża moduły; zapisy przywrócone z dysku nadal mają status NIEAKTUALNE do czasu poprawnego odczytu. Brak monitoringu w tle, brak automatycznych POST.
- **Nieobjęte trwałym JSON:** wiadomości (pamięć RAM), plan tygodniowy (w tym pakiecie nie dodano nowego zapisu JSON), oraz pliki tymczasowe po wylogowaniu.

## Wyniki testów

- Dotychczasowa regresja pakietu 7: **377/377** starszych i **273/273** testów wspólnych stanów — PASS (650/650). Uruchomione na aktualnym kodzie przed końcową kontrolą pakowania.
- Nowe testy realnych struktur cache i polityki offline: **62/62 PASS**. `DirectOfflineFeedStore` w Linux testowany z zastępczym haszowaniem ścieżki — oryginalny iOS `AccountPartition` SHA-256 pozostaje nienaruszony.
- Nowe kontrole statyczne granic bezpieczeństwa: **41/41 PASS**, wcześniejsze kontrole regresji również PASS.
- `swiftc -frontend -parse Sources/*.swift` PASS, ale to nie sprawdza zgodności typów SwiftUI na iOS.
- Zbiorcze uruchomienie testów przekroczyło limit narzędzia na końcowym etapie; pozostałe kontrole uruchomiono osobno z wynikiem PASS. Testy nowych mechanizmów i wcześniejsza regresja są zapisane w `TESTY_PAKIET8_OFFLINE.log`.
- **Nie było testu fizycznego iPhone'a, autoryzowanej Synergii, kompilacji iOS ani IPA.**

## Postęp i następny zakres

- Całość: **50→51% (+1 pp, tylko szacunek)**; pozostało 49%.
- Zadanie „offline” w stałej liście: **75→90% (+15 pp)**. To **60% poprzednio pozostałego zakresu tego zadania** w jednej sesji, bez twierdzenia o pełnej weryfikacji na urządzeniu.
- Etap Synchronizacja 60→64% (+4 pp); ekran główny 80→82% (+2 pp), Ustawienia 60→65% (+5 pp), etap UI 70→71% (+1 pp). Pozostałe zadania bez zmian.
- Dalej: domknięcie lokalnego planu tygodniowego i wybranych danych offline oraz prace nad brakującymi funkcjami modułów. Testy iOS i realnej sesji Synergii dopiero na zlecenie użytkownika; bez generowania IPA przed decyzją użytkownika.
