# Pakiet 9 — trwały plan tygodniowy offline (v0.31, bez builda iOS)

## Baza i zakres

Kontynuacja dokładnie pakietu 8. Nie zmieniono numeru wersji ani listy 36 zadań. Dokończono implementację jednego rozpoczętego zadania: lokalny plan tygodniowy w module offline. Pozostałe moduły zachowano.

## Co zmieniono w rzeczywistym kodzie

1. `DirectTimetable.swift` i `DirectPlanChanges.swift`: bezstratne `Codable` istniejących struktur tygodnia, pozycji równoległych i zmian planu. Bez zmiany parsowania semantyki API.
2. `DirectOfflineTimetableStore.swift`: atomowy zapis w folderze z haszem SHA-256 identyfikatora konta (oryginalny `AccountPartition` w iOS), z `completeFileProtection` i wyłączeniem z kopii zapasowej. Limit 2,5 MB/planu, maksimum 16 tygodni na konto, wersja schematu, odrzucenie obcych kont, podmienionych tygodni, uszkodzonych i zbyt dużych danych, niewłaściwych dat, nadmiarowych wpisów, nieprawidłowych grup i duplikatów ID. Historia zmian oraz nazwy przedmiotów i nauczycieli są opcjonalne — brak odczytu nie powoduje wymyślania danych.
3. `Portal.swift`: odblokowanie planu tylko po potwierdzeniu bieżącego konta przez `/Me`; wczytywanie tylko wybranego tygodnia; zapis dopiero po zgodnym początkowym i końcowym `/Me`. Po zwykłej awarii transportowej w tej samej zweryfikowanej sesji może pozostać ostatni zapis (NIEAKTUALNY). Zmiana konta, błędna tożsamość, wylogowanie, nawigacja, powrót z tła i niejednoznaczne błędy nie są obchodzone. Wylogowanie usuwa magazyn z dysku. Nie ma automatycznego ponawiania żądań ani wysyłania wiadomości.
4. `MainView.swift`: zmiana tygodnia wybiera właściwy lokalny zapis, jeżeli jest odblokowany. Jeden wspólny panel pokazuje stan *stale*, a nie „odczyt potwierdzony”, dopóki dla tygodnia nie nastąpi udany odczyt w tej sesji. Informacja o braku historii jest odrębna od braku planu.
5. Dodatkowa ochrona: błędy w innych modułach wskazujące na utratę weryfikacji konta unieważniają także widoczny plan, a nie tylko jego zapis na dysku.

## Weryfikacja

- Przebieg poprzedniego `run_batch8_offline.sh`: **712/712** testów Foundation-only oraz 41/41 kontroli statycznych — PASS.
- Nowe testy realnego `DirectOfflineTimetableStore` i `DirectOfflineTimetableCodec`: **36/36 PASS**. Obejmują roundtrip tygodnia i historii, 2 konta, 16 tygodni, uszkodzone pliki, podmiany JSON i odmowę dostępu przed `/Me`.
- Nowe testy statyczne struktury/bezpieczeństwa: **45/45 PASS**.
- `swiftc -frontend -parse Sources/*.swift` PASS; to jedynie parser Swift, **nie** kompilacja iOS i nie sprawdza typów SwiftUI.
- Łączna liczba sprawdzonych przypadków logiki offline: **748 = 712 wcześniejszych + 36 nowych**, w uruchomionych częściach. Wspólny skrypt w jednym przebiegu przekroczył limit czasu narzędzia już po testach logicznych; pozostałe kontrole wykonano oddzielnie.
- Bez prawdziwego konta Synergii, urządzenia iOS, symulatora, kompilacji lub IPA. W testach Linux `AccountPartition` używa tylko tymczasowego zamiennika haszowania nazw folderów; produkcyjny SHA-256 pozostaje bez zmian.

## Ograniczenia i kolejny krok

Plan offline **nie jest dostępny po zimnym starcie bez internetu**, dopóki `/Me` nie zweryfikuje konta. Jest to świadoma ochrona danych ucznia. Nie ma informacji o rzeczywistym przydziale do grup równoległych, jeśli API jej nie zwraca. Przechowywane lokalnie dane są oznaczane jako NIEAKTUALNE do nowego udanego odczytu.

Zadanie offline: **90% → 95% (+5 pp)**, czyli co najmniej 50% poprzednio pozostałego zakresu zadania. Implementacja brakującego planu została zakończona, 5% pozostaje na końcowe testy rzeczywistej sesji/iOS. Etap Synchronizacja: 64% → 65% (+1 pp). Cały projekt: **51% wykonano, 49% pozostało**, po zaokrągleniu bez zmiany. Następnie można kontynuować inne zadania źródłowe; blokujące testy środowiska iOS oraz realnej Synergii pozostają na końcowy etap zgodnie z poleceniem użytkownika.
