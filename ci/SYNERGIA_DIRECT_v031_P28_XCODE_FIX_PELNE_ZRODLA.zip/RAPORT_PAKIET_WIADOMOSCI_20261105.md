# Raport techniczny — większy pakiet wiadomości SYNERGIA DIRECT v0.31

## Źródło i ograniczenia

Punktem wyjścia jest **bezpośrednio** ZIP `SYNERGIA_DIRECT_v0_31_WIADOMOSCI_WYSYLANIE_ODPOWIEDZI_PELNE_ZRODLA_BEZ_IPA.zip` (116 plików). Wszystkie pliki bazowe zachowano. Wykorzystano wiedzę o kształtach API i przepływie pobierania z dokumentacji projektu https://github.com/MichalZaniewicz/librus-synergia/blob/main/docs/messages.md oraz struktur klientów https://github.com/FlakM/librus-rs i https://github.com/emsi/librus_pyapi; zmiany są samodzielnie napisanym kodem Swift, nie kopią repozytoriów.

## Implementacja

1. `DirectMailbox`: dodano `notes`, `alerts`, `substitutions`, `absences`, `justifications`, `trash`, `archive/inbox`, `archive/outbox`; stare `inbox`, `outbox` zachowano. Są to **10 skrzynek**. Obsługa 404 pozostaje błędem dostępu, nie pustymi danymi.
2. `DirectMessageParser.list`: obsługa `{"data":[...],"total":N}` oraz samej tablicy. Gdy brak `total`, `complete=false`; duplikaty ID i niekompletne strony są blokowane.
3. `DirectMessagePlainText.render`: dekodowanie wiadomości Base64 (w istniejącym parserze), rozpakowanie XML/CDATA, rozdzielenie akapitów/br, usuwanie potencjalnie aktywnych tagów i ich zawartości, usuwanie pozostałego HTML/XML, odczyt encji Unicode i polskich liter. Wyświetlanie **zwykłym SwiftUI Text** (brak WebView, zdalnych obrazów, JavaScript). Nie jest to pełna obsługa zaawansowanego formatowania HTML.
4. Poprawiono nazwę korespondenta dla wysłanych i archiwalnych wiadomości, bez włączania odpowiedzi z archiwum. Przycisk otwarcia wysłanych nie ostrzega niepotrzebnie o oznaczeniu jako przeczytanej.
5. `DirectAttachmentPolicy` + `SynergiaMessagesClient.attachment`: bilet tylko od `https://sandbox.librus.pl/GetFile/...`, pobranie `.../get` z `Referer: <ticket>`, **bez ciasteczek** i automatycznych przekierowań. Dotychczasowy GET adresu biletu zwracał stronę HTML oczekiwania, nie plik. Pozostają limity 15 MB i sprawdzanie typu odpowiedzi.
6. Dla archiwalnych załączników w UI wskazano oficjalną Synergię zamiast niepewnego API, które według publicznych testów innego projektu zwraca 401. Ten sam warunek egzekwuje `Portal`, nie tylko widok.
7. Pozostawiono bez zmian potwierdzoną architekturę rozdzielania kont, odczyt ocen i frekwencji, osobny potwierdzany POST dla wiadomości oraz brak retry wysyłki.

## Testy

- 27/27 nowych testów — skrzynki, surowe tablice, XML/CDATA, XSS-inert text, HTML entities, pobieranie `/get`, niebezpieczne adresy.
- 25/25 wcześniejszych testów wiadomości, 42/42 wysyłania, 30/30 polityki załączników, 13/13 liczników.
- 12/12 audytu zmian ocen, 11/11 średnich (poprzednie mechanizmy).
- 16/16 + 21/21 + 24/24 kontrole statyczne i ogólne granice źródeł PASS.
- Całość `.swift` przechodzi `swiftc -frontend -parse`; to **nie jest** pełny build SwiftUI ani test na iOS.
- Powtarzalny skrypt: `Tests/run_message_batch_offline.sh`.

## Ograniczenia

Brak dostępu do konta użytkownika uniemożliwia potwierdzenie odpowiedzi serwera, szczególnych uprawnień szkoły, sesji międzydomenowej, prawdziwego pobierania pliku i formy rzeczywistych wiadomości. Kompilacji iOS/IPA nie wykonywano na wyraźną prośbę użytkownika. Część skrzynek może w konkretnej szkole zwracać 404.
