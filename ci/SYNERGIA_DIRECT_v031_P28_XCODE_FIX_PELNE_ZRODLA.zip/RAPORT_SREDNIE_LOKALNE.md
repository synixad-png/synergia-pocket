# SYNERGIA DIRECT — lokalne średnie ocen (v0.31, bez IPA)

Wykonano: osobna implementacja średniej arytmetycznej ważonej z jawną wagą i statusem wliczania, podział przedmiot/semestr, widok orientacyjny. Nieznane lub niestandardowe wartości nie są przeliczane. Nie dotyczy ocen opisowych/punktowych/zachowania.

Testy: 11/11 testów Swift PASS; parser składni źródeł PASS. Bez testu Xcode/iPhone/Synergii.

Zadanie „Pełne oceny z obu semestrów” pozostawione na 72% do rzeczywistej weryfikacji, zgodnie z decyzją użytkownika pomijamy blokadę i realizujemy kolejne zadania.

Zmiana: Kategorie, wagi i średnie: 65% → 75% (+10 pp). Całość 42%, pozostaje 58%.

Co dalej: pozostałe prace nad średnimi obejmują zgodność metodologii średniej ze szkołą i rzeczywistą Synergią; nie da się jej zadeklarować bez sprawdzenia. Można następnie domknąć offline komentarze/szczegóły w ramach zadań etapu 02.
