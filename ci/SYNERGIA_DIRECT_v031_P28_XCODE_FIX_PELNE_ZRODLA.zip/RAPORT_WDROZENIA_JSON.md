# Rozbudowa SYNERGIA DIRECT na bazie v0.31 — bez kompilacji iOS

Dodano trzy zasoby JSON odczytywane z istniejącej sesji WebKit: HomeWorks, Agenda, SchoolNotices.
Pojedynczy odczyt sprawdza tożsamość konta `/Me` przed i po zapytaniu. Widok przechowuje dane wyłącznie w pamięci i kasuje je po nawigacji/logowaniu, bez zapisywania cudzych danych.

Parser odmawia akceptacji nieznanej struktury, pustej listy bez licznika, nieprawidłowych wpisów, nadmiernej liczby rekordów i niespójnego licznika. Nie interpretuje pozycji jako trwałych identyfikatorów.

**Ograniczenie:** repozytoria open source dokumentują endpointy, ale nie zweryfikowano ich odpowiedzi z konta użytkownika; typ i dostępność na gateway/2.0 wymagają sprawdzenia. W szczególności nie potwierdzono stronicowania i autoryzacji części modułów. Nie zastępuje to testów na iPhone/iPad. Kompilacja iOS i IPA nie zostały wykonane.

Referencje: https://github.com/andrewkoltsov/librus-sdk, https://github.com/aeoliux/Violet, https://github.com/MichalZaniewicz/librus-synergia. Kod źródłowy innych autorów nie był kopiowany — wykorzystano wyłącznie publiczną dokumentację endpointów.

## Weryfikacja wykonana w tym środowisku
- Testy parsera Swift na Linux z typami pomocniczymi: 16/16 PASS.
- Parsowanie składni wszystkich plików Sources/*.swift: PASS (bez budowania aplikacji iOS).
- verify_source_boundaries.py: PASS.
- Nie wykonano `xcodebuild`, kompilacji iOS ani testów na iPhone.
- Nie zweryfikowano rzeczywistych odpowiedzi Synergii.
- Nowe dane pozostają wyłącznie w RAM; funkcje obsługi załączników i wysyłania wiadomości nie zostały dokończone.
