# SYNERGIA DIRECT v0.31 — wiadomości JSON (bez kompilacji iOS)

Data: 2026-11-05.

## Wdrożono

1. Oddzielny transport HTTPS GET dla domeny `wiadomosci.librus.pl/api/`, niezależny od odczytu ocen w `synergia.librus.pl/gateway/api/2.0/`. Brak wysyłania danych do pośredniego serwera.
2. Odczyt oficjalnych skrzynek **Odebrane** i **Wysłane**, z paginacją po 50 rekordów, maksymalnie 40 stron / 2000 wiadomości; publikowanie danych dopiero po zebraniu spójnych stron i weryfikacji /Me przed i po odczycie.
3. Odczyt pełnej wiadomości po identyfikatorze z aktualnej listy, dekodowanie Base64 do UTF-8, identyfikatory i metadane załączników bez pobierania plików.
4. Właściwa inicjalizacja domeny Wiadomości przez **oficjalną** stronę `https://synergia.librus.pl/wiadomosci3` w tym samym WebKit — opcja w ekranie wiadomości; bez żądania hasła przez aplikację.
5. Błędy: brak drugiej sesji, brak autoryzacji, kod HTTP 403, błędny format JSON, niedomknięte strony, duplikaty ID, błędne Base64, błędne nazwy załączników oraz sprzeczne liczniki.
6. Ścisłe przypisanie odczytów do konta; czyszczenie wiadomości na nawigacji, powtórnym potwierdzeniu konta, wylogowaniu oraz zmianie/tożsamości sesji. Wiadomości pozostają w pamięci (bez lokalnego zapisu treści).
7. Wbudowany ekran skrzynek, podglądu, pełnej treści i wykazu załączników w SwiftUI.

## Dowody i pochodzenie wiedzy technicznej

- `emsi/librus_pyapi`: dokumentacja nowego OAuth/MultiDomainLogon i pola komunikatów.
  https://github.com/emsi/librus_pyapi
- `FlakM/librus-rs`: niezależnie potwierdzone URL skrzynek, listy, szczegóły, Base64.
  https://github.com/FlakM/librus-rs
- Wykorzystano publicznie opisane punkty końcowe i nazwy pól, **bez kopiowania kodu** z AGPL-3.0. Nowy klient napisano w Swift.

## Testy wykonane w tym środowisku

- 25/25 testów Swift standalone dekodowania, paginacji, kontroli liczników i metadanych.
- 16/16 statycznych kontroli granic domeny, konta i transportu (to nie jest test HTTP na urządzeniu).
- 12/12 regresyjnych testów zmian ocen (Swift standalone).
- 11/11 regresyjnych testów średnich (Swift standalone).
- `swiftc -frontend -parse Sources/*.swift`: PASS.
- `verify_source_boundaries.py`: PASS.
- Zachowano 42/44 istniejących plików Source bajtowo; zmieniono wyłącznie `Portal.swift` i `MainView.swift`, dodano dwie nowe klasy/struktury Swift oraz testy.

## Niezweryfikowane lub jeszcze nieukończone

- **Brak kompilacji iOS, IPA, Xcode, testów iPhone/iPad, autoryzowanej sesji i realnych odpowiedzi serwera.**
- Nie potwierdzono działania logowania między domenami, rzeczywistego odczytu skrzynek, paginacji i pełnych treści na koncie użytkownika.
- Nie wysyłamy, nie odpowiadamy, nie pobieramy załączników i nie pobieramy wiadomości z dodatkowych skrzynek innych niż Odebrane/Wysłane.
- Mimo stosowania GET nie potwierdzono, czy serwer nie oznacza automatycznie otwieranych wiadomości jako przeczytane.
- Nieznany format JSON lub zmiana API oznacza jawny błąd; nie wolno pokazywać fikcyjnych danych.
- Do zamknięcia integracji niezbędna autoryzowana końcowa sesja Synergii i osobno kompilacja/testy iOS — dopiero na wyraźne polecenie użytkownika.

## Uruchomienie testów parsera bez iOS

`swiftc Sources/DirectMessages.swift Tests/direct_messages_standalone.swift -o /tmp/direct_message_tests && /tmp/direct_message_tests`

`python Tests/verify_message_boundaries.py`

**Numer wersji pozostaje v0.31, zgodnie z zasadą niepodnoszenia wersji dla częściowej implementacji.**
