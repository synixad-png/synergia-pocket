# SYNERGIA DIRECT — odczyt odbiorców, tworzenie i wysyłanie wiadomości

Data: 2026-11-05. Baza: `SYNERGIA_DIRECT_v0_31_WIADOMOSCI_ZALACZNIKI_LICZNIKI_PELNE_ZRODLA_BEZ_IPA.zip`. To rozwinięcie **istniejącego** projektu, bez nowej aplikacji demonstracyjnej.

## Zakres techniczny

1. `Sources/DirectMessageCompose.swift` — modele grup i odbiorców, walidacja identyfikatorów i dostępności, ograniczenia treści/tematu, draft przypisany do identyfikatora dziecka **i** tożsamości sesji `wiadomosci.librus.pl`, normalizacja polskich znaków, HTML escaping i Base64 oraz ocena odpowiedzi jako wysłano / odmówiono / niepewne.
2. `Sources/SynergiaMessagesClient.swift` — tylko oficjalna domena HTTPS, bez przekierowań. `GET /me`, `GET /receivers/types?includeClass=true`, `GET /receivers/groups/school-employees?receiverType=<id>` i JEDEN `POST /messages` lub `POST /messages/reply` po potwierdzeniu. Timeout i 5xx są statusem niepewnym; zero automatycznego retry.
3. `Sources/Portal.swift` — dwuetapowe potwierdzenie. Pierwszy przycisk przygotowuje podgląd bez żądania POST, drugi faktycznie wywołuje wysyłkę. Tożsamość głównego `/Me`, tożsamość `/api/me` domeny wiadomości i epoki sesji są ponownie sprawdzane przed POST. Wszelkie drafty znikają po zmianie konta / nawigacji / wylogowaniu. Treść jest tylko w RAM.
4. `Sources/DirectMessages.swift` — sprawdzanie `noReply` i `senderId` przed udostępnieniem Odpowiedz, obsługa `filename` w załącznikach i tolerowanie obciętych wielobajtowych znaków UTF-8 w podglądach list.
5. `Sources/MainView.swift` — sekcja nowej wiadomości/odpowiedzi, filtrowanie odbiorców, temat, treść, jawna akcja potwierdzenia, rozróżnianie sukcesu od wyniku niepewnego.

## Rzeczywiste dokumentowane API (nie zgadywane)

Niezależny projekt `MichalZaniewicz/librus-synergia` publikuje opis formularza: `docs/messages.md` (zaktualizowany 2026-10-12 na podstawie oficjalnego JavaScript; w tym czasie potwierdzono na żywo odpowiedź, a wysyłanie nowej wiadomości pozostawało nieprzetestowane przez autora). Repozytorium: https://github.com/MichalZaniewicz/librus-synergia . Kod `src/librus_synergia/client.py` zawiera `async_send_message_checked` i sprawdzanie statusu. Drugie źródło: https://github.com/emsi/librus_pyapi (obsługa osobnej sesji domeny Wiadomości).

Własna implementacja Swift korzysta z opisu protokołu — bez kopiowania bibliotek Python do projektu.

## Testy dostępne offline

- 42/42 testy `swiftc Sources/DirectMessages.swift Sources/DirectMessageCompose.swift Tests/direct_compose_standalone.swift` + uruchomienie testów.
- 25/25 regresji `direct_messages_standalone.swift`.
- 28/28 polityka załączników, 13/13 liczniki, 12/12 wykrywanie zmian ocen, 11/11 średnie.
- Kontrola statyczna wysyłki 21/21, modułu Wiadomości 16/16, załączników/liczników 24/24 i ogólnych reguł źródeł PASS.
- Kontrola składni wszystkich plików: `swiftc -frontend -parse Sources/*.swift` PASS.

## Ograniczenia i bezpieczeństwo

- **Brak testu realnego HTTP** na zalogowanym koncie, brak kompilacji natywnego celu iOS, brak IPA, brak testu urządzenia. Nie można potwierdzić, że serwer przyjmie wysyłkę ani że WebKit udostępni wszystkie wymagane cookies. Działanie części odbiorców i odpowiedzi zależy od uprawnień szkoły.
- Nie implementowano załączników wychodzących, CC/BCC, przekazywania dalej ani automatycznego odświeżania sesji. Zastosowano pojedynczego odbiorcę i pojedynczy POST jako najmniej ryzykowną funkcję.
- W odpowiedzi niepewnej możliwe jest, że serwer dostarczył wiadomość. Należy ręcznie sprawdzić Wysłane; kod nigdy nie ponawia wysyłki automatycznie.
- Sesja domeny Wiadomości może wygasać niezależnie od sesji głównej. Aplikacja nie obchodzi logowania i nie pyta o hasło.
