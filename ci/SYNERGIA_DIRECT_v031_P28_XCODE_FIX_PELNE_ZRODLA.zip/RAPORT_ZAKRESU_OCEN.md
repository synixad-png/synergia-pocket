# SYNERGIA DIRECT — audyt kompletności ocen (bez kompilacji iOS)

Baza: v0.31 WIDOK_SEMESTROW. Zachowano wcześniej istniejące pliki, dodano obsługę czterech rozdzielnych rodzin ocen.

## Zmiany
- `Sources/SupplementalGrades.swift`: odczyt ocen opisowych (Map), punktowych (Grade), tekstowych (Grade) oraz zachowania (BehaviourGrade.Id), z osobnymi identyfikatorami rodzin, walidacją semestrów i eliminacją kolizji ID między rodzinami.
- `Sources/SynergiaGatewayClient.swift`: dozwolone odczyty czterech dodatkowych zasobów.
- `Sources/Portal.swift`: odczyt tych zasobów w jednej weryfikowanej sesji przed atomowym zapisem; błąd struktury JSON blokuje zapis; odmowy 403/404 są jawnie komunikowane. Pusty standardowy Grades bez licznika nie kasuje wcześniej zapisanych ocen.
- `Sources/DirectGradeStore.swift`: osobny, przypisany do konta magazyn dodatkowych ocen, zgodny wstecznie ze starszym zapisem.
- `Sources/MainView.swift`: prezentacja dodatkowych wpisów i filtrowanie według semestru.
- `Tests/supplemental_grades_standalone.swift`: testy sztucznych przykładów danych.

## Kontrole wykonane
- 28/28 testów dekodowania i integralności zwykłych ocen PASS.
- 9/9 testów powiązań PASS.
- 8/8 testów nowego dekodera PASS (syntetyczne dane o udokumentowanych polach).
- Test stabilizacji strony JS PASS.
- Składnia wszystkich źródeł Swift PASS.

## Niezweryfikowane
- BRAK autoryzowanej sesji na koncie użytkownika i prawdziwych odpowiedzi serwera. Nie potwierdzono, czy wszystkie udokumentowane zasoby są włączone, jakie oceny rzeczywiście mają, ani czy kontynuacja stron odpowiada schematowi serwera.
- Nieobsługiwany jest jeszcze nowy POST `Auth/DescriptiveGradingSystem/PartialGrades/Student/<child LID>`, zależny od osobnego identyfikatora ucznia i odmiennego formatu. Nie udajemy, że pobieramy wszystkie rodzaje ocen.
- Oceny zachowania mają obecnie identyfikator typu, a nie pełną nazwę z BehaviourGrades/Types. Kategoria/limit punktów nie są jeszcze łączone z PointGrades/Categories.
- Testy środowiskowe Xcode, iPhone/iPad i prawdziwej Synergii nie zostały przeprowadzone. Bez nich nie potwierdzono kompletnej funkcjonalności.

## Wniosek
Rozszerzenie kodu jest rzeczywiste i przetestowane poza iOS; zadania „Pełne oceny z obu semestrów” nie można oznaczyć jako ukończonego. Kolejnym niezbędnym krokiem jest pozyskanie bezpiecznie zanonimizowanych przykładów odpowiedzi z autoryzowanej sesji lub test w docelowej aplikacji po osobnym poleceniu kompilacji. Nie należy wymyślać pól ani danych konta.

Źródło struktury: https://michalzaniewicz.github.io/librus-synergia/endpoints/
