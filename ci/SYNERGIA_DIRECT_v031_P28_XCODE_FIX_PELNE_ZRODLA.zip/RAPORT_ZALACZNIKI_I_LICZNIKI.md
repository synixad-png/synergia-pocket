# SYNERGIA DIRECT v0.31 — załączniki i liczniki wiadomości

Data: 2026-11-05. Dalszy rozwój na źródłach z `SYNERGIA_DIRECT_v0_31_WIADOMOSCI_ODCZYT_PELNE_ZRODLA_BEZ_IPA.zip`.

## Prace wykonane

1. `Sources/DirectAttachmentPolicy.swift`: ścisła walidacja adresu HTTPS do pliku z odpowiedzi `data.downloadLink`, blokada adresów lokalnych, IP, credential-in-URL, fragmentów i nietypowych portów. Nieznany CDN może być dozwolony, ponieważ adres dostarcza bezpośrednio uwierzytelnione API. Nigdy nie przesyłamy mu cookies Synergii.
2. `Sources/SynergiaMessagesClient.swift`: GET `attachments/{attachmentId}/messages/{messageId}`, parsowanie biletu, GET wskazanego pliku bez ciasteczek, redirectów i HTML, ograniczenie rozmiaru do 15 MB. Nie używa POST, brak kompilacji IPA.
3. `Sources/Portal.swift`: weryfikacja konta przez `/Me` przed i po pobraniu, odrzucenie transferu przy zmianie sesji; folder tymczasowy, zapis `completeFileProtection`, wyłączenie backupu, limit 60 MB na sesję i czyszczenie plików przy wylogowaniu, nawigacji, zmianie otwartej wiadomości i ponownej weryfikacji.
4. `Sources/MainView.swift`: przycisk `Pobierz załącznik` i po pobraniu `Udostępnij / Zapisz plik` (ShareLink). To nie jest automatyczna synchronizacja plików.
5. `Sources/DirectUnreadCounts.swift`: odczyt liczników `inbox/unreadMessagesCount` z 14 znanych nazw kategorii. Nieznane wartości/typy odrzucane, brakujące kategorie pozostają brakujące. Odczyt wyłącznie po weryfikacji konta przed i po pobraniu.
6. Ostrzeżenie użytkownika przy `Otwórz treść`: otwarcie wiadomości może oznaczyć ją na serwerze jako przeczytaną. Nie dodano automatycznego odczytu treści.

## Testy offline

- Polityka adresów i biletów: 28/28 PASS (`Tests/direct_attachment_policy_standalone.swift`).
- Liczniki: 13/13 PASS (`Tests/direct_unread_counts_standalone.swift`).
- Regresja wiadomości: 25/25 PASS.
- Regresja zmian ocen: 12/12 PASS; średnie ocen: 11/11 PASS.
- Statyczne granice nowych modułów: 24/24 PASS.
- Statyczne granice starego modułu wiadomości: 16/16 PASS; ogólne granice źródeł: 16/16 PASS.
- `swiftc -frontend -parse Sources/*.swift`: PASS (kontrola składni Swift, **nie** kompilacja iOS).
- Paczka ZIP: CRC każdej pozycji PASS i brak IPA/EXE.

## Pochodzenie dokumentowanych pól API

- https://github.com/emsi/librus_pyapi (`attachment` zwraca `data.status` i `data.downloadLink`, endpoint załącznika).
- https://github.com/FlakM/librus-rs (`inbox/unreadMessagesCount`, kod odbierania plików).
- https://pypi.org/project/librus-mcp/ (wydanie z 29.10.2026: odczyt treści może oznaczyć wiadomość jako przeczytaną).

Implementacja jest własnym kodem Swift, nie skopiowano kodu z repozytoriów na innych licencjach.

## Niewykonane i ograniczenia

- Nie wykonywano `xcodebuild`, kompilacji aplikacji, podpisywania, tworzenia IPA, testów na iPhonie ani logowania do realnej Synergii.
- Nie znamy wszystkich rzeczywistych domen CDN i ewentualnych dodatkowych wymagań uwierzytelnienia przy pobieraniu załącznika. W razie niepowodzenia aplikacja pokaże błąd, a nie będzie pobierała przez nieznany serwer pośredni.
- Nie potwierdzono zachowania ShareLink ani `URLSession.bytes(for:)` na fizycznym iOS; sprawdzono wyłącznie składnię źródeł oraz logikę Foundation w testach offline.
- Wysyłanie, odpowiadanie i dodatkowe skrzynki nadal są do wykonania.
