# Zmiany postępu — pakiet 28

W porównaniu z pakietem 27 zmienia się wyłącznie zadanie nr 12 „Frekwencja — statusy” z 75% na 90% (+15 pp). Pozostałe 35 pozycji zachowuje dokładnie poprzednie procenty, nazwy i zakres. Zaokrąglony szacunkowy postęp projektu 65% → 66% (+1 pp), do końca pozostało 34%.

Nie zaliczono testów na koncie Synergii ani urządzeniu; „Testy i wydanie — kompilacja i IPA” pozostaje 0%. Ponowne uruchomienie starszego workflow IPA przez Github nie jest testem ani buildem bieżącego pakietu 28.
