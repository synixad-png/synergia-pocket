# SYNERGIA DIRECT v0.31 — pakiet 28: statusy frekwencji

Baza: kompletne, rzeczywiste źródła pakietu 27. W tym pakiecie zmieniono **wyłącznie** `Sources/DirectAttendanceStatistics.swift` i `Sources/DirectAttendanceAnalyticsView.swift` oraz dodano testy i raport. Sprawdzono oddzielnie obsługę jednoznacznych form usprawiedliwienia, form negatywnych i oczekujących decyzji; „w toku” nie jest już automatycznie kwalifikowane jako usprawiedliwione.

Test `bash Tests/run_batch28_offline.sh`. Raport `RAPORT_PAKIET_28_STATUSY_FREKWENCJI.md`; harmonogram: `HARMONOGRAM_STALY.md`. Zachowano iPhone/iPad jako obsługiwane platformy aplikacji, testy urządzeń dotyczą tylko iPhone. Nie wykonano pełnego builda Xcode ani live testów, nie ma IPA w ZIP. Runner Intel w osobnej gałęzi GitHub kompiluje starszy pakiet 18.

---

# SYNERGIA DIRECT v0.31 — pakiet 27 (frekwencja JSON)

Baza: autentyczny pakiet 26. Ten pakiet dodaje poprawki walidacji odczytu JSON frekwencji w `Sources/SynergiaAttendanceRecords.swift`, testy `Tests/attendance_json_integrity_standalone.swift`, automatyczną regresję `Tests/run_batch27_offline.sh`, sprawdzanie granic `Tests/verify_batch27_boundaries.py` i raport techniczny `RAPORT_PAKIET_27_FREKWENCJA_JSON.md`.

**Bez IPA:** Nie kompilowano Xcode, nie testowano prawdziwej Synergii ani iPhone. Ustawienia iOS projektu i workflow pozostają identyczne z pakietem 26; test urządzeń skupia się na iPhonie.

# SYNERGIA DIRECT v0.31 — pakiet 26 (najnowsze źródła)

- Baza: prawdziwe źródła pakietu 25 (nie aplikacja demonstracyjna).
- Ulepszono wykrywanie zmian ocen zwykłych i dodatkowych, odróżniając metadane od treści ocen; brak w odczycie nie oznacza usunięcia.
- Zmieniono tylko `Sources/Portal.swift` i dodano `Sources/GradeObservedChangeAudit.swift`. Pozostałe pliki źródłowe z pakietu 25 są niezmienione.
- Test: `bash Tests/run_batch26_offline.sh`. Raport: `RAPORT_PAKIET_26_WYKRYWANIE_ZMIAN_OCEN.md`.
- Stała lista 36 zadań: `HARMONOGRAM_STALY.md`.
- Projekt nadal wspiera iPada, ale zakres testów urządzeń jest ograniczony do iPhone. **Nie wykonywano kompilacji iOS i nie dołączono IPA.**

---

# SYNERGIA DIRECT v0.31 — pakiet 25 (najnowsze źródła)

- Pełna baza pakietu 24 z poprawkami przedmiotów i autorów ocen.
- Raport: `RAPORT_PAKIET_25_PRZEDMIOTY_AUTORZY.md`.
- Testy: `bash Tests/run_batch25_offline.sh`.
- Nie zawiera IPA. Nie przeprowadzono rzeczywistego testu iPhone/serwer.

# SYNERGIA DIRECT v0.31 — pakiet 24 (bez IPA)

Baza: pełne źródła pakietu 23. Wdrożono osobny ekran szczegółów oceny, pełne teksty komentarzy i ochronę dostępu do szczegółów na żywo przy zmianie konta, wylogowaniu i zasłonie prywatności. Test: `bash Tests/run_batch24_offline.sh`. Raport: `RAPORT_PAKIET_24_KOMENTARZE_SZCZEGOLY.md`. Stała lista 36 zadań: `HARMONOGRAM_STALY.md`.

Nie wykonano natywnego builda Xcode, testu iOS ani testu na żywym koncie. Nie dołączono ani nie wygenerowano nowego IPA. Pliki źródłowe innych modułów pozostały bez zmian.

---
# SYNERGIA DIRECT v0.31 — pakiet 22: ochrona obu semestrów, testy tylko iPhone

**Baza:** rzeczywiste źródła pakietu 21. Dodano ochronę kompletnych odczytów ocen dodatkowych i zbiorcze statystyki dla obu semestrów. Zakres testowania urządzeń ograniczono do iPhone, nie usuwając wsparcia aplikacji dla iPada. Testy: `bash Tests/run_batch22_incremental_offline.sh`. Pełny raport: `RAPORT_PAKIET_22_SEMESTRY_IPHONE.md`, stałe 36 zadań: `HARMONOGRAM_STALY.md`.

**Uwaga:** nie wykonywano testów z Xcode, na urządzeniu ani na żywej Synergii. Nie uruchamiano workflow iOS, nie tworzono IPA.

---

# SYNERGIA DIRECT v0.31 — pakiet 21: błędy i paginacja (bez IPA)

**Baza:** pełne źródła pakietu 20. Ulepszono walidację kolejnych stron ocen i polskie komunikaty błędów, bez zmian innych modułów. Test: `bash Tests/run_batch21_incremental_offline.sh`. Szczegóły w `RAPORT_PAKIET_21_BLEDY_PAGINACJA.md`. Stały harmonogram: `HARMONOGRAM_STALY.md`. Diagnoza GitHub Actions: `RAPORT_GITHUB_ACTIONS_IPA_20261105.md`.

**Uwaga:** poprzednia próba GitHub Actions zakończyła się awarią przed przydziałem macOS runnera; nie ma IPA. Nie prowadzono testów rzeczywistej Synergii i iOS.

---

# SYNERGIA DIRECT v0.31 — pakiet 18: klient JSON (bez IPA)

**Baza:** pełne źródła pakietu 17. Poprawiono selekcję cookie host/path, kontrolę prawdziwego MIME JSON, limity rozmiaru i bezpieczne kontynuacje listy ocen. Nowa logika: `Sources/GatewayJSONPolicy.swift` + modyfikacja `Sources/SynergiaGatewayClient.swift`. Test: `bash Tests/run_batch18_incremental_offline.sh`. Raport: `RAPORT_PAKIET_18_KLIENT_JSON.md`. Stałe zadania: `HARMONOGRAM_STALY.md`. Nie kompilowano iOS, brak realnego testu serwera, brak IPA.

---

# SYNERGIA DIRECT v0.31 — pakiet 18: klient JSON (bez IPA)

**Baza:** pełne źródła pakietu 17. Poprawiono selekcję cookie host/path, kontrolę prawdziwego MIME JSON, limity rozmiaru i bezpieczne kontynuacje listy ocen. Nowa logika: `Sources/GatewayJSONPolicy.swift` + modyfikacja `Sources/SynergiaGatewayClient.swift`. Test: `bash Tests/run_batch18_incremental_offline.sh`. Raport: `RAPORT_PAKIET_18_KLIENT_JSON.md`. Stałe zadania: `HARMONOGRAM_STALY.md`. Nie kompilowano iOS, brak realnego testu serwera, brak IPA.

---

# SYNERGIA DIRECT v0.31 — pakiet 17: logowanie i sesja (bez IPA)

**Baza:** pełne źródła pakietu 16. Przy uruchomieniu automatyczne sprawdzenie ważności istniejącej sesji WebKit przez serwerowe `/Me`; po oficjalnym logowaniu automatyczna ponowna weryfikacja po wejściu na zaufaną stronę, bez hasła i omijania wygaśnięcia sesji. Nie zmieniono danych pozostałych modułów. Testy: `bash Tests/run_batch17_incremental_offline.sh`. Raport: `RAPORT_PAKIET_17_LOGOWANIE.md`. Harmonogram: `HARMONOGRAM_STALY.md`. Nie wykonywano kompilacji iOS ani IPA; nie przeprowadzono testu na realnym koncie.

---

# SYNERGIA DIRECT v0.31 — pakiet 16: Dokumenty (bez IPA)

**Baza:** pełne źródła pakietu 15. Dodano `DirectSchoolDocuments.swift`, `DirectSchoolDocumentsView.swift`, ostrzejszą weryfikację unikalności ID przed pobieraniem, bezpieczne metadane, filtry, sortowanie i zapisy offline. Testy `bash Tests/run_batch16_incremental_offline.sh`; raport: `RAPORT_PAKIET_16_DOKUMENTY.md`, stałe 36 zadań: `HARMONOGRAM_STALY.md`. Pełnej kompilacji iOS i testów realnej Synergii nie wykonano. Brak IPA.

---

## Pakiet 14 (v0.31): Terminarz

**Stan 05.11.2026 — v0.31, pakiet 15 (bez IPA).** Dodano własny typowany widok `HomeWorkAssignments` — osobno od `HomeWorks` (Terminarz): terminy tylko z pól wskazujących deadline, wyszukiwanie, filtry, daty, opcjonalny przedmiot i kategoria, zachowane pobieranie załączników, izolowany cache i audyt. Testy w `Tests/run_batch15_incremental_offline.sh`; raport w `RAPORT_PAKIET_15_ZADANIA_DOMOWE.md`. Żywego konta iOS/Synergia ani IPA nie testowano/tworzono.


Na bazie pakietu 13 dodano `DirectSchoolAgenda.swift` i `DirectSchoolAgendaView.swift` do bezpiecznego prezentowania odpowiedzi `HomeWorks` (nie mylić z zadaniami domowymi `HomeWorkAssignments`). Dane `Date`, `Content`, kategoria, przedmiot i lekcja są opcjonalne i pochodzą wyłącznie z odpowiedzi JSON; brak daty lub nazw nie jest uzupełniany domysłami. Widok zawiera wyszukiwanie, filtry, grupowanie dni i odtwarzanie offline. Zmiany nie modyfikują wcześniejszych modułów ogłoszeń, ocen i wiadomości.

Testy bez iOS: `bash Tests/run_batch14_incremental_offline.sh`; dokładne wyniki w `RAPORT_PAKIET_14_TERMINARZ.md`. Nie powstało IPA, nie kompilowano aplikacji iOS.

---

# SYNERGIA DIRECT v0.31 — pakiet 13: ogłoszenia (bez IPA)

Aktualny stan i ograniczenia: `RAPORT_BIEZACY.md`, stały harmonogram 36 zadań: `HARMONOGRAM_STALY.md`, raport tej zmiany: `RAPORT_PAKIET_13_OGLOSZENIA.md`. Wykonanie nowych testów: `bash Tests/run_batch13_incremental_offline.sh`. Nie jest to potwierdzona kompilacja iOS, nie zawiera IPA.

---

# SYNERGIA DIRECT v0.31 — pakiet 12: statystyki frekwencji

**Baza:** pełne źródła pakietu 11; ta sama aplikacja i 36-zadaniowy harmonogram. Nowe moduły `DirectAttendanceAnalytics.swift`, `DirectAttendanceAnalyticsView.swift`; rozszerzona klasyfikacja/statusy i parser `SynergiaAttendanceRecords.swift`, integracja `MainView.swift`. Celem są **wyłącznie policzone wpisy** — brak wpisu nie jest obecnością ani podstawą do procentu frekwencji.

**Testy nowego zakresu:** `bash Tests/run_batch12_incremental_offline.sh` (219 testów logiki i 42 kontrole statyczne). **Pełny skrypt:** `bash Tests/run_batch12_full_offline.sh` (może przekraczać limity krótkiej sesji; w takim przypadku należy uruchomić istniejące skrypty częściowo). Nie kompiluje iOS ani nie tworzy IPA. Szczegóły `RAPORT_PAKIET_12_STATYSTYKI_FREKWENCJI.md`.

**Bez iPhone/iPad i bez żywego konta Synergii:** 90% jest oceną implementacji i testów Foundation; nie potwierdzono końcowego działania UI.

---

# SYNERGIA DIRECT v0.31 — pakiet 11: autorzy ocen i przedmioty

Kontynuacja pakietu 10. Weryfikowany dostęp do nazw autorów wpisów ocen po `AddedBy.Id`, próba `Users/{id}` w granicach ścisłej listy dozwolonych adresów, przechowywanie nazw tylko dla danego konta i oznaczanie starych źródeł, filtrowanie ocen po przedmiocie, walidacja identyfikatorów przedmiotów.

**Testy bieżącego pakietu:** `bash Tests/run_batch11_incremental_offline.sh` (74 + 38 nowych testów i 43 kontrole). **Pełna regresja:** `bash Tests/run_batch11_full_offline.sh` (może potrwać; można wykonać w części). Dokumentacja: `RAPORT_PAKIET_11_OCENY_AUTORZY_PRZEDMIOTY.md` i `HARMONOGRAM_STALY.md`.

**Nie uruchomiono kompilacji iOS ani nie utworzono IPA; testy Swift/Linux nie zastępują testów na urządzeniu i żywej Synergii.**

---

## Poprzednie wydania — zapis historii

# SYNERGIA DIRECT v0.31 — pakiet 10: powiadomienia lokalne

Niniejsza paczka jest kontynuacją pełnych źródeł pakietu 9. Dodano możliwość osobnego włączenia powiadomień o zmianach ocen, frekwencji i wiadomości, sprawdzanie autoryzacji UserNotifications, izolację zgody konta przez lokalny Keychain, filtrowanie duplikatów i neutralną treść alertów. Nie ma automatycznej synchronizacji w tle; powiadomienia wyłącznie po ręcznym odświeżeniu.

**Testy offline:** `bash Tests/run_batch10_offline.sh`. W środowisku Swift/Linux wykonują wcześniejsze i nowe testy Foundation-only oraz testy statyczne. Nie jest to build iOS. Dalsze szczegóły w `RAPORT_PAKIET_10_POWIADOMIENIA.md` i `HARMONOGRAM_STALY.md`.

**Nie kompilowano iOS ani IPA; działania realnego systemu iOS i Synergii nie zweryfikowano.**

---

# SYNERGIA DIRECT v0.31 — pakiet 10: powiadomienia lokalne

**Baza:** pełne źródła pakietu 9, bez zmiany wersji i bez tworzenia IPA.

Opracowano `DirectNotificationPolicy.swift`, ustawienia kategorii i ich zapis, ponowne sprawdzanie zgody iOS, ochronę przed zmianą konta i wyścigami, unikanie duplikatów powiadomień i usuwanie komunikatów przy wylogowaniu. Powiadomienia pozostają wyłącznie lokalne i uruchamiane ręczną synchronizacją, bez prywatnych treści i bez monitorowania w tle.

**Testy przyrostowe:** `bash Tests/run_batch10_offline.sh` (221 testów polityki, 52 kontrole statyczne oraz parsowanie Swift). Starszy kod testować przez `bash Tests/run_batch9_offline.sh` lub etapami `run_batch8_offline.sh` i `offline_timetable_standalone.swift` z `run_batch9_offline.sh`; skrypty nie budują iOS. Raport `RAPORT_PAKIET_10_POWIADOMIENIA.md`. Zachowano harmonogram 36 zadań.

**Granice:** źródła bez kompilacji iOS, bez IPA, bez weryfikacji na prawdziwej Synergii lub urządzeniach.

---

# SYNERGIA DIRECT v0.31 — pakiet 9: plan tygodniowy offline

**Kontynuacja rzeczywistych źródeł pakietu 8; numer wersji bez zmiany.**

Dodano `Sources/DirectOfflineTimetableStore.swift`, integrację planu tygodniowego, lokalny zapis 16 tygodni na konto po `/Me`, zapis opcjonalnych zastępstw i nazw oraz rozróżnianie NIEAKTUALNY/odczyt bieżącej sesji. Uszkodzone tygodnie są ignorowane, konto zmienione lub wylogowane blokuje i usuwa zapis. Plan nie jest odblokowywany po zimnym starcie bez potwierdzenia konta.

**Testy bez iOS:** `bash Tests/run_batch9_offline.sh` (suma poprzednich 712 + 36 nowych testów offline, kontrole statyczne). Na dłuższych uruchomieniach można wykonać `bash Tests/run_batch8_offline.sh`, następnie skompilować i uruchomić `offline_timetable_standalone.swift` według skryptu, a kontrolę statyczną przeprowadzić osobno. Składnia Swift to nie pełna kompilacja aplikacji iOS.

**Nie kompilowano iOS, nie tworzono IPA, nie testowano realnej Synergii.** Szczegóły `RAPORT_PAKIET_9_PLAN_OFFLINE.md`, postępy w `HARMONOGRAM_STALY.md`.

---

# SYNERGIA DIRECT v0.31 — pakiet 8: tryb offline i przywracanie

**Aktualna baza:** pakiet 7, bez podmiany projektu. `Sources/DirectOfflineFeedCache.swift` + `DirectOfflineFeedStore.swift` + `DirectOfflineRecovery.swift` obsługują zabezpieczony zapis JSON dla czterech modułów i awaryjne pozostawienie wcześniejszego odczytu po utracie sieci w trwającej zweryfikowanej sesji. Gdy sesja zostanie przerwana lub aplikacja uruchomiona na nowo, lokalne dane muszą pozostać zablokowane do ponownego udanego `/Me`.

**Testy:** `bash Tests/run_batch8_offline.sh`. Nie tworzy aplikacji ani IPA; tylko testy Foundation / kontrola źródeł / parser Swift. Szczegóły w `RAPORT_PAKIET_8_OFFLINE_ODTWARZANIE.md`. Zachowano pełen harmonogram 36 zadań.

**Uwaga:** brak builda iOS, brak testu na urządzeniu i brak weryfikacji na rzeczywistym koncie. Powyższa implementacja nie oznacza potwierdzenia działania na iOS.

---

# SYNERGIA DIRECT v0.31 — pakiet 7: wspólne stany danych JSON

**Baza:** pakiet 6 + pełna implementacja jednego zadania źródłowego w bieżącej sesji: wspólne komunikaty dla 8 modułów i poszczególnych skrzynek, odróżnianie starych zapisów z dysku od aktualnego odczytu. Zmiany rzeczywiście zintegrowane z `Portal.swift` i `MainView.swift`.

**Testy:** `bash Tests/run_batch7_offline.sh`: 377 poprzednich i 273 nowych testów offline, dodatkowo kontrole statyczne; bez kompilacji iOS i IPA. Raport: `RAPORT_PAKIET_7_STANY_UI.md`. `HARMONOGRAM_STALY.md` zachowuje stałe 36 zadań.

**Ryzyko:** brak testów SwiftUI na iPhone/iPad i brak rzeczywistego konta Synergii. Procenty są szacunkami postępu źródeł.

---

# SYNERGIA DIRECT v0.31 — pakiet 6: sesja, internet i prywatność ekranu

**Aktualne źródła (baza pakiet 5)**. Rozpoznawanie przyczyn błędów HTTP i połączenia, osobna obsługa przekierowania do logowania tylko na oficjalnych domenach, blokada lokalnych danych po przejściu w tło, ekran zasłaniający wrażliwą zawartość przy nieaktywnej aplikacji, ponowna weryfikacja `/Me` po powrocie, przyciski sprawdzenia konta i przejścia do logowania. Dotychczasowe moduły pozostają.

**Testy offline:** `bash Tests/run_batch6_offline.sh` — 377/377 testów Foundation-only PASS, 35/35 kontroli statycznych PASS, analiza składni Swift PASS. Nie jest to kompilacja aplikacji dla iPhone/iPad. Nie testowano prawdziwego konta ani symulatora iOS. Więcej w `RAPORT_PAKIET_6_SESJA_SIEC_OSLONA.md` i `HARMONOGRAM_STALY.md`.

**Ważne:** brak automatycznego logowania, brak wysyłania haseł do własnego serwera, brak powiadomień serwerowych w tle, brak automatycznego ponawiania POST. Nie tworzono IPA ani kompilacji iOS.

---

# SYNERGIA DIRECT v0.31 — pakiet 5 (źródła, bez IPA)

Aktualna baza: v0.31 pakiet 4. Dodano ręczną synchronizację JSON ocen/frekwencji/wiadomości, wykrywanie zmian i lokalne powiadomienia za zgodą użytkownika. Uruchamianie powiadomień i synchronizacji wymaga akcji użytkownika — brak automatyki w tle. Poprzednie moduły zachowane.

**Testy bez iOS:** `bash Tests/run_batch5_offline.sh` (Swift na środowisku z Foundation, Python 3). 337/337 PASS; 28/28 nowych statycznych kontroli PASS. `swiftc -frontend -parse Sources/*.swift` to jedynie analiza składni, nie kompilacja aplikacji iOS.

**Ważne:** nie wykonano kompilacji iOS ani IPA. Nie wykonano testów na rzeczywistej Synergii ani iPhonie. Działanie przez nieoficjalne API może się zmieniać.

Raport bieżący: `RAPORT_BIEZACY.md`; harmonogram: `HARMONOGRAM_STALY.md`; szczegóły pakietu: `RAPORT_PAKIET_5_SYNC_JSON_POWIADOMIENIA.md`.

---

# SYNERGIA DIRECT v0.31 — AKTUALNA PACZKA, PAKIET 4 (05.11.2026)

Dalszy rozwój istniejącej aplikacji SwiftUI, bez kompilacji iOS i bez IPA.

**Nowości:** pobieranie załączników z zadań `HomeWorkAssignments` (obie udokumentowane ścieżki plików sandbox), zbiorcze odświeżanie czterech modułów, bezpieczne zachowanie nieaktualnych danych po błędzie, porównywanie wpisów według rzeczywistych ID bez wymyślania usunięć. Kod źródłowy w `Sources/`, testy w `Tests/`.

**Uruchomienie testów offline:** `bash Tests/run_batch4_offline.sh` (295 przypadków logicznych + 33 kontrole statyczne). Ograniczenia i następne działania: `RAPORT_PAKIET_4_ZALACZNIKI_SYNC.md` oraz `HARMONOGRAM_STALY.md`.

**Aktualny szacunek:** 48% wykonano / 52% pozostało. Weryfikacja prawdziwej Synergii, test urządzeniowy i kompilacja iOS nie były wykonywane; pobieranie w prawdziwej sesji nadal niepotwierdzone.

---

# SYNERGIA DIRECT v0.31 — aktualna paczka, pakiet 3 (05.11.2026)

**Bieżące funkcje:** bezpośredni plan tygodniowy z historią odwołań/zastępstw (`Calendars/Substitutions`), lista dokumentów `SchoolFiles` i pobieranie dokumentów przez oficjalny adres z sesji Synergii, przejście do sandbox, zabezpieczony plik tymczasowy i udostępnianie. Dotychczasowy kod ocen, wiadomości, frekwencji, terminów i zadań domowych pozostaje.

**Raport i testy:** `RAPORT_PAKIET_3_DOKUMENTY_I_ZASTEPSTWA.md`, `HARMONOGRAM_STALY.md`, `bash Tests/run_batch3_offline.sh`. 258/258 przypadków logiki offline oraz 32/32 nowe kontrole statyczne PASS. To nie jest kompilacja iOS. Brak potwierdzenia działania na prawdziwym koncie i urządzeniu. Bez IPA.

**Szacunkowo:** 47% zaimplementowano, 53% pozostało.

---

# SYNERGIA DIRECT v0.31 — bieżąca paczka, duży pakiet 2 (05.11.2026)

**Najważniejsze zmiany:** statystyki wpisów frekwencji bez fikcyjnego procentu; naprawione źródła zadań (`HomeWorkAssignments`) i terminarza (`HomeWorks`); bezpośredni plan jednego tygodnia z równoległymi grupami; odczyt listy dokumentów `SchoolFiles`; poprawki granic sesji przy wylogowaniu. Pełna lista i testy: `RAPORT_PAKIET_2_PLAN_FREKWENCJA_ZADANIA_DOKUMENTY.md` oraz `Tests/run_batch2_offline.sh`.

**Stan:** 46% szacunkowo, 54% pozostało. 212 testów logiki offline PASS; 17 dodatkowych kontroli statycznych PASS. Bez kompilacji iOS, bez IPA, bez weryfikacji rzeczywistego konta.

---

# SYNERGIA DIRECT v0.31 — AKTUALNY STAN (pakiet 05.11.2026)

**To jest bieżący opis.** Niżej zachowano historyczne notatki z poprzednich pakietów; mogą one opisywać funkcje jako jeszcze niezaimplementowane, mimo że zostały dodane później.

- Skrzynki: Odebrane, Wysłane, Uwagi, Powiadomienia, Zastępstwa, Nieobecności, Usprawiedliwienia, Kosz i archiwum odebranych/wysłanych (**10 skrzynek**). W zależności od uprawnień szkoły niektóre mogą odpowiadać HTTP 404 — to nie jest pusta skrzynka.
- Listy wiadomości przyjmują zarówno `{data: [...], total: N}`, jak i surowe tablice JSON. Gdy brak licznika, pełność odczytu jest jawnie niepotwierdzona.
- Treść wiadomości: Base64 UTF-8, XML/CDATA i elementy HTML prezentowane jako **bezpieczny zwykły tekst SwiftUI**, bez ładowania obrazów i wykonywania skryptów. Możliwości edycji formatowanego HTML nie wdrożono.
- Załączniki: potwierdzony w publicznej dokumentacji przepływ: bilet z API Wiadomości → tylko `https://sandbox.librus.pl/GetFile/.../get` z Referer oryginalnego biletu, bez cookies i automatycznych redirectów; ochrona limitu 15 MB. Załączniki z archiwum odsyłają do oficjalnej strony.
- Wysyłanie i odpowiedzi pozostają z poprzedniego pakietu: wyłącznie po osobnym potwierdzeniu, jeden POST, brak retry dla niejednoznacznego wyniku.
- Testy offline: `Tests/run_message_batch_offline.sh` — 160 testów przypadków w siedmiu zestawach + kontrole statyczne. Nie jest to build iOS.
- **Ważne:** nie wykonywano testu żywego konta, pełnej kompilacji iOS, testu urządzenia ani IPA. Niezależni autorzy potwierdzili endpointy na swoich kontach, nie na Twoim.

Szczegóły i uczciwy zakres: `RAPORT_PAKIET_WIADOMOSCI_20261105.md`.

---

# SYNERGIA DIRECT v0.26 — etap 1 / izolacja kont w module ocen JSON

**Baza:** rzeczywiste źródła v0.25. Wyłącznie zmiana modułu `DirectGradeStore` i dodatkowe testy.

## Zaimplementowane
- Każde konto `Me.Id` ma odrębny plik z ocenami JSON, zamiast wspólnego pliku `direct-grades.json`.
- Nazwy plików to SHA-256 identyfikatora konta, bez ujawniania identyfikatora w ścieżce.
- Dostęp do zapisanych danych wymaga świeżej, udanej weryfikacji `/Me`, wykonywanej przez istniejący `Portal.refreshDirectGrades()`.
- Dane pochodzące z konta A nie są wyświetlane po odblokowaniu konta B.
- Starszy wspólny plik ocen nie jest automatycznie migracyjnie otwierany; funkcja usuwania danych usuwa oba formaty.
- Dodano testy izolacji dwóch kont, blokowania zapisu bez weryfikacji i nieodczytywania pliku legacy.

## Ważne ograniczenia
- Oddzielny `LocalStore` ze starymi migawkami HTML, `DownloadStore`, zapisane trasy i raporty nie są jeszcze izolowane między kontami. To pozostaje otwartym problemem bezpieczeństwa przed docelowym wydaniem.
- Format odpowiedzi `Me` oraz endpointy JSON nie zostały przetestowane na prawdziwym koncie.
- Nie wykonywano kompilacji Swift/Xcode, XCTest, GitHub Actions ani IPA (na polecenie użytkownika).
- Wykonano wyłącznie kontrolę statyczną i archiwum ZIP.

## Następne konkretne prace
1. Przypisać `LocalStore` i pobrane załączniki do zweryfikowanego konta, blokując ich wyświetlanie bez weryfikacji.
2. Powiązać weryfikację konta z każdym zapisem HTML i pobraniem pliku.
3. Dokończyć etap 1: rygorystyczne testy sesji i rzeczywistych odpowiedzi JSON; nie twierdzić, że integracja działa bez testów konta.


## v0.27 — izolacja diagnostycznych danych między kontami
- LocalStore i DownloadStore domyślnie odmawiają odczytu i zapisu przed weryfikacją `/Me`.
- Dane w `html-accounts/` oraz `school-downloads/accounts/` są przechowywane w katalogach z SHA-256 identyfikatora konta.
- Dawne pliki bez powiązania z kontem nie są automatycznie migrowane ani wyświetlane.
- Na ekranie Połączenie dodano przycisk «Potwierdź konto». Nawigacja blokuje dostęp do danych do kolejnej weryfikacji.
- Testy XCTest przygotowane, nieuruchamiane; brak kompilacji oraz testu prawdziwego konta.
- Nadal do uzupełnienia: odizolowanie ModuleRouteStore i SyncAuditStore, weryfikacja tożsamości w każdym asynchronicznym zapisie HTML oraz obsługa przejść bez utraty autoryzacji.


### v0.28
Rozdzielono zatwierdzone adresy modułów i raporty synchronizacji między kontami. Pliki poprzednio wspólne pozostają w kwarantannie do ręcznego usunięcia. Nie przeprowadzono kompilacji iOS ani testu rzeczywistej sesji.

## Domknięcie prac bezpieczeństwa v0.28 (bez zmiany numeru wersji)

Zabezpieczono opóźnione callbacki odczytu HTML, przerwania synchronizacji, zmianę sesji podczas pobierania plików i transakcyjność zapisu adresów. Szczegóły: `RAPORT_ZAMKNIECIA_v0_28.txt`. Nie kompilowano ani nie tworzono IPA; testy XCTest nie zostały uruchomione.


## v0.29 — frekwencja JSON (etap 2)
Dopisano bezpośredni odczyt frekwencji z API, dekoder typów i lekcji, osobną pamięć konta oraz ekran i testy. Bez kompilacji i IPA.


## v0.30 — kategorie i wagi ocen JSON (jeden ukończony zakres źródłowy)
- Pobieranie `Grades/Categories` w tej samej weryfikowanej sesji co oceny.
- Powiązanie `Category.Id` z `Categories[].Id` bez domyślania kategorii.
- Zachowanie `Weight: 0`, `CountToTheAverage: false`, `CountToTheAverage: null` oraz braku pola.
- Bezpieczna zgodność dekodowania starszych plików JSON (nowe pola opcjonalne).
- Osobna prezentacja nazwy kategorii, wagi i statusu wliczania w SwiftUI.
- Celowo nie obliczono średnich bez potwierdzenia skali szkolnej.
- Brak kompilacji iOS, GitHub Actions oraz IPA; zgodność rzeczywistej sesji nadal do weryfikacji.

## Uzupełnienie kontroli semestrów (bez zmiany numeru wersji)
W `GradeSemesterCoverage.validateReplacement` zablokowano również utratę pojedynczych identyfikatorów ocen z wcześniej zachowanego zestawu. Przeniesienie tego samego ID do innego semestru pozostaje dozwolone. Brak możliwości uznania rzeczywistego usunięcia za potwierdzone, dopóki nie otrzymamy autorytatywnego sygnału z Synergii. Testy zmian wykonano osobno przez Swift na Linux; nie kompilowano aplikacji iOS.


### Uzupełnienie — widok semestrów
Zakładka Oceny ma filtr Wszystkie / I / II / Inne; domyślnie widzi wszystkie wpisy.
Nie zmieniono transportu ani lokalnych zapisów. Testy nowego widoku: `swiftc Sources/SynergiaGradeRecords.swift Sources/GradeSemesterPresentation.swift Tests/semester_presentation_standalone.swift -o /tmp/semester_presentation && /tmp/semester_presentation`.
Brak kompilacji iOS i testów prawdziwego konta.


## Uzupełnienie v0.31: szczegóły ocen
- Zweryfikowano pole `Grade` jako niepusty tekst oraz `AddDate` jako opcjonalny, niepusty tekst (bez zgadywania formatu daty).
- Naprawiono identyfikatory widoku dla komentarzy o identycznej treści, zachowując obydwa wystąpienia.
- Nowe testy: `Tests/grade_details_standalone.swift` i `Tests/GradeDetailsValidationTests.swift`.
- Bez kompilacji iOS / IPA; działanie na rzeczywistej Synergii niepotwierdzone.

## Kontynuacja: powiązania autorów ocen
Nowy plik `Sources/DirectGradeAuthors.swift`; zachowane wcześniejsze mechanizmy. Pole `AddedBy` służy do wskazania autora wpisu, nie do niepotwierdzonego założenia, że jest nauczycielem. Testy: `Tests/grade_teachers_standalone.swift`. Zapis powiązań jest lokalny i przypisany do zweryfikowanego konta. Ograniczenia: brak testu rzeczywistej Synergii, iOS i IPA.


## Wiadomości JSON — aktualizacja 2026-11-05

Odebrane/Wysłane i szczegóły wiadomości są teraz odczytywane przez oddzielną, oficjalną domenę `wiadomosci.librus.pl` po aktywacji sesji w wbudowanej przeglądarce. Zawartość jest **tylko w RAM**, z podwójną weryfikacją konta; nie zaimplementowano wysyłania ani pobierania plików załączników. Instrukcja i ograniczenia: `RAPORT_WIADOMOSCI_JSON.md`. Uruchomienie testów: `swiftc Sources/DirectMessages.swift Sources/DirectMessagePlainText.swift Tests/direct_messages_standalone.swift -o /tmp/messages-test && /tmp/messages-test`.


## Aktualizacja 2026-11-05 — załączniki i liczniki wiadomości

Natywny ekran wiadomości udostępnia teraz pobieranie **pojedynczych** załączników na wyraźne kliknięcie, zapis do zabezpieczonego pliku tymczasowego i udostępnianie przez systemowy arkusz iOS. Dodałem liczniki nieprzeczytanych wiadomości dla rozpoznanych przez API kategorii. Otworzenie treści może oznaczyć wiadomość jako przeczytaną. Przeczytaj `RAPORT_ZALACZNIKI_I_LICZNIKI.md`. Zaimplementowano także grupy/odbiorców, lokalne redagowanie i podgląd, jeden POST wysyłki oraz odpowiedź z dodatkowym potwierdzeniem użytkownika i bez ponawiania po niepewnej odpowiedzi. Nie oznacza to przetestowanej wysyłki na rzeczywistym koncie. Kompilacja iOS/IPA nadal nie została wykonana. Zobacz `RAPORT_WYSYLKA_WIADOMOSCI.md`.
