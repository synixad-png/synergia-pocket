# Ochrona ocen obu semestrów — v0.31

- Semester jest odczytywany jawnie; błędny typ odrzuca odpowiedź.
- Zapis nie może zgubić całego semestru wcześniej obecnego w lokalnym magazynie.
- Zachowano dopuszczalność pojedynczego usunięcia oceny oraz tych samych wartości ocen z różnymi Id.
- Ekran pokazuje liczbę rekordów przypisanych do semestru 1, 2, bez semestru i innych numerów.
- **Obecność dwóch semestrów NIE dowodzi kompletności.** Brak zweryfikowanych liczników poszczególnych semestrów z konta Synergii; nadal potrzebne testy na koncie.
- Nie kompilowano aplikacji iOS ani IPA.

## Pakiet 22 — aktualizacja ochrony obu semestrów
- Do raportu dodano osobne liczniki dla dodatkowych rodzin ocen, wcześniej nieuwzględniane w podstawowym raporcie.
- Ochrona przed zniknięciem wcześniej obserwowanej oceny dotyczy teraz obu ścieżek odczytu i czterech rodzin uzupełniających. Dotyczy również zmian pojedynczych rekordów; rzeczywista procedura usuwania nie jest potwierdzona.
- Stronicowanie dodatkowych rodzin nie jest implementowane bez źródła. Jawne `Next` lub niespójny `TotalCount` powodują bezpieczną odmowę zapisu.
- Testowanie urządzeń od tej pory: **iPhone**, bez iPada. Aplikacja wciąż może być instalowana na iPadzie — wsparcie nie jest testem.
