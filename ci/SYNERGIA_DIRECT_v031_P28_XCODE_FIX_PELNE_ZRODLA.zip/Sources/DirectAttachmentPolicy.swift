import Foundation

/// One-time, user-initiated message attachment downloads. The API's downloadLink
/// is never persisted, exposed in the UI, or sent together with Synergia cookies.
enum DirectAttachmentError: Error, Equatable, LocalizedError {
    case malformedTicket, untrustedDownloadLink, badResponse, sizeLimit, emptyFile, accountChanged

    var errorDescription: String? {
        switch self {
        case .malformedTicket: return "API nie zwróciło prawidłowego linku do załącznika."
        case .untrustedDownloadLink: return "Odrzucono potencjalnie niebezpieczny adres pliku."
        case .badResponse: return "Odpowiedź przy pobieraniu pliku jest nieprawidłowa."
        case .sizeLimit: return "Załącznik przekracza limit 15 MB."
        case .emptyFile: return "Pobrany plik jest pusty."
        case .accountChanged: return "Sesja lub konto zmieniły się podczas pobierania."
        }
    }
}

enum DirectAttachmentPolicy {
    static let maxBytes = 15_000_000
    static let maxSessionBytes = 60_000_000

    /// The download URL is delivered by the authenticated Librus API, but it may
    /// point to an external file CDN. Trust neither redirects nor local IP URLs.
    static func allowedDownloadURL(_ raw: String) -> URL? {
        guard raw.utf8.count <= 8192, let components = URLComponents(string: raw),
              components.scheme?.lowercased() == "https",
              components.user == nil, components.password == nil,
              components.fragment == nil,
              components.port == nil || components.port == 443,
              let host = components.host?.lowercased(),
              host.count <= 253, host.contains("."),
              !host.hasPrefix("."), !host.hasSuffix("."), !host.contains(".."),
              host != "localhost", !host.hasSuffix(".localhost"),
              !host.hasSuffix(".local"), !host.hasSuffix(".internal"),
              !host.hasSuffix(".test"), !host.hasSuffix(".invalid"),
              !host.hasSuffix(".example"), !host.hasSuffix(".onion"),
              !host.contains(":"), // IPv6 literal
              host.split(separator: ".").allSatisfy({ label in
                  label.count <= 63 && !label.isEmpty &&
                  label.first != "-" && label.last != "-" &&
                  label.utf8.allSatisfy({ b in
                      (48...57).contains(b) || (65...90).contains(b) ||
                      (97...122).contains(b) || b == 45
                  })
              }),
              // Numeric IP addresses, including non-dotted representations,
              // are not acceptable as cross-domain download targets.
              !(host.split(separator: ".").allSatisfy { $0.allSatisfy(\.isNumber) }),
              !host.hasPrefix("127."), !host.hasPrefix("10."),
              let url = components.url, url.host?.lowercased() == host else { return nil }
        return url
    }

    static func ticket(_ response: [String: Any]) throws -> URL {
        guard let payload = response["data"] as? [String: Any],
              let raw = payload["downloadLink"] as? String, !raw.isEmpty else {
            throw DirectAttachmentError.malformedTicket
        }
        if let status = payload["status"] as? String,
           ["error", "failure", "failed", "denied"].contains(status.lowercased()) {
            throw DirectAttachmentError.malformedTicket
        }
        guard let url = allowedDownloadURL(raw),
              url.host?.lowercased() == "sandbox.librus.pl",
              url.path.hasPrefix("/GetFile/"),
              url.path.count > "/GetFile/".count,
              !url.path.hasSuffix("/get") else {
            throw DirectAttachmentError.untrustedDownloadLink
        }
        return url
    }

    /// Actual document bytes live at <downloadLink>/get; the original URL
    /// returns an HTML holding page. Referer may only point at the same trusted host.
    static func actualFileURL(_ ticketURL: URL) throws -> URL {
        guard allowedDownloadURL(ticketURL.absoluteString) != nil,
              ticketURL.host?.lowercased() == "sandbox.librus.pl",
              ticketURL.path.hasPrefix("/GetFile/"),
              ticketURL.path.count > "/GetFile/".count,
              !ticketURL.path.hasSuffix("/get") else {
            throw DirectAttachmentError.untrustedDownloadLink
        }
        let url = ticketURL.appendingPathComponent("get")
        guard url.scheme == "https", url.host == ticketURL.host,
              url.path == ticketURL.path + "/get",
              url.query == ticketURL.query, url.fragment == nil else {
            throw DirectAttachmentError.untrustedDownloadLink
        }
        return url
    }

    static func safeFileName(_ value: String) -> Bool {
        !value.isEmpty && value.count <= 240 && !value.hasPrefix(".") &&
        !value.contains("/") && !value.contains("\\") &&
        !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
    }
}
