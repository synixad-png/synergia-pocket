import Foundation

/// Diagnostic aggregates of RECEIVED marks only. Never infer a scheduled-lesson denominator.
/// Missing presence marks and parallel lesson groups make a school attendance % unreliable.
struct DirectAttendanceMonthStatistics: Equatable, Identifiable {
    let month: String? // Gregorian YYYY-MM, nil for malformed server date
    let counts: DirectAttendanceCounters
    var id: String { month.map { "month:\($0)" } ?? "month:unknown" }
    var label: String { month ?? "Data nierozpoznana" }
}

struct DirectAttendanceSubjectSemesterStatistics: Equatable, Identifiable {
    let subjectId: String?
    let subjectName: String
    let semester: Int?
    let counts: DirectAttendanceCounters
    var id: String {
        let subjectKey = subjectId.map { "id:\($0.utf8.count):\($0)" } ?? "missing"
        let semesterKey = semester.map { "number:\($0)" } ?? "missing"
        return subjectKey + ";" + semesterKey
    }
    var semesterLabel: String { semester.map { "Semestr \($0)" } ?? "Semestr nieustalony" }
}

struct DirectAttendanceTypeStatistics: Equatable, Identifiable {
    let typeId: String
    let name: String
    let isPresenceKind: Bool
    let count: Int
    var id: String { "\(typeId)|\(name)|\(isPresenceKind)" }
}

struct DirectAttendanceQuality: Equatable {
    let records: Int
    let unresolvedSubjects: Int
    let unknownSemesters: Int
    let unknownLessonNumbers: Int
    let invalidDates: Int
    let repeatedLessonSlots: Int
    let inconsistentTypeIds: Int
    var hasCautions: Bool {
        unresolvedSubjects > 0 || unknownSemesters > 0 || unknownLessonNumbers > 0 ||
        invalidDates > 0 || repeatedLessonSlots > 0 || inconsistentTypeIds > 0
    }
}

struct DirectAttendanceAnalytics: Equatable {
    let summary: DirectAttendanceSummary
    let months: [DirectAttendanceMonthStatistics]
    let subjectSemesters: [DirectAttendanceSubjectSemesterStatistics]
    let types: [DirectAttendanceTypeStatistics]
    let quality: DirectAttendanceQuality
}

enum DirectAttendanceFilter: Equatable {
    enum Semester: Equatable { case all, unspecified, numbered(Int) }
    enum Subject: Equatable { case all, unspecified, id(String) }
    enum Status: Equatable { case all, present, absent, late, excused, explicitlyUnexcused, unspecifiedAbsence }
    enum Month: Equatable { case all, invalid, yearMonth(String) }

    static func select(_ records: [DirectAttendance], semester: Semester = .all,
                       subject: Subject = .all, status: Status = .all,
                       month: Month = .all) -> [DirectAttendance] {
        records.filter { entry in
            switch semester {
            case .all: break
            case .unspecified: if entry.semester != nil { return false }
            case .numbered(let number): if entry.semester != number { return false }
            }
            switch subject {
            case .all: break
            case .unspecified: if entry.subjectId != nil { return false }
            case .id(let id): if entry.subjectId != id { return false }
            }
            switch month {
            case .all: break
            case .invalid: if DirectAttendanceCalendar.month(for: entry.date) != nil { return false }
            case .yearMonth(let selected): if DirectAttendanceCalendar.month(for: entry.date) != selected { return false }
            }
            switch status {
            case .all: return true
            case .present: return entry.isPresenceKind
            case .absent: return !entry.isPresenceKind
            case .late: return entry.isPresenceKind && DirectAttendanceStatus.isLate(entry.typeName)
            case .excused: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .excused
            case .explicitlyUnexcused: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .unexcused
            case .unspecifiedAbsence: return !entry.isPresenceKind && DirectAttendanceStatus.excuse(entry.typeName) == .unspecified
            }
        }
    }
}

enum DirectAttendanceAnalyticsBuilder {
    static func build(_ records: [DirectAttendance], subjects: [String: String]) -> DirectAttendanceAnalytics {
        let groupedMonths = Dictionary(grouping: records) { DirectAttendanceCalendar.month(for: $0.date) }
        let months = groupedMonths.map { month, entries in
            DirectAttendanceMonthStatistics(month: month, counts: DirectAttendanceStatistics.count(entries))
        }.sorted { a, b in
            switch (a.month, b.month) {
            case let (a?, b?): return a < b
            case (.some, nil): return true
            default: return false
            }
        }
        struct CrossKey: Hashable { let subject: String?; let semester: Int? }
        let cross = Dictionary(grouping: records) { CrossKey(subject: $0.subjectId, semester: $0.semester) }
        let subjectSemesters = cross.map { key, entries in
            DirectAttendanceSubjectSemesterStatistics(subjectId: key.subject,
                subjectName: key.subject.flatMap { subjects[$0] } ?? "Przedmiot nieustalony",
                semester: key.semester, counts: DirectAttendanceStatistics.count(entries))
        }.sorted { a, b in
            let order = a.subjectName.localizedStandardCompare(b.subjectName)
            if order != .orderedSame { return order == .orderedAscending }
            if a.subjectId != b.subjectId { return (a.subjectId ?? "") < (b.subjectId ?? "") }
            return (a.semester ?? Int.max) < (b.semester ?? Int.max)
        }
        struct TypeKey: Hashable { let id: String; let normalizedName: String; let present: Bool }
        let groupedTypes = Dictionary(grouping: records) {
            TypeKey(id: $0.typeId, normalizedName: DirectAttendanceStatus.normalized($0.typeName), present: $0.isPresenceKind)
        }
        let types = groupedTypes.map { key, entries in
            DirectAttendanceTypeStatistics(typeId: key.id,
                name: entries.sorted { $0.id < $1.id }.first?.typeName ?? "Typ nieustalony",
                isPresenceKind: key.present, count: entries.count)
        }.sorted { a, b in
            if a.count != b.count { return a.count > b.count }
            return a.id < b.id
        }
        // Multiple entries at the same date/period can be valid corrections or group records.
        // Report collisions only; never delete or merge marks based on a heuristic.
        var knownSlots = Set<String>()
        var repeats = 0
        for record in records {
            if let day = DirectAttendanceCalendar.day(record.date),
               let no = record.lessonNumber, no > 0 {
                let slot = "\(day)|\(no)"
                if !knownSlots.insert(slot).inserted { repeats += 1 }
            }
        }
        let inconsistentTypes = Dictionary(grouping: records, by: \.typeId)
            .values.filter { Set($0.map { "\(DirectAttendanceStatus.normalized($0.typeName))|\($0.isPresenceKind)" }).count > 1 }.count
        let quality = DirectAttendanceQuality(records: records.count,
            unresolvedSubjects: records.filter { $0.subjectId == nil }.count,
            unknownSemesters: records.filter { $0.semester == nil }.count,
            unknownLessonNumbers: records.filter { ($0.lessonNumber ?? 0) <= 0 }.count,
            invalidDates: records.filter { DirectAttendanceCalendar.day($0.date) == nil }.count,
            repeatedLessonSlots: repeats, inconsistentTypeIds: inconsistentTypes)
        return DirectAttendanceAnalytics(summary: DirectAttendanceStatistics.summarize(records, subjects: subjects),
            months: months, subjectSemesters: subjectSemesters, types: types, quality: quality)
    }
}
