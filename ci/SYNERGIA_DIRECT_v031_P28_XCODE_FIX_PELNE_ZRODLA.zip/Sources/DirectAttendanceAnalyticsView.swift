import SwiftUI

/// Purely local diagnostics of the marks that the Gateway actually returned.
/// No percentages: absent lesson entries are not proof of presence.
struct DirectAttendanceAnalyticsView: View {
    let records: [DirectAttendance]
    let subjects: [String: String]
    let accountId: String?

    @State private var semesterFilter = "all"
    @State private var subjectFilter = "all"
    @State private var statusFilter = "all"
    @State private var monthFilter = "all"

    private var validSemesters: [Int] { Array(Set(records.compactMap(\.semester))).sorted() }
    private var subjectIds: [String] {
        Array(Set(records.compactMap(\.subjectId))).sorted {
            let left = subjects[$0] ?? $0, right = subjects[$1] ?? $1
            let result = left.localizedStandardCompare(right)
            return result == .orderedSame ? $0 < $1 : result == .orderedAscending
        }
    }
    private var months: [String] {
        Array(Array(Set(records.compactMap { DirectAttendanceCalendar.month(for: $0.date) })).sorted().reversed())
    }
    private var filteredRecords: [DirectAttendance] {
        let semester: DirectAttendanceFilter.Semester = semesterFilter == "all" ? .all :
            semesterFilter == "unknown" ? .unspecified : .numbered(Int(semesterFilter) ?? -1)
        let subject: DirectAttendanceFilter.Subject = subjectFilter == "all" ? .all :
            subjectFilter == "unknown" ? .unspecified : .id(String(subjectFilter.dropFirst(3)))
        let month: DirectAttendanceFilter.Month = monthFilter == "all" ? .all :
            monthFilter == "invalid" ? .invalid : .yearMonth(monthFilter)
        let status: DirectAttendanceFilter.Status
        switch statusFilter {
        case "present": status = .present
        case "absent": status = .absent
        case "late": status = .late
        case "excused": status = .excused
        case "unexcused": status = .explicitlyUnexcused
        case "unknown": status = .unspecifiedAbsence
        default: status = .all
        }
        return DirectAttendanceFilter.select(records, semester: semester,
            subject: subject, status: status, month: month)
    }
    private var displayedRecords: [DirectAttendance] {
        Array(filteredRecords.sorted { a, b in
            let dayA = DirectAttendanceCalendar.day(a.date) ?? ""
            let dayB = DirectAttendanceCalendar.day(b.date) ?? ""
            if dayA != dayB { return dayA > dayB }
            if a.lessonNumber != b.lessonNumber { return (a.lessonNumber ?? -1) > (b.lessonNumber ?? -1) }
            return a.id < b.id
        }.prefix(80))
    }

    var body: some View {
        let complete = DirectAttendanceAnalyticsBuilder.build(records, subjects: subjects)
        let selected = DirectAttendanceAnalyticsBuilder.build(filteredRecords, subjects: subjects)
        VStack(alignment: .leading, spacing: 10) {
            Text("Analiza wpisów frekwencji").font(.headline)
            Text("Zliczane są tylko wpisy zwrócone przez Synergię. Brak wpisu nie oznacza obecności, więc nie podajemy oficjalnego procentu frekwencji ani procentów przedmiotowych.")
                .font(.caption).foregroundStyle(.orange)
            if complete.quality.hasCautions {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Jakość i kompletność dostępnych danych").font(.subheadline.bold())
                    if complete.quality.unresolvedSubjects > 0 {
                        Text("Bez powiązanego przedmiotu: \(complete.quality.unresolvedSubjects)")
                    }
                    if complete.quality.unknownSemesters > 0 {
                        Text("Bez semestru: \(complete.quality.unknownSemesters)")
                    }
                    if complete.quality.unknownLessonNumbers > 0 {
                        Text("Bez numeru lekcji: \(complete.quality.unknownLessonNumbers)")
                    }
                    if complete.quality.invalidDates > 0 {
                        Text("Daty wymagające weryfikacji: \(complete.quality.invalidDates)")
                    }
                    if complete.quality.repeatedLessonSlots > 0 {
                        Text("Wiele wpisów tej samej daty i godziny: \(complete.quality.repeatedLessonSlots) (mogą być prawidłowe)")
                    }
                    if complete.quality.inconsistentTypeIds > 0 {
                        Text("Niespójne opisy identyfikatorów statusów: \(complete.quality.inconsistentTypeIds)")
                    }
                }.font(.caption).foregroundStyle(.orange)
            }
            DisclosureGroup("Filtruj wpisy") {
                Picker("Semestr", selection: $semesterFilter) {
                    Text("Wszystkie").tag("all")
                    ForEach(validSemesters, id: \.self) { semester in
                        Text("Semestr \(semester)").tag(String(semester))
                    }
                    if records.contains(where: { $0.semester == nil }) {
                        Text("Nieustalony").tag("unknown")
                    }
                }.pickerStyle(.menu)
                Picker("Przedmiot", selection: $subjectFilter) {
                    Text("Wszystkie").tag("all")
                    ForEach(subjectIds, id: \.self) { id in
                        Text(subjects[id] ?? "Nieznany przedmiot (ID \(id))").tag("id:" + id)
                    }
                    if records.contains(where: { $0.subjectId == nil }) {
                        Text("Nieustalony").tag("unknown")
                    }
                }.pickerStyle(.menu)
                Picker("Miesiąc", selection: $monthFilter) {
                    Text("Wszystkie").tag("all")
                    ForEach(months, id: \.self) { month in Text(month).tag(month) }
                    if records.contains(where: { DirectAttendanceCalendar.month(for: $0.date) == nil }) {
                        Text("Data nierozpoznana").tag("invalid")
                    }
                }.pickerStyle(.menu)
                Picker("Status", selection: $statusFilter) {
                    Text("Wszystkie").tag("all")
                    Text("Obecności").tag("present")
                    Text("Nieobecności").tag("absent")
                    Text("Spóźnienia").tag("late")
                    Text("Usprawiedliwione wg nazwy").tag("excused")
                    Text("Jawnie nieusprawiedliwione").tag("unexcused")
                    Text("Nieobecności bez rozstrzygnięcia").tag("unknown")
                }.pickerStyle(.menu)
                Button("Wyczyść filtry") { resetFilters() }
            }
            Text("Wybrany zakres: \(selected.summary.all.recorded) z \(records.count) wpisów; rozpoznanych dni: \(selected.summary.distinctDates).")
                .font(.subheadline.bold())
            Text("Obecności: \(selected.summary.all.present), nieobecności: \(selected.summary.all.absent), spóźnienia: \(selected.summary.all.late).")
                .font(.caption)
            Text("Wśród nieobecności — usprawiedliwione wg nazwy: \(selected.summary.all.excused), jawnie nieusprawiedliwione: \(selected.summary.all.explicitlyUnexcused), status nieustalony: \(selected.summary.all.absenceStatusUnknown).")
                .font(.caption)
            Text("Usprawiedliwienie jest wnioskowane tylko z jednoznacznej nazwy statusu. Wnioski, oczekiwanie na decyzję i nieznane nazwy pozostają nierozstrzygnięte.")
                .font(.caption).foregroundStyle(.secondary)
            DisclosureGroup("Semestry (wybrane wpisy)") {
                ForEach(selected.summary.bySemester) { item in
                    Text("\(item.label): wpisów \(item.counts.recorded), obecności \(item.counts.present), nieobecności \(item.counts.absent), spóźnienia \(item.counts.late)")
                        .font(.caption)
                }
            }
            DisclosureGroup("Przedmioty (wybrane wpisy)") {
                ForEach(selected.summary.bySubject) { item in
                    Text("\(item.name): wpisów \(item.counts.recorded), obecności \(item.counts.present), nieobecności \(item.counts.absent), spóźnienia \(item.counts.late)")
                        .font(.caption)
                }
            }
            DisclosureGroup("Przedmioty z podziałem na semestry") {
                ForEach(selected.subjectSemesters) { item in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(item.subjectName) · \(item.semesterLabel)").font(.caption.bold())
                        Text("Wpisy \(item.counts.recorded), obecności \(item.counts.present), nieobecności \(item.counts.absent), spóźnienia \(item.counts.late)")
                            .font(.caption)
                    }
                }
            }
            DisclosureGroup("Miesiące") {
                ForEach(selected.months) { item in
                    Text("\(item.label): wpisów \(item.counts.recorded), obecności \(item.counts.present), nieobecności \(item.counts.absent)")
                        .font(.caption)
                }
            }
            DisclosureGroup("Typy frekwencji zgłoszone przez szkołę") {
                ForEach(selected.types) { item in
                    Text("\(item.name): \(item.count) (\(item.isPresenceKind ? "rodzaj obecności" : "rodzaj nieobecności"))")
                        .font(.caption)
                }
            }
            if filteredRecords.isEmpty {
                Text("Brak wpisów spełniających wybrane filtry. Nie oznacza to braku lekcji.")
                    .font(.caption).foregroundStyle(.secondary)
            } else {
                Text("Wpisy w wybranym zakresie").font(.subheadline.bold())
                if filteredRecords.count > displayedRecords.count {
                    Text("Pokazano \(displayedRecords.count) najnowszych z \(filteredRecords.count) wpisów — zawęź filtry, aby obejrzeć pozostałe.")
                        .font(.caption).foregroundStyle(.orange)
                }
                ForEach(displayedRecords) { entry in
                    VStack(alignment: .leading, spacing: 3) {
                        HStack {
                            Text(entry.date).font(.subheadline.bold())
                            Spacer()
                            Text(entry.typeName).font(.subheadline)
                                .foregroundStyle(entry.isPresenceKind ? .green : .red)
                        }
                        Text(entry.subjectId.flatMap { subjects[$0] } ?? "Przedmiot nieustalony").font(.caption)
                        Text("Lekcja: \(entry.lessonNumber.map(String.init) ?? "nieustalona"), semestr: \(entry.semester.map(String.init) ?? "nieustalony")")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 3)
                }
            }
        }
        .onChange(of: accountId) { _ in resetFilters() }
    }

    private func resetFilters() {
        semesterFilter = "all"
        subjectFilter = "all"
        statusFilter = "all"
        monthFilter = "all"
    }
}
