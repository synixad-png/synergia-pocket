import SwiftUI

/// Full, selectable grade details. Always resolves current data from the store,
/// not a snapshot retained by NavigationLink while the user changes accounts.
struct DirectGradeDetailView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    let gradeID: String
    let expectedAccountID: String

    private var liveGrade: DirectGrade? {
        GradeDetailAccess.resolve(
            gradeID: gradeID, expectedAccountID: expectedAccountID,
            verifiedAccountID: portal.store.verifiedAccountId,
            cacheAccountID: portal.directGradeStore.verifiedAccountId,
            privacyShieldActive: portal.privacyShieldActive,
            grades: portal.directGradeStore.grades)
    }

    var body: some View {
        Group {
            if let grade = liveGrade {
                List {
                    Section("Ocena") {
                        LabeledContent("Wartość", value: grade.value)
                        LabeledContent("Przedmiot", value:
                            portal.directGradeStore.subjects[grade.subjectId] ?? "ID \(grade.subjectId)")
                        LabeledContent("Semestr", value: grade.semester.map(String.init) ?? "Nieustalony")
                        LabeledContent("Data wystawienia", value: grade.addedAt ?? "Nieustalona")
                        if let name = grade.categoryName {
                            LabeledContent("Kategoria", value: name)
                        } else if let categoryID = grade.categoryId {
                            LabeledContent("Kategoria", value: "Nieustalona (ID \(categoryID))")
                        } else {
                            LabeledContent("Kategoria", value: "Nieustalona")
                        }
                        if let weight = grade.weight {
                            LabeledContent("Waga", value: weight.formatted())
                        } else {
                            LabeledContent("Waga", value: "Nieustalona")
                        }
                        LabeledContent("Wliczanie do średniej", value:
                            grade.countsToAverage.map { $0 ? "Tak" : "Nie" } ?? "Nieustalone")
                        LabeledContent("Autor wpisu", value:
                            GradeSubjectAuthorAudit.attribution(for: grade,
                                names: portal.directGradeStore.teachers,
                                earlierIds: portal.directGradeStore.olderTeacherIds).label)
                    }
                    Section("Komentarze (\(grade.commentTexts.count))") {
                        if grade.commentTexts.isEmpty {
                            Text("W aktualnie zapisanym odczycie nie ma komentarzy do tej oceny.")
                                .foregroundStyle(.secondary)
                        }
                        // Different comments may have equal text; their individual
                        // positions keep both entries visible without deduplication.
                        ForEach(Array(grade.commentTexts.enumerated()), id: \.offset) { entry in
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Komentarz \(entry.offset + 1)")
                                    .font(.caption).foregroundStyle(.secondary)
                                Text(verbatim: entry.element.isEmpty
                                     ? "(Komentarz nie zawiera tekstu)" : entry.element)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .textSelection(.enabled)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 6)
                        }
                    }
                    Section {
                        Text("Informacje pochodzą z ostatniego poprawnego odczytu JSON; nie gwarantują aktualności ani kompletności danych na serwerze.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            } else {
                ContentUnavailableView("Dane oceny zablokowane",
                                       systemImage: "lock.shield",
                                       description: Text("Po zmianie konta, wylogowaniu lub ukryciu danych otwórz oceny ponownie po weryfikacji konta."))
            }
        }
        .navigationTitle("Szczegóły oceny")
        .navigationBarTitleDisplayMode(.inline)
    }
}
