import Foundation

/// Notification preferences contain NO school data, account identifiers or message text.
/// Global consent is reset at explicit local sign-out; iOS authorization is checked separately.
enum DirectNotificationCategory: String, CaseIterable, Codable, Hashable, Identifiable {
    case grades, attendance, messages
    var id: String { rawValue }
    var requestIdentifier: String { "pl.synixad.synergiadirect.change." + rawValue }
}

struct DirectNotificationPreferences: Codable, Equatable {
    var schemaVersion: Int = 1
    var enabled: Bool = false
    var grades: Bool = true
    var attendance: Bool = true
    var messages: Bool = true

    func permits(_ kind: DirectNotificationCategory) -> Bool {
        guard enabled else { return false }
        switch kind {
        case .grades: return grades
        case .attendance: return attendance
        case .messages: return messages
        }
    }

    mutating func set(_ kind: DirectNotificationCategory, enabled: Bool) {
        switch kind {
        case .grades: grades = enabled
        case .attendance: attendance = enabled
        case .messages: messages = enabled
        }
    }

    /// The app never schedules a first-snapshot, incomplete, or account-mismatched event.
    func categories(from plan: CoreLocalNotificationPlan) -> [DirectNotificationCategory] {
        let proposed: [(DirectNotificationCategory, Bool)] = [
            (.grades, plan.grades), (.attendance, plan.attendance), (.messages, plan.messages)
        ]
        return proposed.compactMap { kind, changed in changed && permits(kind) ? kind : nil }
    }
}

/// Explicitly fail closed when settings are damaged or from a future schema.
enum DirectNotificationPreferenceStorage {
    static let key = "synergia.direct.notification.preferences.v1"

    static func load(from defaults: UserDefaults = .standard) -> DirectNotificationPreferences {
        guard let raw = defaults.data(forKey: key),
              let saved = try? JSONDecoder().decode(DirectNotificationPreferences.self, from: raw) else {
            return DirectNotificationPreferences()
        }
        guard saved.schemaVersion == 1 else { return DirectNotificationPreferences() }
        return saved
    }

    static func save(_ preferences: DirectNotificationPreferences, to defaults: UserDefaults = .standard) {
        guard let data = try? JSONEncoder().encode(preferences) else { return }
        defaults.set(data, forKey: key)
    }

    static func clear(from defaults: UserDefaults = .standard) {
        defaults.removeObject(forKey: key)
    }
}

/// Suppress duplicate alerts from back-to-back manual refreshes while not
/// persisting any fingerprint, identifier, grade or other private information.
struct DirectNotificationDebouncer {
    private(set) var lastDispatch: [DirectNotificationCategory: Date] = [:]
    let minimumInterval: TimeInterval

    init(minimumInterval: TimeInterval = 20) { self.minimumInterval = max(0, minimumInterval) }

    mutating func eligible(_ requested: [DirectNotificationCategory], at now: Date) -> [DirectNotificationCategory] {
        var result: [DirectNotificationCategory] = []
        for kind in Set(requested) {
            if let last = lastDispatch[kind] {
                let elapsed = now.timeIntervalSince(last)
                if elapsed >= 0 && elapsed < minimumInterval { continue }
            }
            lastDispatch[kind] = now
            result.append(kind)
        }
        return DirectNotificationCategory.allCases.filter { result.contains($0) }
    }

    mutating func reset() { lastDispatch.removeAll() }
}

/// Only live, successfully verified /Me identities may change the notification
/// account binding. Keep the identifier in RAM only; reset on local sign-out.
struct DirectNotificationAccountGate {
    private(set) var lastVerifiedAccountId: String?

    /// True indicates a different, newly verified account and requires a new opt-in.
    mutating func verify(_ accountId: String) -> Bool {
        guard !accountId.isEmpty else { return false }
        defer { lastVerifiedAccountId = accountId }
        guard let lastVerifiedAccountId else { return false }
        return lastVerifiedAccountId != accountId
    }

    mutating func reset() { lastVerifiedAccountId = nil }
}

/// Pure generation-based guard for asynchronous OS permission callbacks.
/// A foreground transition during a system prompt must NOT cancel the prompt.
struct DirectNotificationAuthorizationGate {
    private(set) var generation = 0
    private(set) var requestInProgress = false

    mutating func beginUserRequest() -> Int {
        generation += 1
        requestInProgress = true
        return generation
    }

    mutating func beginStatusCheck() -> Int? {
        guard !requestInProgress else { return nil }
        generation += 1
        return generation
    }

    mutating func acceptUserRequest(_ ticket: Int) -> Bool {
        guard requestInProgress, generation == ticket else { return false }
        requestInProgress = false
        return true
    }

    func acceptStatusCheck(_ ticket: Int) -> Bool {
        !requestInProgress && ticket == generation
    }

    mutating func cancel() {
        generation += 1
        requestInProgress = false
    }
}

/// Pure predicate for account-scoped opt-in. No consent from the previous
/// process may be used until a live /Me owner matches the Keychain binding.
enum DirectNotificationOwnerPolicy {
    static func mayActivate(preferences: DirectNotificationPreferences,
                            boundAccount: String?, verifiedAccount: String?) -> Bool {
        guard preferences.enabled,
              let boundAccount, !boundAccount.isEmpty,
              let verifiedAccount, !verifiedAccount.isEmpty else { return false }
        return boundAccount == verifiedAccount
    }
}

/// A permission prompt may temporarily move the iOS scene to `.inactive`.
/// That alone is not a logout. A real background transition or a changed
/// account epoch must still invalidate an outstanding permission callback.
enum DirectNotificationPromptPolicy {
    static func canBind(verifiedOwner: String, currentVerifiedOwner: String?,
                        accountEpochUnchanged: Bool, enteredBackground: Bool) -> Bool {
        !verifiedOwner.isEmpty && verifiedOwner == currentVerifiedOwner &&
            accountEpochUnchanged && !enteredBackground
    }
}
