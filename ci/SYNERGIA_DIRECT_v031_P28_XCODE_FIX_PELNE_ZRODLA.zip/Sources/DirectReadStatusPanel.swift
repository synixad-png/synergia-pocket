import SwiftUI

/// Wspólna, dostępna dla VoiceOver prezentacja stanu odczytu JSON.
struct DirectReadStatusPanel: View {
    let state: DirectReadPresentation

    private var stateColor: Color {
        switch state.kind {
        case .available, .empty: return .green
        case .loading, .notRequested: return .secondary
        case .locked, .failed, .stale, .partial: return .orange
        }
    }
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: state.kind.symbol)
                .font(.title3)
                .foregroundStyle(stateColor)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(state.kind.title).font(.subheadline.bold())
                Text(state.kind.guidance).font(.caption).foregroundStyle(.secondary)
                if let count = state.count {
                    Text("Wpisów w odczycie: \(count)")
                        .font(.caption).monospacedDigit()
                }
                if let date = state.capturedAt {
                    Text("Odczyt z: \(date.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 6)
        .accessibilityElement(children: .combine)
    }
}
