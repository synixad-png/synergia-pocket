import SwiftUI

/// UI for SchoolFiles only. Download/share remain explicit user actions.
struct DirectSchoolDocumentsView: View {
    let feed: DirectSchoolFeed
    let fileURLs: [String: URL]
    let downloadBusy: Bool
    let downloadStatus: String
    let onDownload: (DirectSchoolFileReference, DirectSchoolFeedEntry) -> Void

    @State private var query = ""
    @State private var availability = 0
    @State private var fileExtension = ""
    @State private var order = 0

    private var visible: [DirectSchoolFeedEntry] {
        DirectSchoolDocumentsPresentation.entries(
            feed, query: query,
            availability: DirectSchoolDocumentsPresentation.Availability(rawValue: availability) ?? .all,
            extensionFilter: fileExtension.isEmpty ? nil : fileExtension,
            order: DirectSchoolDocumentsPresentation.Order(rawValue: order) ?? .name)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Szukaj dokumentów", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Picker("Pobieranie", selection: $availability) {
                Text("Wszystkie").tag(0)
                Text("Link zweryfikowany").tag(1)
                Text("Brak linku").tag(2)
            }.pickerStyle(.menu)
            Picker("Rozszerzenie nazwy", selection: $fileExtension) {
                Text("Wszystkie rozszerzenia").tag("")
                ForEach(DirectSchoolDocumentsPresentation.extensions(feed), id: \.self) { ext in
                    Text(".\(ext)").tag(ext)
                }
            }.pickerStyle(.menu)
            Picker("Sortuj", selection: $order) {
                Text("Według nazwy").tag(0)
                Text("Według daty dodania").tag(1)
            }.pickerStyle(.segmented)
            Text("Wyświetlono \(visible.count) z \(feed.records.count) odczytanych wpisów. Brak linku nie oznacza braku dokumentu.")
                .font(.caption).foregroundStyle(.secondary)
            if visible.isEmpty {
                Text("Brak dokumentów spełniających wybrane kryteria.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(visible) { entry in
                VStack(alignment: .leading, spacing: 6) {
                    Text(entry.title).font(.headline).textSelection(.enabled)
                    if let ext = DirectSchoolDocumentsPresentation.filenameExtension(entry.title) {
                        Text("Rozszerzenie nazwy: .\(ext) (typ pliku niezweryfikowany)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if let addedDay = entry.document?.addedDay {
                        Text("Dodano: \(addedDay)").font(.caption)
                    }
                    if let status = entry.document?.serverStatus {
                        Text("Status serwera: \(status)").font(.caption).textSelection(.enabled)
                    }
                    if entry.document == nil {
                        Text("Starszy zapis. Odśwież po zalogowaniu, aby odczytać dostępne metadane.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    if let file = DirectSchoolDocumentsPresentation.uniqueDownloadReference(entry, in: feed) {
                        if let savedURL = fileURLs[file.id] {
                            ShareLink(item: savedURL) {
                                Label("Udostępnij / Zapisz dokument", systemImage: "square.and.arrow.up")
                            }
                        } else {
                            Button {
                                onDownload(file, entry)
                            } label: {
                                Label("Pobierz dokument", systemImage: "arrow.down.doc")
                            }.disabled(downloadBusy)
                        }
                    } else {
                        Text("Brak jednoznacznego, zweryfikowanego odnośnika — pobieranie wyłączone.")
                            .font(.caption2).foregroundStyle(.orange)
                    }
                    Divider()
                }.padding(.vertical, 3)
            }
            if downloadBusy { ProgressView("Trwa pobieranie dokumentu…") }
            if !downloadStatus.isEmpty {
                Text(downloadStatus).font(.caption).foregroundStyle(.secondary)
            }
            Text("Lista może być niekompletna, a dane offline nieaktualne. Status serwera nie upoważnia sam w sobie do pobierania. " +
                 "Pobieranie jest ręczne, z ponownym sprawdzeniem konta.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .onChange(of: feed.verifiedAccountId) { _, _ in
            query = ""; availability = 0; fileExtension = ""; order = 0
        }
        .onChange(of: feed.fetchedAt) { _, _ in
            fileExtension = ""
        }
    }
}
