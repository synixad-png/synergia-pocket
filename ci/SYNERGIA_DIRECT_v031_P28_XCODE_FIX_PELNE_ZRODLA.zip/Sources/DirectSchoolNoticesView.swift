import SwiftUI

/// Separate view for direct JSON notices; it does not mark announcements read
/// on the server or execute any HTML returned by the school.
struct DirectSchoolNoticesView: View {
    let feed: DirectSchoolFeed
    @State private var search = ""
    @State private var filter = 0

    private var visible: [DirectSchoolFeedEntry] {
        feed.records.filter { entry in
            guard let notice = entry.notice else {
                return filter == 0 && (search.isEmpty || entry.title.localizedCaseInsensitiveContains(search))
            }
            let matchesStatus = filter == 0 ||
                (filter == 1 && notice.wasRead == false) || (filter == 2 && notice.wasRead == true)
            let term = search.trimmingCharacters(in: .whitespacesAndNewlines)
            let matchesText = term.isEmpty || entry.title.localizedCaseInsensitiveContains(term) ||
                (notice.body?.localizedCaseInsensitiveContains(term) ?? false)
            return matchesStatus && matchesText
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Szukaj w ogłoszeniach", text: $search)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Picker("Stan odczytu", selection: $filter) {
                Text("Wszystkie").tag(0)
                Text("Nieprzeczytane").tag(1)
                Text("Przeczytane").tag(2)
            }.pickerStyle(.segmented)
            Text("Widocznych: \(visible.count) z \(feed.records.count). Nieznany stan odczytu nie jest uznawany za przeczytany.")
                .font(.caption).foregroundStyle(.secondary)
            if visible.isEmpty {
                Text("Brak ogłoszeń spełniających wybrane kryteria.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(visible) { entry in
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .top) {
                        Text(entry.title).font(.headline).textSelection(.enabled)
                        Spacer(minLength: 6)
                        switch entry.notice?.wasRead {
                        case .some(true): Label("Przeczytane", systemImage: "checkmark.circle")
                        case .some(false): Label("Nieprzeczytane", systemImage: "circle.fill")
                        default: Label("Brak statusu", systemImage: "questionmark.circle")
                        }
                    }.font(.caption).foregroundStyle(.secondary)
                    if let notice = entry.notice {
                        if let created = notice.creationDate { Text("Dodano: \(created)").font(.caption) }
                        if notice.startDate != nil || notice.endDate != nil {
                            Text("Publikacja: \(notice.startDate ?? "brak daty") – \(notice.endDate ?? "brak daty")")
                                .font(.caption)
                        }
                        if let body = notice.body {
                            Text(body).font(.subheadline).textSelection(.enabled)
                        } else {
                            Text("Brak pełnej treści w odczycie JSON.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    } else {
                        Text("Zapis w starszym formacie — ponów pobieranie, aby odczytać szczegóły.")
                            .font(.caption).foregroundStyle(.secondary)
                        ForEach(entry.details, id: \.self) { detail in
                            Text(detail).font(.subheadline).textSelection(.enabled)
                        }
                    }
                    Divider()
                }.padding(.vertical, 3)
            }
            Text("Status odczytu pochodzi z serwera. Otwieranie wpisu tutaj nie zmienia go w Synergii. Dane offline mogą być nieaktualne.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .onChange(of: feed.verifiedAccountId) { _, _ in search = ""; filter = 0 }
    }
}
