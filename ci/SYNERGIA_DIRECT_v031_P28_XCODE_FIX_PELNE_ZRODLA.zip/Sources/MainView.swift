import SwiftUI

struct MainView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        TabView {
            NavigationStack { DashboardView() }
                .tabItem { Label("Start", systemImage: "house.fill") }
            NavigationStack { ModuleView(module: .grades) }
                .tabItem { Label("Oceny", systemImage: "graduationcap.fill") }
            NavigationStack { ModuleView(module: .timetable) }
                .tabItem { Label("Plan", systemImage: "calendar") }
            NavigationStack { ModuleView(module: .messages) }
                .tabItem { Label("Wiadomości", systemImage: "envelope.fill") }
            NavigationStack { MoreView() }
                .tabItem { Label("Więcej", systemImage: "square.grid.2x2.fill") }
        }
        .tint(.indigo)
        .overlay {
            if portal.privacyShieldActive {
                ZStack {
                    Color(.systemBackground).ignoresSafeArea()
                    VStack(spacing: 12) {
                        Image(systemName: "lock.shield.fill")
                            .font(.largeTitle)
                        Text("SYNERGIA DIRECT").font(.headline)
                        Text("Dane ukryte do czasu aktywacji i weryfikacji sesji.")
                            .font(.caption).multilineTextAlignment(.center)
                    }.padding(24)
                }
            }
        }
        .onAppear { portal.restoreOfficialSessionAtLaunch() }
        .onChange(of: scenePhase) { _, newPhase in
            portal.scenePhaseChanged(to: newPhase)
        }
        .alert("Synergia Direct", isPresented: Binding(
            get: { portal.alert != nil },
            set: { if !$0 { portal.alert = nil } }
        )) {
            Button("OK") { portal.alert = nil }
        } message: { Text(portal.alert ?? "") }
    }
}

struct DashboardView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("Twój dziennik").font(.largeTitle.bold())
                    Text("Dane dostępne lokalnie na tym urządzeniu")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(.top, 14)
                NavigationLink(destination: ConnectionView()) {
                    HStack {
                        Image(systemName: "lock.iphone").font(.title2)
                        VStack(alignment: .leading) {
                            Text("Połączenie z Synergią").font(.headline)
                            Text(portal.accountStatus).font(.caption).lineLimit(3)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                    }.padding(16).foregroundStyle(.primary)
                        .background(.indigo.opacity(0.10), in: RoundedRectangle(cornerRadius: 16))
                }
                VStack(alignment: .leading, spacing: 8) {
                    Button { portal.verifyAccount() } label: {
                        Label("Sprawdź aktywną sesję", systemImage: "checkmark.shield")
                    }
                    .disabled(portal.isBusy || portal.isSyncing || portal.coreSyncBusy)
                    Button { portal.synchronizeCoreModules() } label: {
                        Label("Synchronizuj oceny, frekwencję i wiadomości JSON", systemImage: "arrow.triangle.2.circlepath.circle")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(portal.coreSyncBusy || portal.isBusy || portal.isSyncing)
                    if portal.coreSyncBusy { ProgressView("Trwa sprawdzanie trzech modułów…") }
                    Text(portal.coreSyncStatus).font(.caption).foregroundStyle(.secondary)
                    Button { portal.refreshAllDirectFeeds() } label: {
                        Label("Odśwież zadania, terminarz, ogłoszenia i dokumenty JSON", systemImage: "arrow.clockwise.circle")
                    }
                    .buttonStyle(.bordered)
                    .disabled(portal.coreSyncBusy || portal.directFeedBatchBusy ||
                              portal.directFeedBusy != nil || portal.isBusy || portal.isSyncing ||
                              portal.store.verifiedAccountId == nil)
                    if portal.directFeedBatchBusy { ProgressView("Trwa odczyt czterech modułów…") }
                    if portal.store.verifiedAccountId != nil {
                        let saved = portal.directOfflineFeedStore.feeds
                        Text("Zapis offline: \(saved.count)/4 modułów. Odtworzony zapis jest NIEAKTUALNY do ponownego odświeżenia. Brak dostępu do danych przed potwierdzeniem konta.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if let change = portal.coreSyncChanges {
                        Text("Wykryte: oceny +\(change.newGrades) / zmienione \(change.editedGrades), " +
                             "frekwencja +\(change.newAttendance) / zmienione \(change.editedAttendance), " +
                             "wiadomości +\(change.newMessages).")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Divider()
                    Button {
                        portal.syncApprovedModules()
                    } label: {
                        Label("Synchronizuj zapisane moduły", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(portal.isSyncing || portal.isBusy)
                    if portal.isSyncing {
                        Button("Przerwij synchronizację") { portal.stopSync() }
                            .buttonStyle(.bordered)
                    }
                    Text(portal.syncSummary).font(.caption).foregroundStyle(.secondary)
                    if let run = portal.auditStore.lastRun {
                        DisclosureGroup("Raport ostatniej synchronizacji") {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Zapisano stron: \(run.savedPages); pozostałych wyników: \(run.failedPages)")
                                    .font(.caption)
                                if run.interrupted {
                                    Text("Synchronizacja została przerwana.")
                                        .font(.caption).foregroundStyle(.orange)
                                }
                                ForEach(run.pages) { entry in
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("\(entry.module.title): \(entry.status.rawValue)")
                                            .font(.caption.bold())
                                        Text(entry.explanation).font(.caption2).foregroundStyle(.secondary)
                                        if entry.detectedPagination {
                                            Text("Wykryto wiele stron wyników.")
                                                .font(.caption2).foregroundStyle(.orange)
                                        }
                                    }
                                }
                                Text("Raport dotyczy wyłącznie zatwierdzonych stron; nie potwierdza pełnej liczby ocen ani wiadomości w Synergii.")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let delta = portal.lastDelta {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Porównanie lokalne: \(delta.module.title)").font(.subheadline.bold())
                            if delta.comparable {
                                Text("Wiersze dodane: \(delta.addedRowOccurrences), usunięte: \(delta.removedRowOccurrences)")
                                    .font(.caption)
                            } else {
                                Text("Odczyty nieporównywalne").font(.caption)
                            }
                            Text(delta.explanation).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    Text("Synchronizacja na pierwszym planie. Dane modułu zapisują się dopiero po zaakceptowaniu wszystkich zatwierdzonych stron.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Text("Moduły").font(.title3.bold())
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(SchoolModule.allCases) { module in
                        NavigationLink(destination: ModuleView(module: module)) {
                            VStack(alignment: .leading, spacing: 12) {
                                Image(systemName: module.symbol).font(.title2).foregroundStyle(.indigo)
                                Text(module.title).font(.headline).foregroundStyle(.primary)
                                if let snapshot = portal.store.snapshot(for: module) {
                                    Text("Odczyt: \(snapshot.capturedAt.formatted(date: .numeric, time: .shortened))")
                                        .font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                                } else {
                                    Text("Brak lokalnego odczytu").font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                            .frame(maxWidth: .infinity, minHeight: 106, alignment: .leading)
                            .padding(14)
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                        }
                    }
                }
                Text("Lokalne odczyty nie gwarantują kompletności ani aktualności danych w Synergii.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(16)
        }
        .navigationTitle("SYNERGIA DIRECT")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ModuleView: View {
    @State private var gradeSemesterSelection = 0
    @State private var gradeSubjectSelection = ""
    @State private var showDirectSendConfirmation = false
    @State private var directRecipientSearch = ""
    @EnvironmentObject private var portal: SynergiaPortal
    let module: SchoolModule

    private var readPresentation: DirectReadPresentation {
        let account = portal.store.verifiedAccountId
        let verified = account != nil && !portal.privacyShieldActive
        let failed = portal.failedDirectReads.contains(module)
        switch module {
        case .grades:
            let db = portal.directGradeStore
            return .evaluate(verified: verified, loading: portal.directGradeBusy, failed: failed,
                             count: db.capturedAt == nil ? nil : db.grades.count + db.supplemental.count,
                             capturedAt: db.capturedAt, complete: false,
                             accountMatches: db.verifiedAccountId == account,
                             fresh: portal.freshDirectReads.contains(.grades))
        case .attendance:
            let db = portal.directAttendanceStore
            return .evaluate(verified: verified, loading: portal.directAttendanceBusy, failed: failed,
                             count: db.capturedAt == nil ? nil : db.records.count,
                             capturedAt: db.capturedAt, complete: false,
                             accountMatches: db.verifiedAccountId == account,
                             fresh: portal.freshDirectReads.contains(.attendance))
        case .messages:
            // Wiadomości obejmują wiele skrzynek; brak odczytu Odebranych
            // nie może ukrywać poprawnie pobranej skrzynki Wysłane lub archiwum.
            let snapshots = Array(portal.directMailboxes.values)
            let count = snapshots.isEmpty ? nil : snapshots.reduce(0) { $0 + $1.messages.count }
            let last = snapshots.map(\.fetchedAt).max()
            return .evaluate(verified: verified,
                             loading: portal.directMessagesBusy != nil || portal.directUnreadBusy,
                             failed: !portal.failedDirectMailboxes.isEmpty,
                             count: count, capturedAt: last,
                             complete: false, // Nie pobrano z definicji wszystkich skrzynek.
                             accountMatches: snapshots.allSatisfy { $0.accountId == account })
        case .timetable:
            let plan = portal.directTimetable
            let chosenWeek = DirectTimetableParser.monday(containing: portal.timetableChosenDate)
            return .evaluate(verified: verified, loading: portal.directTimetableBusy,
                             failed: failed, count: plan?.monday == chosenWeek ? plan?.entries.count : nil,
                             capturedAt: plan?.monday == chosenWeek ? plan?.fetchedAt : nil,
                             complete: false,
                             accountMatches: plan == nil || plan?.accountId == account,
                             fresh: portal.freshDirectReads.contains(.timetable))
        case .homework, .calendar, .announcements, .documents:
            let feed = portal.directFeeds[module]
            return .evaluate(verified: verified,
                             loading: portal.directFeedBusy == module || portal.directFeedBatchBusy,
                             failed: failed, count: feed?.records.count, capturedAt: feed?.fetchedAt,
                             complete: feed?.completenessKnown ?? false,
                             accountMatches: feed == nil || feed?.verifiedAccountId == account,
                             fresh: portal.freshDirectReads.contains(module))
        }
    }
    var body: some View {
        List {
            Section("Stan odczytu JSON") {
                DirectReadStatusPanel(state: readPresentation)
            }
            if module == .grades {
                Section("Oceny bezpośrednio z Synergii (JSON)") {
                    Button {
                        portal.refreshDirectGrades()
                    } label: {
                        Label("Pobierz oceny z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(portal.directGradeBusy)
                    if portal.directGradeBusy { ProgressView("Trwa odczyt JSON…") }
                    Text(portal.directGradeStatus)
                        .font(.caption).foregroundStyle(.secondary)
                    if let date = portal.directGradeStore.capturedAt {
                        Text("Ostatni poprawny zapis: \(date.formatted(date: .numeric, time: .shortened))")
                            .font(.caption)
                        Text("Ocen zwykłych: \(portal.directGradeStore.grades.count), pozostałych wpisów: \(portal.directGradeStore.supplemental.count). Kompletność konta nie została potwierdzona.")
                            .font(.caption).foregroundStyle(.orange)
                        let availableSubjects = Array(Set(
                            portal.directGradeStore.grades.map(\.subjectId) +
                            portal.directGradeStore.supplemental.compactMap(\.subjectId)))
                            .sorted { a, b in
                                (portal.directGradeStore.subjects[a] ?? a).localizedCompare(
                                    portal.directGradeStore.subjects[b] ?? b) == .orderedAscending
                            }
                        Picker("Przedmiot", selection: $gradeSubjectSelection) {
                            Text("Wszystkie przedmioty").tag("")
                            ForEach(availableSubjects, id: \.self) { id in
                                Text(portal.directGradeStore.subjects[id] ?? "ID \(id)").tag(id)
                            }
                        }
                        if !gradeSubjectSelection.isEmpty && !availableSubjects.contains(gradeSubjectSelection) {
                            Text("Poprzednio wybrany przedmiot nie występuje w tym koncie.")
                                .font(.caption).foregroundStyle(.orange)
                            Button("Pokaż wszystkie przedmioty") { gradeSubjectSelection = "" }
                        }
                        ForEach(portal.directGradeStore.supplemental.filter { item in
                            (gradeSubjectSelection.isEmpty || item.subjectId == gradeSubjectSelection) &&
                            (gradeSemesterSelection == 0 || (gradeSemesterSelection == 3
                                ? item.semester != 1 && item.semester != 2
                                : item.semester == gradeSemesterSelection))
                        }) { extra in
                            VStack(alignment: .leading, spacing: 2) {
                                Text("\(extra.family.rawValue): \(extra.value)")
                                if let subject = extra.subjectId {
                                    Text("Przedmiot: \(portal.directGradeStore.subjects[subject] ?? "ID \(subject)")")
                                        .font(.caption)
                                }
                                Text("Semestr: \(extra.semester.map(String.init) ?? "brak oznaczenia")")
                                    .font(.caption)
                            }
                        }
                        Text(GradePortfolioSemesterCoverage.report(
                            standard: portal.directGradeStore.grades,
                            supplemental: portal.directGradeStore.supplemental).message)
                            .font(.caption).foregroundStyle(.orange)
                    }
                    Picker("Semestr", selection: $gradeSemesterSelection) {
                        Text("Wszystkie").tag(0)
                        Text("I").tag(1)
                        Text("II").tag(2)
                        Text("Inne").tag(3)
                    }
                    .pickerStyle(.segmented)
                    let selectedGrades = GradeSemesterPresentation.select(
                        portal.directGradeStore.grades, filter: gradeSemesterSelection)
                        .filter { gradeSubjectSelection.isEmpty || $0.subjectId == gradeSubjectSelection }
                    let referenceAudit = GradeSubjectAuthorAudit.summarize(
                        selectedGrades,
                        subjects: portal.directGradeStore.subjects,
                        authors: portal.directGradeStore.teachers,
                        earlierAuthorIds: portal.directGradeStore.olderTeacherIds)
                    Text(referenceAudit.message)
                        .font(.caption)
                        .foregroundStyle(referenceAudit.hasWarnings ? Color.orange : Color.secondary)
                    Text(GradeSemesterPresentation.summary(
                        grades: portal.directGradeStore.grades.filter {
                            gradeSubjectSelection.isEmpty || $0.subjectId == gradeSubjectSelection
                        }, filter: gradeSemesterSelection))
                        .font(.caption).foregroundStyle(.secondary)
                    if !selectedGrades.isEmpty {
                        Section("Średnie lokalne — wyłącznie orientacyjne") {
                            Text("Nie są to średnie oficjalnie obliczone przez Synergię. Oceny z plusami, minusami i nieznanymi wagami nie są przeliczane na podstawie domysłów.")
                                .font(.caption).foregroundStyle(.secondary)
                            ForEach(GradeWeightedAverage.calculate(selectedGrades), id: \.id) { summary in
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("\(portal.directGradeStore.subjects[summary.subjectId] ?? summary.subjectId) · semestr \(summary.semester)")
                                        .font(.subheadline)
                                    if let value = summary.mean {
                                        Text("Średnia orientacyjna: \(value.formatted(.number.precision(.fractionLength(2))))")
                                    } else {
                                        Text(summary.reason ?? "Nie można obliczyć")
                                            .font(.caption).foregroundStyle(.orange)
                                    }
                                    Text("Wliczone: \(summary.includedCount) · pominięte: \(summary.excludedCount) · nierozstrzygnięte: \(summary.unresolvedCount)")
                                        .font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    ForEach(selectedGrades) { grade in
                        NavigationLink {
                            DirectGradeDetailView(
                                gradeID: grade.id,
                                expectedAccountID: portal.store.verifiedAccountId ?? "")
                        } label: {
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text(portal.directGradeStore.subjects[grade.subjectId] ?? "Przedmiot ID \(grade.subjectId)")
                                        .font(.headline)
                                    Spacer()
                                    Text(grade.value).font(.title3.bold())
                                }
                                if let date = grade.addedAt {
                                    Text("Data: \(date)").font(.caption).foregroundStyle(.secondary)
                                }
                                if !grade.commentTexts.isEmpty {
                                    Text("Komentarze: \(grade.commentTexts.count) — otwórz pełne szczegóły")
                                        .font(.caption).foregroundStyle(.secondary)
                                } else {
                                    Text("Otwórz pełne szczegóły oceny")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }.padding(.vertical, 3)
                        }
                    }
                }
            }
            if module == .messages {
                Section("Wiadomości bezpośrednio z Synergii (JSON)") {
                    Text("Sesja Wiadomości działa w osobnej domenie. Jeśli odczyt zgłosi brak sesji, otwórz najpierw oficjalną skrzynkę.")
                        .font(.caption).foregroundStyle(.secondary)
                    NavigationLink(destination: ConnectionView(initialModule: .messages, openMessages: true)) {
                        Label("Otwórz oficjalne Wiadomości", systemImage: "lock.shield")
                    }
                    Button {
                        portal.refreshDirectUnreadCounts()
                    } label: {
                        Label("Pobierz liczniki nieprzeczytanych", systemImage: "number")
                    }
                    .disabled(portal.directUnreadBusy || portal.directMessagesBusy != nil ||
                        portal.directMessageDetailBusy || portal.directAttachmentBusy != nil)
                    if portal.directUnreadBusy { ProgressView("Sprawdzanie liczników…") }
                    if let unread = portal.directUnreadCounts {
                        ForEach(Array(DirectUnreadCounts.fields.enumerated()), id: \.offset) { item in
                            if let count = unread.values[item.element.key] {
                                Text("\(item.element.label): \(count)").font(.caption)
                            }
                        }
                    }
                    if !portal.directUnreadStatus.isEmpty {
                        Text(portal.directUnreadStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    ForEach(DirectMailbox.allCases) { mailbox in
                        Button {
                            portal.refreshDirectMessages(mailbox)
                        } label: {
                            Label("Pobierz: \(mailbox.label)", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .disabled(portal.directMessagesBusy != nil || portal.directMessageDetailBusy || portal.directUnreadBusy || portal.directAttachmentBusy != nil)
                        if portal.directMessagesBusy == mailbox { ProgressView("Pobieranie stron…") }
                        if let snapshot = portal.directMailboxes[mailbox] {
                            DirectReadStatusPanel(state: .evaluate(
                                verified: portal.store.verifiedAccountId != nil,
                                loading: portal.directMessagesBusy == mailbox,
                                failed: portal.failedDirectMailboxes.contains(mailbox),
                                count: snapshot.messages.count, capturedAt: snapshot.fetchedAt,
                                complete: snapshot.complete,
                                accountMatches: snapshot.accountId == portal.store.verifiedAccountId))
                        } else if portal.failedDirectMailboxes.contains(mailbox) {
                            DirectReadStatusPanel(state: .evaluate(
                                verified: portal.store.verifiedAccountId != nil,
                                loading: portal.directMessagesBusy == mailbox,
                                failed: true, count: nil, capturedAt: nil, complete: false))
                        }
                        Text(portal.directMessagesStatus[mailbox] ?? "Nie odczytano skrzynki")
                            .font(.caption).foregroundStyle(.secondary)
                        if let snapshot = portal.directMailboxes[mailbox] {
                            Text("\(mailbox.label): \(snapshot.messages.count) wpisów; odczyt \(snapshot.fetchedAt.formatted(date: .numeric, time: .shortened))")
                                .font(.caption).foregroundStyle(.secondary)
                            ForEach(snapshot.messages) { message in
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(message.subject).font(.headline)
                                    Text("\(mailbox.isOutgoing ? "Do" : "Od"): \(message.correspondent)")
                                        .font(.subheadline)
                                    if let date = message.sentAt { Text(date).font(.caption) }
                                    if message.hasAttachments {
                                        Label("Wiadomość ma załączniki", systemImage: "paperclip")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    if !message.preview.isEmpty {
                                        Text(message.preview).font(.subheadline).lineLimit(3)
                                    }
                                    Button(mailbox.mayMarkRead ? "Otwórz treść (może oznaczyć jako przeczytaną)" : "Otwórz treść") {
                                        portal.refreshDirectMessageDetail(message)
                                    }
                                    .font(.caption)
                                    .disabled(portal.directMessageDetailBusy || portal.directMessagesBusy != nil || portal.directUnreadBusy || portal.directAttachmentBusy != nil)
                                    if let detail = portal.directMessageDetail,
                                       detail.id == message.id, detail.mailbox == mailbox {
                                        Text(detail.body).font(.body).textSelection(.enabled)
                                        if detail.replyAllowed {
                                            Button {
                                                portal.beginDirectReply(to: detail)
                                            } label: {
                                                Label("Odpowiedz — przejdź do formularza poniżej", systemImage: "arrowshape.turn.up.left")
                                            }
                                            .disabled(portal.directSendBusy || portal.directRecipientBusy)
                                        }
                                        if !detail.attachments.isEmpty && !mailbox.supportsDirectAttachments {
                                            Text("Archiwalne załączniki pobierz przez oficjalną stronę Synergii — dostęp przez API może być zablokowany.")
                                                .font(.caption).foregroundStyle(.secondary)
                                        }
                                        if !detail.attachments.isEmpty && mailbox.supportsDirectAttachments {
                                            Text("Załączniki (\(detail.attachments.count)):")
                                                .font(.caption.bold())
                                            ForEach(detail.attachments) { file in
                                                VStack(alignment: .leading, spacing: 4) {
                                                    Text("\(file.name)" + (file.sizeBytes.map { " (\($0) B)" } ?? ""))
                                                        .font(.caption).textSelection(.enabled)
                                                    let attachmentKey = portal.directAttachmentKey(file, message: detail)
                                                    if let localURL = portal.directAttachmentURLs[attachmentKey] {
                                                        ShareLink(item: localURL) {
                                                            Label("Udostępnij / Zapisz plik", systemImage: "square.and.arrow.up")
                                                        }
                                                        .font(.caption)
                                                    } else {
                                                        Button {
                                                            portal.downloadDirectMessageAttachment(file, in: detail)
                                                        } label: {
                                                            Label("Pobierz załącznik", systemImage: "arrow.down.doc")
                                                        }
                                                        .font(.caption)
                                                        .disabled(portal.directAttachmentBusy != nil ||
                                                            portal.directMessagesBusy != nil || portal.directMessageDetailBusy)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }.padding(.vertical, 6)
                            }
                        }
                    }
                    if portal.directMessageDetailBusy { ProgressView("Odczyt treści…") }
                    if portal.directAttachmentBusy != nil { ProgressView("Pobieranie załącznika…") }
                    if !portal.directAttachmentStatus.isEmpty {
                        Text(portal.directAttachmentStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    if !portal.directMessageDetailStatus.isEmpty {
                        Text(portal.directMessageDetailStatus)
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text("Załączniki są pobierane tylko na żądanie, a wiadomości nie są zapisywane w lokalnym cache.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Section("Napisz wiadomość / odpowiedz") {
                    Text("Wysyłanie korzysta z oficjalnej domeny Wiadomości. Nie jest uruchamiane automatycznie. W przypadku niepewnego wyniku sprawdź folder Wysłane, zanim napiszesz ponownie.")
                        .font(.caption).foregroundStyle(.secondary)
                    Button {
                        portal.beginDirectNewMessage()
                    } label: {
                        Label("Nowa wiadomość — wyczyść formularz", systemImage: "square.and.pencil")
                    }
                    .disabled(portal.directSendBusy || portal.directRecipientBusy)
                    if let reply = portal.directReplyContext {
                        Text("Odpowiedź do: \(reply.recipientName)")
                            .font(.subheadline.bold())
                        Text("Wątek: \(reply.subject)")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Button {
                            portal.refreshDirectRecipientGroups()
                        } label: {
                            Label("Pobierz grupy odbiorców", systemImage: "person.2")
                        }
                        .disabled(portal.directRecipientBusy || portal.directSendBusy || portal.directMessagesBusy != nil)
                        if let groups = portal.directRecipientGroups {
                            Menu {
                                ForEach(groups.groups) { group in
                                    Button(group.name) { portal.refreshDirectRecipients(group) }
                                }
                            } label: {
                                Label(portal.directSelectedGroup?.name ?? "Wybierz grupę", systemImage: "person.3")
                            }
                            .disabled(portal.directRecipientBusy || portal.directSendBusy)
                        }
                        if let recipients = portal.directRecipientList {
                            TextField("Znajdź odbiorcę na liście", text: $directRecipientSearch)
                                .textInputAutocapitalization(.words)
                                .autocorrectionDisabled()
                            let filtered = recipients.recipients.filter {
                                directRecipientSearch.isEmpty || $0.name.localizedCaseInsensitiveContains(directRecipientSearch)
                            }
                            Menu {
                                ForEach(filtered) { person in
                                    Button(person.name + (person.available == false ? " (niedostępny)" : "")) {
                                        portal.selectDirectRecipient(person)
                                    }
                                    .disabled(person.available == false)
                                }
                            } label: {
                                Label(portal.directSelectedRecipient?.name ?? "Wybierz odbiorcę (\(filtered.count))", systemImage: "person.crop.circle")
                            }
                            .disabled(filtered.isEmpty || portal.directRecipientBusy || portal.directSendBusy)
                        }
                    }
                    if portal.directRecipientBusy { ProgressView("Pobieranie odbiorców…") }
                    if !portal.directRecipientStatus.isEmpty {
                        Text(portal.directRecipientStatus).font(.caption).foregroundStyle(.secondary)
                    }
                    TextField("Temat", text: $portal.directDraftSubject)
                        .textInputAutocapitalization(.sentences)
                        .disabled(portal.directSendBusy)
                    TextEditor(text: $portal.directDraftBody)
                        .frame(minHeight: 120)
                        .accessibilityLabel("Treść wiadomości")
                        .disabled(portal.directSendBusy)
                    Text("Limit: 200 znaków tematu, 10 000 znaków treści. Brak załączników wychodzących.")
                        .font(.caption2).foregroundStyle(.secondary)
                    Button {
                        if portal.prepareDirectSend() { showDirectSendConfirmation = true }
                    } label: {
                        Label("Sprawdź i potwierdź wysyłkę", systemImage: "paperplane")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(portal.directSendBusy || portal.directRecipientBusy ||
                        portal.directMessagesBusy != nil || portal.directMessageDetailBusy ||
                        portal.directAttachmentBusy != nil || portal.directUnreadBusy)
                    if portal.directSendBusy { ProgressView("Wysyłanie — nie zamykaj sesji…") }
                    if !portal.directSendStatus.isEmpty {
                        Text(portal.directSendStatus).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            if [.homework, .calendar, .announcements, .documents].contains(module) {
                Section("Dane bezpośrednio z Synergii (JSON)") {
                    Button {
                        portal.refreshDirectFeed(module)
                    } label: {
                        Label("Pobierz dane z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(portal.directFeedBusy != nil || portal.directFeedBatchBusy)
                    Button {
                        portal.refreshAllDirectFeeds()
                    } label: {
                        Label("Odśwież zadania, terminarz, ogłoszenia i dokumenty", systemImage: "arrow.clockwise.circle")
                    }.disabled(portal.directFeedBusy != nil || portal.directFeedBatchBusy)
                    if portal.directFeedBusy == module || portal.directFeedBatchBusy {
                        ProgressView("Trwa odczyt JSON…")
                    }
                    Text(portal.directFeedStatus[module] ?? "Nie pobierano danych JSON")
                        .font(.caption).foregroundStyle(.secondary)
                    if let change = portal.directFeedDeltas[module] {
                        Text(change.summary).font(.caption).foregroundStyle(.secondary)
                    }
                    if let feed = portal.directFeeds[module] {
                        Text("Odczyt: \(feed.fetchedAt.formatted(date: .numeric, time: .shortened))")
                            .font(.caption)
                        if module == .announcements {
                            DirectSchoolNoticesView(feed: feed)
                        } else if module == .calendar {
                            DirectSchoolAgendaView(feed: feed)
                        } else if module == .homework {
                            DirectHomeworkAssignmentsView(
                                feed: feed,
                                fileURLs: portal.directHomeworkFileURLs,
                                downloadBusy: portal.directHomeworkFileBusy != nil ||
                                    portal.directFeedBusy != nil || portal.directFeedBatchBusy,
                                downloadStatus: portal.directHomeworkFileStatus,
                                onDownload: { file, item in
                                    portal.downloadDirectHomeworkFile(file, from: item)
                                }
                            )
                        } else if module == .documents {
                            DirectSchoolDocumentsView(
                                feed: feed,
                                fileURLs: portal.directSchoolFileURLs,
                                downloadBusy: portal.directSchoolFileBusy != nil ||
                                    portal.directFeedBusy != nil || portal.directFeedBatchBusy,
                                downloadStatus: portal.directSchoolFileStatus,
                                onDownload: { file, item in
                                    portal.downloadDirectSchoolFile(file, from: item)
                                }
                            )
                        }
                        Text("Odczyt tylko do odczytu. Nie potwierdza wszystkich stron ani pełnej liczby danych w szkole.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
            if module == .timetable {
                Section("Plan lekcji — bezpośredni JSON") {
                    DatePicker("Tydzień zawierający", selection: $portal.timetableChosenDate,
                               displayedComponents: .date)
                        .onChange(of: portal.timetableChosenDate) { _, _ in
                            portal.selectCachedTimetableWeek()
                        }
                    Text("Zapisane tygodnie można przeglądać po potwierdzeniu konta. Zapis offline zawsze ma oznaczenie NIEAKTUALNY.")
                        .font(.caption2).foregroundStyle(.secondary)
                    Button {
                        portal.refreshDirectTimetable()
                    } label: {
                        Label("Pobierz wybrany tydzień", systemImage: "calendar.badge.clock")
                    }.disabled(portal.directTimetableBusy)
                    if portal.directTimetableBusy { ProgressView("Trwa pobieranie planu…") }
                    Text(portal.directTimetableStatus).font(.caption).foregroundStyle(.secondary)
                    if let plan = portal.directTimetable,
                       plan.monday != DirectTimetableParser.monday(containing: portal.timetableChosenDate) {
                        Text("Wybrano inny tydzień. Pobierz go, aby zobaczyć właściwy plan; poprzedniego nie pokazano jako aktualny.")
                            .font(.caption).foregroundStyle(.orange)
                    }
                    if let plan = portal.directTimetable,
                       plan.monday == DirectTimetableParser.monday(containing: portal.timetableChosenDate) {
                        Text("Tydzień od \(plan.monday); dni w odpowiedzi: \(plan.reportedDates.count)")
                            .font(.caption.bold())
                        if plan.splitPeriods > 0 {
                            Text("Godziny z kilkoma grupami: \(plan.splitPeriods). To wszystkie grupy, NIE wybrany plan konkretnego ucznia.")
                                .font(.caption).foregroundStyle(.orange)
                        }
                        ForEach(plan.entries) { item in
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text(item.date).font(.headline)
                                    if let lessonNo = item.lessonNumber {
                                        Text("Lekcja \(lessonNo)").font(.subheadline)
                                    }
                                    Spacer()
                                    if item.isCanceled == true { Text("Odwołana").foregroundStyle(.red) }
                                    else if item.isSubstitution == true { Text("Zastępstwo").foregroundStyle(.orange) }
                                }
                                if item.timeFrom != nil || item.timeTo != nil {
                                    Text("Godziny: \(item.timeFrom ?? "?")–\(item.timeTo ?? "?")")
                                        .font(.caption)
                                }
                                Text(item.subjectId.flatMap { portal.directTimetableSubjects[$0] } ?? "Przedmiot nierozpoznany")
                                    .font(.subheadline)
                                if item.parallelCount > 1 {
                                    Text("Równoległa grupa \(item.parallelIndex + 1) z \(item.parallelCount) — przydział nieznany")
                                        .font(.caption).foregroundStyle(.orange)
                                }
                            }.padding(.vertical, 3)
                        }
                        Divider()
                        Text("Odwołania i zastępstwa").font(.headline)
                        Text(portal.directPlanChangesStatus).font(.caption).foregroundStyle(.secondary)
                        if let history = portal.directPlanChanges,
                           history.accountId == plan.accountId {
                            let changes = history.forWeek(plan.monday)
                            if changes.isEmpty {
                                Text("Brak wpisów zmian w odpowiedzi dla wybranego tygodnia.")
                                    .font(.caption)
                            }
                            ForEach(changes) { change in
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack {
                                        Text("Zmiana z \(change.originalDate)").font(.subheadline.bold())
                                        Spacer()
                                        Text(change.kind == .cancelled ? "Odwołano" :
                                             change.kind == .shifted ? "Przesunięto" :
                                             change.kind == .substitution ? "Zastępstwo" : "Typ nieustalony")
                                            .font(.caption)
                                    }
                                    let oldName = change.originalSubjectId.flatMap { portal.directTimetableSubjects[$0] }
                                    let newName = change.currentSubjectId.flatMap { portal.directTimetableSubjects[$0] }
                                    Text("Pierwotnie: \(oldName ?? "przedmiot nieustalony")" +
                                         (change.originalLessonNumber.map { ", lekcja \($0)" } ?? ""))
                                        .font(.caption)
                                    if let currentDate = change.currentDate {
                                        Text("Nowy termin: \(currentDate)" +
                                             (change.currentLessonNumber.map { ", lekcja \($0)" } ?? ""))
                                            .font(.caption)
                                    }
                                    if let newName {
                                        Text("Nowy przedmiot: \(newName)").font(.caption)
                                    }
                                    if let teacher = change.originalTeacherId.flatMap({ portal.directTimetableTeachers[$0] }),
                                       !teacher.isEmpty {
                                        Text("Dotychczasowy nauczyciel: \(teacher)").font(.caption)
                                    }
                                    if let teacher = change.currentTeacherId.flatMap({ portal.directTimetableTeachers[$0] }),
                                       !teacher.isEmpty {
                                        Text("Nauczyciel zastępujący: \(teacher)").font(.caption)
                                    }
                                    if let room = change.currentClassroom {
                                        Text("Sala: \(room)").font(.caption)
                                    }
                                }.padding(.vertical, 4)
                            }
                        }
                        Text("Plan obejmuje tylko wybrany tydzień. Brak nazw i danych grup nie jest uzupełniany zgadywaniem.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
            if module == .attendance {
                Section("Frekwencja bezpośrednio z Synergii (JSON)") {
                    Button {
                        portal.refreshDirectAttendance()
                    } label: {
                        Label("Pobierz frekwencję z aktywnej sesji", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(portal.directAttendanceBusy)
                    if portal.directAttendanceBusy { ProgressView("Trwa odczyt JSON…") }
                    Text(portal.directAttendanceStatus)
                        .font(.caption).foregroundStyle(.secondary)
                    if let date = portal.directAttendanceStore.capturedAt {
                        Text("Zapis: \(date.formatted(date: .numeric, time: .shortened)); wpisów: \(portal.directAttendanceStore.records.count)")
                            .font(.caption)
                    }
                    Text("Brak wpisu dla lekcji nie oznacza obecności. Status pochodzi z typów Synergii, a nie z numeru wpisu.")
                        .font(.caption2).foregroundStyle(.orange)
                    if !portal.directAttendanceStore.records.isEmpty {
                        DirectAttendanceAnalyticsView(records: portal.directAttendanceStore.records,
                            subjects: portal.directAttendanceStore.subjects,
                            accountId: portal.directAttendanceStore.verifiedAccountId)
                    } else if portal.directAttendanceStore.capturedAt != nil {
                        Text("W poprzednim zapisie nie ma wpisów frekwencji. Nie oznacza to braku lekcji ani potwierdzonej obecności.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            Section {
                if let snapshot = portal.store.snapshot(for: module) {
                    Label("Zapis lokalny: \(snapshot.capturedAt.formatted(date: .abbreviated, time: .shortened))", systemImage: "clock")
                        .font(.caption)
                    Text("Odczyt diagnostyczny — zawartość nie została zweryfikowana względem pełnej listy w Synergii.")
                        .font(.caption).foregroundStyle(.orange)
                } else {
                    Text("Brak dodatkowego zapisu HTML. Dane JSON są pokazywane w sekcjach powyżej.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                NavigationLink(destination: ConnectionView(initialModule: module)) {
                    Label("Otwórz połączenie i odczytaj", systemImage: "arrow.triangle.2.circlepath")
                }
                if let route = portal.routes.route(for: module) {
                    Text("Adres modułu zapamiętany: \(route.approvedAt.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            if let snapshot = portal.store.snapshot(for: module) {
                Section("Spójność ostatniego lokalnego zapisu") {
                    let integrity = BatchIntegrityAudit.inspect([snapshot], module: module)
                    Text("Zapisane wiersze: \(integrity.recordCount); tabele: \(integrity.tableCount)")
                        .font(.caption)
                    Text(integrity.explanation)
                        .font(.caption2).foregroundStyle(.secondary)
                    Text("To kontrola techniczna pojedynczego zapisu, a nie dowód pełnej liczby danych w Synergii.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Section("Audyt rozpoznawania — bez treści danych") {
                    let coverage = ParserCoverageAudit.inspect(snapshot)
                    Text("Rozpoznane tabele: \(coverage.recognizedTables) z \(coverage.tableCount)")
                        .font(.caption)
                    Text("Wiersze do analizy: \(coverage.rowsConsidered); odrzucone: \(coverage.rowsRejected)")
                        .font(.caption)
                    DisclosureGroup("Pokaż anonimowy raport") {
                        Text(coverage.formatted())
                            .font(.system(.caption2, design: .monospaced))
                            .textSelection(.enabled)
                    }
                    Text("Raport nie zawiera nazwisk, ocen, wiadomości, adresów ani HTML. Nie potwierdza kompletności.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                if module == .grades {
                    let preview = GradeParser.preview(snapshot: snapshot)
                    let identity = GradeIdentityAudit.review(snapshot: snapshot)
                    Section("Wstępnie rozpoznane oceny (\(preview.grades.count))") {
                        Text("Kandydaci powiązania z wpisem: \(identity.linkedCandidates), niejednoznaczne: \(identity.ambiguousLinks), bez linku: \(identity.withoutLink). Nie są to potwierdzone identyfikatory.")
                            .font(.caption2).foregroundStyle(.secondary)
                        Text("Identyfikator oparty na numerze wiersza NIE jest trwały. Zmiana kolejności ocen nie oznacza dodania nowej oceny.")
                            .font(.caption2).foregroundStyle(.secondary)
                        Text("To nie jest potwierdzona pełna lista ocen. Rozpoznawane są wyłącznie tabele z jednoznacznymi nagłówkami.")
                            .font(.caption).foregroundStyle(.orange)
                        ForEach(preview.grades) { candidate in
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(candidate.subject).font(.headline)
                                    Spacer()
                                    Text(candidate.value).font(.title3.bold())
                                }
                                if let date = candidate.dateText { Text("Data: \(date)").font(.caption) }
                                if let weight = candidate.weightText { Text("Waga: \(weight)").font(.caption) }
                                if let category = candidate.category { Text("Kategoria: \(category)").font(.caption) }
                                if let semester = candidate.semester { Text("Semestr: \(semester)").font(.caption) }
                                if let comment = candidate.comment { Text("Komentarz: \(comment)").font(.caption).textSelection(.enabled) }
                            }.padding(.vertical, 3)
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .timetable {
                    let preview = TimetableParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznany plan (\(preview.entries.count))") {
                        ForEach(preview.entries) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(entry.day) · \(entry.subject)").font(.headline)
                                Text("Lekcja: \(entry.lesson)").font(.caption)
                                if let time = entry.startTime { Text("Od: \(time)").font(.caption) }
                                if let time = entry.endTime { Text("Do: \(time)").font(.caption) }
                                if let room = entry.room { Text("Sala: \(room)").font(.caption) }
                                if let teacher = entry.teacher { Text("Nauczyciel: \(teacher)").font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .attendance {
                    let preview = AttendanceParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznana frekwencja (\(preview.entries.count))") {
                        ForEach(preview.entries) { entry in
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(entry.dateText) · \(entry.subject)").font(.headline)
                                Text("Status: \(entry.status)").font(.subheadline)
                                if let lesson = entry.lesson { Text("Lekcja: \(lesson)").font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .messages {
                    let preview = MessageParser.preview(snapshot: snapshot)
                    Section("Wstępnie rozpoznane wiadomości (\(preview.messages.count))") {
                        ForEach(preview.messages) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.subject).font(.headline)
                                Text(item.sender).font(.subheadline)
                                if let date = item.dateText { Text(date).font(.caption).foregroundStyle(.secondary) }
                                if let recipient = item.recipient { Text("Do: \(recipient)").font(.caption) }
                                if let preview = item.previewText { Text(preview).font(.subheadline).textSelection(.enabled) }
                            }.padding(.vertical, 3)
                        }
                        ForEach(preview.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .messages {
                    let details = MessageDetails.preview(snapshot: snapshot)
                    Section("Skrzynki — odczyt lokalny") {
                        ForEach(LocalMailbox.allCases) { mailbox in
                            let entries = details.items.filter { $0.mailbox == mailbox }
                            if !entries.isEmpty {
                                DisclosureGroup("\(mailbox.rawValue) (\(entries.count))") {
                                    ForEach(entries) { item in
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(item.subject).font(.headline)
                                            Text("Od: \(item.sender)").font(.caption)
                                            if let recipient = item.recipient { Text("Do: \(recipient)").font(.caption) }
                                            if let date = item.dateText { Text(date).font(.caption) }
                                            if let link = item.detailLink {
                                                Button("Otwórz szczegóły w oficjalnej Synergii") {
                                                    portal.openTrustedLink(link)
                                                }.font(.caption)
                                            }
                                            if !item.attachmentCandidates.isEmpty {
                                                Text("Możliwe załączniki (\(item.attachmentCandidates.count)) — niezweryfikowane")
                                                    .font(.caption2).foregroundStyle(.orange)
                                                ForEach(item.attachmentCandidates) { attachment in
                                                    Button("Otwórz: \(attachment.title)") {
                                                        portal.openTrustedLink(attachment)
                                                    }.font(.caption)
                                                }
                                            }
                                            if let body = item.body {
                                                Text(body).font(.subheadline).textSelection(.enabled)
                                            } else {
                                                Text("Pełna treść niedostępna w lokalnym odczycie")
                                                    .font(.caption2).foregroundStyle(.secondary)
                                            }
                                        }.padding(.vertical, 4)
                                    }
                                }
                            }
                        }
                        ForEach(details.warnings, id: \.self) { warning in
                            Text(warning).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if module == .calendar {
                    let preview = AdditionalParsers.calendar(snapshot)
                    Section("Rozpoznane wydarzenia (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.title).font(.headline)
                                Text(item.dateText).font(.caption)
                                if let subject = item.subject { Text(subject).font(.caption) }
                                if let details = item.details { Text(details).textSelection(.enabled) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if module == .homework {
                    let preview = AdditionalParsers.homework(snapshot)
                    Section("Rozpoznane zadania (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.subject).font(.headline)
                                Text(item.description).textSelection(.enabled)
                                if let due = item.dueDate { Text("Termin: \(due)").font(.caption) }
                                if let teacher = item.teacher { Text(teacher).font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if module == .announcements {
                    let preview = AdditionalParsers.announcements(snapshot)
                    Section("Rozpoznane ogłoszenia (\(preview.items.count))") {
                        ForEach(preview.items) { item in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.title).font(.headline)
                                if let body = item.body { Text(body).textSelection(.enabled) }
                                if let date = item.dateText { Text(date).font(.caption) }
                                if let author = item.author { Text(author).font(.caption) }
                            }
                        }
                        ForEach(preview.warnings, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                if !snapshot.records.isEmpty {
                    Section("Wiersze z widocznego dokumentu (\(snapshot.records.count))") {
                        ForEach(snapshot.records) { record in
                            VStack(alignment: .leading, spacing: 5) {
                                ForEach(Array(record.fields.enumerated()), id: \.offset) { index, value in
                                    Text(value).font(index == 0 ? .headline : .subheadline)
                                        .foregroundStyle(index == 0 ? .primary : .secondary)
                                        .textSelection(.enabled)
                                }
                            }.padding(.vertical, 5)
                        }
                    }
                }
                if !snapshot.excerpt.isEmpty {
                    Section("Fragment tekstu strony") {
                        Text(snapshot.excerpt).font(.subheadline).textSelection(.enabled)
                    }
                }
                if !snapshot.links.isEmpty {
                    Section("Odnośniki na stronie") {
                        ForEach(snapshot.links) { link in
                            Button {
                                portal.openTrustedLink(link)
                            } label: {
                                HStack {
                                    Text(link.title).lineLimit(2)
                                    Spacer()
                                    Image(systemName: "arrow.up.right")
                                }
                            }
                        }
                        Text("Odnośniki można otworzyć w zakładce połączenia. Pobieranie załączników nie jest jeszcze zweryfikowane.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .confirmationDialog("Potwierdź wysłanie wiadomości", isPresented: $showDirectSendConfirmation,
                            titleVisibility: .visible) {
            Button("Wyślij wiadomość TERAZ") { portal.confirmDirectSend() }
            Button("Anuluj", role: .cancel) { portal.cancelPreparedDirectSend() }
        } message: {
            Text(portal.directSendPreview ?? "Wysyłka nie jest już przygotowana.")
        }
        .navigationTitle(module.title)
    }
}

struct ConnectionView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    var initialModule: SchoolModule = .grades
    var openMessages: Bool = false
    @State private var selection: SchoolModule = .grades
    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Image(systemName: "checkmark.shield.fill").foregroundStyle(.green)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Logowanie tylko na oficjalnej stronie Synergii")
                    Text("Zapisana sesja jest sprawdzana automatycznie. Jeśli wygasła, wymagane jest ponowne logowanie.")
                        .font(.caption2).foregroundStyle(.secondary)
                }.font(.footnote)
                Spacer()
            }.padding(.horizontal)
            PortalWebView().environmentObject(portal)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            Picker("Moduł", selection: $selection) {
                ForEach(SchoolModule.allCases) { module in
                    Text(module.title).tag(module)
                }
            }.padding(.horizontal)
            HStack(spacing: 12) {
                Button { portal.goBack() } label: { Label("Wstecz", systemImage: "chevron.left") }
                    .disabled(!portal.webView.canGoBack)
                Button { portal.refresh() } label: { Label("Odśwież", systemImage: "arrow.clockwise") }
                Spacer()
                Button { portal.capture(selection) } label: { Label("Odczytaj", systemImage: "square.and.arrow.down") }
                    .buttonStyle(.borderedProminent).disabled(portal.isBusy || portal.isSyncing)
            }
            HStack {
                Button { portal.verifyAccount() } label: {
                    Label("Potwierdź konto", systemImage: "person.crop.circle.badge.checkmark")
                }.buttonStyle(.borderedProminent)
                Button { portal.openLoginPage() } label: {
                    Label("Logowanie", systemImage: "person.crop.circle")
                }.buttonStyle(.bordered)
                Text(portal.accountStatus).font(.caption2).foregroundStyle(.secondary)
            }.padding(.horizontal)
            Button { portal.rememberCurrentModule(selection) } label: {
                Label("Odczytaj i zapamiętaj adres modułu", systemImage: "bookmark")
            }.disabled(portal.isBusy || portal.isSyncing)
            if portal.routes.route(for: selection) != nil {
                Button { portal.rememberAdditionalPage(selection) } label: {
                    Label("Zatwierdź następną stronę wyników", systemImage: "plus.rectangle.on.rectangle")
                }.disabled(portal.isBusy || portal.isSyncing)
            }
            HStack(spacing: 12) {
                Text("Zatwierdzonych stron: \(portal.routes.pages(for: selection).count)")
                    .font(.caption2).foregroundStyle(.secondary)
                Spacer()
                if portal.routes.route(for: selection) != nil {
                    Button("Usuń adres", role: .destructive) {
                        do { try portal.routes.remove(selection) }
                        catch { portal.alert = error.localizedDescription }
                    }.font(.caption2)
                }
            }.font(.caption).padding(.horizontal)
            DisclosureGroup("Diagnostyka struktury (bez danych osobowych)") {
                Text(portal.paginationNote).font(.caption2)
                Text(portal.diagnosticSummary)
                    .font(.system(.caption2, design: .monospaced))
                    .textSelection(.enabled)
                Text("Raport pokazuje tylko liczby i układ kolumn. Nie zawiera treści ocen, wiadomości, nazwisk, adresów ani HTML.")
                    .font(.caption2).foregroundStyle(.secondary)
            }.padding(.horizontal)
            Text(portal.status).font(.caption2).foregroundStyle(.secondary)
                .lineLimit(3).padding(.horizontal)
            Text("Zapisz stronę główną modułu, następnie odwiedź i zatwierdź każdą dodatkową stronę. Nie gwarantuje to automatycznego wykrycia wszystkich podstron w Synergii.")
                .font(.caption2).foregroundStyle(.secondary).padding(.horizontal)
        }
        .navigationTitle("Połączenie")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { selection = initialModule; if openMessages { portal.openMessagesInPortal() } else { portal.start() } }
    }
}

struct MoreView: View {
    var body: some View {
        List {
            Section("Dziennik") {
                ForEach([SchoolModule.attendance, .calendar, .homework, .announcements, .documents]) { module in
                    NavigationLink(destination: ModuleView(module: module)) {
                        Label(module.title, systemImage: module.symbol)
                    }
                }
            }
            Section("Konto") {
                NavigationLink(destination: ConnectionView()) { Label("Połączenie z Synergią", systemImage: "network") }
                NavigationLink(destination: DownloadsView()) { Label("Pobrane załączniki", systemImage: "arrow.down.doc") }
                NavigationLink(destination: SettingsView()) { Label("Prywatność i ustawienia", systemImage: "gearshape") }
            }
        }.navigationTitle("Więcej")
    }
}

struct SettingsView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    @State private var askToErase = false

    private func localStatus(for module: SchoolModule) -> String {
        let legacy = portal.store.snapshot(for: module) != nil ? "HTML" : "Brak"
        switch module {
        case .grades: return portal.directGradeStore.capturedAt != nil ? "JSON" : legacy
        case .attendance: return portal.directAttendanceStore.capturedAt != nil ? "JSON" : legacy
        case .homework, .calendar, .announcements, .documents:
            return portal.directOfflineFeedStore.feeds[module] != nil ? "JSON (stare)" : legacy
        case .messages: return portal.store.snapshot(for: module) != nil ? "HTML" : "Bez zapisu JSON"
        case .timetable: return legacy
        }
    }
    var body: some View {
        List {
            Section("Sesja Synergii") {
                Text(portal.accountStatus).font(.footnote)
                Button("Sprawdź teraz konto") { portal.verifyAccount() }
                    .disabled(portal.isBusy || portal.isSyncing || portal.coreSyncBusy)
                NavigationLink(destination: ConnectionView()) {
                    Label("Otwórz logowanie i połączenie", systemImage: "lock.shield")
                }
                Text("Po powrocie z tła dostęp do lokalnych danych wymaga ponownego potwierdzenia. Brak internetu nie oznacza wylogowania z serwera.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Powiadomienia o zmianach") {
                Toggle("Powiadomienia lokalne po ręcznym odświeżeniu", isOn:
                    Binding(get: { portal.localNotificationsEnabled },
                            set: { portal.setLocalNotifications($0) }))
                Text(portal.localNotificationsStatus).font(.caption).foregroundStyle(.secondary)
                Toggle("Oceny", isOn: Binding(
                    get: { portal.localNotificationPreferences.grades },
                    set: { portal.setLocalNotificationCategory(.grades, enabled: $0) }))
                Toggle("Frekwencja", isOn: Binding(
                    get: { portal.localNotificationPreferences.attendance },
                    set: { portal.setLocalNotificationCategory(.attendance, enabled: $0) }))
                Toggle("Wiadomości odebrane", isOn: Binding(
                    get: { portal.localNotificationPreferences.messages },
                    set: { portal.setLocalNotificationCategory(.messages, enabled: $0) }))
                Button("Sprawdź uprawnienia systemu") { portal.refreshLocalNotificationAuthorization() }
                Text("Wybór kategorii zapisuje się na tym urządzeniu. Wylogowanie z usunięciem danych " +
                     "kasuje również zgodę aplikacji; system może wymagać jej ponownego włączenia w Ustawieniach iOS.")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Tylko nowe lub zmienione wpisy po porównaniu dwóch odczytów tego samego konta. " +
                     "Bez nazwisk, treści wiadomości i wartości ocen. " +
                     "Brak sprawdzania w tle i automatycznych powiadomień przy zamkniętej aplikacji.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Dane i prywatność") {
                Label("Brak własnego serwera i konta pośredniczącego", systemImage: "checkmark.shield")
                Label("Sesja zapisywana w magazynie WebKit", systemImage: "iphone")
                Label("Oceny, frekwencja i cztery moduły JSON: chroniony zapis lokalny", systemImage: "lock.doc")
                Label("Wiadomości i szkice: tylko pamięć aplikacji", systemImage: "envelope.badge.shield.half.filled")
                Label("Brak automatycznego pobierania w tle", systemImage: "pause.circle")
            }
            Section("Dane na urządzeniu") {
                ForEach(SchoolModule.allCases) { module in
                    HStack {
                        Text(module.title)
                        Spacer()
                        Text(localStatus(for: module))
                        .foregroundStyle(.secondary)
                    }
                }
                HStack { Text("Zachowane moduły JSON"); Spacer(); Text("\(portal.directOfflineFeedStore.feeds.count)").foregroundStyle(.secondary) }
                Text("Zapis lokalny jest udostępniany dopiero po potwierdzeniu konta przez /Me i zawsze jako nieaktualny do ponownego pobrania.")
                    .font(.caption).foregroundStyle(.secondary)
                HStack { Text("Pobrane pliki"); Spacer(); Text("\(portal.downloads.items.count)").foregroundStyle(.secondary) }
                HStack { Text("Zapamiętane moduły"); Spacer(); Text("\(portal.routes.routes.count)").foregroundStyle(.secondary) }
                Button("Usuń lokalne dane, załączniki oraz cookies", role: .destructive) { askToErase = true }
                    .disabled(portal.isBusy)
            }
            Section("Ograniczenia") {
                Text("Odczyty i wysyłanie wiadomości pozostają niezweryfikowane na prawdziwym koncie. Wysyłanie wymaga osobnego potwierdzenia, a wynik niepewny nie jest automatycznie ponawiany. Brak obejścia logowania i synchronizacji w tle.")
                    .font(.footnote)
            }
        }
        .navigationTitle("Ustawienia")
        .confirmationDialog("Usunąć zapisane moduły, załączniki i lokalną sesję WebKit?", isPresented: $askToErase) {
            Button("Usuń z urządzenia", role: .destructive) { portal.signOutAndClear() }
        }
    }
}


struct DownloadsView: View {
    @EnvironmentObject private var portal: SynergiaPortal
    var body: some View {
        List {
            Section {
                Text("Pliki są pobierane tylko po kliknięciu łącza na oficjalnej stronie i zapisywane lokalnie. Nie wszystkie typy załączników zostały przetestowane.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Zapisane pliki") {
                if portal.downloads.items.isEmpty {
                    ContentUnavailableView("Brak załączników", systemImage: "doc", description: Text("Otwórz wiadomość w połączeniu z Synergią i wybierz załącznik."))
                } else {
                    ForEach(portal.downloads.items) { item in
                        HStack(spacing: 12) {
                            Image(systemName: "doc.fill").foregroundStyle(.indigo)
                            VStack(alignment: .leading) {
                                Text(item.displayName).lineLimit(2)
                                Text("\(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file)) · \(item.savedAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if let url = portal.downloads.file(for: item) {
                                ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                            }
                        }
                    }
                    .onDelete { offsets in
                        let current = portal.downloads.items
                        for index in offsets {
                            do { try portal.downloads.remove(current[index]) }
                            catch { portal.alert = "Nie udało się usunąć pliku: \(error.localizedDescription)" }
                        }
                    }
                }
            }
        }
        .navigationTitle("Załączniki")
    }
}
