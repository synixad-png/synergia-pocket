import Foundation

/// User-approved, site-local destinations. These are discovered from actual pages,
/// not hard-coded guesses about private endpoints.
struct ModuleRoute: Codable, Identifiable {
    var module: SchoolModule
    var url: String
    var approvedAt: Date
    var id: String { module.rawValue + "|" + url }
}

@MainActor
final class ModuleRouteStore: ObservableObject {
    @Published private(set) var routes: [SchoolModule: ModuleRoute] = [:]
    @Published private(set) var extraRoutes: [SchoolModule: [ModuleRoute]] = [:]
    private let root: URL
    private(set) var verifiedAccountId: String?
    init(root: URL? = nil) {
        self.root = root ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        // Legacy unscoped routes must never be loaded, even after login.
    }
    private func accountFile(_ id: String) -> URL {
        AccountPartition.directory(for: id, under: root.appendingPathComponent("module-routes-accounts", isDirectory: true))
            .appendingPathComponent("routes.json")
    }
    func lock() {
        verifiedAccountId = nil
        routes.removeAll()
        extraRoutes.removeAll()
    }
    func unlock(accountId: String) {
        lock()
        guard !accountId.isEmpty else { return }
        verifiedAccountId = accountId
        if let data = try? Data(contentsOf: accountFile(accountId)),
           let decoded = try? JSONDecoder().decode([ModuleRoute].self, from: data) {
            for route in decoded.prefix(SchoolModule.allCases.count * 20) {
                if let candidate = URL(string: route.url), PortalPolicy.isAllowed(candidate),
                   candidate.user == nil, candidate.password == nil {
                    if routes[route.module] == nil { routes[route.module] = route }
                    else if routes[route.module]?.url != route.url {
                        extraRoutes[route.module, default: []].append(route)
                    }
                }
            }
        }
    }
    func route(for module: SchoolModule) -> ModuleRoute? { verifiedAccountId == nil ? nil : routes[module] }
    func pages(for module: SchoolModule) -> [ModuleRoute] {
        guard verifiedAccountId != nil, let first = routes[module] else { return [] }
        return [first] + (extraRoutes[module] ?? [])
    }
    func appendPage(module: SchoolModule, pageURL: URL) throws {
        guard verifiedAccountId != nil else { throw RouteError.accountNotVerified }
        let candidate = try cleaned(pageURL)
        guard routes[module] != nil else { throw RouteError.primaryMissing }
        guard pages(for: module).count < 20 else { throw RouteError.tooManyPages }
        if pages(for: module).contains(where: { $0.url == candidate.absoluteString }) { return }
        let previous = extraRoutes[module]
        extraRoutes[module, default: []].append(ModuleRoute(module: module,
            url: candidate.absoluteString, approvedAt: Date()))
        do { try persist() }
        catch { extraRoutes[module] = previous; throw error }
    }
    private func cleaned(_ input: URL) throws -> URL {
        guard PortalPolicy.isAllowed(input), input.user == nil, input.password == nil else {
            throw RouteError.invalidURL
        }
        var parts = URLComponents(url: input, resolvingAgainstBaseURL: false)
        parts?.fragment = nil
        guard let cleaned = parts?.url else { throw RouteError.invalidURL }
        return cleaned
    }
    func remember(module: SchoolModule, pageURL: URL) throws {
        guard verifiedAccountId != nil else { throw RouteError.accountNotVerified }
        let clean = try cleaned(pageURL)
        let previous = routes[module]
        let previousExtras = extraRoutes[module]
        routes[module] = ModuleRoute(module: module, url: clean.absoluteString, approvedAt: Date())
        extraRoutes[module] = nil
        do { try persist() }
        catch { routes[module] = previous; extraRoutes[module] = previousExtras; throw error }
    }
    func remove(_ module: SchoolModule) throws {
        guard verifiedAccountId != nil else { throw RouteError.accountNotVerified }
        let previous = routes[module]
        let previousExtras = extraRoutes[module]
        routes[module] = nil
        extraRoutes[module] = nil
        do { try persist() }
        catch { routes[module] = previous; extraRoutes[module] = previousExtras; throw error }
    }
    func erase() throws {
        lock()
        let scoped = root.appendingPathComponent("module-routes-accounts", isDirectory: true)
        if FileManager.default.fileExists(atPath: scoped.path) { try FileManager.default.removeItem(at: scoped) }
        let legacy = root.appendingPathComponent("synergia-module-routes.json")
        if FileManager.default.fileExists(atPath: legacy.path) { try FileManager.default.removeItem(at: legacy) }
    }
    private func persist() throws {
        guard let account = verifiedAccountId else { throw RouteError.accountNotVerified }
        let url = accountFile(account)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(SchoolModule.allCases.flatMap { module -> [ModuleRoute] in
            guard verifiedAccountId != nil, let first = routes[module] else { return [] }
            return [first] + (extraRoutes[module] ?? [])
        }).write(to: url, options: [.atomic, .completeFileProtection])
    }
    enum RouteError: LocalizedError { case invalidURL, primaryMissing, tooManyPages, accountNotVerified
        var errorDescription: String? {
            switch self {
            case .accountNotVerified: return "Najpierw potwierdź konto Synergii."
            case .invalidURL: return "Strona nie należy do dozwolonej domeny Synergii."
            case .primaryMissing: return "Najpierw zapamiętaj główny adres modułu."
            case .tooManyPages: return "Limit 20 zatwierdzonych stron na moduł."
            }
        }
    }
}
