import XCTest
@testable import SynergiaDirect

final class AccountPartitionTests: XCTestCase {
    func testDifferentAccountsHaveDifferentPathsWithoutRawIds() {
        let root = URL(fileURLWithPath: "/tmp/example")
        let first = AccountPartition.directory(for: "pupil-A", under: root)
        let second = AccountPartition.directory(for: "pupil-B", under: root)
        XCTAssertNotEqual(first, second)
        XCTAssertFalse(first.path.contains("pupil-A"))
    }
    @MainActor func testOldUnscopedHTMLNeverLoadsWithoutVerifiedIdentity() {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: temp) }
        let store = LocalStore(directory: temp)
        XCTAssertNil(store.snapshot(for: .grades))
        XCTAssertThrowsError(try store.save(ModuleSnapshot(module: .grades, capturedAt: Date(),
          title: "x", sourceURL: "https://synergia.librus.pl", records: [], links: [], excerpt: "")))
    }
    @MainActor func testDownloadsFailClosedWithoutIdentity() {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: temp) }
        let store = DownloadStore(root: temp)
        XCTAssertTrue(store.items.isEmpty)
        XCTAssertThrowsError(try store.importDownload(from: temp.appendingPathComponent("a"),
          suggestedFilename: "a.pdf", sourceURL: "https://synergia.librus.pl"))
    }
}
