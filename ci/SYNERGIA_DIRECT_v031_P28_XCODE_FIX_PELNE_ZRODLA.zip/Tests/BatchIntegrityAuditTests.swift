import Foundation
import XCTest
@testable import SynergiaDirect

final class BatchIntegrityAuditTests: XCTestCase {
    private func page(_ url: String, module: SchoolModule = .grades, count: Int = 1,
                      includeTable: Bool = true) -> ModuleSnapshot {
        ModuleSnapshot(module: module, capturedAt: Date(), title: "test", sourceURL: url,
            records: (0..<count).map { _ in PortalRecord(fields: ["matematyka", "5"]) },
            links: [], excerpt: "", tables: includeTable ? [CapturedTable(caption: "", rows: [["Przedmiot", "Ocena"], ["Matematyka", "5"]])] : [])
    }
    func testAcceptsTwoConsistentPagesButDoesNotClaimServerCompleteness() {
        let result = BatchIntegrityAudit.inspect([
            page("https://synergia.librus.pl/p1"),
            page("https://synergia.librus.pl/p2")], module: .grades)
        XCTAssertTrue(result.accepted)
        XCTAssertEqual(result.recordCount, 2)
        XCTAssertTrue(result.explanation.contains("niepotwierdzona"))
    }
    func testRejectsMixedEmptyGradePage() {
        let result = BatchIntegrityAudit.inspect([
            page("https://synergia.librus.pl/p1"),
            page("https://synergia.librus.pl/p2", count: 0)], module: .grades)
        XCTAssertFalse(result.accepted)
        XCTAssertTrue(result.issueCodes.contains("mixed_empty_page"))
    }
    func testRejectsMissingTablesForMessages() {
        let result = BatchIntegrityAudit.inspect([
            page("https://synergia.librus.pl/m1", module: .messages),
            page("https://synergia.librus.pl/m2", module: .messages, includeTable: false)], module: .messages)
        XCTAssertFalse(result.accepted)
        XCTAssertTrue(result.issueCodes.contains("mixed_missing_tables"))
    }
    func testRejectsRepeatedAndExternalURLs() {
        let same = page("https://synergia.librus.pl/p1")
        XCTAssertTrue(BatchIntegrityAudit.inspect([same,same],module:.grades).issueCodes.contains("duplicate_page"))
        XCTAssertTrue(BatchIntegrityAudit.inspect([page("https://example.com/test")],module:.grades).issueCodes.contains("invalid_origin"))
    }
    func testReportNeverIncludesPersonalContentOrURL() {
        let result = BatchIntegrityAudit.inspect([page("https://synergia.librus.pl/oceny?secret=PRIVATE")],module:.grades)
        XCTAssertFalse(result.issueCodes.joined().contains("PRIVATE"))
    }
}
