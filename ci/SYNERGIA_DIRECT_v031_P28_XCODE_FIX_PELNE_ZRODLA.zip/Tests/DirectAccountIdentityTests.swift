import XCTest
@testable import SynergiaDirect

final class DirectAccountIdentityTests: XCTestCase {
    func testNestedMeIdentifier() throws {
        XCTAssertEqual(try DirectAccountIdentity.parse(["Me": ["Id": 42]]).id, "42")
    }
    func testNestedUserIdentifier() throws {
        XCTAssertEqual(try DirectAccountIdentity.parse(["Me": ["User": ["Id": "pupil-1"]]]).id, "pupil-1")
    }
    func testMissingIdentifierFailsClosed() {
        XCTAssertThrowsError(try DirectAccountIdentity.parse(["Me": ["Name": "Student"]]))
    }
    func testConflictingIdentifiersFailClosed() {
        XCTAssertThrowsError(try DirectAccountIdentity.parse(["Id": 7, "Me": ["Id": 8]]))
    }
    @MainActor
    func testStoreRequiresVerifiedAccount() throws {
        let store = DirectGradeStore()
        store.lock()
        XCTAssertThrowsError(try store.replace(grades: [], subjects: [:], accountId: "A"))
    }
}
