import XCTest
@testable import SynergiaDirect

final class DirectAttendanceCompletenessTests: XCTestCase {
    func testMatchingCountAccepted() throws {
        try DirectAttendanceCompleteness.validate(root: ["TotalCount": 2], decodedCount: 2, previousCount: 1)
    }
    func testTruncatedDataRejected() {
        XCTAssertThrowsError(try DirectAttendanceCompleteness.validate(
            root: ["TotalCount": 5], decodedCount: 2, previousCount: 3))
    }
    func testExplicitContinuationRejected() {
        XCTAssertThrowsError(try DirectAttendanceCompleteness.validate(
            root: ["Next": "?page=2"], decodedCount: 2, previousCount: 0))
    }
    func testEmptyWithoutConfirmationPreservesPreviousSnapshot() {
        XCTAssertThrowsError(try DirectAttendanceCompleteness.validate(
            root: [:], decodedCount: 0, previousCount: 8))
    }
    func testConfirmedZeroAccepted() throws {
        try DirectAttendanceCompleteness.validate(
            root: ["TotalCount": 0], decodedCount: 0, previousCount: 8)
    }
}
