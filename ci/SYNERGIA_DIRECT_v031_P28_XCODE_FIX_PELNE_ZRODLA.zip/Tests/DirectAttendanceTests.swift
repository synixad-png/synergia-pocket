import XCTest
@testable import SynergiaDirect

final class DirectAttendanceTests: XCTestCase {
    private let types: [String: Any] = ["Types": [
        ["Id": 1, "Name": "Nieobecność", "IsPresenceKind": false],
        ["Id": 2, "Name": "Spóźnienie", "IsPresenceKind": true],
        ["Id": 100, "Name": "Obecność", "IsPresenceKind": true],
        ["Id": 1685, "Name": "Pobyt w sanatorium", "IsPresenceKind": true]
    ]]
    private let lessons: [String: Any] = ["Lessons": [
        ["Id": 77, "Subject": ["Id": 42]]
    ]]
    func testRealisticAttendanceRecords() throws {
        let root: [String: Any] = ["Attendances": [
            ["Id": "t41685", "Date": "2026-10-29", "Lesson": ["Id": 77], "LessonNo": 6, "Type": ["Id": 1], "Semester": 1],
            ["Id": 23, "Date": "2026-10-30", "Lesson": ["Id": 77], "LessonNo": 1, "Type": ["Id": 2]]
        ]]
        let result = try SynergiaAttendanceRecords.decode(attendances: root, types: types, lessons: lessons)
        XCTAssertEqual(result.map(\.id), ["t41685", "23"])
        XCTAssertEqual(result.map(\.subjectId), ["42", "42"])
        XCTAssertFalse(result[0].isPresenceKind)
        XCTAssertTrue(result[1].isPresenceKind) // Late is still a presence kind.
    }
    func testSchoolSpecificPresenceType() throws {
        let root: [String: Any] = ["Attendances": [
            ["Id": 5, "Date": "2026-11-02", "Lesson": ["Id": 77], "Type": ["Id": 1685]]
        ]]
        let result = try SynergiaAttendanceRecords.decode(attendances: root, types: types, lessons: lessons)
        XCTAssertEqual(result[0].typeName, "Pobyt w sanatorium")
        XCTAssertTrue(result[0].isPresenceKind)
    }
    func testUnresolvedSubjectNeverInvented() throws {
        let root: [String: Any] = ["Attendances": [
            ["Id": 5, "Date": "2026-11-02", "Lesson": ["Id": 999], "Type": ["Id": 100]]
        ]]
        let result = try SynergiaAttendanceRecords.decode(attendances: root, types: types, lessons: lessons)
        XCTAssertNil(result[0].subjectId)
    }
    func testUnknownTypeRejected() {
        let root: [String: Any] = ["Attendances": [
            ["Id": 5, "Date": "2026-11-02", "Lesson": ["Id": 77], "Type": ["Id": 999]]
        ]]
        XCTAssertThrowsError(try SynergiaAttendanceRecords.decode(attendances: root, types: types, lessons: lessons))
    }
    func testDuplicateIdentityRejected() {
        let item: [String: Any] = ["Id": 5, "Date": "2026-11-02", "Lesson": ["Id": 77], "Type": ["Id": 100]]
        XCTAssertThrowsError(try SynergiaAttendanceRecords.decode(
            attendances: ["Attendances": [item, item]], types: types, lessons: lessons))
    }
    func testMissingLookupRejected() {
        XCTAssertThrowsError(try SynergiaAttendanceRecords.decode(
            attendances: ["Attendances": []], types: [:], lessons: lessons))
    }
}
