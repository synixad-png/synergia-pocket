import XCTest
@testable import SynergiaDirect

final class DirectGatewayGradeTests: XCTestCase {
    func testGradesResolveCommentsFromSeparateEndpoint() throws {
        let grades: [String: Any] = ["Grades": [
            ["Id": 101, "Grade": "5+", "Subject": ["Id": 42], "Category": ["Id": 7],
             "Semester": 1, "AddDate": "2026-10-01", "Comments": [["Id": 11]]],
            ["Id": 102, "Grade": "5+", "Subject": ["Id": 42], "Category": ["Id": 7],
             "Semester": 1, "AddDate": "2026-10-01", "Comments": []]
        ]]
        let comments: [String: Any] = ["Comments": [["Id": 11, "Text": "Praca pisemna"]]]
        let result = try SynergiaGradeRecords.decode(grades: grades, comments: comments)
        XCTAssertEqual(result.count, 2) // Equal values are two separate grade records.
        XCTAssertEqual(result[0].commentTexts, ["Praca pisemna"])
        XCTAssertEqual(result[0].subjectId, "42")
        XCTAssertEqual(result[1].id, "102")
    }
    func testRejectDuplicateIdentitiesInsteadOfDiscardingGrades() {
        let rows: [String: Any] = ["Grades": [
            ["Id": 1, "Grade": "4", "Subject": ["Id": 2]],
            ["Id": 1, "Grade": "5", "Subject": ["Id": 2]]]]
        XCTAssertThrowsError(try SynergiaGradeRecords.decode(grades: rows, comments: nil))
    }
    func testRejectMissingRoot() {
        XCTAssertThrowsError(try SynergiaGradeRecords.decode(grades: [:], comments: nil))
    }
}
