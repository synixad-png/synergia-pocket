import XCTest
@testable import SynergiaDirect

@MainActor
final class DirectGradeAccountIsolationTests: XCTestCase {
    func testSeparateAccountsKeepIndependentCaches() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = DirectGradeStore(directory: root)
        store.unlock(accountId: "A")
        try store.replace(grades: [], subjects: ["1": "Matematyka"], accountId: "A")
        store.unlock(accountId: "B")
        XCTAssertTrue(store.subjects.isEmpty)
        try store.replace(grades: [], subjects: ["2": "Fizyka"], accountId: "B")
        store.unlock(accountId: "A")
        XCTAssertEqual(store.subjects["1"], "Matematyka")
        XCTAssertNil(store.subjects["2"])
        store.lock()
        XCTAssertNil(store.verifiedAccountId)
        XCTAssertTrue(store.subjects.isEmpty)
    }

    func testUnverifiedWritesBlockedAndLegacyCacheNeverRead() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try Data("legacy-sensitive-data".utf8).write(to: root.appendingPathComponent("direct-grades.json"))
        let store = DirectGradeStore(directory: root)
        XCTAssertThrowsError(try store.replace(grades: [], subjects: [:], accountId: "A"))
        store.unlock(accountId: "A")
        XCTAssertTrue(store.subjects.isEmpty)
        try store.erase()
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent("direct-grades.json").path))
    }
}
