import XCTest
@testable import SynergiaDirect

final class DirectGradeCategoriesTests: XCTestCase {
    func testWeightZeroAndExplicitFalsePreserved() throws {
        let root: [String: Any] = ["Categories": [["Id": 7, "Name": "Kartkówka", "Weight": 0,
                                                   "CountToTheAverage": false]]]
        let result = try SynergiaGradeCategories.decode(root)
        XCTAssertEqual(result["7"]?.weight, 0)
        XCTAssertEqual(result["7"]?.countsToAverage, false)
    }

    func testNullCountFlagDefaultsToTrueButMissingRemainsUnknown() throws {
        let root: [String: Any] = ["Categories": [
            ["Id": 1, "Name": "Pierwsza", "Weight": 3, "CountToTheAverage": NSNull()],
            ["Id": 2, "Name": "Druga", "Weight": 1]
        ]]
        let result = try SynergiaGradeCategories.decode(root)
        XCTAssertEqual(result["1"]?.countsToAverage, true)
        XCTAssertNil(result["2"]?.countsToAverage)
    }

    func testDuplicateIDsAndInvalidWeightRejected() {
        XCTAssertThrowsError(try SynergiaGradeCategories.decode(["Categories": [
            ["Id": 1, "Name": "A"], ["Id": 1, "Name": "B"]]]))
        XCTAssertThrowsError(try SynergiaGradeCategories.decode(["Categories": [
            ["Id": 1, "Name": "A", "Weight": -2]]]))
    }

    func testTwoSameValueGradesRetainIdentitiesAndEnrichment() throws {
        let grades = try SynergiaGradeRecords.decode(grades: ["Grades": [
            ["Id": 10, "Grade": "5", "Subject": ["Id": 3], "Category": ["Id": 7]],
            ["Id": 11, "Grade": "5", "Subject": ["Id": 3], "Category": ["Id": 7]]
        ]], comments: nil)
        let categories = try SynergiaGradeCategories.decode(["Categories": [
            ["Id": 7, "Name": "Sprawdzian", "Weight": 3, "CountToTheAverage": true]]])
        let result = SynergiaGradeCategories.enrich(grades, categories: categories)
        XCTAssertEqual(result.map(\.id), ["10", "11"])
        XCTAssertEqual(result[0].categoryName, "Sprawdzian")
        XCTAssertEqual(result[0].weight, 3)
        XCTAssertTrue(SynergiaGradeCategories.unresolvedCategoryIds(result, categories: categories).isEmpty)
        let saved = try JSONEncoder().encode(result)
        XCTAssertEqual(try JSONDecoder().decode([DirectGrade].self, from: saved), result)
    }

    func testOldCacheCanDecodeAndUnknownReferenceNotInvented() throws {
        let old = Data("""
        [{"id":"100","subjectId":"7","categoryId":"42","value":"4","semester":1,"addedAt":null,"commentTexts":[]}]
        """.utf8)
        let grades = try JSONDecoder().decode([DirectGrade].self, from: old)
        XCTAssertNil(grades[0].weight)
        XCTAssertNil(grades[0].categoryName)
        XCTAssertEqual(SynergiaGradeCategories.unresolvedCategoryIds(grades, categories: [:]), ["42"])
    }
}
