import XCTest
@testable import SynergiaDirect

final class DirectGradeCompletenessTests: XCTestCase {
    func testMatchingTotalAllowsSinglePage() throws {
        try DirectGradeCompleteness.validate(root: ["TotalCount": 2], decodedCount: 2, previousCount: 2)
    }
    func testIncompleteCountDoesNotReplaceGrades() {
        XCTAssertThrowsError(try DirectGradeCompleteness.validate(root: ["TotalCount": 18], decodedCount: 10, previousCount: 18))
    }
    func testNextPageIsNotAcceptedAsComplete() {
        XCTAssertThrowsError(try DirectGradeCompleteness.validate(root: ["Next": "/next"], decodedCount: 10, previousCount: 0))
    }
    func testUnconfirmedEmptyResponseDoesNotErasePreviousGrades() {
        XCTAssertThrowsError(try DirectGradeCompleteness.validate(root: [:], decodedCount: 0, previousCount: 3))
    }
    func testExplicitEmptyTotalIsAllowed() throws {
        try DirectGradeCompleteness.validate(root: ["TotalCount": 0], decodedCount: 0, previousCount: 3)
    }
    func testInvalidTotalIsRejected() {
        XCTAssertThrowsError(try DirectGradeCompleteness.validate(root: ["TotalCount": "unknown"], decodedCount: 3, previousCount: 3))
    }
}
