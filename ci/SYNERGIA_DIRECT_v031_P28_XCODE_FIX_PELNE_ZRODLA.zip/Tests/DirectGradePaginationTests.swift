import XCTest
@testable import SynergiaDirect

final class DirectGradePaginationTests: XCTestCase {
    private let base = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Grades")!
    func testExplicitSameResourceContinuation() throws {
        let next = try DirectGradePagination.continuation(
            ["Next": "?page=2"], current: base, base: base)
        XCTAssertEqual(next?.absoluteString, base.absoluteString + "?page=2")
    }
    func testRejectForeignOrOtherResource() {
        for value in ["https://evil.example/steal", "/gateway/api/2.0/Users?page=2", "true"] {
            XCTAssertThrowsError(try DirectGradePagination.continuation(["Next": value], current: base, base: base))
        }
    }
    func testZeroTotalPreservedAfterMerge() throws {
        let merged = try DirectGradePagination.merge([["Grades": [], "TotalCount": 0]], previousCount: 0)
        XCTAssertEqual(merged["TotalCount"] as? Int, 0)
        try DirectGradeCompleteness.validate(root: merged, decodedCount: 0, previousCount: 3)
    }

    func testMergeRetainsEqualValueGradesWithDifferentIDs() throws {
        let a: [String: Any] = ["Grades": [["Id": 1, "Grade": "5", "Subject": ["Id": 2]]], "TotalCount": 2, "Next": "?page=2"]
        let b: [String: Any] = ["Grades": [["Id": 2, "Grade": "5", "Subject": ["Id": 2]]], "TotalCount": 2]
        XCTAssertEqual(try (DirectGradePagination.merge([a,b], previousCount: 0)["Grades"] as? [Any])?.count, 2)
    }
    func testRejectInconsistentTotalOrRepeatID() {
        let a: [String: Any] = ["Grades": [["Id": 1]], "TotalCount": 2, "Next": "?page=2"]
        let b: [String: Any] = ["Grades": [["Id": 1]], "TotalCount": 2]
        XCTAssertThrowsError(try DirectGradePagination.merge([a,b], previousCount: 0))
        XCTAssertThrowsError(try DirectGradePagination.merge([a], previousCount: 0))
    }
    func testRejectInterruptedOrUnfinishedChain() {
        let one = ["Grades": [["Id": 1]], "Next": "?page=2"] as [String: Any]
        let two = ["Grades": [["Id": 2]]] as [String: Any]
        XCTAssertThrowsError(try DirectGradePagination.merge([one], previousCount: 0))
        XCTAssertNoThrow(try DirectGradePagination.merge([one, two], previousCount: 0))
        XCTAssertThrowsError(try DirectGradePagination.merge([two, two], previousCount: 0))
        XCTAssertThrowsError(try DirectGradePagination.merge([one, one], previousCount: 0))
    }
    func testRejectUnverifiedEmptyInitialSnapshot() {
        XCTAssertThrowsError(try DirectGradePagination.merge([["Grades": []]], previousCount: 0))
        XCTAssertThrowsError(try DirectGradeCompleteness.validate(root: ["Grades": []], decodedCount: 0, previousCount: 0))
        XCTAssertNoThrow(try DirectGradePagination.merge([["Grades": [], "TotalCount": 0]], previousCount: 0))
    }
    func testNoSilentErasureOfPreviousGrades() {
        XCTAssertThrowsError(try DirectGradePagination.merge([["Grades": []]], previousCount: 2))
        XCTAssertNoThrow(try DirectGradePagination.merge([["Grades": [], "TotalCount": 0]], previousCount: 2))
    }
}
