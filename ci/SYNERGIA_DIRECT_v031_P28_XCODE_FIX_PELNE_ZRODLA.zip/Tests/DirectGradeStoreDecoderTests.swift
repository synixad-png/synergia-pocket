import XCTest
@testable import SynergiaDirect

final class DirectGradeStoreDecoderTests: XCTestCase {
    func testSubjectNamesDecodeByIdentity() throws {
        let value: [String: Any] = ["Subjects": [["Id": 7, "Name": "Matematyka"]]]
        XCTAssertEqual(try SynergiaSubjects.decode(value)["7"], "Matematyka")
    }
    func testDuplicateSubjectIdsAreRejected() {
        let value: [String: Any] = ["Subjects": [["Id": 7, "Name": "Matematyka"], ["Id": 7, "Name": "Fizyka"]]]
        XCTAssertThrowsError(try SynergiaSubjects.decode(value))
    }
    func testEqualGradeValuesRetainSeparateIDsAndCodability() throws {
        let input: [String: Any] = ["Grades": [
            ["Id": 91, "Grade": "5", "Subject": ["Id": 7]],
            ["Id": 92, "Grade": "5", "Subject": ["Id": 7]]]]
        let parsed = try SynergiaGradeRecords.decode(grades: input, comments: nil)
        let roundTrip = try JSONDecoder().decode([DirectGrade].self, from: JSONEncoder().encode(parsed))
        XCTAssertEqual(roundTrip.map(\.id), ["91", "92"])
    }
}
