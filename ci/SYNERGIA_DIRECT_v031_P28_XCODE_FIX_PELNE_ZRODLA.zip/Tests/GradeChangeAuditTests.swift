import XCTest
@testable import SynergiaDirect

final class GradeChangeAuditTests: XCTestCase {
    private func g(_ id: String, _ sem: Int?, _ val: String = "4") -> DirectGrade {
        DirectGrade(id: id, subjectId: "math", categoryId: nil, value: val, semester: sem, addedAt: nil, commentTexts: [])
    }
    func testReorderIsUnchanged() throws {
        let rows = [g("a", 1), g("b", 2), g("c", nil)]
        let audit = try GradeChangeAudit.compare(previous: rows, incoming: rows.reversed())
        XCTAssertEqual(audit.added, 0)
        XCTAssertEqual(audit.edited, 0)
        XCTAssertEqual(audit.unchanged, 3)
    }
    func testEditedUnknownSemesterIncluded() throws {
        let audit = try GradeChangeAudit.compare(previous: [g("a", nil)], incoming: [g("a", nil, "5")])
        XCTAssertEqual(audit.edited, 1)
        XCTAssertEqual(audit.unassignedOrOtherSemesterChanges, 1)
    }
    func testMovedSemesterIsNotNewOrMissing() throws {
        let audit = try GradeChangeAudit.compare(previous: [g("a", 1)], incoming: [g("a", 2)])
        XCTAssertEqual(audit.movedBetweenSemesters, 1)
        XCTAssertEqual(audit.added, 0)
        XCTAssertEqual(audit.absentInLatestRead, 0)
    }
    func testMissingGradeNotCalledDeleted() throws {
        let audit = try GradeChangeAudit.compare(previous: [g("a", 1)], incoming: [])
        XCTAssertEqual(audit.absentInLatestRead, 1)
        XCTAssertTrue(audit.summary.contains("nie oznacza potwierdzonego usunięcia"))
    }
    func testDuplicatesFailClosedBothSides() throws {
        XCTAssertThrowsError(try GradeChangeAudit.compare(previous: [g("a", 1), g("a", 1)], incoming: []))
        XCTAssertThrowsError(try GradeChangeAudit.compare(previous: [], incoming: [g("a", 1), g("a", 2)]))
    }
    func testChangedOtherSemesterIncluded() throws {
        let audit = try GradeChangeAudit.compare(previous: [g("a", 3)], incoming: [g("a", 3, "6")])
        XCTAssertEqual(audit.unassignedOrOtherSemesterChanges, 1)
    }
}
