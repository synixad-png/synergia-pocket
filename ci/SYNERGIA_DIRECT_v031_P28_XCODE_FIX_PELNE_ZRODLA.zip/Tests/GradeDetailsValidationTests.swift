import XCTest
@testable import SynergiaDirect

final class GradeDetailsValidationTests: XCTestCase {
    private func grade(_ raw: Any) -> [String: Any] {
        ["Id": 1, "Subject": ["Id": 2], "Grade": raw]
    }
    private func decode(_ rows: [[String: Any]], comments: [String: Any]? = nil) throws -> [DirectGrade] {
        try SynergiaGradeRecords.decode(grades: ["Grades": rows], comments: comments)
    }
    func testBlankGradeRejected() {
        XCTAssertThrowsError(try decode([grade("  ")]))
    }
    func testMalformedDateRejectedInsteadOfSilentlyDisappearing() {
        var value = grade("5")
        value["AddDate"] = 12345
        XCTAssertThrowsError(try decode([value]))
    }
    func testDateCanBeAbsent() throws {
        XCTAssertNil(try decode([grade("5")]).first?.addedAt)
    }
    func testEqualTextCommentsAreBothPreserved() throws {
        var value = grade("5")
        value["Comments"] = [["Id": 101], ["Id": 102]]
        let comments: [String: Any] = ["Comments": [
            ["Id": 101, "Text": "Uwaga"], ["Id": 102, "Text": "Uwaga"]]
        ]
        XCTAssertEqual(try decode([value], comments: comments)[0].commentTexts, ["Uwaga", "Uwaga"])
    }
}
