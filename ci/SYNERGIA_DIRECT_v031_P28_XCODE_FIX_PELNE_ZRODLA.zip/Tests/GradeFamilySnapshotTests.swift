import XCTest
@testable import SynergiaDirect

final class GradeFamilySnapshotTests: XCTestCase {
    private func mark(_ family: SupplementalGradeFamily, _ id: String) -> SupplementalGrade {
        SupplementalGrade(family: family, sourceId: id, subjectId: "4", value: "5", semester: 1, addedAt: nil)
    }

    func testForbiddenFamilyRetainsOldRowsButUpdatesAvailableFamily() {
        let previous = [mark(.points, "old"), mark(.text, "previous")]
        let fresh = [mark(.text, "new")]
        let result = GradeFamilySnapshot.reconcile(fresh: fresh, previous: previous, unavailable: [.points])
        XCTAssertEqual(Set(result.map(\.id)), ["PointGrades:old", "BaseTextGrades:new"])
    }

    func testConfirmedEmptyFamilyDeletesOldRows() {
        let previous = [mark(.points, "old")]
        XCTAssertTrue(GradeFamilySnapshot.reconcile(fresh: [], previous: previous, unavailable: []).isEmpty)
    }

    func testUnknownFamilyDoesNotCrossContaminate() {
        let previous = [mark(.points, "p1"), mark(.descriptive, "d1")]
        let actual = GradeFamilySnapshot.reconcile(fresh: [], previous: previous, unavailable: [.points])
        XCTAssertEqual(actual.map(\.id), ["PointGrades:p1"])
    }
}
