import XCTest
@testable import SynergiaDirect

final class GradeSemesterCoverageTests: XCTestCase {
    private func grade(_ id: String, _ semester: Int?) -> DirectGrade {
        DirectGrade(id: id, subjectId: "2", categoryId: nil, value: "5", semester: semester, addedAt: nil, commentTexts: [])
    }
    func testBothSemestersAndUnspecifiedRemainVisible() throws {
        let report = try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 1), grade("b", 2), grade("c", nil)], previous: [])
        XCTAssertEqual(report.firstCount, 1)
        XCTAssertEqual(report.secondCount, 1)
        XCTAssertEqual(report.unspecifiedCount, 1)
        XCTAssertTrue(report.observedBothSemesters)
        XCTAssertTrue(report.message.contains("niepotwierdzona"))
    }
    func testPreviouslyObservedSecondSemesterCannotSilentlyDisappear() {
        XCTAssertThrowsError(try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 1)], previous: [grade("a", 1), grade("b", 2)]))
    }
    func testUnconfirmedDeletionWithinSemesterIsBlocked() {
        XCTAssertThrowsError(try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 1), grade("c", 2)],
            previous: [grade("a", 1), grade("b", 1), grade("c", 2)]))
    }
    func testSemesterMoveKeepsIdentity() throws {
        XCTAssertNoThrow(try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 2)], previous: [grade("a", 1)]))
    }
    func testUnknownSemesterMissingRecordIsBlocked() {
        XCTAssertThrowsError(try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 1)], previous: [grade("a", 1), grade("b", nil)]))
    }
    func testDuplicateIDsRejectedEvenAcrossSemesters() {
        XCTAssertThrowsError(try GradeSemesterCoverage.validateReplacement(
            incoming: [grade("a", 1), grade("a", 2)], previous: []))
    }
    func testMalformedSemesterDoesNotBecomeNil() {
        let root: [String: Any] = ["Grades": [["Id": 1, "Grade": "5", "Subject": ["Id": 2], "Semester": "unknown"]]]
        XCTAssertThrowsError(try SynergiaGradeRecords.decode(grades: root, comments: nil))
    }
    func testNoClaimOfFullCoverageFromTwoObservedSemesters() {
        let report = GradeSemesterCoverage.report([grade("a", 1), grade("b", 2)])
        XCTAssertTrue(report.observedBothSemesters)
        XCTAssertTrue(report.message.contains("niepotwierdzona"))
    }

    func testReorderingDoesNotCreateNewGrades() throws {
        let before = [grade("a", 1), grade("b", 2)]
        let deltas = try GradeSemesterCoverage.compare(incoming: before.reversed(), previous: before)
        XCTAssertTrue(deltas.allSatisfy { $0.addedIds.isEmpty && $0.missingIds.isEmpty && $0.changedIds.isEmpty })
    }
    func testMissingGradeFlaggedAsObservationNotDeletion() throws {
        let before = [grade("a", 1), grade("b", 1), grade("c", 2)]
        let after = [grade("a", 1), grade("c", 2)]
        let first = try GradeSemesterCoverage.compare(incoming: after, previous: before)[0]
        XCTAssertEqual(first.missingIds, ["b"])
        XCTAssertTrue(first.hasUnexplainedShrinkage)
    }
    func testGradeChangeNotMisreportedAsNew() throws {
        let before = [grade("a", 1)]
        let after = [DirectGrade(id: "a", subjectId: "2", categoryId: nil, value: "4", semester: 1, addedAt: nil, commentTexts: [])]
        let first = try GradeSemesterCoverage.compare(incoming: after, previous: before)[0]
        XCTAssertEqual(first.changedIds, ["a"])
        XCTAssertTrue(first.addedIds.isEmpty)
    }
    func testSemesterMigrationNotCountedAsNewIdentity() throws {
        let before = [grade("a", 1)]
        let after = [grade("a", 2)]
        let deltas = try GradeSemesterCoverage.compare(incoming: after, previous: before)
        XCTAssertEqual(deltas[0].movedOutIds, ["a"])
        XCTAssertEqual(deltas[1].movedInIds, ["a"])
        XCTAssertTrue(deltas.allSatisfy { $0.addedIds.isEmpty && $0.missingIds.isEmpty })
    }
    func testDuplicateIDsBlockComparison() {
        XCTAssertThrowsError(try GradeSemesterCoverage.compare(incoming: [grade("a", 1), grade("a", 2)], previous: []))
    }
}

final class SupplementalSemesterCoverageTests: XCTestCase {
    private func grade(_ id: String, _ family: SupplementalGradeFamily, _ semester: Int?) -> SupplementalGrade {
        SupplementalGrade(family: family, sourceId: id, subjectId: "10", value: "5",
                          semester: semester, addedAt: nil)
    }
    func testPreviouslyObservedSecondSemesterInAdditionalFamilyCannotVanish() {
        let before = [grade("a", .points, 1), grade("b", .text, 2)]
        XCTAssertThrowsError(try SupplementalSemesterCoverage.validateReplacement(
            fresh: [before[0]], previous: before, unavailable: []))
    }
    func testUnavailableFamilyRetainedWithoutTreatingAsZero() {
        let before = [grade("a", .points, 1), grade("b", .text, 2)]
        XCTAssertNoThrow(try SupplementalSemesterCoverage.validateReplacement(
            fresh: [before[0]], previous: before, unavailable: [.text]))
    }
    func testSameRecordChangingSemesterIsNotLoss() {
        let before = [grade("a", .points, 1)]
        XCTAssertNoThrow(try SupplementalSemesterCoverage.validateReplacement(
            fresh: [grade("a", .points, 2)], previous: before, unavailable: []))
    }
    func testReportIncludesAdditionalFamiliesWithoutAssumingCompleteness() {
        let result = GradePortfolioSemesterCoverage.report(
            standard: [], supplemental: [grade("a", .points, 2)])
        XCTAssertEqual(result.supplemental.secondCount, 1)
        XCTAssertTrue(result.message.contains("nie jest potwierdzona"))
    }
}
