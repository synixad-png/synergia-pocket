# SYNERGIA DIRECT — device test policy, 2026-11-05

The requested verification scope is **iPhone only**. Do not schedule or run
any iPad simulator or physical-iPad test. Existing iPad compatibility of the app
(`TARGETED_DEVICE_FAMILY: 1,2`) is retained; device compatibility and test
scope are separate choices. This policy does **not** claim that iPhone tests
have already been executed.

The manual GitHub workflow checks this policy before the unsigned iOS build.
The current workflow is **build-only**, not a simulator/device XCTest suite.
If a native simulator/XCTest stage is added later, its destination MUST specify
an available iPhone simulator explicitly and must never select an iPad simulator.

The previously failed GitHub Actions run has `runner_id=0`, `steps=[]` and
0 ms macOS billed time. Removing an iPad test cannot resolve this runner
allocation failure, because no test ran on that runner in the first place.
