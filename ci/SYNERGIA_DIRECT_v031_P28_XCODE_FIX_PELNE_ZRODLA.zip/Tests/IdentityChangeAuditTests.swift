import Foundation
import XCTest
@testable import SynergiaDirect

final class IdentityChangeAuditTests: XCTestCase {
    private let url = "https://synergia.librus.pl/oceny"
    private func gradeSnapshot(_ grades: [(String, String)], linkIDs: [String?]) -> ModuleSnapshot {
        let heading = ["Przedmiot", "Ocena"]
        let rows = [heading] + grades.map { [$0.0, $0.1] }
        let rowLinks: [[CapturedRowLink]] = [[]] + linkIDs.map { id in
            id.map { [CapturedRowLink(title: "Szczegóły", url: "https://synergia.librus.pl/ocena/" + $0)] } ?? []
        }
        return ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny",
            sourceURL: url, records: [], links: [], excerpt: "",
            tables: [CapturedTable(caption: "Semestr 1", rows: rows, rowLinks: rowLinks)])
    }
    func testReorderingIsNotAChangeWhenLinksAreUnique() {
        let old = gradeSnapshot([("Matematyka","5"),("Polski","4")], linkIDs: ["101","102"])
        let new = gradeSnapshot([("Polski","4"),("Matematyka","5")], linkIDs: ["102","101"])
        let report = IdentityChangeAudit.compare(previous: old, current: new)
        XCTAssertTrue(report.comparable)
        XCTAssertEqual(report.possibleAdded, 0)
        XCTAssertEqual(report.possibleEdited, 0)
        XCTAssertEqual(report.possibleRemoved, 0)
    }
    func testModifiedValueIsOnlyCandidateEdit() {
        let old = gradeSnapshot([("Matematyka","5")], linkIDs: ["101"])
        let new = gradeSnapshot([("Matematyka","4")], linkIDs: ["101"])
        let report = IdentityChangeAudit.compare(previous: old, current: new)
        XCTAssertEqual(report.possibleEdited, 1)
        XCTAssertEqual(report.possibleAdded, 0)
    }
    func testUnlinkedOrRepeatedKeysPreventReliableNewCount() {
        let old = gradeSnapshot([("Matematyka","5")], linkIDs: [nil])
        let new = gradeSnapshot([("Matematyka","5"),("Polski","4")], linkIDs: [nil,"200"])
        let report = IdentityChangeAudit.compare(previous: old, current: new)
        XCTAssertFalse(report.comparable)
        XCTAssertEqual(report.possibleAdded, 0)
    }
    func testChangedOriginPreventsComparison() {
        let old = gradeSnapshot([("Matematyka","5")], linkIDs: ["100"])
        let new = ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny",
            sourceURL: "https://synergia.librus.pl/inne", records: [], links: [], excerpt: "",
            tables: old.tables)
        XCTAssertFalse(IdentityChangeAudit.compare(previous: old, current: new).comparable)
    }
    func testNoLinksInLegacyDataDoNotGenerateNewGrades() {
        let old = gradeSnapshot([("Matematyka","5")], linkIDs: [nil])
        XCTAssertFalse(IdentityChangeAudit.compare(previous: old, current: old).comparable)
    }
}
