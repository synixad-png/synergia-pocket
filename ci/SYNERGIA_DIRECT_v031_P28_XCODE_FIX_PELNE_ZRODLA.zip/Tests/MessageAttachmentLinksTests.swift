import Foundation
import XCTest
@testable import SynergiaDirect

final class MessageAttachmentLinksTests: XCTestCase {
    private func link(_ title: String, _ url: String) -> CapturedRowLink {
        CapturedRowLink(title: title, url: url)
    }
    private func table(_ links: [CapturedRowLink]) -> CapturedTable {
        CapturedTable(caption: "Odebrane", rows: [["Nadawca", "Temat"], ["N", "T"]],
                      rowLinks: [[], links])
    }
    func testDetailAndAttachmentAreSeparated() {
        let r = MessageLinkInspector.inspect(table: table([
            link("Czytaj", "https://synergia.librus.pl/wiadomosci/10"),
            link("Pobierz załącznik", "https://synergia.librus.pl/pliki/11")
        ]), rowIndex: 1)
        XCTAssertNotNil(r.detail)
        XCTAssertEqual(r.attachments.count, 1)
        XCTAssertFalse(r.ambiguous)
    }
    func testUnsafeLinkIsNotAnAttachment() {
        let r = MessageLinkInspector.inspect(table: table([
            link("Pobierz", "https://evil.example/attack.pdf"),
            link("Czytaj", "https://synergia.librus.pl/wiadomosci/10")
        ]), rowIndex: 1)
        XCTAssertTrue(r.attachments.isEmpty)
        XCTAssertNotNil(r.detail)
    }
    func testDistinctContentLinksStayAmbiguous() {
        let r = MessageLinkInspector.inspect(table: table([
            link("Otwórz", "https://synergia.librus.pl/wiadomosci/1"),
            link("Czytaj", "https://synergia.librus.pl/wiadomosci/2")
        ]), rowIndex: 1)
        XCTAssertNil(r.detail)
        XCTAssertTrue(r.ambiguous)
    }
    func testDuplicateDownloadTargetIsNotDuplicated() {
        let r = MessageLinkInspector.inspect(table: table([
            link("Pobierz", "https://synergia.librus.pl/a.pdf"),
            link("Załącznik", "https://synergia.librus.pl/a.pdf")
        ]), rowIndex: 1)
        XCTAssertEqual(r.attachments.count, 1)
    }
    func testNoMetadataDoesNotInventLinks() {
        let t = CapturedTable(caption: "Odebrane", rows: [["Nadawca", "Temat"]])
        let r = MessageLinkInspector.inspect(table: t, rowIndex: 0)
        XCTAssertNil(r.detail)
        XCTAssertTrue(r.attachments.isEmpty)
    }
}
