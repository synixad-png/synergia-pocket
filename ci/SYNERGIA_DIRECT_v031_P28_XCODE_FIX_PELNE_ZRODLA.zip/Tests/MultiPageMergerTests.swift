import XCTest
@testable import SynergiaDirect

final class MultiPageMergerTests: XCTestCase {
    func testEqualRowsArePreserved() throws {
        let p1 = ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny",
            sourceURL: "https://synergia.librus.pl/a?page=1", records: [PortalRecord(fields: ["matematyka", "5"])], links: [], excerpt: "", tables: nil)
        let p2 = ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny",
            sourceURL: "https://synergia.librus.pl/a?page=2", records: [PortalRecord(fields: ["matematyka", "5"])], links: [], excerpt: "", tables: nil)
        XCTAssertEqual(try MultiPageMerger.merge([p1,p2], module: .grades).records.count, 2)
        XCTAssertThrowsError(try MultiPageMerger.merge([p1,p1], module: .grades))
        XCTAssertThrowsError(try MultiPageMerger.merge([p1,p2], module: .messages))
    }
    func testEmptyBatchRejected() { XCTAssertThrowsError(try MultiPageMerger.merge([], module: .grades)) }
}
