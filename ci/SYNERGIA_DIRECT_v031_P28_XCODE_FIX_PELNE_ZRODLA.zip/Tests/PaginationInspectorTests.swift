import XCTest
@testable import SynergiaDirect

final class PaginationInspectorTests: XCTestCase {
    let origin = "https://synergia.librus.pl/oceny?page=1"
    func testDetectsUnapprovedPage() {
        let result = PaginationInspector.audit(
            observed: [origin, "https://synergia.librus.pl/oceny?page=2"],
            approved: [origin], origin: origin)
        XCTAssertEqual(result.missingApprovalCount, 1)
        XCTAssertTrue(result.hasUnapprovedPages)
    }
    func testApprovedAndRepeatedLinks() {
        let second = "https://synergia.librus.pl/oceny?page=2"
        let result = PaginationInspector.audit(observed: [origin, second, second],
                                               approved: [origin, second], origin: origin)
        XCTAssertEqual(result.missingApprovalCount, 0)
        XCTAssertFalse(result.hasUnapprovedPages)
    }
    func testOtherOriginCannotBeApprovedAsPagination() {
        let result = PaginationInspector.audit(observed: ["https://evil.example/oceny?page=2"],
            approved: [origin, "https://evil.example/oceny?page=2"], origin: origin)
        XCTAssertEqual(result.invalidCount, 1)
        XCTAssertTrue(result.hasUnapprovedPages)
    }
    func testMoreThanTwentyLinksRejected() {
        let links = (1...21).map { "https://synergia.librus.pl/oceny?page=\($0)" }
        XCTAssertTrue(PaginationInspector.audit(observed: links, approved: links,
                                                origin: origin).hasUnapprovedPages)
    }
}
