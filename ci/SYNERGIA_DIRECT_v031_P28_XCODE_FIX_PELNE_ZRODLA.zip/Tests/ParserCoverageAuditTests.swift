import Foundation
import XCTest
@testable import SynergiaDirect

final class ParserCoverageAuditTests: XCTestCase {
    private func snapshot(_ tables: [CapturedTable], module: SchoolModule = .grades) -> ModuleSnapshot {
        ModuleSnapshot(module: module, capturedAt: Date(), title: "PRYWATNY TYTUŁ",
            sourceURL: "https://synergia.librus.pl/sekret?token=sekret", records: [], links: [],
            excerpt: "PRYWATNA TREŚĆ", tables: tables)
    }
    func testOnlyClosedVocabularyIsExported() {
        let value = snapshot([CapturedTable(caption: "Nazwisko Ucznia", rows: [
            ["Przedmiot", "Ocena", "Komentarz"],
            ["Matematyka", "5", "Prywatna treść"]
        ])])
        let report = ParserCoverageAudit.inspect(value)
        let json = report.formatted()
        XCTAssertEqual(report.recognizedTables, 1)
        XCTAssertTrue(report.recognizedRoles.contains("grade"))
        for secret in ["Nazwisko", "Matematyka", "Prywatna", "PRYWATNY", "sekret", "token", "5"] {
            XCTAssertFalse(json.contains(secret), "Found leaked content")
        }
    }
    func testUnknownHeadersCannotBeReported() {
        let report = ParserCoverageAudit.inspect(snapshot([CapturedTable(caption: "", rows: [
            ["Nazwisko Ucznia", "Dane prywatne"], ["XYZ", "sekret"]
        ])]))
        XCTAssertEqual(report.recognizedTables, 0)
        XCTAssertFalse(report.structurallyComplete)
        XCTAssertFalse(report.formatted().contains("Nazwisko"))
    }
    func testNoTablesIsNotComplete() {
        let report = ParserCoverageAudit.inspect(snapshot([]))
        XCTAssertFalse(report.structurallyComplete)
    }
    func testTooManyTablesIsFlagged() {
        let many = Array(repeating: CapturedTable(caption: "", rows: [["Przedmiot", "Ocena"], ["X", "4"]]), count: 41)
        let report = ParserCoverageAudit.inspect(snapshot(many))
        XCTAssertFalse(report.structurallyComplete)
        XCTAssertTrue(report.warnings.contains(where: { $0.contains("40") }))
    }
}
