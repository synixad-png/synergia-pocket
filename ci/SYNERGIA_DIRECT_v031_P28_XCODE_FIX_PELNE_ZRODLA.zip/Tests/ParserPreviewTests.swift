// Future XCTest target, deliberately not compiled in this stage.
import Foundation
import XCTest
@testable import SynergiaDirect

final class ParserPreviewTests: XCTestCase {
    private func snapshot(_ module: SchoolModule, _ tables: [CapturedTable]) -> ModuleSnapshot {
        ModuleSnapshot(module: module, capturedAt: Date(timeIntervalSince1970: 0),
            title: module.title, sourceURL: "https://synergia.librus.pl/example",
            records: [], links: [], excerpt: "", tables: tables)
    }

    func testGradeColumnsDoNotLeakBetweenTables() {
        let tables = [
            CapturedTable(caption: "Semestr I", rows: [["Przedmiot", "Ocena", "Waga", "Komentarz"],
                ["Matematyka", "5", "2", "Sprawdzian"]]),
            CapturedTable(caption: "Obca tabela", rows: [["Nieoczekiwane", "3"]])
        ]
        let result = GradeParser.preview(snapshot: snapshot(.grades, tables))
        XCTAssertEqual(result.grades.count, 1)
        XCTAssertEqual(result.grades[0].semester, "1")
        XCTAssertEqual(result.grades[0].comment, "Sprawdzian")
    }

    func testNoGuessedSemesterOrMultipleGradesPerCell() {
        let result = GradeParser.preview(snapshot: snapshot(.grades, [
            CapturedTable(caption: "Oceny", rows: [["Przedmiot", "Ocena"], ["Polski", "4"], ["Fizyka", "4 5"]])
        ]))
        XCTAssertEqual(result.grades.count, 1)
        XCTAssertNil(result.grades[0].semester)
        XCTAssertEqual(result.rejectedRows, 1)
    }

    func testDuplicateGradeValuesAreRetainedAndFlagged() {
        let result = GradeParser.preview(snapshot: snapshot(.grades, [
            CapturedTable(caption: "Semestr I", rows: [
                ["Przedmiot", "Ocena", "Data"],
                ["Matematyka", "5", "2026-09-10"],
                ["Matematyka", "5", "2026-09-10"]])
        ]))
        XCTAssertEqual(result.grades.count, 2)
        XCTAssertEqual(result.possibleDuplicateGroups, 1)
    }

    func testTimetableRequiresExplicitDayAndSubjectColumns() {
        let result = TimetableParser.preview(snapshot: snapshot(.timetable, [
            CapturedTable(caption: "Plan", rows: [
                ["Dzień", "Przedmiot", "Sala", "Nauczyciel"],
                ["Poniedziałek", "Matematyka", "101", "A. Test"]]),
            CapturedTable(caption: "Inne", rows: [["Poniedziałek", "Historia"]])
        ]))
        XCTAssertEqual(result.entries.count, 1)
        XCTAssertEqual(result.entries[0].room, "101")
    }

    func testAttendanceDoesNotGuessUnknownStatus() {
        let result = AttendanceParser.preview(snapshot: snapshot(.attendance, [
            CapturedTable(caption: "Frekwencja", rows: [
                ["Data", "Przedmiot", "Status"],
                ["2026-10-01", "Polski", "Obecność"],
                ["2026-10-02", "Polski", "?"]])
        ]))
        XCTAssertEqual(result.entries.count, 1)
        XCTAssertEqual(result.unknownStatusCount, 1)
    }

    func testMessageRecipientAndPreviewOnlyWhenExplicit() {
        let result = MessageParser.preview(snapshot: snapshot(.messages, [
            CapturedTable(caption: "Wiadomości", rows: [["Nadawca", "Temat", "Odbiorca", "Podgląd"],
                ["Sekretariat", "Zebranie", "Rodzic", "Zapraszamy na spotkanie"]])
        ]))
        XCTAssertEqual(result.messages.count, 1)
        XCTAssertEqual(result.messages[0].recipient, "Rodzic")
        XCTAssertEqual(result.messages[0].previewText, "Zapraszamy na spotkanie")
    }
}

extension ParserPreviewTests {
    func testCalendarRejectsTablesWithoutDate() {
        let result = AdditionalParsers.calendar(snapshot(.calendar, [
            CapturedTable(caption: "Inne", rows: [["Wydarzenie", "Opis"], ["Uroczystość", "Bez daty"]]),
            CapturedTable(caption: "Terminarz", rows: [["Data", "Wydarzenie", "Przedmiot"],
                ["2026-11-15", "Sprawdzian", "Matematyka"]])
        ]))
        XCTAssertEqual(result.items.count, 1)
        XCTAssertEqual(result.items[0].subject, "Matematyka")
    }
    func testHomeworkRequiresSubjectAndDescription() {
        let result = AdditionalParsers.homework(snapshot(.homework, [
            CapturedTable(caption: "Zadania", rows: [["Przedmiot", "Zadanie", "Termin"],
                ["Polski", "Przeczytać rozdział", "2026-11-10"]]),
            CapturedTable(caption: "Inne", rows: [["Termin", "Zadanie"], ["jutro", "Dowolne"]])
        ]))
        XCTAssertEqual(result.items.count, 1)
        XCTAssertEqual(result.items[0].dueDate, "2026-11-10")
    }
    func testAnnouncementRequiresAdditionalContext() {
        let result = AdditionalParsers.announcements(snapshot(.announcements, [
            CapturedTable(caption: "Ogłoszenia", rows: [["Tytuł", "Data", "Autor"],
                ["Zebranie", "2026-11-07", "Sekretariat"]]),
            CapturedTable(caption: "Inne", rows: [["Tytuł"], ["Niepotwierdzone"]])
        ]))
        XCTAssertEqual(result.items.count, 1)
    }
    func testMessageMailboxFromTableCaptionOnly() {
        let result = MessageDetails.preview(snapshot: snapshot(.messages, [
            CapturedTable(caption: "Odebrane", rows: [["Nadawca", "Temat", "Treść"],
                ["Szkoła", "Zebranie", "Zapraszamy"]]),
            CapturedTable(caption: "Tabela bez oznaczenia", rows: [["Nadawca", "Temat"],
                ["Szkoła", "Inny komunikat"]])
        ]))
        XCTAssertEqual(result.items.count, 2)
        XCTAssertEqual(result.items[0].mailbox, .inbox)
        XCTAssertEqual(result.items[0].body, "Zapraszamy")
        XCTAssertEqual(result.items[1].mailbox, .unknown)
        XCTAssertNil(result.items[1].body)
    }
}
