import Foundation
import XCTest
@testable import SynergiaDirect

final class RecordIdentityTests: XCTestCase {
    private func link(_ title: String, _ url: String) -> CapturedRowLink {
        CapturedRowLink(title: title, url: url)
    }
    func testOneTrustedLinkCanBeOpened() {
        let table = CapturedTable(caption: "Wiadomości", rows: [["Temat"], ["Spotkanie"]],
            rowLinks: [[], [link("Czytaj", "https://synergia.librus.pl/wiadomosci/5")]])
        XCTAssertEqual(RecordIdentity.uniqueLink(in: table, rowIndex: 1)?.title, "Czytaj")
    }
    func testUnsafeAndAmbiguousLinksAreNotReturned() {
        let table = CapturedTable(caption: "", rows: [["x"], ["y"]], rowLinks: [
            [link("Obcy", "https://attacker.example/5")],
            [link("A", "https://synergia.librus.pl/1"), link("B", "https://synergia.librus.pl/2")]
        ])
        XCTAssertNil(RecordIdentity.uniqueLink(in: table, rowIndex: 0))
        XCTAssertNil(RecordIdentity.uniqueLink(in: table, rowIndex: 1))
    }
    func testEarlierSnapshotsWithoutRowLinksRemainDecodable() throws {
        let json = #"{"caption":"Wiadomości","rows":[["Temat"]]}"#
        let table = try JSONDecoder().decode(CapturedTable.self, from: Data(json.utf8))
        XCTAssertNil(table.rowLinks)
    }
    func testGradeCandidatesAreNotServerIdentifiers() {
        let snapshot = ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny",
            sourceURL: "https://synergia.librus.pl/oceny", records: [], links: [], excerpt: "",
            tables: [CapturedTable(caption: "", rows: [["Przedmiot","Ocena"], ["Matematyka","5"]])])
        let report = GradeIdentityAudit.review(snapshot: snapshot)
        XCTAssertEqual(report.recognized, 1)
        XCTAssertEqual(report.linkedCandidates, 0)
        XCTAssertEqual(report.withoutLink, 1)
    }
}
