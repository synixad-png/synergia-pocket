import XCTest
@testable import SynergiaDirect

final class ScopedMetadataTests: XCTestCase {
    @MainActor func testRoutesIsolatedAndLockedByDefault() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ModuleRouteStore(root: root)
        XCTAssertNil(store.route(for: .grades))
        XCTAssertThrowsError(try store.remember(module: .grades, pageURL: URL(string: "https://synergia.librus.pl/")!))
        store.unlock(accountId: "A")
        try store.remember(module: .grades, pageURL: URL(string: "https://synergia.librus.pl/grades")!)
        XCTAssertNotNil(store.route(for: .grades))
        store.unlock(accountId: "B")
        XCTAssertNil(store.route(for: .grades))
        store.unlock(accountId: "A")
        XCTAssertNotNil(store.route(for: .grades))
        store.lock()
        XCTAssertTrue(store.routes.isEmpty)
    }

    @MainActor func testSyncAuditIsolatedAndLockedByDefault() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = SyncAuditStore(root: root)
        let now = Date()
        let record = SyncRunAudit(startedAt: now, finishedAt: now, pages: [], interrupted: false)
        XCTAssertThrowsError(try store.save(record))
        store.unlock(accountId: "A")
        try store.save(record)
        XCTAssertNotNil(store.lastRun)
        store.unlock(accountId: "B")
        XCTAssertNil(store.lastRun)
        store.unlock(accountId: "A")
        XCTAssertNotNil(store.lastRun)
        store.lock()
        XCTAssertNil(store.lastRun)
    }

    @MainActor func testLegacyUnscopedMetadataIsNotLoaded() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try Data("[]".utf8).write(to: root.appendingPathComponent("synergia-module-routes.json"))
        let routeStore = ModuleRouteStore(root: root)
        routeStore.unlock(accountId: "A")
        XCTAssertTrue(routeStore.routes.isEmpty)
        let run = SyncRunAudit(startedAt: Date(), finishedAt: Date(), pages: [], interrupted: false)
        try JSONEncoder().encode(run).write(to: root.appendingPathComponent("synergia-sync-audit.json"))
        let audit = SyncAuditStore(root: root)
        audit.unlock(accountId: "A")
        XCTAssertNil(audit.lastRun)
    }
}
