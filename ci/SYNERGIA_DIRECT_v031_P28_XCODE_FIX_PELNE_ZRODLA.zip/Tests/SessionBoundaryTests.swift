import XCTest
@testable import SynergiaDirect

final class SessionBoundaryTests: XCTestCase {
    @MainActor func testRouteWriteFailureDoesNotPublishUnpersistedRoute() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try Data("blocked".utf8).write(to: root)
        defer { try? FileManager.default.removeItem(at: root) }
        let routes = ModuleRouteStore(root: root)
        routes.unlock(accountId: "A")
        XCTAssertThrowsError(try routes.remember(module: .grades,
            pageURL: URL(string: "https://synergia.librus.pl/grades")!))
        XCTAssertNil(routes.route(for: .grades))
    }

    @MainActor func testDifferentAccountsCannotReadOtherAccountSyncReport() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let reports = SyncAuditStore(root: root)
        let report = SyncRunAudit(startedAt: Date(), finishedAt: Date(), pages: [], interrupted: false)
        reports.unlock(accountId: "first")
        try reports.save(report)
        reports.lock()
        XCTAssertNil(reports.lastRun)
        reports.unlock(accountId: "second")
        XCTAssertNil(reports.lastRun)
        reports.unlock(accountId: "first")
        XCTAssertNotNil(reports.lastRun)
    }

    @MainActor func testModuleRoutesStayPrivateAfterSwitch() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let routes = ModuleRouteStore(root: root)
        routes.unlock(accountId: "first")
        try routes.remember(module: .grades,
            pageURL: URL(string: "https://synergia.librus.pl/grades")!)
        routes.lock()
        XCTAssertTrue(routes.pages(for: .grades).isEmpty)
        routes.unlock(accountId: "second")
        XCTAssertNil(routes.route(for: .grades))
        routes.unlock(accountId: "first")
        XCTAssertEqual(routes.pages(for: .grades).count, 1)
    }
}
