import XCTest
@testable import SynergiaDirect

final class SnapshotComparisonTests: XCTestCase {
    private func snapshot(rows: [[String]], url: String = "https://synergia.librus.pl/oceny") -> ModuleSnapshot {
        ModuleSnapshot(module: .grades, capturedAt: Date(), title: "Oceny", sourceURL: url,
                       records: [], links: [], excerpt: "", tables: [CapturedTable(caption: "", rows: rows)])
    }
    func testRepeatedIdenticalGradesRemainDistinctOccurrences() {
        let old = snapshot(rows: [["Przedmiot","Ocena"],["Matematyka","5"]])
        let new = snapshot(rows: [["Przedmiot","Ocena"],["Matematyka","5"],["Matematyka","5"]])
        let result = SnapshotComparator.compare(previous: old, current: new)
        XCTAssertTrue(result.comparable)
        XCTAssertEqual(result.addedRowOccurrences, 1)
        XCTAssertEqual(result.removedRowOccurrences, 0)
    }
    func testChangedURLIsNotComparable() {
        let a = snapshot(rows: [["Przedmiot","Ocena"]])
        let b = snapshot(rows: [["Przedmiot","Ocena"]], url: "https://synergia.librus.pl/oceny?semestr=2")
        XCTAssertFalse(SnapshotComparator.compare(previous: a, current: b).comparable)
    }
    func testStructuralDiagnosticsContainNoPersonalText() {
        let input = PageCaptureFixture.make()
        let output = StructuralDiagnostics.from(input).formatted()
        XCTAssertFalse(output.contains("Sekret Ucznia"))
        XCTAssertFalse(output.contains("https://synergia.librus.pl"))
    }
}

private enum PageCaptureFixture {
    static func make() -> PageCapture {
        // PageCapture is Decodable and intentionally constructed through decoded sample JSON.
        let json = #"{"title":"Sekret Ucznia","url":"https://synergia.librus.pl/oceny","heading":"Oceny","rows":[["Sekret Ucznia"]],"links":[],"excerpt":"Sekret Ucznia","documentReady":true,"loginFormPresent":false,"isTruncated":false,"hasPagination":false,"tables":[{"caption":"Sekret Ucznia","rows":[["Sekret Ucznia"]]}]}"#
        return try! JSONDecoder().decode(PageCapture.self, from: Data(json.utf8))
    }
}
