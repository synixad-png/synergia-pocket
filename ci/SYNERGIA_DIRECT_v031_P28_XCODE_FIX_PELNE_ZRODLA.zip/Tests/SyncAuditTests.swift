import XCTest
@testable import SynergiaDirect

final class SyncAuditTests: XCTestCase {
    func testSavedPageNeverClaimsModuleCompleteness() {
        let page = SyncPageAudit(module: .grades, status: .savedPage, checkedAt: Date(),
            storedRows: 5, detectedPagination: false, clippedByLimit: false,
            explanation: "Jedna strona")
        XCTAssertTrue(page.pageSaved)
        XCTAssertFalse(page.moduleCompletenessVerified)
    }
    func testPartialPageIsNotSuccessful() {
        let page = SyncPageAudit(module: .messages, status: .rejectedPartial,
            checkedAt: Date(), storedRows: 0, detectedPagination: true,
            clippedByLimit: false, explanation: "Stronicowanie")
        let run = SyncRunAudit(startedAt: Date(), finishedAt: Date(), pages: [page], interrupted: false)
        XCTAssertEqual(run.savedPages, 0)
        XCTAssertEqual(run.failedPages, 1)
        XCTAssertTrue(page.detectedPagination)
    }
    func testAuditCanRoundTripWithoutSensitiveURLs() throws {
        let page = SyncPageAudit(module: .grades, status: .loginRequired, checkedAt: Date(),
            storedRows: 0, detectedPagination: false, clippedByLimit: false,
            explanation: "Wykryto formularz logowania")
        let run = SyncRunAudit(startedAt: Date(), finishedAt: Date(), pages: [page], interrupted: true)
        let encoded = try JSONEncoder().encode(run)
        XCTAssertFalse(String(decoding: encoded, as: UTF8.self).contains("https://"))
        XCTAssertEqual(try JSONDecoder().decode(SyncRunAudit.self, from: encoded).pages.first?.status, .loginRequired)
    }
}
