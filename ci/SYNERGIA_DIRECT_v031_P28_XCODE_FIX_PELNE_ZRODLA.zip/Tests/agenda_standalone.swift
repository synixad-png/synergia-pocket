import Foundation

// Transport stub replaces WebKit on Linux; the real app uses SynergiaGatewayClient.
enum SynergiaGatewayClient {
    enum Resource: String {
        case homework = "HomeWorks", homeworkAssignments = "HomeWorkAssignments"
        case schoolNotices = "SchoolNotices", schoolFiles = "SchoolFiles"
    }
}

@main struct AgendaTests {
    static var ok = 0
    static var fails = 0
    static func test(_ title: String, _ check: () throws -> Bool) {
        do {
            if try check() { ok += 1 } else { fails += 1; print("FAIL \(title)") }
        } catch { fails += 1; print("FAIL \(title): \(error)") }
    }
    static func refuses(_ result: () throws -> Any) -> Bool { (try? result()) == nil }
    static func sample(_ id: Int, _ day: String = "2026-11-05") -> [String:Any] {
        ["Id": id, "Date": day, "Content": "<p>Sprawdzian &amp; kartkówka \(id)</p>",
         "Category": ["Id": 2, "Name": "Sprawdzian"], "Subject": ["Id": 4, "Name":"Matematyka"], "LessonNo": "3"]
    }
    static func feed(_ rows: [[String:Any]], date: Date = Date()) throws -> DirectSchoolFeed {
        try DirectSchoolFeedParser.parse(["HomeWorks": rows], module: .calendar, accountId: "konto", date: date)
    }
    static func main() {
        test("agenda distinct from real homework") {
            try DirectSchoolFeedParser.resource(for: .calendar) == .homework &&
                DirectSchoolFeedParser.resource(for: .homework) == .homeworkAssignments
        }
        test("subject name from explicit response") { DirectSchoolAgendaEvent.parse(sample(1)).subjectName == "Matematyka" }
        test("category name from explicit response") { DirectSchoolAgendaEvent.parse(sample(1)).categoryName == "Sprawdzian" }
        test("category ID from explicit response") { DirectSchoolAgendaEvent.parse(sample(1)).categoryId == "2" }
        test("lesson number text") { DirectSchoolAgendaEvent.parse(sample(1)).lessonNumber == "3" }
        test("HTML is inert text") { DirectSchoolAgendaEvent.parse(sample(1)).body == "Sprawdzian & kartkówka 1" }
        test("no script reaches text") { DirectSchoolAgendaEvent.parse(["Content":"<script>alert(1)</script><b>OK</b>"]).body == "OK" }
        test("numeric category name is not fabricated") { DirectSchoolAgendaEvent.parse(["Category":["Id":42]]).categoryName == nil }
        test("missing date is unknown") { DirectSchoolAgendaEvent.parse(["Content":"OK"]).day == nil }
        test("no private fields copied") { DirectSchoolAgendaEvent.parse(["Content":"Test", "User":["Name":"SECRET"]]).body == "Test" }
        test("dates sorted, undated last") {
            let f = try feed([sample(2,"2026-11-20"), sample(1,"2026-10-11"), ["Id":3,"Content":"Bez daty"]])
            let visible = DirectSchoolAgendaPresentation.entries(f,today:"2026-11-05")
            return visible.map { $0.serverId ?? "" } == ["1","2","3"]
        }
        test("upcoming inclusive today") {
            let f = try feed([sample(1,"2026-11-04"),sample(2,"2026-11-05"),sample(3,"2026-11-06")])
            let list = DirectSchoolAgendaPresentation.entries(f,period:.upcoming,today:"2026-11-05")
            return list.count == 2 && list.map { $0.serverId } == ["2","3"]
        }
        test("past excludes present") {
            let f = try feed([sample(1,"2026-11-04"),sample(2,"2026-11-05")])
            return DirectSchoolAgendaPresentation.entries(f,period:.past,today:"2026-11-05").count == 1
        }
        test("undated includes malformed dates") {
            let f = try feed([sample(1,"2026-02-30"),sample(2,"2026-11-05")])
            return DirectSchoolAgendaPresentation.entries(f,period:.undated,today:"2026-11-05").count == 1
        }
        test("filter by category") {
            let f = try feed([sample(1)])
            return DirectSchoolAgendaPresentation.entries(f,query:"SPRAWDZIAN",today:"2026-11-05").count == 1
        }
        test("filter by subject") {
            let f = try feed([sample(1)])
            return DirectSchoolAgendaPresentation.entries(f,query:"mateMATyka",today:"2026-11-05").count == 1
        }
        test("filter by content") {
            let f = try feed([sample(1)])
            return DirectSchoolAgendaPresentation.entries(f,query:"KARTKÓWKA",today:"2026-11-05").count == 1
        }
        test("not from homework feed") {
            let f = try DirectSchoolFeedParser.parse(["HomeWorkAssignments":[["Id":1,"Topic":"A"]]],module:.homework,accountId:"konto")
            return f.records.first?.agenda == nil && DirectSchoolAgendaPresentation.entries(f,today:"2026-11-05").isEmpty
        }
        test("not from notice feed") {
            let f = try DirectSchoolFeedParser.parse(["SchoolNotices":[["Id":1,"Subject":"Notice"]]],module:.announcements,accountId:"konto")
            return f.records.first?.agenda == nil
        }
        test("parsed title is not raw HTML") {
            let f = try feed([sample(1)])
            return f.records[0].title == "Sprawdzian & kartkówka 1" && f.records[0].details.allSatisfy { !$0.contains("<p>") }
        }
        test("grouping produces date sections") {
            let f = try feed([sample(1,"2026-11-05"),sample(2,"2026-11-05"),sample(3,"2026-11-06")])
            let g = DirectSchoolAgendaPresentation.groups(DirectSchoolAgendaPresentation.entries(f,today:"2026-11-05"))
            return g.count == 2 && g[0].entries.count == 2 && g[1].entries.count == 1
        }
        test("empty unknown does not erase stored feed") {
            refuses { try DirectSchoolFeedParser.parse(["HomeWorks":[[String:Any]]()],module:.calendar,accountId:"konto") }
        }
        test("explicit empty total is valid") {
            let f = try DirectSchoolFeedParser.parse(["HomeWorks":[[String:Any]](),"Total":0],module:.calendar,accountId:"konto")
            return f.records.isEmpty && f.completenessKnown
        }
        test("server count not invented") {
            let f = try feed([sample(1)])
            return f.reportedTotal == nil && !f.completenessKnown
        }
        test("malformed title rejects record") { refuses { try feed([["Id":1,"Content":"<script>x</script>"]]) } }
        test("text body length is bounded") {
            DirectSchoolAgendaEvent.parse(["Content":String(repeating:"x",count:12001)]).body == nil
        }
        test("offline roundtrip") {
            let f = try feed([sample(1)])
            let bytes = try DirectOfflineFeedCache.encode(f,expectedAccountId:"konto")
            return try DirectOfflineFeedCache.decode(bytes,module:.calendar,expectedAccountId:"konto").records.first?.agenda == f.records.first?.agenda
        }
        test("offline cross-account denied") {
            let f = try feed([sample(1)])
            let bytes = try DirectOfflineFeedCache.encode(f,expectedAccountId:"konto")
            return refuses { try DirectOfflineFeedCache.decode(bytes,module:.calendar,expectedAccountId:"inne") }
        }
        test("offline cross-module denied") {
            let f = try feed([sample(1)])
            let bytes = try DirectOfflineFeedCache.encode(f,expectedAccountId:"konto")
            return refuses { try DirectOfflineFeedCache.decode(bytes,module:.homework,expectedAccountId:"konto") }
        }
        test("event changes audited") {
            let before = try feed([sample(1)])
            var item = sample(1); item["Content"] = "Nowy wpis"
            let after = try feed([item])
            return DirectFeedChangeAudit.compare(previous:before,current:after).changed == 1
        }
        test("account change not comparable") {
            let before = try feed([sample(1)])
            let after = try DirectSchoolFeedParser.parse(["HomeWorks":[sample(1)]],module:.calendar,accountId:"inne")
            return !DirectFeedChangeAudit.compare(previous:before,current:after).comparable
        }
        test("legacy offline decoder supports missing agenda field") {
            let f = try feed([sample(1)])
            let bytes = try DirectOfflineFeedCache.encode(f,expectedAccountId:"konto")
            var object = try JSONSerialization.jsonObject(with:bytes) as! [String:Any]
            var stored = object["feed"] as! [String:Any]
            var records = stored["records"] as! [[String:Any]]
            records[0].removeValue(forKey:"agenda")
            stored["records"] = records
            object["feed"] = stored
            let legacy = try JSONSerialization.data(withJSONObject:object)
            return try DirectOfflineFeedCache.decode(legacy,module:.calendar,expectedAccountId:"konto").records[0].agenda == nil
        }
        // Validate every date in a 12-year representative range, including leap days.
        for y in 2022...2033 {
            for month in 1...12 {
                for d in 1...31 {
                    let day = String(format:"%04d-%02d-%02d",y,month,d)
                    var cal = Calendar(identifier:.gregorian); cal.timeZone = TimeZone(secondsFromGMT:0)!
                    let ref = cal.date(from:DateComponents(year:y,month:month,day:d))!
                    let expected = cal.component(.month,from:ref)==month
                    test("date \(day)") { (DirectSchoolAgendaEvent.validDay(day) != nil) == expected }
                }
            }
        }
        test("timestamp day normalized") { DirectSchoolAgendaEvent.validDay("2026-11-05T12:00:00") == "2026-11-05" }
        test("query-looking date rejected") { DirectSchoolAgendaEvent.validDay("2026-11-05&secret=1") == nil }
        test("nonASCII day rejected") { DirectSchoolAgendaEvent.validDay("٢٠٢٦-١١-٠٥") == nil }
        print("AGENDA PASS=\(ok) FAIL=\(fails)")
        if fails > 0 { exit(1) }
    }
}
