import Foundation

@main struct AttendanceAnalyticsTests {
    static var passed = 0, failed = 0
    static func check(_ name: String, _ value: @autoclosure () -> Bool) {
        if value() { passed += 1 } else { failed += 1; print("FAIL: \(name)") }
    }
    static func mark(_ id: String, date: String = "2026-10-05", lesson: Int? = 1,
                     semester: Int? = 1, subject: String? = "42", typeId: String = "100",
                     type: String = "Obecność", present: Bool = true) -> DirectAttendance {
        DirectAttendance(id: id, date: date, lessonNumber: lesson, semester: semester,
            lessonId: "lesson-\(id)", subjectId: subject, typeId: typeId,
            typeName: type, isPresenceKind: present)
    }
    static func main() {
        let validDays = ["2026-01-01", "2026-02-28", "2024-02-29", "2000-02-29", "2100-12-31", "2026-11-05T08:00:00", "2026-11-05 08:00:00"]
        for (i, day) in validDays.enumerated() { check("valid date \(i)", DirectAttendanceCalendar.day(day) == String(day.prefix(10))) }
        let invalidDays = ["", "1", "2026-13-05", "2026-00-05", "2026-01-00", "2026-11-31", "2026-02-29", "2023-02-29", "2100-02-29", "2026/01/05", "20260105", "2026-01-05garbage", "2026-02-30", "2026-04-31", "2026-1-05", "2026-01-5", "2026-01-01Z", "2026-01-01x", "2026-01-01;", "\u{00E9}2026-11-05", "2026-\u{00E9}1-01"]
        for (i, day) in invalidDays.enumerated() { check("invalid date \(i)", DirectAttendanceCalendar.day(day) == nil) }
        check("year-month derives from valid date", DirectAttendanceCalendar.month(for: "2026-10-05T12:00") == "2026-10")
        check("bad month unavailable", DirectAttendanceCalendar.month(for: "2026-02-30") == nil)
        check("leap year supported", DirectAttendanceCalendar.day("2028-02-29") != nil)
        check("century nonleap", DirectAttendanceCalendar.day("1900-02-29") == nil)

        let rows = [
            mark("a", date: "2026-10-05", lesson: 1, semester: 1, subject: "42", typeId: "100"),
            mark("b", date: "2026-10-05T08:00:00", lesson: 2, semester: 1, subject: "42", typeId: "2", type: "Spóźnienie", present: true),
            mark("c", date: "2026-10-06", lesson: 3, semester: 1, subject: "42", typeId: "3", type: "Nieobecność uspr.", present: false),
            mark("d", date: "2026-11-06", lesson: 1, semester: 2, subject: "50", typeId: "1", type: "Nieobecność", present: false),
            mark("e", date: "2026-11-06", lesson: 2, semester: 2, subject: "50", typeId: "X", type: "Nieusprawiedliwiona nieobecność", present: false),
            mark("f", date: "invalid", lesson: nil, semester: nil, subject: nil, typeId: "custom", type: "Pobyt w sanatorium", present: true),
            mark("g", date: "2026-11-06", lesson: 3, semester: 2, subject: "50", typeId: "2", type: "SPOŹNIENIE", present: true),
            mark("h", date: "2026-11-06", lesson: 3, semester: 2, subject: "50", typeId: "2", type: "Spóźnienie", present: true)
        ]
        let names = ["42": "Matematyka", "50": "Geografia"]
        let report = DirectAttendanceAnalyticsBuilder.build(rows, subjects: names)
        check("all marks included", report.summary.all.recorded == rows.count)
        check("all counters consistent", report.summary.all.consistent)
        check("present count", report.summary.all.present == 5)
        check("absence count", report.summary.all.absent == 3)
        check("late count", report.summary.all.late == 3)
        check("excused", report.summary.all.excused == 1)
        check("explicit unexcused", report.summary.all.explicitlyUnexcused == 1)
        check("unresolved absence", report.summary.all.absenceStatusUnknown == 1)
        check("distinct normalized calendar days only", report.summary.distinctDates == 3)
        check("subject totals conserved", report.summary.bySubject.reduce(0) { $0 + $1.counts.recorded } == rows.count)
        check("semester totals conserved", report.summary.bySemester.reduce(0) { $0 + $1.counts.recorded } == rows.count)
        check("month totals conserved", report.months.reduce(0) { $0 + $1.counts.recorded } == rows.count)
        check("cross totals conserved", report.subjectSemesters.reduce(0) { $0 + $1.counts.recorded } == rows.count)
        check("type totals conserved", report.types.reduce(0) { $0 + $1.count } == rows.count)
        check("two valid months plus invalid", report.months.map(\.month) == ["2026-10", "2026-11", nil])
        check("October three entries", report.months[0].counts.recorded == 3)
        check("November four entries", report.months[1].counts.recorded == 4)
        check("invalid one entry", report.months[2].counts.recorded == 1)
        check("cross three partitions", report.subjectSemesters.count == 3)
        check("cross math term1", report.subjectSemesters.contains { $0.subjectId == "42" && $0.semester == 1 && $0.counts.recorded == 3 })
        check("cross geography term2", report.subjectSemesters.contains { $0.subjectId == "50" && $0.semester == 2 && $0.counts.recorded == 4 })
        check("cross unknown separated", report.subjectSemesters.contains { $0.subjectId == nil && $0.semester == nil && $0.counts.recorded == 1 })
        check("types by server identity", report.types.contains { $0.typeId == "2" && $0.count == 3 })
        check("type unknown presence classification", report.types.contains { $0.typeId == "custom" && $0.isPresenceKind && $0.count == 1 })
        check("quality unresolved subject", report.quality.unresolvedSubjects == 1)
        check("quality missing term", report.quality.unknownSemesters == 1)
        check("quality missing lesson", report.quality.unknownLessonNumbers == 1)
        check("quality invalid day", report.quality.invalidDates == 1)
        check("quality duplicate slot diagnostic", report.quality.repeatedLessonSlots == 1)
        check("quality detects no contradictory type ID in record set", report.quality.inconsistentTypeIds == 0)
        check("quality cautions", report.quality.hasCautions)
        check("unknown month label", report.months[2].label == "Data nierozpoznana")
        check("cross labels", report.subjectSemesters.first { $0.subjectId == nil }?.semesterLabel == "Semestr nieustalony")
        let empty = DirectAttendanceAnalyticsBuilder.build([], subjects: [:])
        check("empty no records", empty.summary.all.recorded == 0)
        check("empty no types", empty.types.isEmpty)
        check("empty no months", empty.months.isEmpty)
        check("empty no cross", empty.subjectSemesters.isEmpty)
        check("empty no warnings", !empty.quality.hasCautions)

        let divergent = [mark("1", typeId: "same", type: "Obecność"),
                         mark("2", date: "2026-10-06", typeId: "same", type: "Nieobecność", present: false)]
        let divergentAnalysis = DirectAttendanceAnalyticsBuilder.build(divergent, subjects: [:])
        check("inconsistent type definitions flagged", divergentAnalysis.quality.inconsistentTypeIds == 1)
        check("inconsistent type definitions not merged", divergentAnalysis.types.count == 2)
        check("inconsistent types still counted", divergentAnalysis.summary.all.recorded == 2)

        check("all filter", DirectAttendanceFilter.select(rows).count == 8)
        check("semester 1", DirectAttendanceFilter.select(rows, semester: .numbered(1)).count == 3)
        check("semester 2", DirectAttendanceFilter.select(rows, semester: .numbered(2)).count == 4)
        check("semester unknown", DirectAttendanceFilter.select(rows, semester: .unspecified).map(\.id) == ["f"])
        check("semester nonexistent", DirectAttendanceFilter.select(rows, semester: .numbered(3)).isEmpty)
        check("subject math", DirectAttendanceFilter.select(rows, subject: .id("42")).count == 3)
        check("subject geography", DirectAttendanceFilter.select(rows, subject: .id("50")).count == 4)
        check("subject unknown", DirectAttendanceFilter.select(rows, subject: .unspecified).map(\.id) == ["f"])
        check("subject missing ID", DirectAttendanceFilter.select(rows, subject: .id("99")).isEmpty)
        check("status presence", DirectAttendanceFilter.select(rows, status: .present).count == 5)
        check("status absence", DirectAttendanceFilter.select(rows, status: .absent).count == 3)
        check("status late", DirectAttendanceFilter.select(rows, status: .late).count == 3)
        check("status excused", DirectAttendanceFilter.select(rows, status: .excused).map(\.id) == ["c"])
        check("status unexcused", DirectAttendanceFilter.select(rows, status: .explicitlyUnexcused).map(\.id) == ["e"])
        check("status undecided", DirectAttendanceFilter.select(rows, status: .unspecifiedAbsence).map(\.id) == ["d"])
        check("month October", DirectAttendanceFilter.select(rows, month: .yearMonth("2026-10")).count == 3)
        check("month November", DirectAttendanceFilter.select(rows, month: .yearMonth("2026-11")).count == 4)
        check("month invalid", DirectAttendanceFilter.select(rows, month: .invalid).map(\.id) == ["f"])
        check("month different year", DirectAttendanceFilter.select(rows, month: .yearMonth("2025-11")).isEmpty)
        check("multiple filters conjunctive", DirectAttendanceFilter.select(rows,
            semester: .numbered(2), subject: .id("50"), status: .absent, month: .yearMonth("2026-11")).map(\.id) == ["d", "e"])
        check("incompatible filters return empty", DirectAttendanceFilter.select(rows,
            semester: .numbered(1), subject: .id("50")).isEmpty)
        check("server custom presence remains presence", DirectAttendanceFilter.select(rows, status: .present).contains { $0.id == "f" })
        check("unknown status not classified unexcused", DirectAttendanceFilter.select(rows, status: .explicitlyUnexcused).allSatisfy { $0.typeName.localizedCaseInsensitiveContains("nieusprawiedliw") })

        let edgeTypes = [
            mark("1", type: "Nieobecność nieuspr.", present: false),
            mark("2", type: "Nieobecność uspr.", present: false),
            mark("3", type: "Nieobecność", present: false),
            mark("4", type: "Spóźnienie", present: false),
            mark("5", type: "Spóźnienie", present: true),
            mark("6", type: "Inny status", present: true)
        ]
        let edges = DirectAttendanceStatistics.count(edgeTypes)
        check("edge presence flag is authoritative", edges.present == 2 && edges.absent == 4)
        check("edge excuse negative first", edges.explicitlyUnexcused == 1)
        check("edge excuse positive", edges.excused == 1)
        check("edge excuse unclassified", edges.absenceStatusUnknown == 2)
        check("edge late must be present", edges.late == 1)
        check("edge identity all conserved", edges.consistent)
        check("filter late ignores absent late label", DirectAttendanceFilter.select(edgeTypes, status: .late).map(\.id) == ["5"])
        check("filter unspecified absence includes absent late", Set(DirectAttendanceFilter.select(edgeTypes, status: .unspecifiedAbsence).map(\.id)) == Set(["3", "4"]))

        // Integration fixtures: actual Gateway envelope shapes and school-defined type.
        let attendanceRoot: [String: Any] = ["Attendances": [
            ["Id": "t41685", "Date": "2026-10-09", "Lesson": ["Id": "77"], "LessonNo": "6",
             "Semester": "2", "Type": ["Id": "2"]],
            ["Id": 33, "Date": "2026-10-10", "Lesson": ["Id": 99], "LessonNo": true,
             "Semester": false, "Type": ["Id": 1685]],
            ["Id": 34, "Date": "2026-10-11", "Lesson": ["Id": 77], "LessonNo": "2x",
             "Semester": "3.0", "Type": ["Id": 3]]
        ]]
        let typesRoot: [String: Any] = ["Types": [
            ["Id": 2, "Name": "Spóźnienie", "IsPresenceKind": true],
            ["Id": 3, "Name": "Nieobecność uspr.", "IsPresenceKind": false],
            ["Id": 1685, "Name": "Pobyt w sanatorium", "IsPresenceKind": true]
        ]]
        let lessonsRoot: [String: Any] = ["Lessons": [
            ["Id": 77, "Subject": ["Id": 42]],
            ["Id": 99, "Subject": ["Id": 50]]
        ]]
        do {
            let decoded = try SynergiaAttendanceRecords.decode(attendances: attendanceRoot,
                types: typesRoot, lessons: lessonsRoot)
            check("Gateway IDs preserve strings and prefixed values", decoded.map(\.id) == ["t41685", "33", "34"])
            check("Gateway string lesson recognized", decoded[0].lessonNumber == 6)
            check("Gateway string semester recognized", decoded[0].semester == 2)
            check("Gateway boolean lesson rejected", decoded[1].lessonNumber == nil)
            check("Gateway boolean semester rejected", decoded[1].semester == nil)
            check("Gateway malformed lesson rejected", decoded[2].lessonNumber == nil)
            check("Gateway malformed semester rejected", decoded[2].semester == nil)
            check("Gateway lesson joins to subject", decoded.map(\.subjectId) == ["42", "50", "42"])
            check("Gateway custom type counts as presence", decoded[1].isPresenceKind && decoded[1].typeId == "1685")
            let gatewaySummary = DirectAttendanceAnalyticsBuilder.build(decoded, subjects: ["42":"Matematyka", "50":"Geografia"])
            check("Gateway analytics no phantom lessons", gatewaySummary.summary.all.recorded == 3)
            check("Gateway late included in presence", gatewaySummary.summary.all.present == 2 && gatewaySummary.summary.all.late == 1)
            check("Gateway excuse classified from name", gatewaySummary.summary.all.excused == 1)
            check("Gateway diagnostics missing lesson counts", gatewaySummary.quality.unknownLessonNumbers == 2)
            check("Gateway diagnostics missing semester counts", gatewaySummary.quality.unknownSemesters == 2)
        } catch { check("Gateway fixture decodes", false) }
        do {
            _ = try SynergiaAttendanceRecords.decode(attendances: ["Attendances": [["Id": 1,
                "Date": "2026-10-10", "Lesson": ["Id": 77], "Type": ["Id": 404]]]],
                types: typesRoot, lessons: lessonsRoot)
            check("Unknown type must fail closed", false)
        } catch AttendanceDecodeError.missingAttendanceType { check("Unknown type must fail closed", true) }
          catch { check("Unknown type must fail closed", false) }

        // Exhaustive, reproducible selection/aggregation conservation across all combinations.
        let semesters: [DirectAttendanceFilter.Semester] = [.all, .unspecified, .numbered(1), .numbered(2), .numbered(10)]
        let subjects: [DirectAttendanceFilter.Subject] = [.all, .unspecified, .id("42"), .id("50"), .id("not-there")]
        let months: [DirectAttendanceFilter.Month] = [.all, .invalid, .yearMonth("2026-10"), .yearMonth("2026-11")]
        for semester in semesters {
            for subject in subjects {
                for month in months {
                    let filtered = DirectAttendanceFilter.select(rows, semester: semester, subject: subject, month: month)
                    let report = DirectAttendanceAnalyticsBuilder.build(filtered, subjects: names)
                    check("matrix balances subject×semester/month", report.subjectSemesters.reduce(0) { $0 + $1.counts.recorded } == filtered.count &&
                        report.months.reduce(0) { $0 + $1.counts.recorded } == filtered.count &&
                        report.types.reduce(0) { $0 + $1.count } == filtered.count)
                }
            }
        }
        print("ATTENDANCE_ANALYTICS PASS=\(passed) FAIL=\(failed)")
        if failed > 0 { exit(1) }
    }
}
