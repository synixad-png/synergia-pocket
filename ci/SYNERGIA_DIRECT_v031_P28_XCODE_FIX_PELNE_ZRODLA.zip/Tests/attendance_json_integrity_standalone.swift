import Foundation
import CoreFoundation

@main struct AttendanceJSONIntegrityTests {
    static var passed = 0
    static var failed = 0
    static func check(_ label: String, _ result: @autoclosure () -> Bool) {
        if result() { passed += 1 } else { failed += 1; print("FAIL: \(label)") }
    }
    static func row(id: Any = "att-1", type: Any = 12, lesson: Any = 91,
                    date: Any = "2026-10-29", number: Any = 2, semester: Any = 1) -> [String: Any] {
        ["Id": id, "Date": date, "Lesson": ["Id": lesson],
         "Type": ["Id": type], "LessonNo": number, "Semester": semester]
    }
    static func decode(_ rows: [[String: Any]],
                       types: [[String: Any]] = [["Id": 12, "Name": "Obecność", "IsPresenceKind": true]],
                       lessons: [[String: Any]] = [["Id": 91, "Subject": ["Id": 4]]]) throws -> [DirectAttendance] {
        try SynergiaAttendanceRecords.decode(attendances: ["Attendances": rows],
            types: ["Types": types], lessons: ["Lessons": lessons])
    }
    static func isMalformed(_ input: [[String: Any]]) -> Bool {
        do { _ = try decode(input); return false }
        catch AttendanceDecodeError.malformedRecord { return true }
        catch { return false }
    }
    static func isMissingType(_ input: [[String: Any]], types: [[String: Any]]) -> Bool {
        do { _ = try decode(input, types: types); return false }
        catch AttendanceDecodeError.missingAttendanceType { return true }
        catch { return false }
    }
    static func main() {
        do {
            let decoded = try decode([row()]);
            check("baseline ID and subject", decoded[0].id == "att-1" && decoded[0].subjectId == "4")
            check("baseline classification", decoded[0].isPresenceKind && decoded[0].typeName == "Obecność")
            check("baseline lesson", decoded[0].lessonNumber == 2 && decoded[0].semester == 1)
        } catch { failed += 1; print("FAIL baseline: \(error)") }
        for (index, candidate) in [0, 1, NSNumber(value: 1), NSNumber(value: 0), NSNumber(value: 1.0),
                                    NSNumber(value: 2), "true", "false", NSNull(), 1.5, Double.nan].enumerated() {
            check("non-boolean flag rejected \(index)", isMissingType([row()],
                types: [["Id": 12, "Name": "Obecność", "IsPresenceKind": candidate]]))
        }
        for (index, flag) in [true, false].enumerated() {
            do {
                let results = try decode([row()], types: [["Id": 12, "Name": "Typ", "IsPresenceKind": flag]])
                check("real boolean \(index)", results[0].isPresenceKind == flag)
            } catch { check("real boolean \(index)", false) }
        }
        for (index, badId) in [true, false, 1.5, -2.25, Double.infinity, Double.nan,
                               "", "  ", NSNull()].enumerated() {
            check("malformed ID \(index)", isMalformed([row(id: badId)]))
            check("malformed lesson ref ID \(index)", isMalformed([row(lesson: badId)]))
            check("malformed type ref ID \(index)", isMalformed([row(type: badId)]))
        }
        for (index, badDate) in ["", "\t ", NSNull(), 0, true].enumerated() {
            check("malformed date \(index)", isMalformed([row(date: badDate)]))
        }
        for (index, typeName) in ["", "  ", "\t\n"].enumerated() {
            check("empty name refuses invented type \(index)", isMissingType([row()],
                types: [["Id": 12, "Name": typeName, "IsPresenceKind": true]]))
        }
        for (index, invalid) in [0, 1, "unknown", NSNull()].enumerated() {
            do {
                let result = try decode([row()], types: [
                    ["Id": 12, "Name": "Obecność", "IsPresenceKind": true],
                    ["Id": 22, "Name": "Unrelated", "IsPresenceKind": invalid]])
                check("unused bad type does not erase record \(index)", result.count == 1)
            } catch { check("unused bad type \(index)", false) }
        }
        for (index, pair) in [
            [["Id": 12, "Name": "Obecność", "IsPresenceKind": true], ["Id": 12, "Name": "", "IsPresenceKind": true]],
            [["Id": 12, "Name": "", "IsPresenceKind": true], ["Id": 12, "Name": "Obecność", "IsPresenceKind": true]],
            [["Id": 12, "Name": "Obecność", "IsPresenceKind": NSNumber(value: 1)], ["Id": 12, "Name": "Obecność", "IsPresenceKind": false]]
        ].enumerated() {
            do { _ = try decode([row()], types: pair); check("duplicate type \(index)", false) }
            catch AttendanceDecodeError.duplicateReference { check("duplicate type \(index)", true) }
            catch { check("duplicate type wrong error \(index)", false) }
        }
        do {
            _ = try decode([row(id: "1"), row(id: "1")])
            check("duplicate attendance rejected", false)
        } catch AttendanceDecodeError.duplicateRecord("1") {
            check("duplicate attendance rejected", true)
        } catch { check("duplicate attendance error", false) }
        do {
            let only = try decode([row(lesson: 999)])
            check("unresolved lesson subject not inferred", only.count == 1 && only[0].subjectId == nil)
        } catch { check("unresolved lesson fallback", false) }
        let labels: [AttendanceDecodeError] = [
            .malformedRoot("Attendances"), .malformedRecord(0), .duplicateRecord("1"),
            .duplicateReference("Type: 12"), .missingAttendanceType("12")
        ]
        for (index, failure) in labels.enumerated() {
            check("Polish error \(index)", (failure.errorDescription ?? "").contains("Nie ") ||
                  (failure.errorDescription ?? "").contains("Odczyt "))
            check("error does not reveal source id \(index)", !(failure.errorDescription ?? "").contains("Type: 12"))
        }
        for x in 0..<64 {
            let value: Any = x.isMultiple(of: 2) ? String(x) : x
            do {
                let parsed = try decode([row(id: value, type: 12, lesson: 91)])
                check("valid string/numeric ID \(x)", parsed[0].id == String(x))
            } catch { check("valid ID \(x)", false) }
        }
        // Exercise Foundation JSONSerialization, not only hand-created Swift dictionaries.
        for (index, literal) in ["true", "false", "1", "0", "null"].enumerated() {
            let document = """
            {"Attendances":[{"Id":"a","Date":"2026-10-05","Lesson":{"Id":1},"Type":{"Id":2}}],
             "Types":[{"Id":2,"Name":"Test","IsPresenceKind":\(literal)}],
             "Lessons":[{"Id":1,"Subject":{"Id":3}}]}
            """
            do {
                let data = Data(document.utf8)
                let root = try JSONSerialization.jsonObject(with: data) as! [String: Any]
                let parsed = try SynergiaAttendanceRecords.decode(attendances: root, types: root, lessons: root)
                check("JSONSerialization flag \(index)", index < 2 && parsed.count == 1 && parsed[0].isPresenceKind == (index == 0))
            } catch AttendanceDecodeError.missingAttendanceType {
                check("JSONSerialization flag \(index)", index >= 2)
            } catch { check("JSONSerialization flag \(index)", false) }
        }
        print("ATTENDANCE_JSON_INTEGRITY PASSED=\(passed) FAILED=\(failed)")
        if failed != 0 { exit(1) }
    }
}
