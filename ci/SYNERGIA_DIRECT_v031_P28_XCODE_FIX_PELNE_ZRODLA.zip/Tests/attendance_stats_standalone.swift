import Foundation

@main struct AttendanceStatsTests {
    static var pass = 0, fail = 0
    static func check(_ title: String, _ result: @autoclosure () -> Bool) {
        if result() { pass += 1; print("PASS " + title) }
        else { fail += 1; print("FAIL " + title) }
    }
    static func record(_ id: String, type: String, present: Bool,
                       subject: String? = "1", semester: Int? = 1,
                       date: String = "2026-10-05") -> DirectAttendance {
        DirectAttendance(id: id, date: date, lessonNumber: 1, semester: semester,
            lessonId: "22", subjectId: subject, typeId: id, typeName: type, isPresenceKind: present)
    }
    static func main() {
        let rows = [
            record("1", type: "Obecność", present: true),
            record("2", type: "Spóźnienie", present: true),
            record("3", type: "Nieobecność uspr.", present: false),
            record("4", type: "Nieobecność", present: false, subject: "2", semester: 2),
            record("5", type: "Nieusprawiedliwiona nieobecność", present: false, subject: "2", semester: nil),
            record("6", type: "Pobyt w sanatorium", present: true, subject: nil, semester: nil, date: "2026-10-06"),
            record("7", type: "SpOZnIeNiE", present: true, subject: "2", semester: 2)
        ]
        let s = DirectAttendanceStatistics.summarize(rows, subjects: ["1": "Matematyka", "2": "Biologia"])
        check("counts exhaustive", s.all.consistent)
        check("total", s.all.recorded == 7)
        check("presence", s.all.present == 4)
        check("absences", s.all.absent == 3)
        check("late belongs to presence", s.all.late == 2)
        check("excused from label", s.all.excused == 1)
        check("explicitly unexcused only", s.all.explicitlyUnexcused == 1)
        check("plain absence remains unknown", s.all.absenceStatusUnknown == 1)
        check("two distinct dates", s.distinctDates == 2)
        check("semester 1,2,unspecified", s.bySemester.map(\.label) == ["Semestr 1", "Semestr 2", "Semestr nieustalony"])
        check("semester totals", s.bySemester.map(\.counts.recorded) == [3,2,2])
        check("semester partitions exhaustive", s.bySemester.reduce(0) { $0 + $1.counts.recorded } == 7)
        check("subject partitions exhaustive", s.bySubject.reduce(0) { $0 + $1.counts.recorded } == 7)
        check("two named subjects and unknown", s.bySubject.count == 3)
        check("subject id preserved", s.bySubject.contains { $0.subjectId == "2" && $0.name == "Biologia" && $0.counts.absent == 2 })
        check("unknown subject distinct", s.bySubject.contains { $0.subjectId == nil && $0.counts.present == 1 })
        check("empty snapshot no inferred lessons", DirectAttendanceStatistics.summarize([], subjects: [:]).all.recorded == 0)
        check("empty summary consistent", DirectAttendanceStatistics.count([]).consistent)
        let custom = DirectAttendanceStatistics.count([
            record("1", type: "Niestandardowy status", present: false),
            record("2", type: "Obecność ale własny typ", present: true)])
        check("custom type uses server presence flag", custom.absent == 1 && custom.present == 1)
        check("custom unknown excuse", custom.absenceStatusUnknown == 1)
        check("not every present is late", custom.late == 0)
        let noData = DirectAttendanceStatistics.count([record("1", type: "Nieobecność", present: false)])
        check("plain absence not labeled unexcused", noData.explicitlyUnexcused == 0)
        print("ATTENDANCE_STATS PASS=\(pass) FAIL=\(fail)")
        if fail > 0 { exit(1) }
    }
}
