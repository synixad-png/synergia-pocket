import Foundation

@main struct AttendanceStatusSemanticsTests {
    static var pass = 0
    static var fail = 0
    static func expect(_ name: String, _ condition: @autoclosure () -> Bool) {
        if condition() { pass += 1 } else { fail += 1; print("FAIL: \(name)") }
    }
    static func mark(_ id: String, _ name: String, present: Bool) -> DirectAttendance {
        DirectAttendance(id: id, date: "2026-11-05", lessonNumber: 2, semester: 1,
                         lessonId: "lesson-\(id)", subjectId: "math", typeId: "type-\(id)",
                         typeName: name, isPresenceKind: present)
    }
    static func main() {
        let excused = ["Nieobecność usprawiedliwiona", "USPRAWIEDLIWIONA NIEOBECNOŚĆ", "Nieobecność uspr.",
                       "Nieobecność uspr", "Nieobecność usprawiedliwione", "Usprawiedliwiony wpis"]
        let unexcused = ["Nieusprawiedliwiona nieobecność", "NIEOBECNOŚĆ NIEUSPR.",
                         "Nieobecność nieuspr", "Nieusprawiedliwiony wpis"]
        let unresolved = ["Nieobecność", "Do usprawiedliwienia", "Oczekuje na usprawiedliwienie",
                          "Oczekuje na rozpatrzenie", "Prośba o usprawiedliwienie", "Wniosek o usprawiedliwienie",
                          "Brak usprawiedliwienia", "Bez usprawiedliwienia", "Usprawiedliwienie w toku",
                          "Usprawiedliwienie do akceptacji", "Usprawiedliwienie", "Nieobecność usprawiedliwienie",
                          "Własny status szkoły", "Usprawiedliwienia", "Usprawiedliwianie"]
        for label in excused {
            expect("explicit confirmed excuse: \(label)", DirectAttendanceStatus.excuse(label) == .excused)
        }
        for label in unexcused {
            expect("explicit refusal: \(label)", DirectAttendanceStatus.excuse(label) == .unexcused)
        }
        for label in unresolved {
            expect("unknown or pending, not confirmed: \(label)", DirectAttendanceStatus.excuse(label) == .unspecified)
        }
        // The status name must never override the school's IsPresenceKind flag.
        let variants = excused + unexcused + unresolved
        for (i, label) in variants.enumerated() {
            for serverPresence in [true, false] {
                let records = [mark("\(i)-\(serverPresence)", label, present: serverPresence)]
                let result = DirectAttendanceStatistics.count(records)
                expect("record conserved \(i)/\(serverPresence)", result.consistent && result.recorded == 1)
                expect("server kind wins \(i)/\(serverPresence)", result.present == (serverPresence ? 1 : 0))
                if !serverPresence {
                    let actual: DirectAttendanceStatus.Excuse = DirectAttendanceStatus.excuse(label)
                    expect("nonpresence breakdown agrees \(i)", (actual == .excused && result.excused == 1) ||
                           (actual == .unexcused && result.explicitlyUnexcused == 1) ||
                           (actual == .unspecified && result.absenceStatusUnknown == 1))
                } else {
                    expect("presence never enters excuse counts \(i)", result.excused == 0 &&
                           result.explicitlyUnexcused == 0 && result.absenceStatusUnknown == 0)
                }
            }
        }
        let mixed = variants.enumerated().map { mark("\($0.offset)", $0.element, present: false) }
        let counts = DirectAttendanceStatistics.count(mixed)
        expect("mixed partitions", counts.consistent && counts.recorded == variants.count)
        expect("mixed excused", counts.excused == excused.count)
        expect("mixed unexcused", counts.explicitlyUnexcused == unexcused.count)
        expect("mixed unresolved", counts.absenceStatusUnknown == unresolved.count)
        let excusedFiltered = DirectAttendanceFilter.select(mixed, status: .excused)
        let unresolvedFiltered = DirectAttendanceFilter.select(mixed, status: .unspecifiedAbsence)
        expect("filter confirmed only", excusedFiltered.count == excused.count)
        expect("filter unknown only", unresolvedFiltered.count == unresolved.count)
        expect("all entries accounted for", DirectAttendanceFilter.select(mixed).count == variants.count)
        print("P28_STATUS_SEMANTICS PASS=\(pass) FAIL=\(fail)")
        if fail > 0 { exit(1) }
    }
}
