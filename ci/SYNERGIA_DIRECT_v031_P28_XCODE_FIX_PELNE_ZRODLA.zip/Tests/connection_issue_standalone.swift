import Foundation

var tests = 0
func eq<T: Equatable>(_ actual: T, _ expected: T, _ name: String) {
    precondition(actual == expected, "FAILED \(name): \(actual) != \(expected)")
    tests += 1
}

for (code, issue) in [
    (401, DirectConnectionIssue.loginRequired),
    (403, .forbidden), (408, .timedOut), (429, .rateLimited),
    (503, .maintenance), (500, .serviceError(500)),
    (502, .serviceError(502)), (504, .serviceError(504)),
    (404, .serviceError(404)), (200, .serviceError(200)),
] {
    eq(DirectConnectionIssue.http(code), issue, "HTTP \(code)")
}

for (e, issue) in [
    (URLError(.notConnectedToInternet), DirectConnectionIssue.offline),
    (URLError(.timedOut), .timedOut),
    (URLError(.networkConnectionLost), .interrupted),
    (URLError(.cancelled), .interrupted),
    (URLError(.cannotConnectToHost), .unknown),
] {
    eq(DirectConnectionIssue.network(e), issue, "network \(e.code)")
}

eq(DirectConnectionIssue.network(NSError(domain: "other", code: URLError.timedOut.rawValue)), .unknown, "not URLError")
eq(DirectConnectionIssue.loginRequired.isAuthenticationProblem, true, "auth only")
eq(DirectConnectionIssue.forbidden.isAuthenticationProblem, false, "403 not logout")
eq(DirectConnectionIssue.rateLimited.isAuthenticationProblem, false, "429 not logout")
eq(DirectConnectionIssue.offline.isAuthenticationProblem, false, "offline not logout")
eq(DirectConnectionIssue.maintenance.canRetryReadManually, true, "later manual retry")
eq(DirectConnectionIssue.loginRequired.canRetryReadManually, false, "login instead of retry")
eq(DirectConnectionIssue.invalidResponse.canRetryReadManually, false, "unknown parsing not retry")
eq(DirectConnectionIssue.forbidden.canRetryReadManually, false, "forbidden not retry")
eq(DirectConnectionIssue.offline.canRetryReadManually, true, "network manual retry")
eq(DirectConnectionIssue.rateLimited.canRetryReadManually, true, "delayed manual retry")
eq(DirectConnectionIssue.serviceError(404).isAuthenticationProblem, false, "missing module not logout")
eq(DirectConnectionIssue.invalidResponse.message.isEmpty, false, "invalid response description")
eq(DirectConnectionIssue.loginRequired.message.contains("Zaloguj"), true, "login instruction")
eq(DirectConnectionIssue.offline.message.contains("wylogowanie"), false, "offline is not logout")

let gatewayURL = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Me")!
for (status, location, issue) in [
    (302, "/loguj/portalRodzina", DirectConnectionIssue.loginRequired),
    (303, "https://portal.librus.pl/rodzina/synergia/loguj", .loginRequired),
    (307, "https://api.librus.pl/OAuth/Authorization?client_id=46", .loginRequired),
    (301, "https://evil.example/loguj", .invalidResponse),
    (302, "http://synergia.librus.pl/loguj", .invalidResponse),
    (302, "/gateway/api/2.0/Me", .invalidResponse),
    (302, "https://portal.librus.pl.evil.example/loguj", .invalidResponse),
    (200, "/loguj", .invalidResponse),
    (302, "https://bad:pass@synergia.librus.pl/loguj", .invalidResponse),
] {
    eq(DirectConnectionIssue.redirect(status: status, location: location, from: gatewayURL), issue,
       "redirect \(status) \(location)")
}
eq(DirectConnectionIssue.redirect(status: 302, location: nil, from: gatewayURL), .invalidResponse,
   "missing redirect location")

print("DIRECT CONNECTION: \(tests)/\(tests) tests PASS")
