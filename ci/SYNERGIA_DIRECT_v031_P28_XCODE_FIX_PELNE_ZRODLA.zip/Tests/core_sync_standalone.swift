import Foundation

@main struct CoreSyncTests {
    static var checks = 0
    static func check(_ label: String, _ okay: @autoclosure () -> Bool) {
        precondition(okay(), label)
        checks += 1
        print("PASS " + label)
    }
    static func grade(_ id: String, _ value: String = "4", _ semester: Int? = 1) -> DirectGrade {
        DirectGrade(id: id, subjectId: "42", categoryId: nil, value: value,
                    semester: semester, addedAt: nil, commentTexts: [])
    }
    static func attendance(_ id: String, present: Bool = true) -> DirectAttendance {
        DirectAttendance(id: id, date: "2026-11-05", lessonNumber: 1, semester: 1,
            lessonId: "22", subjectId: "42", typeId: "1", typeName: present ? "Obecność" : "Nieobecność",
            isPresenceKind: present)
    }
    static func message(_ id: String, _ subject: String = "Temat") -> DirectMessage {
        DirectMessage(id: id, mailbox: .inbox, subject: subject, correspondent: "Nauczyciel",
                      sentAt: "2026-11-05", readAt: nil, preview: "Treść", hasAttachments: false)
    }
    static func inbox(_ ids: [String], account: String = "student-1", complete: Bool = true) -> DirectMailboxSnapshot {
        DirectMailboxSnapshot(mailbox: .inbox, messages: ids.map { message($0) }, total: ids.count,
            fetchedAt: Date(), accountId: account, messageSessionId: "session", complete: complete)
    }
    static func main() throws {
        let unchanged = try DirectCoreSyncAudit.compareGrades(previous: [grade("1"), grade("2")],
            current: [grade("2"), grade("1")])
        check("reordering grades is not a change", unchanged.added == 0 && unchanged.edited == 0 && unchanged.missing == 0)
        let g = try DirectCoreSyncAudit.compareGrades(previous: [grade("1"), grade("2")],
            current: [grade("1", "5"), grade("3")])
        check("new grade", g.added == 1)
        check("edited grade", g.edited == 1)
        check("missing grade only absent", g.missing == 1)
        let first = try DirectCoreSyncAudit.compareGrades(previous: [], current: [grade("1")])
        check("first baseline changes detected for reporting", first.added == 1)
        let empty = try DirectCoreSyncAudit.compareGrades(previous: [], current: [])
        check("empty grade snapshots", empty.added == 0 && empty.edited == 0 && empty.missing == 0)
        do {
            _ = try DirectCoreSyncAudit.compareGrades(previous: [grade("1"), grade("1")], current: [])
            fatalError("duplicate previous accepted")
        } catch CoreSyncComparisonError.duplicateID("1") { checks += 1; print("PASS duplicate previous grade rejected") }
        do {
            _ = try DirectCoreSyncAudit.compareGrades(previous: [], current: [grade("1"), grade("1")])
            fatalError("duplicate current accepted")
        } catch CoreSyncComparisonError.duplicateID("1") { checks += 1; print("PASS duplicate current grade rejected") }

        let a = try DirectCoreSyncAudit.compareAttendance(previous: [attendance("1"), attendance("2")],
            current: [attendance("2", present: false), attendance("3")])
        check("new attendance", a.added == 1)
        check("edited attendance", a.edited == 1)
        check("missing attendance only absent", a.missing == 1)
        let sameA = try DirectCoreSyncAudit.compareAttendance(previous: [attendance("1"), attendance("2")],
            current: [attendance("2"), attendance("1")])
        check("attendance reordering", sameA.added == 0 && sameA.edited == 0)
        do {
            _ = try DirectCoreSyncAudit.compareAttendance(previous: [attendance("1"), attendance("1")], current: [])
            fatalError("duplicate attendance accepted")
        } catch CoreSyncComparisonError.duplicateID("1") { checks += 1; print("PASS duplicate attendance rejected") }
        try DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(
            previous: [attendance("a")], incoming: [attendance("a"), attendance("b")])
        checks += 1; print("PASS attendance can grow")
        try DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(previous: [], incoming: [])
        checks += 1; print("PASS empty attendance baseline")
        do {
            try DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(
                previous: [attendance("a"), attendance("b")], incoming: [attendance("b")])
            fatalError("disappeared attendance accepted")
        } catch AttendanceCompletenessError.missingRecords(1) { checks += 1; print("PASS partial attendance blocked") }
        func supplemental(_ family: SupplementalGradeFamily, _ id: String, _ value: String) -> SupplementalGrade {
            SupplementalGrade(family: family, sourceId: id, subjectId: "42", value: value, semester: 1, addedAt: nil)
        }
        let oldExtra = [supplemental(.points, "1", "5/10"), supplemental(.text, "1", "Aktywność")]
        let newExtra = [supplemental(.points, "1", "8/10"), supplemental(.text, "1", "Aktywność"), supplemental(.descriptive, "2", "Dobrze")]
        let family = try DirectCoreSyncAudit.compareSupplemental(previous: oldExtra, current: newExtra)
        check("supplemental family names isolate equal IDs", family.added == 1 && family.edited == 1 && family.missing == 0)
        let oldReorder = try DirectCoreSyncAudit.compareSupplemental(previous: oldExtra, current: oldExtra.reversed())
        check("supplemental reorder unchanged", oldReorder.added == 0 && oldReorder.edited == 0)
        let missingFamily = try DirectCoreSyncAudit.compareSupplemental(previous: oldExtra, current: [oldExtra[0]])
        check("missing supplemental family detected", missingFamily.missing == 1)
        do {
            _ = try DirectCoreSyncAudit.compareSupplemental(previous: oldExtra, current: oldExtra + [oldExtra[0]])
            fatalError("duplicate supplemental accepted")
        } catch CoreSyncComparisonError.duplicateID("PointGrades:1") { checks += 1; print("PASS duplicate supplemental blocked") }
        let messages = try DirectCoreSyncAudit.compareInbox(previous: inbox(["m1", "m2"]), current: inbox(["m2", "m3"]))
        check("new message", messages.added == 1)
        check("missing message not deletion", messages.missing == 1)
        let reordered = try DirectCoreSyncAudit.compareInbox(previous: inbox(["m1", "m2"]), current: inbox(["m2", "m1"]))
        check("message reordering", reordered.added == 0 && reordered.missing == 0)
        do {
            _ = try DirectCoreSyncAudit.compareInbox(previous: inbox(["m1"], account: "a"), current: inbox(["m2"], account: "b"))
            fatalError("different accounts accepted")
        } catch CoreSyncComparisonError.differentAccount { checks += 1; print("PASS changed account rejected") }
        do {
            _ = try DirectCoreSyncAudit.compareInbox(previous: inbox(["m1"], complete: false), current: inbox(["m2"]))
            fatalError("incomplete baseline accepted")
        } catch CoreSyncComparisonError.incompleteMessages { checks += 1; print("PASS incomplete baseline rejected") }
        do {
            _ = try DirectCoreSyncAudit.compareInbox(previous: inbox(["m1"]), current: inbox(["m2"], complete: false))
            fatalError("incomplete current accepted")
        } catch CoreSyncComparisonError.incompleteMessages { checks += 1; print("PASS incomplete current rejected") }
        let sameM = try DirectCoreSyncAudit.compareInbox(previous: inbox([]), current: inbox([]))
        check("two complete empty inboxes", sameM.added == 0)

        let positive = CoreSyncChanges(newGrades: 1, editedGrades: 2, newAttendance: 3,
             editedAttendance: 1, newMessages: 2, disappearedGrades: 0,
             disappearedAttendance: 0, disappearedMessages: 0)
        check("positive change detection", positive.hasNews)
        let missingOnly = CoreSyncChanges(newGrades: 0, editedGrades: 0, newAttendance: 0,
             editedAttendance: 0, newMessages: 0, disappearedGrades: 2,
             disappearedAttendance: 3, disappearedMessages: 4)
        check("missing records not counted as news", !missingOnly.hasNews)
        func plan(consent: Bool = true, account: Bool = true,
                  gb: Bool = true, ab: Bool = true, mb: Bool = true,
                  gr: Bool = true, ar: Bool = true, mr: Bool = true,
                  deltas: CoreSyncChanges = positive) -> CoreLocalNotificationPlan {
            CoreLocalNotificationPlan.make(consent: consent, accountMatched: account,
              hadGradesBaseline: gb, hadAttendanceBaseline: ab, hadInboxBaseline: mb,
              gradesReliable: gr, attendanceReliable: ar, inboxReliable: mr, changes: deltas)
        }
        check("all three opt-in notifications", plan() == CoreLocalNotificationPlan(grades: true, attendance: true, messages: true))
        check("consent required", plan(consent: false) == .none)
        check("same account required", plan(account: false) == .none)
        check("no grade notification on first baseline", !plan(gb: false).grades)
        check("no attendance notification on first baseline", !plan(ab: false).attendance)
        check("no message notification on first baseline", !plan(mb: false).messages)
        check("unreliable grade read suppressed", !plan(gr: false).grades)
        check("unreliable attendance read suppressed", !plan(ar: false).attendance)
        check("incomplete inbox suppressed", !plan(mr: false).messages)
        check("missing-only no notifications", plan(deltas: missingOnly) == .none)
        let editedOnly = CoreSyncChanges(newGrades: 0, editedGrades: 1, newAttendance: 0,
            editedAttendance: 1, newMessages: 0, disappearedGrades: 0,
            disappearedAttendance: 0, disappearedMessages: 0)
        check("edited grades and attendance notify", plan(deltas: editedOnly) == CoreLocalNotificationPlan(grades: true, attendance: true, messages: false))
        let onlyMessage = CoreSyncChanges(newGrades: 0, editedGrades: 0, newAttendance: 0,
            editedAttendance: 0, newMessages: 1, disappearedGrades: 1,
            disappearedAttendance: 1, disappearedMessages: 1)
        check("only new messages notify", plan(deltas: onlyMessage) == CoreLocalNotificationPlan(grades: false, attendance: false, messages: true))
        check("no false notifications on zero", plan(deltas: CoreSyncChanges(newGrades: 0, editedGrades: 0, newAttendance: 0, editedAttendance: 0, newMessages: 0, disappearedGrades: 0, disappearedAttendance: 0, disappearedMessages: 0)) == .none)
        print("CORE_SYNC PASS \(checks)/\(checks)")
    }
}
