import Foundation

func check(_ passes: Bool, _ reason: String) {
    if !passes { fatalError("FAIL: " + reason) }
}
func permits(_ before: String?, _ now: String?, _ remoteStart: String,
             _ remoteEnd: String, _ accountEpoch: Bool = true,
             _ requestEpoch: Bool = true, _ visible: Bool = true) -> Bool {
    DirectAccountCommitPolicy.permits(verifiedAtStart: before, verifiedNow: now,
        remoteBefore: remoteStart, remoteAfter: remoteEnd,
        accountEpochUnchanged: accountEpoch,
        requestEpochUnchanged: requestEpoch, foregroundAndVisible: visible)
}
var cases = 0
func assertPermits(_ expected: Bool, _ a: String?, _ b: String?, _ c: String,
                   _ d: String, _ epoch: Bool = true,
                   _ request: Bool = true, _ visible: Bool = true) {
    check(permits(a,b,c,d,epoch,request,visible) == expected, "account isolation assertion \(cases)")
    cases += 1
}
assertPermits(true, "student-A", "student-A", "student-A", "student-A")
assertPermits(false, nil, "student-A", "student-A", "student-A")
assertPermits(false, "", "student-A", "student-A", "student-A")
assertPermits(false, "student-A", nil, "student-A", "student-A")
assertPermits(false, "student-A", "", "student-A", "student-A")
assertPermits(false, "student-A", "student-B", "student-A", "student-A")
assertPermits(false, "student-A", "student-A", "student-B", "student-B")
assertPermits(false, "student-A", "student-A", "student-A", "student-B")
assertPermits(false, "student-A", "student-A", "student-B", "student-A")
assertPermits(false, "student-A", "student-A", "student-A", "student-A", false)
assertPermits(false, "student-A", "student-A", "student-A", "student-A", true, false)
assertPermits(false, "student-A", "student-A", "student-A", "student-A", true, true, false)
let owners: [String?] = [nil, "", "A", "B", "C"]
for start in owners {
 for current in owners {
  for first in ["", "A", "B", "C"] {
   for last in ["", "A", "B", "C"] {
    for e in [false,true] {
     for r in [false,true] {
      for v in [false,true] {
       let expected = start != nil && start != "" && current == start &&
        first == start && last == start && e && r && v
       assertPermits(expected,start,current,first,last,e,r,v)
      }
     }
    }
   }
  }
 }
}
print("PASS: \(cases) account ownership/epoch/foreground permutations")
