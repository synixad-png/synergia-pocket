import Foundation

@main
struct AttachmentPolicyTests {
    static var good = 0
    static var bad = 0
    static func check(_ name: String, _ ok: @autoclosure () -> Bool) {
        if ok() { good += 1; print("PASS \(name)") }
        else { bad += 1; print("FAIL \(name)") }
    }
    static func ticket(_ value: [String: Any]) -> Bool {
        (try? DirectAttachmentPolicy.ticket(value)) != nil
    }
    static func main() {
        let cdn = "https://dl.example-cdn.net/secret/attachment.pdf?X-Token=abc%2Fxyz"
        check("signed CDN link accepted", DirectAttachmentPolicy.allowedDownloadURL(cdn) != nil)
        check("untrusted HTTP refused", DirectAttachmentPolicy.allowedDownloadURL("http://dl.example-cdn.net/file") == nil)
        check("embedded username refused", DirectAttachmentPolicy.allowedDownloadURL("https://alice@dl.example-cdn.net/file") == nil)
        check("embedded password refused", DirectAttachmentPolicy.allowedDownloadURL("https://alice:pass@dl.example-cdn.net/file") == nil)
        check("file URL refused", DirectAttachmentPolicy.allowedDownloadURL("file:///tmp/password") == nil)
        check("localhost refused", DirectAttachmentPolicy.allowedDownloadURL("https://localhost/file") == nil)
        check("local hostname refused", DirectAttachmentPolicy.allowedDownloadURL("https://printer.local/file") == nil)
        check("internal hostname refused", DirectAttachmentPolicy.allowedDownloadURL("https://gw.internal/file") == nil)
        check("numeric IPv4 refused", DirectAttachmentPolicy.allowedDownloadURL("https://192.168.0.1/file") == nil)
        check("numeric public IPv4 refused", DirectAttachmentPolicy.allowedDownloadURL("https://8.8.8.8/file") == nil)
        check("IPv6 refused", DirectAttachmentPolicy.allowedDownloadURL("https://[::1]/file") == nil)
        check("fragment refused", DirectAttachmentPolicy.allowedDownloadURL("https://dl.example-cdn.net/file#cookie") == nil)
        check("custom port refused", DirectAttachmentPolicy.allowedDownloadURL("https://dl.example-cdn.net:8080/file") == nil)
        check("repeated dot refused", DirectAttachmentPolicy.allowedDownloadURL("https://dl..example-cdn.net/file") == nil)
        check("trailing dot refused", DirectAttachmentPolicy.allowedDownloadURL("https://dl.example-cdn.net./file") == nil)
        check("HTTPS port 443 permitted", DirectAttachmentPolicy.allowedDownloadURL("https://dl.example-cdn.net:443/file") != nil)
        check("missing data object refused", !ticket(["downloadLink": cdn]))
        check("missing link refused", !ticket(["data": ["status": "success"]]))
        check("valid API ticket", ticket(["data": ["status": "success", "downloadLink": "https://sandbox.librus.pl/GetFile/abc123"]]))
        check("failed API ticket refused", !ticket(["data": ["status": "error", "downloadLink": "https://sandbox.librus.pl/GetFile/abc123"]]))
        check("bad URL API ticket refused", !ticket(["data": ["downloadLink": "http://localhost/file"]]))
        check("untrusted CDN ticket refused", !ticket(["data": ["downloadLink": cdn]]))
        check("archive holding page location", (try? DirectAttachmentPolicy.actualFileURL(URL(string: "https://sandbox.librus.pl/GetFile/abc123")!))?.path == "/GetFile/abc123/get")
        check("normal name", DirectAttachmentPolicy.safeFileName("oceny 2026.pdf"))
        check("Unicode filename", DirectAttachmentPolicy.safeFileName("załącznik.jpg"))
        check("path traversal refused", !DirectAttachmentPolicy.safeFileName("../hidden.txt"))
        check("Windows traversal refused", !DirectAttachmentPolicy.safeFileName("..\\hidden.txt"))
        check("hidden filename refused", !DirectAttachmentPolicy.safeFileName(".config"))
        check("control char refused", !DirectAttachmentPolicy.safeFileName("name\n.txt"))
        check("size bound", DirectAttachmentPolicy.maxBytes == 15_000_000 && DirectAttachmentPolicy.maxSessionBytes == 60_000_000)
        print("TOTAL PASS=\(good) FAIL=\(bad)")
        if bad > 0 { exit(1) }
    }
}
