import Foundation

@main
struct ComposeStandaloneTests {
    static var passed = 0
    static var failed = 0
    static func check(_ label: String, _ operation: () throws -> Bool) {
        do {
            if try operation() { passed += 1; print("PASS \(label)") }
            else { failed += 1; print("FAIL \(label)") }
        } catch { failed += 1; print("FAIL \(label): \(error)") }
    }
    static func rejects(_ expected: DirectComposeError, _ action: () throws -> Any) -> Bool {
        do { _ = try action(); return false }
        catch let error as DirectComposeError { return error == expected }
        catch { return false }
    }
    static let groupJSON: [String: Any] = ["data": ["defaultGroup": "teachers", "list": [
        ["id":"teachers", "name": "Nauczyciele"],
        ["id":"tutors", "name": "Wychowawcy"],
        ["id":"parentsCouncil", "name": "Rada Rodziców"],
        ["id":"sadmin", "name": "Administrator"]
    ]]]
    static let membersJSON: [String: Any] = ["receivers": [
        ["accountId":"LID-123", "label":"Anna Nauczycielka", "availabilityStatus":["isAvailable":true]],
        ["accountId":"LID-456", "label":"Jan Zastępca", "availabilityStatus":["isAvailable":false]],
        ["accountId":"LID-789", "label":"Sekretariat"]
    ]]
    static let group = DirectRecipientGroup(id: "teachers", name: "Nauczyciele")
    static func list(_ account: String = "child1", session: String = "parent1") throws -> DirectRecipientListSnapshot {
        try DirectMessageCompose.recipients(membersJSON, group: group, accountId: account, messageSessionId: session)
    }
    static func valid(_ subject: String = "Sprawa szkolna", _ body: String = "Dzień dobry\nTest <>&") throws -> DirectValidatedDraft {
        let listed = try list()
        return try DirectMessageCompose.draft(recipient: listed.recipients[0], listed: listed,
                                              accountId: "child1", subject: subject, text: body)
    }
    static func main() {
        check("grupy odbiorców zgodne z formatem 2026") {
            let groups = try DirectMessageCompose.groups(groupJSON, accountId:"child1", messageSessionId:"parent1")
            return groups.groups == [group, DirectRecipientGroup(id:"tutors", name:"Wychowawcy")]
        }
        check("grupy innego konta nie są akceptowane") {
            rejects(.unexpectedShape) { try DirectMessageCompose.groups(groupJSON, accountId:"", messageSessionId:"parent1") }
        }
        check("sesja wiadomości jest wymagana") {
            rejects(.unexpectedShape) { try DirectMessageCompose.groups(groupJSON, accountId:"child1", messageSessionId:"../root") }
        }
        check("brak data list odrzucany") {
            rejects(.unexpectedShape) { try DirectMessageCompose.groups(["data": [:]], accountId:"x", messageSessionId:"y") }
        }
        check("duplikat grup odrzucany") {
            let json: [String: Any] = ["data":["list":[["id":"teachers", "name":"A"],["id":"teachers", "name":"B"]]]]
            return rejects(.duplicateIdentifier) { try DirectMessageCompose.groups(json, accountId:"x", messageSessionId:"y") }
        }
        check("złe ID grupy odrzucane") {
            let json: [String:Any] = ["data":["list":[["id":"../../bad", "name":"A"]]]]
            return rejects(.unsafeIdentifier) { try DirectMessageCompose.groups(json, accountId:"x", messageSessionId:"y") }
        }
        check("odbiorcy i statusy dostępności") {
            let l = try list()
            return l.recipients.count == 3 && l.recipients[0].available == true &&
                l.recipients[1].available == false && l.recipients[2].available == nil
        }
        check("pusta grupa jest poprawna") {
            let l = try DirectMessageCompose.recipients(["receivers": []], group: group, accountId:"x", messageSessionId:"y")
            return l.recipients.isEmpty
        }
        check("nieprawidłowy format odbiorców odrzucony") {
            rejects(.unexpectedShape) { try DirectMessageCompose.recipients(["data":[]], group: group, accountId:"x", messageSessionId:"y") }
        }
        check("powtórzony odbiorca odrzucony") {
            let row = ["accountId":"A", "label":"Anna"]
            return rejects(.duplicateIdentifier) { try DirectMessageCompose.recipients(["receivers":[row,row]], group: group, accountId:"x", messageSessionId:"y") }
        }
        check("id z ukośnikiem odrzucone") {
            rejects(.unsafeIdentifier) {
                try DirectMessageCompose.recipients(["receivers":[["accountId":"../bad", "label":"A"]]], group: group, accountId:"x", messageSessionId:"y")
            }
        }
        check("niedostępny odbiorca nie może otrzymać wiadomości") {
            let l = try list()
            return rejects(.unavailableRecipient) { try DirectMessageCompose.draft(recipient:l.recipients[1],listed:l,accountId:"child1",subject:"temat",text:"wiadomość") }
        }
        check("brak odbiorcy zostaje odrzucony") {
            rejects(.missingRecipient) { try DirectMessageCompose.draft(recipient:nil,listed:nil,accountId:"child1",subject:"temat",text:"tekst") }
        }
        check("inny uczeń nie może użyć listy poprzedniego") {
            let l = try list()
            return rejects(.staleSession) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child2",subject:"temat",text:"tekst") }
        }
        check("odbiorca spoza listy odrzucony") {
            let l = try list()
            let forged = DirectRecipient(id:"LID-Z",name:"Nieznany",groupId:"teachers",available:true)
            return rejects(.staleSession) { try DirectMessageCompose.draft(recipient:forged,listed:l,accountId:"child1",subject:"temat",text:"tekst") }
        }
        check("pusty temat odrzucony") {
            let l = try list()
            return rejects(.emptySubject) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child1",subject:"  ",text:"tekst") }
        }
        check("pusta treść odrzucona") {
            let l = try list()
            return rejects(.emptyText) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child1",subject:"temat",text:"  ") }
        }
        check("limit tematu") {
            let l = try list()
            return rejects(.tooLong) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child1",subject:String(repeating:"x",count:201),text:"tekst") }
        }
        check("limit treści") {
            let l = try list()
            return rejects(.tooLong) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child1",subject:"temat",text:String(repeating:"x",count:10001)) }
        }
        check("polskie znaki i białe znaki w draft") {
            let d = try valid("  Żółć  ", "  Dzień dobry!  ")
            return d.subject == "Żółć" && d.text == "Dzień dobry!" && d.messageSessionId == "parent1"
        }
        check("białe znaki nie są wysyłane jako pusty temat") {
            let l = try list()
            return rejects(.emptySubject) { try DirectMessageCompose.draft(recipient:l.recipients[0],listed:l,accountId:"child1",subject:"\n\t",text:"treść") }
        }
        check("HTML jest escapowany, nowe linie zachowane") {
            let escaped = DirectMessageCompose.htmlEscapedBody("<img onerror='x'>&\nDzień\r\nDobry")
            return escaped == "&lt;img onerror=&#39;x&#39;&gt;&amp;<br>Dzień<br>Dobry"
        }
        check("nowa wiadomość ma wymagany payload") {
            let p = DirectMessageCompose.payload(try valid())
            let receiver = ((p["receivers"] as? [String:Any])?["schoolReceivers"] as? [[String:String]])?.first?["accountId"]
            let subject = Data(base64Encoded:p["topic"] as! String).flatMap { String(data:$0,encoding:.utf8) }
            let content = Data(base64Encoded:p["content"] as! String).flatMap { String(data:$0,encoding:.utf8) }
            return receiver == "LID-123" && subject == "Sprawa szkolna" &&
                content == "Dzień dobry<br>Test &lt;&gt;&amp;" && p["originalMessageId"] == nil &&
                p["storageId"] is NSNull && p["category"] as? String == "normal"
        }
        check("odpowiedź z prawdziwym ID wątku") {
            let reply = DirectReplyContext(originalMessageId:"12345",originalSenderId:"LID-SENDER",subject:"Termin",recipientName:"Nauczyciel",accountId:"child1",messageSessionId:"parent1")
            let d = try DirectMessageCompose.draft(recipient:nil,listed:nil,accountId:"child1",subject:"Re: Termin",text:"Dziękuję",reply:reply)
            return d.originalMessageId == 12345 && (DirectMessageCompose.payload(d)["originalMessageId"] as? Int) == 12345
        }
        check("odpowiedź z nie-numerycznym ID odrzucona") {
            let r = DirectReplyContext(originalMessageId:"LID-bad",originalSenderId:"sender",subject:"t",recipientName:"x",accountId:"child1",messageSessionId:"parent1")
            return rejects(.replyNotAllowed) { try DirectMessageCompose.draft(recipient:nil,listed:nil,accountId:"child1",subject:"t",text:"text",reply:r) }
        }
        check("odpowiedź innego dziecka odrzucona") {
            let r = DirectReplyContext(originalMessageId:"12",originalSenderId:"sender",subject:"t",recipientName:"x",accountId:"child2",messageSessionId:"parent1")
            return rejects(.replyNotAllowed) { try DirectMessageCompose.draft(recipient:nil,listed:nil,accountId:"child1",subject:"t",text:"text",reply:r) }
        }
        check("odpowiedź ze złym nadawcą odrzucona") {
            let r = DirectReplyContext(originalMessageId:"12",originalSenderId:"../../",subject:"t",recipientName:"x",accountId:"child1",messageSessionId:"parent1")
            return rejects(.replyNotAllowed) { try DirectMessageCompose.draft(recipient:nil,listed:nil,accountId:"child1",subject:"t",text:"text",reply:r) }
        }
        check("parser: możliwość odpowiedzi tylko przy noReply=0") {
            let entry: [String:Any] = ["messageId":"123", "senderId":"LID-OK", "senderName":"Anna", "topic":"Temat", "Message":"SGVsbG8=", "noReply":0, "attachments":[]]
            let d = try DirectMessageParser.detail(["data":entry],mailbox:.inbox,requestedId:"123")
            return d.replyAllowed && d.senderId == "LID-OK"
        }
        check("parser: noReply=1 odcina odpowiedź") {
            let entry: [String:Any] = ["messageId":"123", "senderId":"LID-OK", "senderName":"Anna", "topic":"Temat", "Message":"SGVsbG8=", "noReply":1, "attachments":[]]
            let d = try DirectMessageParser.detail(["data":entry],mailbox:.inbox,requestedId:"123")
            return !d.replyAllowed
        }
        check("parser: brak noReply odcina odpowiedź") {
            let entry: [String:Any] = ["messageId":"123", "senderId":"LID-OK", "senderName":"Anna", "topic":"Temat", "Message":"SGVsbG8=", "attachments":[]]
            return try !DirectMessageParser.detail(["data":entry],mailbox:.inbox,requestedId:"123").replyAllowed
        }
        check("parser: filename jako nazwa załącznika") {
            let entry: [String:Any] = ["messageId":"123", "senderName":"Anna", "topic":"Temat", "Message":"SGVsbG8=", "attachments":[["id":"1", "filename":"zadanie.pdf"]]]
            return try DirectMessageParser.detail(["data":entry],mailbox:.inbox,requestedId:"123").attachments.first?.name == "zadanie.pdf"
        }
        check("parser: obcięty podgląd UTF-8 nie usuwa wiadomości") {
            let badEnding = Data([0x61,0x62,0xF0,0x9F]).base64EncodedString()
            let m: [String:Any] = ["messageId":"3", "senderName":"Anna", "topic":"Temat", "content":badEnding]
            return try DirectMessageParser.list(["data":[m],"total":1],mailbox:.inbox).messages.count == 1
        }
        check("serwer potwierdza 201 i identyfikator") {
            let payload = Data("{\"data\":{\"messageId\":1234,\"status\":\"sent\"}}".utf8)
            return DirectSendResponse.evaluate(status:201,data:payload) == .sent(messageId:"1234")
        }
        check("potwierdzenie odpowiedzi bez ID") {
            DirectSendResponse.evaluate(status:200,data:Data()) == .sent(messageId:nil)
        }
        check("400 oznacza odmowę, nie niepewność") {
            if case .refused = DirectSendResponse.evaluate(status:400,data:Data()) { return true }
            return false
        }
        check("401 oznacza odmowę, nie niepewność") {
            if case .refused = DirectSendResponse.evaluate(status:401,data:Data()) { return true }
            return false
        }
        check("500 oznacza niepewność, nie sukces") {
            if case .uncertain = DirectSendResponse.evaluate(status:500,data:Data()) { return true }
            return false
        }
        check("429 oznacza niepewność") {
            if case .uncertain = DirectSendResponse.evaluate(status:429,data:Data()) { return true }
            return false
        }
        check("JSON sukcesu z errors jest niepewny") {
            if case .uncertain = DirectSendResponse.evaluate(status:201,data:Data("{\"errors\":[\"Nope\"]}".utf8)) { return true }
            return false
        }
        check("nieznane dane HTTP 201 są niepewne") {
            if case .uncertain = DirectSendResponse.evaluate(status:201,data:Data("<html>".utf8)) { return true }
            return false
        }
        check("niestandardowy status data jest niepewny") {
            if case .uncertain = DirectSendResponse.evaluate(status:201,data:Data("{\"data\":{\"status\":\"error\"}}".utf8)) { return true }
            return false
        }
        check("niepotwierdzony 202 nie oznacza wysłania") {
            if case .uncertain = DirectSendResponse.evaluate(status:202,data:Data()) { return true }
            return false
        }
        print("TOTAL PASS=\(passed) FAIL=\(failed)")
        if failed > 0 { exit(1) }
    }
}
