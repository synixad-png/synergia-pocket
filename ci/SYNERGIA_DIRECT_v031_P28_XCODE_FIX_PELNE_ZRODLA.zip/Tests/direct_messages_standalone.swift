import Foundation

@main
struct MessageStandaloneTest {
    static var passed = 0
    static var failed = 0
    static func test(_ label: String, _ action: () throws -> Bool) {
        do {
            if try action() { passed += 1; print("PASS \(label)") }
            else { failed += 1; print("FAIL \(label)") }
        } catch {
            failed += 1; print("FAIL \(label): \(error)")
        }
    }
    static func rejects(_ code: DirectMessageError, _ action: () throws -> Any) -> Bool {
        do { _ = try action(); return false }
        catch let error as DirectMessageError { return error == code }
        catch { return false }
    }
    static func inbox(_ id: String = "123", content: String = "SGVsbG8g8J+Riw==") -> [String: Any] {
        ["messageId": id, "senderName": "Nauczyciel", "topic": "Temat", "content": content,
         "sendDate": "2026-11-05", "readDate": NSNull(), "isAnyFileAttached": true]
    }
    static func outbox(_ id: String = "123") -> [String: Any] {
        ["messageId": id, "receiverName": "Szkoła", "topic": "Odpowiedź",
         "content": "VHJlxZvEhw==", "sendDate": "2026-11-05", "isAnyFileAttached": false]
    }
    static func detail(_ id: String = "123") -> [String: Any] {
        ["messageId": id, "senderName": "Nauczyciel", "topic": "Temat",
         "Message": "VHJlxZvEhyB3aWFkb21vxZvEhw==", "sendDate": "2026-11-05",
         "attachments": [["id": "a-12", "name": "zadanie.pdf", "size": 1536]]]
    }
    static func main() {
        test("odczyt odebranych i Base64") {
            let page = try DirectMessageParser.list(["data": [inbox()], "total": 1], mailbox: .inbox)
            return page.messages.count == 1 && page.messages[0].preview == "Hello 👋" && page.messages[0].hasAttachments
        }
        test("odczyt wysłanych") {
            let p = try DirectMessageParser.list(["data": [outbox()], "total": 1], mailbox: .outbox)
            return p.messages[0].correspondent == "Szkoła"
        }
        test("nazwa z imienia i nazwiska") {
            var m = inbox(); m.removeValue(forKey: "senderName"); m["senderFirstName"] = "Jan"; m["senderLastName"] = "Nowak"
            return try DirectMessageParser.list(["data": [m], "total": 1], mailbox: .inbox).messages[0].correspondent == "Jan Nowak"
        }
        test("pełna treść i załącznik") {
            let d = try DirectMessageParser.detail(["data": detail()], mailbox: .inbox, requestedId: "123")
            return d.body == "Treść wiadomość" && d.attachments[0].sizeBytes == 1536
        }
        test("odmowa obcego identyfikatora") {
            rejects(.invalidRecord) { try DirectMessageParser.detail(["data": detail()], mailbox: .inbox, requestedId: "999") }
        }
        test("odmowa ścieżki jako identyfikatora") {
            rejects(.unexpectedShape) { try DirectMessageParser.detail(["data": detail()], mailbox: .inbox, requestedId: "../a") }
        }
        test("zły format odpowiedzi") {
            rejects(.unexpectedShape) { try DirectMessageParser.list(["messages": [inbox()]], mailbox: .inbox) }
        }
        test("pusty temat") {
            var m = inbox(); m["topic"] = "   "
            return rejects(.invalidRecord) { try DirectMessageParser.list(["data": [m]], mailbox: .inbox) }
        }
        test("niepoprawne Base64") {
            rejects(.invalidBase64) { try DirectMessageParser.list(["data": [inbox(content: "@!@")]], mailbox: .inbox) }
        }
        test("brak treści w szczegółach") {
            var d = detail(); d.removeValue(forKey: "Message")
            return rejects(.invalidRecord) { try DirectMessageParser.detail(["data": d], mailbox: .inbox, requestedId: "123") }
        }
        test("znacznik total typu bool") {
            rejects(.invalidTotal) { try DirectMessageParser.list(["data": [inbox()], "total": true], mailbox: .inbox) }
        }
        test("total mniejszy niż dane") {
            rejects(.invalidTotal) { try DirectMessageParser.list(["data": [inbox()], "total": 0], mailbox: .inbox) }
        }
        test("duplikat w jednej odpowiedzi") {
            rejects(.duplicateIdentifier) { try DirectMessageParser.list(["data": [inbox(), inbox()], "total": 2], mailbox: .inbox) }
        }
        test("duplikat między stronami") {
            let full = (1...50).map { inbox(String($0)) }
            let p1 = try! DirectMessageParser.list(["data": full], mailbox: .inbox)
            let p2 = try! DirectMessageParser.list(["data": [inbox("1")]], mailbox: .inbox)
            return rejects(.duplicateIdentifier) { try DirectMessageParser.merge([p1,p2], mailbox: .inbox, accountId: "A") }
        }
        test("licznik niezmienny między stronami") {
            let full = (1...50).map { inbox(String($0)) }
            let p1 = try! DirectMessageParser.list(["data": full, "total": 51], mailbox: .inbox)
            let p2 = try! DirectMessageParser.list(["data": [inbox("51")], "total": 52], mailbox: .inbox)
            return rejects(.invalidTotal) { try DirectMessageParser.merge([p1,p2], mailbox: .inbox, accountId: "A") }
        }
        test("niepełny odczyt nie przechodzi") {
            let p = try! DirectMessageParser.list(["data": [inbox("1")], "total": 2], mailbox: .inbox)
            return rejects(.incompleteMailbox) { try DirectMessageParser.merge([p], mailbox: .inbox, accountId: "A") }
        }
        test("pełne zero ma poprawny licznik") {
            let p = try DirectMessageParser.list(["data": [[String: Any]](), "total": 0], mailbox: .inbox)
            let snap = try DirectMessageParser.merge([p], mailbox: .inbox, accountId: "A")
            return snap.complete && snap.messages.isEmpty
        }
        test("pusta skrzynka bez licznika = niepotwierdzona") {
            let p = try DirectMessageParser.list(["data": [[String: Any]]()], mailbox: .inbox)
            return try !DirectMessageParser.merge([p], mailbox: .inbox, accountId: "A").complete
        }
        test("odmowa łączenia kont bez ID") {
            let p = try! DirectMessageParser.list(["data": [[String: Any]]()], mailbox: .inbox)
            return rejects(.incompleteMailbox) { try DirectMessageParser.merge([p], mailbox: .inbox, accountId: "") }
        }
        test("odmowa mieszania skrzynek") {
            let p = try! DirectMessageParser.list(["data": [outbox()]], mailbox: .outbox)
            return rejects(.unexpectedShape) { try DirectMessageParser.merge([p], mailbox: .inbox, accountId: "A") }
        }
        test("bezpieczne identyfikatory") {
            DirectMessageParser.safeIdentifier("ab_3-XYZ") &&
            !DirectMessageParser.safeIdentifier("a/b") && !DirectMessageParser.safeIdentifier("a?x=1")
        }
        test("ścieżki w nazwie załącznika odrzucone") {
            var d = detail(); d["attachments"] = [["id": "12", "name": "../password.txt"]]
            return rejects(.invalidRecord) { try DirectMessageParser.detail(["data": d], mailbox: .inbox, requestedId: "123") }
        }
        test("duplikat identyfikatora załącznika") {
            var d = detail(); d["attachments"] = [["id": "1", "name": "x.pdf"], ["id": "1", "name": "y.pdf"]]
            return rejects(.duplicateIdentifier) { try DirectMessageParser.detail(["data": d], mailbox: .inbox, requestedId: "123") }
        }
        test("flaga false nie oznacza pliku") {
            let p = try DirectMessageParser.list(["data": [outbox()]], mailbox: .outbox)
            return !p.messages[0].hasAttachments
        }
        test("nieznany rozmiar załącznika jest dozwolony") {
            var d = detail(); d["attachments"] = [["id": "123", "name": "foto.png"]]
            return try DirectMessageParser.detail(["data": d], mailbox: .inbox, requestedId: "123").attachments[0].sizeBytes == nil
        }
        print("TOTAL PASS=\(passed) FAIL=\(failed)")
        if failed > 0 { exit(1) }
    }
}
