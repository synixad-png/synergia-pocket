import Foundation

var checked = 0
func expect(_ condition: @autoclosure () -> Bool, _ explanation: String) {
    checked += 1
    if !condition() { fputs("FAIL [\(checked)]: \(explanation)\n", stderr); exit(1) }
}
let stamp = Date(timeIntervalSince1970: 1_790_000_000)
func state(_ verified: Bool, _ loading: Bool, _ failed: Bool, _ count: Int?,
           _ saved: Date?, _ complete: Bool, _ match: Bool = true) -> DirectReadPresentation {
    DirectReadPresentation.evaluate(verified: verified, loading: loading, failed: failed,
                                    count: count, capturedAt: saved, complete: complete, accountMatches: match)
}
expect(state(false, false, false, 24, stamp, true).kind == .locked, "no account cannot expose saved grade")
expect(state(true, false, false, 24, stamp, true, false).kind == .locked, "wrong account locked")
expect(state(true, true, false, 24, stamp, true).kind == .loading, "loading overrides valid snapshot")
expect(state(true, true, true, 24, stamp, false).kind == .loading, "loading overrides previous error")
expect(state(true, false, true, 24, stamp, true).kind == .stale, "failed refresh has old snapshot")
expect(state(true, false, true, nil, nil, false).kind == .failed, "failed before first read")
expect(state(true, false, false, nil, nil, true).kind == .notRequested, "no data cannot say empty")
expect(state(true, false, false, 0, stamp, false).kind == .partial, "empty without counter not confirmed")
expect(state(true, false, false, 0, stamp, true).kind == .empty, "empty with counter")
expect(state(true, false, false, 4, stamp, true).kind == .available, "full reported page")
expect(state(true, false, false, 4, stamp, false).kind == .partial, "number unknown")
expect(state(true, false, false, 4, nil, true).kind == .notRequested, "no timestamp not loaded")
expect(DirectReadPresentation.evaluate(verified: true, loading: false, failed: false,
    count: 4, capturedAt: stamp, complete: true, fresh: false).kind == .stale,
    "disk snapshot is stale until current-session read")
expect(DirectReadPresentation.evaluate(verified: true, loading: false, failed: false,
    count: 0, capturedAt: stamp, complete: true, fresh: false).kind == .stale,
    "old zero is not confirmed empty now")
expect(DirectReadPresentation.evaluate(verified: true, loading: true, failed: false,
    count: 4, capturedAt: stamp, complete: true, fresh: false).kind == .loading,
    "freshness does not override loading")
expect(state(false, true, true, 4, stamp, true).count == nil, "locked state hides count")
expect(state(false, true, true, 4, stamp, true).capturedAt == nil, "locked state hides timestamp")
for verified in [false, true] {
    for match in [false, true] {
        for loading in [false, true] {
            for failed in [false, true] {
                for complete in [false, true] {
                    for hasDate in [false, true] {
                        for hasCount in [false, true] {
                            let s = state(verified, loading, failed, hasCount ? 7 : nil,
                                          hasDate ? stamp : nil, complete, match)
                            if !verified || !match {
                                expect(s.kind == .locked && s.count == nil && s.capturedAt == nil,
                                       "locked for all state combinations")
                            } else if loading {
                                expect(s.kind == .loading, "busy for all state combinations")
                            } else if failed {
                                expect(s.kind == (hasDate ? .stale : .failed), "typed failure priority")
                            } else if !hasDate || !hasCount {
                                expect(s.kind == .notRequested, "no proof of read")
                            } else {
                                expect(s.kind == (complete ? .available : .partial), "fetched unknown completeness")
                            }
                            expect(!s.kind.title.isEmpty && !s.kind.guidance.isEmpty && !s.kind.symbol.isEmpty,
                                   "accessible label is never empty")
                        }
                    }
                }
            }
        }
    }
}
print("DIRECT READ PRESENTATION PASS: \(checked)/\(checked)")
