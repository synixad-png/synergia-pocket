import Foundation

var count = 0
func ensure(_ condition: @autoclosure () -> Bool, _ message: String) {
    count += 1
    if !condition() { fputs("FAIL: \(message)\n", stderr); exit(1) }
}

var policy = DirectSessionLifecyclePolicy()
ensure(!policy.isClearing, "default no cleanup")
ensure(!policy.verificationInFlight, "default no verification")
ensure(policy.beginVerification(), "first /Me permitted")
ensure(!policy.beginVerification(), "duplicate /Me rejected")
ensure(!policy.isClearing, "verification does not imply cleanup")
policy.finishVerification()
ensure(policy.beginVerification(), "verification permitted after completion")
ensure(policy.beginCleanup(), "cleanup begins during verification")
ensure(!policy.verificationInFlight, "cleanup invalidates previous /Me")
ensure(policy.isClearing, "cleanup state visible")
ensure(!policy.beginVerification(), "/Me rejected during purge")
ensure(!policy.beginCleanup(), "duplicate sign-out ignored")
policy.cancelVerification()
ensure(policy.isClearing, "navigation cannot cancel cleanup")
policy.finishCleanup()
ensure(policy.beginVerification(), "new /Me permitted only after purge callback")
policy.cancelVerification()
ensure(!policy.verificationInFlight, "navigation cancels pending verification")
ensure(policy.beginVerification(), "trusted page may start new /Me after navigation")
policy.finishVerification()
ensure(!policy.verificationInFlight, "completion releases the single-flight gate")

// Model-check all interleavings of verification, navigation, cleanup and callback.
// The independent model uses two Booleans, not the policy's methods.
for seed in 1...512 {
    var state = DirectSessionLifecyclePolicy()
    var expectedVerifying = false
    var expectedClearing = false
    var prng = UInt32(seed)
    for step in 1...32 {
        prng = prng &* 1664525 &+ 1013904223
        let event = Int((prng >> 16) % 5)
        switch event {
        case 0:
            let allowed = !expectedVerifying && !expectedClearing
            ensure(state.beginVerification() == allowed, "verification gate seed \(seed) step \(step)")
            if allowed { expectedVerifying = true }
        case 1:
            state.finishVerification()
            expectedVerifying = false
        case 2:
            state.cancelVerification()
            expectedVerifying = false
        case 3:
            let allowed = !expectedClearing
            ensure(state.beginCleanup() == allowed, "cleanup gate seed \(seed) step \(step)")
            if allowed { expectedClearing = true; expectedVerifying = false }
        default:
            state.finishCleanup()
            expectedClearing = false
        }
        ensure(state.verificationInFlight == expectedVerifying,
               "verification state seed \(seed) step \(step)")
        ensure(state.isClearing == expectedClearing,
               "cleanup state seed \(seed) step \(step)")
        ensure(!(state.isClearing && state.verificationInFlight),
               "never verify while clearing seed \(seed) step \(step)")
    }
}
print("SESSION LIFECYCLE PASS \(count)/\(count) assertions")
