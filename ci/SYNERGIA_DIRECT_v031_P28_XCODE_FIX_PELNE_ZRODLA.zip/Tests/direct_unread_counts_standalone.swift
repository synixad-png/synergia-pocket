import Foundation

@main struct UnreadTests {
    static var pass = 0
    static func check(_ expected: Bool, _ label: String) {
        if !expected { print("FAIL \(label)"); exit(1) }
        pass += 1; print("PASS \(label)")
    }
    static func reject(_ d: [String: Any]) -> Bool {
        do { _ = try DirectUnreadCountParser.parse(d); return false }
        catch { return true }
    }
    static func main() throws {
        let input: [String: Any] = ["data": ["inbox": 3, "notes": 0, "archiveInbox": 12]]
        let a = try DirectUnreadCountParser.parse(input)
        check(a.values["inbox"] == 3, "inbox count")
        check(a.values["notes"] == 0, "explicit zero")
        check(a.values["alerts"] == nil, "missing is unknown")
        check(a.values["archiveInbox"] == 12, "archive")
        check(DirectUnreadCounts.fields.count == 14, "categories documented")
        check(reject([:]), "missing data")
        check(reject(["data": [:]]), "missing inbox")
        check(reject(["data": ["inbox": -1]]), "negative")
        check(reject(["data": ["inbox": true]]), "bool")
        check(reject(["data": ["inbox": 0.5]]), "fractional")
        check(reject(["data": ["inbox": 1_000_001]]), "huge")
        check(reject(["data": ["inbox": 1, "alerts": "2"]]), "wrong type")
        check(!reject(["data": ["inbox": 0, "newUnknownCategory": 99]]), "unknown category harmless")
        print("TOTAL PASS=\(pass) FAIL=0")
    }
}
