import Foundation
import CoreFoundation

// Portable Foundation checks. They do not verify real SchoolFiles responses
// or compile the iOS SwiftUI / WebKit application.
enum SynergiaGatewayClient {
    enum Resource: String { case homework = "HomeWorks", homeworkAssignments = "HomeWorkAssignments",
        schoolNotices = "SchoolNotices", schoolFiles = "SchoolFiles" }
}

@main struct DocumentTests {
    static var passed = 0
    static var failed = 0
    static func check(_ title: String, _ body: () throws -> Bool) {
        do {
            if try body() { passed += 1 } else { failed += 1; print("FAIL: \(title)") }
        } catch { failed += 1; print("FAIL: \(title): \(error)") }
    }
    static func row(_ id: Int, _ name: String = "Regulamin.pdf", _ date: String? = "2026-11-05",
                    _ status: Any? = "opublikowano") -> [String: Any] {
        var fields: [String: Any] = ["id":id, "displayName":name,
            "downloadUrl":"/pliki_szkoly/pobierz/\(id)"]
        if let date { fields["addedOnDate"] = date }
        if let status { fields["fileStatus"] = status }
        return fields
    }
    static func feed(_ rows: [[String: Any]], owner: String = "student-A", total: Int? = nil) throws -> DirectSchoolFeed {
        var root: [String: Any] = ["Data": rows]
        if let total { root["Total"] = total }
        return try DirectSchoolFeedParser.parse(root, module: .documents, accountId: owner,
            date: Date(timeIntervalSince1970: 1_783_000_000))
    }
    static func safeFile(_ entry: DirectSchoolFeedEntry, _ feed: DirectSchoolFeed) -> DirectSchoolFileReference? {
        DirectSchoolDocumentsPresentation.uniqueDownloadReference(entry, in: feed)
    }
    static func main() {
        check("SchoolFiles resource unchanged") { try DirectSchoolFeedParser.resource(for: .documents) == .schoolFiles }
        check("typed metadata explicit") {
            let record = try feed([row(1)]).records[0]
            return record.document?.addedDay == "2026-11-05" && record.document?.serverStatus == "opublikowano"
        }
        check("no inferred date from Date") {
            var item = row(1, "A.pdf", nil, nil); item["Date"] = "2026-11-04"
            return try feed([item]).records[0].document?.addedDay == nil
        }
        check("unrecognized dates remain unknown") {
            try feed([row(1, "A.pdf", "2026-02-30")]).records[0].document?.addedDay == nil
        }
        check("ISO datetime prefix read") {
            try feed([row(1, "A.pdf", "2026-11-05T12:00:00")]).records[0].document?.addedDay == "2026-11-05"
        }
        check("nested status remains unknown") {
            try feed([row(1, "A.pdf", nil, ["x":"y"])]).records[0].document?.serverStatus == nil
        }
        check("HTML status is inert") {
            try feed([row(1, "A.pdf", nil, "<script>steal()</script><p>Gotowe &amp; czytelne</p>")])
                .records[0].document?.serverStatus == "Gotowe & czytelne"
        }
        check("too long status unavailable") {
            try feed([row(1, "A.pdf", nil, String(repeating:"A", count: 121))]).records[0].document?.serverStatus == nil
        }
        check("unknown MIME not invented") { DirectSchoolDocumentsPresentation.filenameExtension("Dokument") == nil }
        check("PDF from name") { DirectSchoolDocumentsPresentation.filenameExtension("A.PDF") == "pdf" }
        check("multi-dot extension") { DirectSchoolDocumentsPresentation.filenameExtension("a.b.docx") == "docx" }
        check("weird suffix rejected") { DirectSchoolDocumentsPresentation.filenameExtension("x.a b") == nil }
        check("dotfile rejected") { DirectSchoolDocumentsPresentation.filenameExtension(".secrets") == nil }
        check("dangerous slash rejected") { DirectSchoolDocumentsPresentation.filenameExtension("../../x.pdf") == nil }
        check("long extension rejected") { DirectSchoolDocumentsPresentation.filenameExtension("x."+String(repeating:"a",count:13)) == nil }
        check("verified link") {
            let f = try feed([row(1)]); return safeFile(f.records[0], f)?.id == "1"
        }
        check("wrong URL blocks download") {
            var item = row(1); item["downloadUrl"] = "/pliki_szkoly/pobierz/2"
            let f = try feed([item]); return safeFile(f.records[0], f) == nil && f.records.count == 1
        }
        check("duplicate document ID blocks both") {
            let f = try feed([row(1,"A.pdf"), row(1,"B.pdf")]);
            return f.records.count == 2 && f.records.allSatisfy { safeFile($0, f) == nil }
        }
        check("duplicate ID with malformed second URL also blocked") {
            var item=row(1,"B.pdf"); item["downloadUrl"]="https://evil.example/get"
            let f = try feed([row(1), item]); return f.records.allSatisfy { safeFile($0, f) == nil }
        }
        check("duplicate names different IDs allowed") {
            let f = try feed([row(1),row(2)]); return f.records.allSatisfy { safeFile($0,f) != nil }
        }
        check("no link filter") {
            var invalid=row(2);invalid["downloadUrl"]="/bad"
            let f=try feed([row(1),invalid]); return DirectSchoolDocumentsPresentation.entries(f,availability:.noVerifiedLink).count==1
        }
        check("valid link filter") {
            var invalid=row(2);invalid["downloadUrl"]="/bad"
            let f=try feed([row(1),invalid]); return DirectSchoolDocumentsPresentation.entries(f,availability:.verifiedLink).map{$0.serverId}==["1"]
        }
        check("filter in names") {
            let f=try feed([row(1,"Plan.pdf"),row(2,"Regulamin.docx")]); return DirectSchoolDocumentsPresentation.entries(f,query:"regula").count==1
        }
        check("search status") {
            let f=try feed([row(1,"A.pdf",nil,"wersja testowa"),row(2,"B.pdf",nil,"ważny")]);
            return DirectSchoolDocumentsPresentation.entries(f,query:"testowa").count==1
        }
        check("search by date") {
            let f=try feed([row(1,"A.pdf","2026-10-15"),row(2,"B.pdf","2026-11-05")]);
            return DirectSchoolDocumentsPresentation.entries(f,query:"2026-10-15").count==1
        }
        check("extensions deduplicated") {
            let f=try feed([row(1,"A.pdf"),row(2,"B.PDF"),row(3,"C.docx")]);
            return DirectSchoolDocumentsPresentation.extensions(f)==["docx","pdf"]
        }
        check("extension filter") {
            let f=try feed([row(1,"A.pdf"),row(2,"B.docx")]);
            return DirectSchoolDocumentsPresentation.entries(f,extensionFilter:"pdf").map{$0.serverId}==["1"]
        }
        check("alphabetical order") {
            let f=try feed([row(1,"Z.pdf"),row(2,"A.pdf")]);
            return DirectSchoolDocumentsPresentation.entries(f).map{$0.serverId}==["2","1"]
        }
        check("newest before older") {
            let f=try feed([row(1,"A.pdf","2026-11-01"),row(2,"B.pdf","2026-11-05")]);
            return DirectSchoolDocumentsPresentation.entries(f,order:.newest).map{$0.serverId}==["2","1"]
        }
        check("undated last on newest") {
            let f=try feed([row(1,"A.pdf",nil),row(2,"B.pdf","2026-11-04")]);
            return DirectSchoolDocumentsPresentation.entries(f,order:.newest).map{$0.serverId}==["2","1"]
        }
        check("non-documents never leaked") {
            let f=try DirectSchoolFeedParser.parse(["HomeWorks":[["Id":5,"Content":"Termin"]]],
              module:.calendar,accountId:"student-A")
            return DirectSchoolDocumentsPresentation.entries(f).isEmpty &&
              DirectSchoolDocumentsPresentation.extensions(f).isEmpty
        }
        check("optional metadata nil in other modules") {
            let f=try DirectSchoolFeedParser.parse(["HomeWorks":[["Id":5,"Content":"Termin"]]],
              module:.calendar,accountId:"student-A")
            return f.records[0].document == nil
        }
        check("cache round trip preserves doc") {
            let f=try feed([row(1)]);let bytes=try DirectOfflineFeedCache.encode(f,expectedAccountId:"student-A",now:Date())
            let restored=try DirectOfflineFeedCache.decode(bytes,module:.documents,expectedAccountId:"student-A",now:Date())
            return restored == f && restored.records[0].document?.addedDay == "2026-11-05"
        }
        check("cache cross-account rejected") {
            let f=try feed([row(1)]); let bytes=try DirectOfflineFeedCache.encode(f,expectedAccountId:"student-A",now:Date())
            return (try? DirectOfflineFeedCache.decode(bytes,module:.documents,expectedAccountId:"student-B",now:Date())) == nil
        }
        check("cache malformed document date rejected") {
            let f=try feed([row(1)]);let encoded=try DirectOfflineFeedCache.encode(f,expectedAccountId:"student-A",now:Date())
            guard var json=try JSONSerialization.jsonObject(with:encoded) as? [String:Any],
                  var data=json["feed"] as? [String:Any],
                  var records=data["records"] as? [[String:Any]],
                  var document=records[0]["document"] as? [String:Any] else { return false }
            document["addedDay"]="2026-02-30"; records[0]["document"]=document
            data["records"]=records;json["feed"]=data
            let modified=try JSONSerialization.data(withJSONObject:json)
            return (try? DirectOfflineFeedCache.decode(modified,module:.documents,expectedAccountId:"student-A",now:Date())) == nil
        }
        check("old cache without document remains compatible") {
            let f=try feed([row(1)]);let encoded=try DirectOfflineFeedCache.encode(f,expectedAccountId:"student-A",now:Date())
            guard var json=try JSONSerialization.jsonObject(with:encoded) as? [String:Any],
                  var data=json["feed"] as? [String:Any],
                  var records=data["records"] as? [[String:Any]] else { return false }
            records[0].removeValue(forKey:"document")
            data["records"]=records;json["feed"]=data
            let old=try JSONSerialization.data(withJSONObject:json)
            let restored=try DirectOfflineFeedCache.decode(old,module:.documents,expectedAccountId:"student-A",now:Date())
            return restored.records[0].document == nil && restored.records[0].schoolFile != nil
        }
        check("change in server status audited") {
            let old=try feed([row(1,"A.pdf",nil,"old")]);let new=try feed([row(1,"A.pdf",nil,"new")]);
            let delta=DirectFeedChangeAudit.compare(previous:old,current:new)
            return delta.comparable && delta.changed==1
        }
        check("change in addedDay audited") {
            let old=try feed([row(1,"A.pdf", "2026-11-01")]);let new=try feed([row(1,"A.pdf","2026-11-02")]);
            return DirectFeedChangeAudit.compare(previous:old,current:new).changed==1
        }
        check("account boundary audited") {
            let old=try feed([row(1)],owner:"student-A");let new=try feed([row(1)],owner:"student-B");
            return !DirectFeedChangeAudit.compare(previous:old,current:new).comparable
        }
        check("duplicates not used to claim removal") {
            let old=try feed([row(1),row(1,"B.pdf")]);let new=try feed([row(1)]);
            return !DirectFeedChangeAudit.compare(previous:old,current:new).comparable
        }
        check("incomplete response isn't complete") {
            let f=try feed([row(1)],total:3);return !f.completenessKnown
        }
        check("verified empty response stays empty") {
            let f=try feed([],total:0);return f.completenessKnown && f.records.isEmpty
        }
        check("raw URL not shown in details") {
            let f=try feed([row(1)]);return f.records[0].details.allSatisfy{ !$0.contains("/pliki_szkoly/") }
        }
        for y in 2000...2026 {
            let date="\(y)-02-29"
            check("calendar date \(y) remains conservative") {
                let f=try feed([row(1,"A.pdf",date)])
                let leap=(y%4==0 && (y%100 != 0 || y%400==0))
                return (f.records[0].document?.addedDay != nil)==leap
            }
        }
        print("BATCH16_DOCUMENTS PASS=\(passed) FAIL=\(failed)")
        if failed>0 { exit(1) }
    }
}
