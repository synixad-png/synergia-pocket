import Foundation

enum SynergiaGatewayClient {
    enum Resource: String {
        case homework = "HomeWorks", homeworkAssignments = "HomeWorkAssignments"
        case schoolNotices = "SchoolNotices", schoolFiles = "SchoolFiles"
    }
}

@main struct FeedDeltaTests {
    static var passed=0, failed=0
    static func check(_ name:String,_ body:() throws -> Bool) {
        do { if try body() {passed += 1; print("PASS "+name)} else {failed += 1; print("FAIL "+name)} }
        catch {failed += 1; print("FAIL \(name): \(error)")}
    }
    static func feed(_ values:[[String:Any]], total:Int?=nil, account:String="abc",
                     module:SchoolModule = .announcements) throws -> DirectSchoolFeed {
        var root:[String:Any] = [module == .announcements ? "SchoolNotices" : "HomeWorkAssignments": values]
        if let total { root["Total"] = total }
        return try DirectSchoolFeedParser.parse(root, module:module, accountId:account)
    }
    static func notice(_ id:String,_ title:String="Notice") -> [String:Any] {
        ["Id": id,"Subject":title,"Content":"Treść"]
    }
    static func homework(_ id:Int,files:[[String:Any]]?=nil) -> [String:Any] {
        var record:[String:Any]=["Id":id,"Topic":"Ćwiczenie"]
        if let files { record["HomeworkAssigmentFiles"]=files }
        return record
    }
    static func main() {
        check("initial item uses server Id") { try feed([notice("n1")]).records[0].serverId == "n1" }
        check("added entry") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1")]), current:try feed([notice("n1"),notice("n2")]));return d.comparable && d.added==1 && d.changed==0}
        check("updated text") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1","old")]),current:try feed([notice("n1","new")]));return d.changed==1 && d.added==0}
        check("reordered entries not a change") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1"),notice("n2")]), current:try feed([notice("n2"),notice("n1")]));return d.changed==0 && d.added==0 && d.missingUnconfirmed==0}
        check("missing on incomplete page never deleted") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1"),notice("n2")]),current:try feed([notice("n1")]));return d.removedConfirmed==0 && d.missingUnconfirmed==1}
        check("complete current but previous incomplete never deleted") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1"),notice("n2")]),current:try feed([notice("n1")],total:1));return d.removedConfirmed==0 && d.missingUnconfirmed==1}
        check("no deletion inferred from two complete lists") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1"),notice("n2")],total:2),current:try feed([notice("n1")],total:1));return d.removedConfirmed==0 && d.missingUnconfirmed==1}
        check("different account incomparable") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1")],account:"abc"),current:try feed([notice("n1")],account:"def"));return !d.comparable && d.removedConfirmed==0}
        check("duplicate IDs incomparable") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1")]),current:try feed([notice("n1"),notice("n1")]));return !d.comparable}
        check("record without server ID incomparable") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1")]),current:try feed([["Subject":"No id"]]));return !d.comparable}
        check("different module incomparable") {let d=DirectFeedChangeAudit.compare(previous:try feed([notice("n1")]),current:try feed([homework(11)],module:.homework));return !d.comparable}
        check("both empty with confirmed total") {let d=DirectFeedChangeAudit.compare(previous:try feed([],total:0), current:try feed([],total:0));return d.comparable && d.added==0 && d.removedConfirmed==0}
        check("changed homework attachments") {
            let f:[String:Any]=["Id":32,"Name":"A.pdf","Url":"https://synergia.librus.pl/gateway/api/2.0/HomeWorkAssignments/Attachment/11-32"]
            let before=try feed([homework(11,files:[])],module:.homework)
            let after=try feed([homework(11,files:[f])],module:.homework)
            let d=DirectFeedChangeAudit.compare(previous:before,current:after)
            return d.changed==1 && after.records[0].homeworkFiles?.first?.name=="A.pdf"
        }
        check("no attachment field remains unknown") {try feed([homework(11)],module:.homework).records[0].homeworkFiles == nil}
        check("empty attachments are known empty") {try feed([homework(11,files:[])],module:.homework).records[0].homeworkFiles?.isEmpty==true}
        check("reject malformed attachment without hiding discrepancy") {
            do {_ = try feed([homework(11,files:[["Id":2,"Name":"x.pdf","Url":"https://evil.tld/file"]])],module:.homework);return false} catch{return true}
        }
        print("FEED DELTAS PASS=\(passed) FAIL=\(failed)")
        if failed>0 {exit(1)}
    }
}
