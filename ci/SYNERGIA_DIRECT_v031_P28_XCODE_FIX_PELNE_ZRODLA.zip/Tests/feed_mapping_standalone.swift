import Foundation

// Only for standalone Linux parser tests; the app uses the real WebKit transport.
enum SynergiaGatewayClient {
    enum Resource: String {
        case homework = "HomeWorks"
        case homeworkAssignments = "HomeWorkAssignments"
        case schoolNotices = "SchoolNotices"
        case schoolFiles = "SchoolFiles"
    }
}

@main struct FeedTests {
    static var pass = 0, fail = 0
    static func check(_ title: String, _ body: () throws -> Bool) {
        do {
            if try body() { pass += 1; print("PASS " + title) }
            else { fail += 1; print("FAIL " + title) }
        } catch { fail += 1; print("FAIL " + title + ": \(error)") }
    }
    static func fixtureFile(_ id:Int) -> [String: Any] {
        ["id":id,"displayName":"Regulamin.pdf","downloadUrl":"/pliki_szkoly/pobierz/\(id)"]
    }
    static func main() {
        check("homework resource is assignments") {
            try DirectSchoolFeedParser.resource(for: .homework) == .homeworkAssignments
        }
        check("calendar resource is homeworks") {
            try DirectSchoolFeedParser.resource(for: .calendar) == .homework
        }
        check("announcements resource") { try DirectSchoolFeedParser.resource(for: .announcements) == .schoolNotices }
        check("school documents resource") { try DirectSchoolFeedParser.resource(for: .documents) == .schoolFiles }
        check("not guessing unsupported timetable source") {
            do { _ = try DirectSchoolFeedParser.resource(for: .timetable); return false }
            catch DirectSchoolFeedError.unsupportedModule { return true }
        }
        check("actual assignment fields") {
            let feed = try DirectSchoolFeedParser.parse(["HomeWorkAssignments": [[
                "Id": 92, "Topic": "Zadanie A", "Text": "Wykonaj pracę",
                "DueDate": "2026-11-12", "Date": "2026-11-05"
            ]]], module: .homework, accountId: "abc")
            return feed.records.count == 1 && feed.records[0].title == "Zadanie A" &&
                feed.records[0].details.contains("Do: 2026-11-12") && feed.verifiedAccountId == "abc"
        }
        check("real agenda fields HomeWorks") {
            let feed = try DirectSchoolFeedParser.parse(["HomeWorks": [[
                "Id": 1, "Date": "2026-11-12", "Content": "Sprawdzian z geografii"
            ]]], module: .calendar, accountId: "abc")
            return feed.records[0].title == "Sprawdzian z geografii"
        }
        check("real announcement fields SchoolNotices") {
            let feed = try DirectSchoolFeedParser.parse(["SchoolNotices": [[
                "Id": "LID-NBOARD-NOTICE-1", "Subject": "Ogłoszenie", "Content": "Treść",
                "CreationDate": "2026-11-05"
            ]]], module: .announcements, accountId: "abc")
            return feed.records[0].title == "Ogłoszenie" && feed.records[0].details.contains("Dodano: 2026-11-05")
        }
        check("real school files fields") {
            let feed = try DirectSchoolFeedParser.parse(["Data": [[
                "id": 31, "displayName": "Regulamin szkoły.pdf", "addedOnDate": "2026-11-03",
                "fileStatus": "ok", "downloadUrl": "/pliki_szkoly/pobierz/31"
            ]]], module: .documents, accountId: "abc")
            return feed.records[0].title == "Regulamin szkoły.pdf" &&
                !feed.records[0].details.contains { $0.contains("downloadUrl") || $0.contains("/pliki_szkoly") }
        }
        check("school file row carries verified download reference") {
            let feed = try DirectSchoolFeedParser.parse(["Data": [fixtureFile(77)]], module: .documents, accountId: "abc")
            return feed.records[0].schoolFile?.path == "/pliki_szkoly/pobierz/77"
        }
        check("mismatched download link not exposed") {
            var item=fixtureFile(77);item["downloadUrl"]="/pliki_szkoly/pobierz/78"
            let feed = try DirectSchoolFeedParser.parse(["Data":[item]],module:.documents,accountId:"abc")
            return feed.records.count == 1 && feed.records[0].schoolFile == nil
        }
        check("non-document feed never exposes downloadable reference") {
            let item:[String:Any]=["Id":77,"Topic":"Zadanie","id":77,
                "displayName":"lekcja.pdf", "downloadUrl":"/pliki_szkoly/pobierz/77"]
            let feed = try DirectSchoolFeedParser.parse(["HomeWorkAssignments":[item]],module:.homework,accountId:"abc")
            return feed.records[0].schoolFile == nil
        }
        check("school file reference not included in visible detail strings") {
            let feed = try DirectSchoolFeedParser.parse(["Data": [fixtureFile(77)]], module: .documents, accountId: "abc")
            return feed.records[0].details.allSatisfy { !$0.contains("pobierz") }
        }
        check("empty unknown is not asserted empty") {
            do { _ = try DirectSchoolFeedParser.parse(["Data": [[String:Any]]()],module:.documents,accountId:"abc"); return false }
            catch DirectSchoolFeedError.unknownShape { return true }
        }
        check("explicit empty count zero supported") {
            let feed = try DirectSchoolFeedParser.parse(["Data": [[String:Any]](),"Total": 0],module:.documents,accountId:"abc")
            return feed.records.isEmpty && feed.completenessKnown
        }
        check("incomplete count never confirmed") {
            let feed = try DirectSchoolFeedParser.parse(["Data": [["displayName":"A.pdf"]],"Total": 4],module:.documents,accountId:"abc")
            return !feed.completenessKnown
        }
        check("missing title rejected") {
            do { _ = try DirectSchoolFeedParser.parse(["HomeWorkAssignments":[["Id": 1]]],module:.homework,accountId:"abc"); return false }
            catch DirectSchoolFeedError.malformedEntry { return true }
        }
        check("no personal data in arbitrary nested references") {
            let feed = try DirectSchoolFeedParser.parse(["HomeWorks":[[
                "Content":"Test", "Subject":["Id": 999,"Url":"secret"]
            ]]],module:.calendar,accountId:"abc")
            return feed.records[0].details.allSatisfy { !$0.contains("secret") }
        }
        print("FEED_MAPPINGS PASS=\(pass) FAIL=\(fail)")
        if fail > 0 { exit(1) }
    }
}
