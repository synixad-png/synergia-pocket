import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

var checks = 0
func assertThat(_ condition: @autoclosure () -> Bool, _ name: String) {
    checks += 1
    if !condition() { fatalError("FAIL [\(checks)] \(name)") }
}
func makeCookie(domain: String, path: String = "/", secure: Bool = true,
                expires: Date = Date().addingTimeInterval(3600)) -> HTTPCookie {
    var properties: [HTTPCookiePropertyKey: Any] = [
        .name: "test", .value: "mock", .domain: domain, .path: path, .expires: expires
    ]
    if secure { properties[.secure] = "TRUE" }
    return HTTPCookie(properties: properties)!
}
let host = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Me")!
let now = Date(timeIntervalSince1970: 2_000_000_000)
func cookie(_ domain: String, path: String = "/", secure: Bool = true,
            expires: Date? = nil) -> HTTPCookie {
    makeCookie(domain: domain, path: path, secure: secure,
               expires: expires ?? now.addingTimeInterval(3600))
}
let good = cookie("synergia.librus.pl")
assertThat(GatewayJSONPolicy.cookieApplies(good, to: host, now: now), "host cookie")
assertThat(GatewayJSONPolicy.cookieApplies(cookie(".librus.pl"), to: host, now: now), "site-domain cookie")
assertThat(GatewayJSONPolicy.cookieApplies(cookie(".synergia.librus.pl"), to: host, now: now), "host-domain cookie")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("librus.pl"), to: host, now: now), "parent host-only cookie not shared")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("portal.librus.pl"), to: host, now: now), "portal cookie not shared")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie(".notlibrus.pl"), to: host, now: now), "other site not shared")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("evilsynergia.librus.pl"), to: host, now: now), "sibling host not shared")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie(".evil-synergia.librus.pl"), to: host, now: now), "suffix spoof not shared")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", secure: false), to: host, now: now), "insecure cookie blocked")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", expires: now.addingTimeInterval(-1)), to: host, now: now), "expired cookie blocked")
assertThat(!GatewayJSONPolicy.cookieApplies(good, to: URL(string: "http://synergia.librus.pl/gateway/api/2.0/Me")!, now: now), "HTTP blocked")
assertThat(!GatewayJSONPolicy.cookieApplies(good, to: URL(string: "https://synergia.librus.pl:8443/gateway/api/2.0/Me")!, now: now), "custom port blocked")
assertThat(GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway"), to: host, now: now), "child path")
assertThat(GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway/api/2.0/Me"), to: host, now: now), "exact path")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway/api/2.0/Meta"), to: host, now: now), "different path")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway/api/2.0/M"), to: host, now: now), "partial segment blocked")
assertThat(!GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway/api/2.0/Me/other"), to: host, now: now), "longer cookie path blocked")
assertThat(GatewayJSONPolicy.cookieApplies(cookie("synergia.librus.pl", path: "/gateway/"), to: host, now: now), "trailing slash parent")
let cookies = [cookie("librus.pl"), cookie("portal.librus.pl"), cookie(".librus.pl"), good, cookie("synergia.librus.pl", secure: false)]
let scoped = GatewayJSONPolicy.applicableCookies(cookies, to: host, now: now)
assertThat(scoped.count == 2, "only two matching secure cookies")
assertThat(scoped[0].domain == ".librus.pl", "preserves sequence 1")
assertThat(scoped[1].domain == "synergia.librus.pl", "preserves sequence 2")
for ct in ["application/json", "application/json; charset=UTF-8", "APPLICATION/JSON", " application/ld+json ; charset=utf-8", "application/vnd.api+json", "application/problem+json"] {
    assertThat(GatewayJSONPolicy.isJSONContentType(ct), "accept JSON: \(ct)")
}
for ct in ["text/html; note=application/json", "text/plain", "text/json", "application/javascript", "application/jsonp", "application/+json", "application/json-evil", "application/json-extra; application/json", "", "application/thing+json+xml"] {
    assertThat(!GatewayJSONPolicy.isJSONContentType(ct), "reject MIME: \(ct)")
}
assertThat(!GatewayJSONPolicy.isJSONContentType(nil), "reject missing MIME")
for size in [0, 1, 12, 3_999_999, 4_000_000] {
    assertThat(GatewayJSONPolicy.withinJSONLimit(bodyBytes: size, expectedBytes: -1), "unknown length accepted in limit")
    assertThat(GatewayJSONPolicy.withinJSONLimit(bodyBytes: size, expectedBytes: Int64(size)), "declared length accepted")
}
for size in [-1, 4_000_001, 99_000_000] {
    assertThat(!GatewayJSONPolicy.withinJSONLimit(bodyBytes: size, expectedBytes: -1), "actual oversize rejected")
}
assertThat(!GatewayJSONPolicy.withinJSONLimit(bodyBytes: 100, expectedBytes: 4_000_001), "declared oversize rejected")
assertThat(!GatewayJSONPolicy.withinJSONLimit(bodyBytes: 100, expectedBytes: -2), "invalid unknown-length code rejected")
let gradeBase = "https://synergia.librus.pl/gateway/api/2.0/Grades"
for query in ["?page=2", "?offset=100&limit=25", "?cursor=abcdef%3D", "?page.id=2", "?x[y]=5"] {
    assertThat(GatewayJSONPolicy.safeContinuationQuery(URL(string: gradeBase + query)!), "valid observed-shape query: \(query)")
}
for query in ["", "?", "?page=", "?=2", "?page=1&page=2", "?page=1&Page=2", "?page=1&", "?a=%0A", "?page=1&limit=2&x=3&y=4&z=5&p=6&q=7&r=8&s=9"] {
    assertThat(!GatewayJSONPolicy.safeContinuationQuery(URL(string: gradeBase + query)!), "invalid query: \(query)")
}
assertThat(!GatewayJSONPolicy.safeContinuationQuery(URL(string: gradeBase + "?cursor=" + String(repeating: "a", count: 2050))!), "query-size bound")
print("GATEWAY JSON POLICY PASS: \(checks) test cases")
