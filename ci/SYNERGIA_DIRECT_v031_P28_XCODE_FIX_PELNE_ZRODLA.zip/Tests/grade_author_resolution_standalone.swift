import Foundation

@main struct GradeAuthorResolutionTests {
    static func grade(_ id: String, author: String?) -> DirectGrade {
        DirectGrade(id: id, subjectId: "11", categoryId: nil, value: "5",
                    semester: 1, addedAt: nil, commentTexts: [], teacherId: author)
    }
    static func main() throws {
        var passed = 0
        func ok(_ condition: Bool, _ label: String) {
            precondition(condition, "FAIL: " + label)
            passed += 1
        }
        let rows = [grade("1", author:"7"), grade("2", author:"8"),
                    grade("3", author:"9"), grade("4", author:nil)]
        let current = ["7": " Anna  Nowak ", "8": "", "1234": "Unrelated Person"]
        let previous = ["7": "A. Nowak", "8": "Anna Nowak", "9": "", "888": "Old unrelated"]
        let result = DirectGradeAuthors.reconcile(grades:rows, current:current, previous:previous)
        ok(result.names["7"] == "Anna  Nowak", "fresh takes priority")
        ok(result.names["8"] == "Anna Nowak", "same account fallback")
        ok(result.names["9"] == nil, "blank previous not trusted")
        ok(result.names["1234"] == nil, "unreferenced live not saved")
        ok(result.names["888"] == nil, "unreferenced previous not saved")
        ok(result.staleIds == Set(["8"]), "only previous source flagged stale")
        ok(result.unresolvedIds == ["9"], "accurate unresolved")
        ok(result.summary.contains("aktualnie ustaleni: 1"), "summary fresh")
        ok(result.summary.contains("wcześniejszego odczytu: 1"), "summary old")
        ok(result.summary.contains("nieustaleni: 1"), "summary unresolved")
        let freshOnly = DirectGradeAuthors.reconcile(grades:rows, current:current, previous:[:])
        ok(freshOnly.names["8"] == nil, "no same-account fallback without prior data")
        ok(freshOnly.unresolvedIds == ["8", "9"], "missing from current")
        let empty = DirectGradeAuthors.reconcile(grades:[], current:current, previous:previous)
        ok(empty.names.isEmpty && empty.staleIds.isEmpty && empty.unresolvedIds.isEmpty, "no authors when no grades")
        for good in ["1", "2", "123", "999999999999"] {
            ok(DirectGradeAuthors.requestableUserId(good), "valid numeric author id \(good)")
        }
        for bad in ["", "0", "01", "-1", "+3", " 4", "4 ", "4/../5", "3?x", "7#x", "8%2F", "4.5", "9999999999999", "a88", "１"] {
            ok(!DirectGradeAuthors.requestableUserId(bad), "rejected unsafe path \(bad)")
        }
        let single: [String: Any] = ["User": ["Id": 7, "FirstName":"Alicja", "LastName":"  Żak  "]]
        ok(try DirectGradeAuthors.decodeSingle(single,requestedId:"7") == "Alicja Żak", "single user validated")
        let emptySingle: [String: Any] = ["User": ["Id":7,"FirstName": NSNull(),"LastName": NSNull()]]
        ok(try DirectGradeAuthors.decodeSingle(emptySingle,requestedId:"7") == "", "empty individual name preserved as blank")
        func fails<T>(_ action: () throws -> T) -> Bool { do { _ = try action(); return false } catch { return true } }
        ok(fails { try DirectGradeAuthors.decodeSingle(single,requestedId:"8") }, "mismatching ID refused")
        ok(fails { try DirectGradeAuthors.decodeSingle(["User": ["Id":true,"FirstName":"A"]],requestedId:"7") }, "bool ID refused")
        ok(fails { try DirectGradeAuthors.decodeSingle(["Users": [["Id":7,"FirstName":"A"]]],requestedId:"7") }, "list not allowed in single endpoint")
        ok(fails { try DirectGradeAuthors.decodeSingle(["User": ["Id":7,"FirstName":22]],requestedId:"7") }, "invalid name type refused")
        ok(fails { try DirectGradeAuthors.decodeSingle(["User": ["Id":7,"LastName":false]],requestedId:"7") }, "invalid surname refused")
        ok(fails { try DirectGradeAuthors.decodeSingle(["User": ["Id":7,"LastName":"B"]],requestedId:"0") }, "invalid URL path refused")
        let users: [String: Any] = ["Users": [
            ["Id":7,"FirstName":"Anna","LastName":"Nowak"],
            ["Id":8,"FirstName":"", "LastName":"Żak"],
            ["Id":9,"FirstName":NSNull(),"LastName":NSNull()]]]
        let listing = try DirectGradeAuthors.decode(users)
        ok(listing["7"] == "Anna Nowak", "list full")
        ok(listing["8"] == "Żak", "list single field")
        ok(listing["9"] == "", "list absent field")
        ok(DirectGradeAuthors.missingIds(rows,users:listing) == ["9"], "empty user names unresolved")
        ok(DirectGradeAuthors.missingIds(rows,users:[:]) == ["7","8","9"], "missing all users")
        ok(fails { try DirectGradeAuthors.decode(["Users": [["Id":7,"FirstName":"A"],["Id":7,"FirstName":"B"]]]) }, "duplicate user refused")
        ok(fails { try DirectGradeAuthors.decode(["Users": [["Id":true,"FirstName":"A"]]]) }, "list bool ID refused")
        ok(fails { try DirectGradeAuthors.decode(["Users": [["Id":9,"FirstName":12]]]) }, "list number name refused")
        ok(fails { try DirectGradeAuthors.decode(["Users": [["Id":9,"LastName":["A"]]]]) }, "list array surname refused")
        ok(fails { try DirectGradeAuthors.decode(["Users": "bad"]) }, "malformed list refused")
        let roundtrip = try JSONDecoder().decode([DirectGrade].self, from: JSONEncoder().encode(rows))
        ok(roundtrip.map(\.teacherId) == rows.map(\.teacherId), "author IDs preserved in cache")
        ok(!DirectGradeAuthors.reconcile(grades: roundtrip, current:[:], previous:previous).names.isEmpty,
           "saved same-account authors recoverable")
        let fakeSameName = ["7": "Teacher One", "8": "Teacher One"]
        ok(DirectGradeAuthors.reconcile(grades: rows, current: fakeSameName, previous: [:]).names.count == 2,
           "distinct author IDs may have identical names")
        for i in 10...30 {
            let id = String(i)
            let group = [grade(String(i), author:id)]
            let value = DirectGradeAuthors.reconcile(grades:group,
                current:[id:" Teacher \(i) "],previous:[:])
            ok(value.names[id] == "Teacher \(i)", "specific author mapping \(i)")
        }
        print("PASS \(passed)/\(passed) grade-author resolution checks")
    }
}
