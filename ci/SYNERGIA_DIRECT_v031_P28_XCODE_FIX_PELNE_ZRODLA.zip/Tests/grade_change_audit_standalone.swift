import Foundation
@main struct Runner {
    static func main() throws {
        func g(_ id: String, _ sem: Int?, _ val: String = "4") -> DirectGrade {
            DirectGrade(id: id, subjectId: "math", categoryId: nil, value: val, semester: sem, addedAt: nil, commentTexts: [])
        }
        var checks = 0
        func check(_ condition: Bool) { precondition(condition); checks += 1 }
        let old = [g("a", 1), g("b", 2), g("c", nil), g("d", 3)]
        let order = try GradeChangeAudit.compare(previous: old, incoming: old.reversed())
        check(order.unchanged == 4 && order.edited == 0)
        let now = [g("a", 2), g("b", 2, "5"), g("c", nil, "6"), g("new", 1)]
        let d = try GradeChangeAudit.compare(previous: old, incoming: now)
        check(d.added == 1)
        check(d.edited == 3)
        check(d.absentInLatestRead == 1)
        check(d.movedBetweenSemesters == 1)
        check(d.unassignedOrOtherSemesterChanges == 1)
        check(d.unchanged == 0)
        check(d.summary.contains("nie oznacza potwierdzonego usunięcia"))
        do { _ = try GradeChangeAudit.compare(previous: old + [g("a", 1)], incoming: now); fatalError("Duplicate old ID accepted") }
        catch GradeSemesterCoverageError.snapshotContainsDuplicateID("a") { checks += 1 }
        do { _ = try GradeChangeAudit.compare(previous: old, incoming: now + [g("new", 1)]); fatalError("Duplicate new ID accepted") }
        catch GradeSemesterCoverageError.snapshotContainsDuplicateID("new") { checks += 1 }
        let noChanges = try GradeChangeAudit.compare(previous: [], incoming: [])
        check(noChanges.added == 0 && noChanges.absentInLatestRead == 0)
        let unknown = try GradeChangeAudit.compare(previous: [g("u", 3)], incoming: [g("u", 3, "5")])
        check(unknown.unassignedOrOtherSemesterChanges == 1)
        print("PASS \(checks)/12 grade-change checks")
    }
}
