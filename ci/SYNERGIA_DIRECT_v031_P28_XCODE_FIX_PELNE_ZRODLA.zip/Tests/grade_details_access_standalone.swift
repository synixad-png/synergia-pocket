import Foundation

@main enum GradeDetailAccessTest {
    static func main() {
        var passed = 0
        func check(_ label: String, _ value: Bool) {
            guard value else { fatalError("FAIL: \(label)") }
            passed += 1
        }
        let long = String(repeating: "pełna treść\n", count: 180)
        let g = DirectGrade(id: "grade-7", subjectId: "3", categoryId: "c1", value: "5",
            semester: 1, addedAt: "2026-11-05", commentTexts: [long, "Ta sama uwaga", "Ta sama uwaga", ""])
        let other = DirectGrade(id: "grade-9", subjectId: "4", categoryId: nil, value: "4",
            semester: 2, addedAt: nil, commentTexts: [])
        func access(_ id: String = "grade-7", _ owner: String = "alice",
                    _ current: String? = "alice", _ cache: String? = "alice",
                    _ hidden: Bool = false, entries: [DirectGrade] = []) -> DirectGrade? {
            GradeDetailAccess.resolve(gradeID: id, expectedAccountID: owner,
                verifiedAccountID: current, cacheAccountID: cache,
                privacyShieldActive: hidden, grades: entries)
        }
        check("authorized same account", access(entries:[g]) == g)
        check("missing grade", access("absent", entries:[g]) == nil)
        check("empty grade id", access("", entries:[g]) == nil)
        check("empty expected owner", access("grade-7", "", entries:[g]) == nil)
        check("changed logged-in owner", access("grade-7", "alice", "bob", "alice", false, entries: [g]) == nil)
        check("changed store owner", access("grade-7", "alice", "alice", "bob", false, entries: [g]) == nil)
        check("logged out", access("grade-7", "alice", nil, nil, false, entries: [g]) == nil)
        check("store locked", access("grade-7", "alice", "alice", nil, false, entries: [g]) == nil)
        check("shield hides old snapshot", access("grade-7", "alice", "alice", "alice", true, entries: [g]) == nil)
        check("grade removed on refresh", access(entries:[other]) == nil)
        check("access second record", access("grade-9", entries:[other]) == other)
        check("long comment retained", access(entries:[g])?.commentTexts[0] == long)
        check("newlines retained", access(entries:[g])?.commentTexts[0].contains("\n") == true)
        check("equal comments remain separate", access(entries:[g])?.commentTexts.filter {$0 == "Ta sama uwaga"}.count == 2)
        check("empty comment remains explicit", access(entries:[g])?.commentTexts.last == "")
        check("no comment case", access("grade-9", entries:[other])?.commentTexts.isEmpty == true)
        check("no accidental grade fallback", access("grade-7", entries:[other,g])?.id == "grade-7")
        check("case-sensitive account binding", access("grade-7", "ALICE", "alice", "alice", false, entries: [g]) == nil)
        print("RESULT \(passed)/\(passed) PASS")
    }
}
