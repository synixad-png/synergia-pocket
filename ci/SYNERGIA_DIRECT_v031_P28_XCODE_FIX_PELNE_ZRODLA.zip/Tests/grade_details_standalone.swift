import Foundation

@main struct GradeDetailsStandalone {
    static func main() throws {
        var count = 0
        func check(_ label: String, _ value: Bool) {
            guard value else { fatalError("FAIL: \(label)") }
            count += 1
        }
        func rejects(_ operation: () throws -> Any) -> Bool {
            do { _ = try operation(); return false } catch { return true }
        }
        func row(_ id: Int, _ value: Any = "5") -> [String: Any] {
            ["Id": id, "Subject": ["Id": 3], "Grade": value]
        }
        func read(_ rows: [[String: Any]], _ comments: [String: Any]? = nil) throws -> [DirectGrade] {
            try SynergiaGradeRecords.decode(grades: ["Grades": rows], comments: comments)
        }
        check("empty grade rejected", rejects { try read([row(1, "")]) })
        check("whitespace grade rejected", rejects { try read([row(1, " \n")]) })
        check("number grade rejected", rejects { try read([row(1, 5)]) })
        check("valid grade retained", try read([row(1, "5")])[0].value == "5")
        var dated = row(1); dated["AddDate"] = "2026-10-20"
        check("text date retained", try read([dated])[0].addedAt == "2026-10-20")
        dated["AddDate"] = 12
        check("numeric date rejected", rejects { try read([dated]) })
        dated["AddDate"] = false
        check("boolean date rejected", rejects { try read([dated]) })
        dated["AddDate"] = "  "
        check("blank date rejected", rejects { try read([dated]) })
        dated["AddDate"] = NSNull()
        check("explicit null date allowed", try read([dated])[0].addedAt == nil)
        let identicalComments: [String: Any] = ["Comments": [
            ["Id": 10, "Text": "Ta sama uwaga"],
            ["Id": 11, "Text": "Ta sama uwaga"]
        ]]
        var detailed = row(2)
        detailed["Comments"] = [["Id": 10], ["Id": 11]]
        let result = try read([detailed], identicalComments)
        check("equal comment texts retained twice", result[0].commentTexts.count == 2)
        check("comments preserve order", result[0].commentTexts == ["Ta sama uwaga", "Ta sama uwaga"])
        check("missing referenced comment rejected", rejects { try read([detailed], ["Comments": [["Id": 10, "Text": "Ta sama uwaga"]]]) })
        var category = row(3); category["Category"] = ["Id": 44]
        check("category reference retained", try read([category])[0].categoryId == "44")
        category["Category"] = ["Name": "No id"]
        check("invalid category rejected", rejects { try read([category]) })
        print("RESULT \(count)/\(count) PASS")
    }
}
