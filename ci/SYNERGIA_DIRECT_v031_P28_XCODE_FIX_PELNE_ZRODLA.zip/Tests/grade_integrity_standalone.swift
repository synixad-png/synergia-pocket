import Foundation
@main struct GradeIntegrityTest {
 static func record(_ id: Any, _ sem: Int = 1) -> [String:Any] { ["Id":id,"Subject":["Id":2],"Grade":"5","Semester":sem] }
 static func main() throws {
  var total = 0
  func ok(_ label: String, _ condition: Bool) { if !condition { fatalError("FAIL: \(label)") }; total += 1; print("PASS: \(label)") }
  func fails(_ f: () throws -> Any) -> Bool { do { _ = try f(); return false } catch { return true } }
  let page:[String:Any] = ["Grades":[record(1),record(2,2)],"TotalCount":2]
  let combined=try DirectGradePagination.merge([page],previousCount:0)
  ok("accepted valid records",(combined["Grades"] as? [[String:Any]])?.count == 2)
  let decoded=try SynergiaGradeRecords.decode(grades: combined,comments:nil)
  ok("IDs normalized",decoded.map(\.id) == ["1","2"])
  ok("semesters kept",decoded.map(\.semester) == [1,2])
  ok("complete total",!fails { try DirectGradeCompleteness.validate(root:combined,decodedCount:2,previousCount:1) })
  ok("boolean total rejected",fails { try DirectGradePagination.merge([["Grades":[record(1)],"TotalCount":true]],previousCount:0) })
  ok("boolean total rejected in final validation",fails { try DirectGradeCompleteness.validate(root:["Grades":[record(1)],"TotalCount":false],decodedCount:1,previousCount:0) })
  ok("boolean grade ID rejected",fails { try SynergiaGradeRecords.decode(grades:["Grades":[record(true)]],comments:nil) })
  ok("boolean grade ID rejected in pagination",fails { try DirectGradePagination.merge([["Grades":[record(true)]]],previousCount:0) })
  ok("duplicates across pages rejected",fails { try DirectGradePagination.merge([["Grades":[record(2)],"Next":"?page=2"],["Grades":[record("2")]]],previousCount:0) })
  ok("truncated page rejected",fails { try DirectGradePagination.merge([["Grades":[record(1)],"TotalCount":2]],previousCount:0) })
  ok("empty replaces existing blocked",fails { try DirectGradePagination.merge([["Grades":[]]],previousCount:1) })
  ok("empty first sync without total blocked",fails { try DirectGradePagination.merge([["Grades":[]]],previousCount:0) })
  ok("empty first sync final validation blocked",fails { try DirectGradeCompleteness.validate(root:["Grades":[]],decodedCount:0,previousCount:0) })
  ok("empty explicit zero permitted",!fails { try DirectGradePagination.merge([["Grades":[],"TotalCount":0]],previousCount:1) })
  let first=try SynergiaGradeRecords.decode(grades:["Grades":[record(1)]],comments:nil)
  ok("missing second semester ID blocked",fails { try GradeSemesterCoverage.validateReplacement(incoming:first,previous:decoded) })
  ok("reorder stays complete",!fails { try GradeSemesterCoverage.validateReplacement(incoming:decoded.reversed(),previous:decoded) })
  ok("moves allowed",!fails { try GradeSemesterCoverage.validateReplacement(incoming:[DirectGrade(id:"1",subjectId:"2",categoryId:nil,value:"5",semester:2,addedAt:nil,commentTexts:[])],previous:first) })
  ok("invalid decimal semester rejected",fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":1,"Subject":["Id":2],"Grade":"5","Semester":1.5]]],comments:nil) })
  ok("unfinished single page rejected",fails { try DirectGradePagination.merge([["Grades":[record(1)],"Next":"?page=2"]],previousCount:0) })
  ok("multi-page without link rejected",fails { try DirectGradePagination.merge([["Grades":[record(1)]],["Grades":[record(2)]]],previousCount:0) })
  ok("completed explicit chain accepted",!fails { try DirectGradePagination.merge([["Grades":[record(1)],"Next":"?page=2"],["Grades":[record(2)]]],previousCount:0) })
  ok("unsafe continuation rejected",fails { try DirectGradePagination.merge([["Grades":[record(1)],"Next":"https://example.com/grades"],["Grades":[record(2)]]],previousCount:0) })
  ok("malformed grade comment list rejected", fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":31,"Subject":["Id":2],"Grade":"5","Comments":"wrong"]]],comments:nil) })
  ok("malformed grade comment object rejected", fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":31,"Subject":["Id":2],"Grade":"5","Comments":["Id":1]]]],comments:nil) })
  ok("malformed category rejected", fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":31,"Subject":["Id":2],"Grade":"5","Category":true]]],comments:nil) })
  ok("category without identity rejected", fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":31,"Subject":["Id":2],"Grade":"5","Category":["Name":"Test"]]]],comments:nil) })
  ok("absent comment and category remain valid", !fails { try SynergiaGradeRecords.decode(grades:["Grades":[record(31)]],comments:nil) })
  ok("null optional references remain valid", !fails { try SynergiaGradeRecords.decode(grades:["Grades":[["Id":31,"Subject":["Id":2],"Grade":"5","Comments":NSNull(),"Category":NSNull()]]],comments:nil) })
  print("RESULT \(total)/\(total) PASS")
 }
}
