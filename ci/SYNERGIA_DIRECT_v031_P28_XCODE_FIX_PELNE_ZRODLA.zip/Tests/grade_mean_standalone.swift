import Foundation

func grade(_ id: String, _ value: String, _ weight: Double?, _ included: Bool?, subject: String = "math", semester: Int? = 1) -> DirectGrade {
    DirectGrade(id: id, subjectId: subject, categoryId: "c", value: value,
                semester: semester, addedAt: nil, commentTexts: [], categoryName: "x",
                weight: weight, countsToAverage: included)
}
func check(_ condition: @autoclosure () -> Bool, _ desc: String) {
    guard condition() else { fatalError("FAIL: " + desc) }
    print("PASS " + desc)
}
@main struct Test {
 static func main() {
    let result = GradeWeightedAverage.calculate([grade("1","5",2,true),grade("2","3",1,true)])
    check(result.count == 1, "one group")
    check(abs(result[0].mean! - 13.0/3.0) < 0.00001, "weighted mean")
    check(GradeWeightedAverage.calculate([grade("a","4",nil,true)])[0].mean == nil, "missing weight")
    check(GradeWeightedAverage.calculate([grade("a","4",1,nil)])[0].mean == nil, "unknown inclusion")
    check(GradeWeightedAverage.calculate([grade("a","5+",1,true)])[0].mean == nil, "ambiguous plus grade")
    check(GradeWeightedAverage.calculate([grade("a","5",0,true),grade("b","3",1,true)])[0].mean == 3, "zero weight skipped")
    check(GradeWeightedAverage.calculate([grade("a","5",1,false),grade("b","3",1,true)])[0].mean == 3, "excluded grade skipped")
    check(GradeWeightedAverage.calculate([grade("a","4",1,true,semester:1),grade("b","3",1,true,semester:2)]).count == 2, "semesters separated")
    check(GradeWeightedAverage.calculate([grade("a","4",1,true,semester:nil)]).isEmpty, "no guessed semester")
    check(GradeWeightedAverage.calculate([grade("a","5",1,true),grade("b","np",1,true)])[0].mean == nil, "unsupported text blocks mean")
    check(GradeWeightedAverage.calculate([grade("a","5",1,true,subject:"a"),grade("b","3",1,true,subject:"b")]).count == 2, "subjects separated")
    print("ALL 11 PASS")
 }
}
