import Foundation

@main struct Runner {
    static func main() throws {
        var count = 0
        func check(_ condition: Bool, _ message: String) {
            precondition(condition, message)
            count += 1
        }
        func grade(_ id: String, _ value: String = "4", _ semester: Int? = 1) -> DirectGrade {
            DirectGrade(id: id, subjectId: "math", categoryId: "cat", value: value,
                        semester: semester, addedAt: "2026-11-01", commentTexts: ["uwaga"])
        }
        func other(_ id: String, _ family: SupplementalGradeFamily = .points,
                   _ value: String = "10", _ semester: Int? = 1) -> SupplementalGrade {
            SupplementalGrade(family: family, sourceId: id, subjectId: "math", value: value,
                              semester: semester, addedAt: "2026-11-01")
        }
        func changes(_ before: [DirectGrade], _ after: [DirectGrade],
                     _ otherBefore: [SupplementalGrade] = [],
                     _ otherAfter: [SupplementalGrade] = [],
                     _ unavailable: Set<SupplementalGradeFamily> = []) throws -> GradeObservedChangeReport {
            try GradeObservedChangeAudit.compare(previous: before, current: after,
                previousSupplemental: otherBefore, currentSupplemental: otherAfter,
                unavailable: unavailable)
        }

        let base = [grade("g1"), grade("g2", "5", 2)]
        let none = try changes(base, base.reversed())
        check(none.observedNew == 0, "reorder is not addition")
        check(none.observedEdited == 0, "reorder is not edit")
        check(none.unchangedStandard == 2, "reorder unchanged")
        check(!none.hasObservedNews, "no news in stable snapshot")
        check(none.allFamiliesRead, "no unavailable family")

        var category = base[0]
        category.categoryName = "kartkówka"
        category.weight = 2
        category.countsToAverage = true
        let meta = try changes([base[0]], [category])
        check(meta.metadataOnlyStandard == 1, "enrichment changes only metadata")
        check(meta.editedStandard == 0, "metadata must not be grade edit")
        check(!meta.hasObservedNews, "no notification for metadata only")
        check(meta.unchangedStandard == 0, "category changes explicitly counted")
        check(meta.summary.contains("metadanych"), "clear status text")

        var newValue = category
        newValue = DirectGrade(id: category.id, subjectId: category.subjectId,
                               categoryId: category.categoryId, value: "6", semester: 1,
                               addedAt: category.addedAt, commentTexts: category.commentTexts)
        let changed = try changes([category], [newValue])
        check(changed.editedStandard == 1, "value edit")
        check(changed.metadataOnlyStandard == 0, "content edit outranks metadata")
        check(changed.observedEdited == 1, "content edit counted once")
        check(changed.hasObservedNews, "grade modification is observable")

        let comments = DirectGrade(id: "g1", subjectId: "math", categoryId: "cat", value: "4",
                                   semester: 1, addedAt: "2026-11-01", commentTexts: ["new"])
        check(try changes([base[0]], [comments]).editedStandard == 1, "comment content counts")
        var author = base[0]; author.teacherId = "teacher-1"
        check(try changes([base[0]], [author]).editedStandard == 1, "explicit author ID counts")
        let subject = DirectGrade(id: "g1", subjectId: "history", categoryId: "cat", value: "4",
                                  semester: 1, addedAt: "2026-11-01", commentTexts: ["uwaga"])
        check(try changes([base[0]], [subject]).editedStandard == 1, "subject change counts")
        let semester = grade("g1", "4", 2)
        let moved = try changes([base[0]], [semester])
        check(moved.movedStandard == 1, "moved semester is tracked")
        check(moved.editedStandard == 1, "semester edit counts once")
        check(moved.addedStandard == 0, "moved ID is not added")
        check(moved.missingStandard == 0, "moved ID is not missing")

        let added = try changes(base, base + [grade("third")])
        check(added.addedStandard == 1, "new ID")
        check(added.observedNew == 1, "new grade observed")
        check(added.editedStandard == 0, "other grades untouched")
        let missing = try changes(base, [base[1]])
        check(missing.missingStandard == 1, "missing ID reported")
        check(missing.observedNew == 0, "missing is not addition")
        check(missing.observedEdited == 0, "missing is not an edit")
        check(missing.summary.contains("nie potwierdzenie"), "absence not deletion")
        check(missing.hasMissing, "missing flag")

        let points = other("7", .points), descriptive = other("7", .descriptive)
        let otherNone = try changes([], [], [points, descriptive], [descriptive, points])
        check(otherNone.unchangedSupplemental == 2, "family ID namespaces")
        check(otherNone.addedSupplemental == 0, "no false other addition")
        let otherAdded = try changes([], [], [points], [points, descriptive])
        check(otherAdded.addedSupplemental == 1, "new family ID")
        check(otherAdded.observedNew == 1, "all families included")
        let otherEdit = try changes([], [], [points], [other("7", .points, "11")])
        check(otherEdit.editedSupplemental == 1, "supplemental value edit")
        check(otherEdit.observedEdited == 1, "supplemental delta")
        let oldMissingOther = try changes([], [], [points], [])
        check(oldMissingOther.missingSupplemental == 1, "missing other detected")
        check(!oldMissingOther.hasObservedNews, "missing not news")
        let missingUnavailable = try changes([], [], [points], [], [.points])
        check(missingUnavailable.missingSupplemental == 0, "unavailable is not missing")
        check(missingUnavailable.addedSupplemental == 0, "unavailable is not empty baseline")
        check(!missingUnavailable.allFamiliesRead, "incomplete capture marked")
        check(missingUnavailable.unavailableFamilies == [SupplementalGradeFamily.points.rawValue], "family displayed")
        let stale = try changes([], [], [points], [points], [.points])
        check(stale.unchangedSupplemental == 0, "stale family excluded")
        check(!stale.hasObservedNews, "stale family no notifications")
        let mixed = try changes(base, base + [grade("third")],
                                [points], [points, descriptive], [.points])
        check(mixed.observedNew == 2, "standard + fresh other")
        check(mixed.unavailableFamilies == [SupplementalGradeFamily.points.rawValue], "partial status")
        check(!mixed.allFamiliesRead, "never call partial complete")

        do {
            _ = try changes([grade("g")], [grade("g"), grade("g")])
            fatalError("duplicate standard ID accepted")
        } catch GradeSemesterCoverageError.snapshotContainsDuplicateID("g") { count += 1 }
        do {
            _ = try changes([], [], [points, points], [points], [.points])
            fatalError("duplicate other ID accepted")
        } catch GradeObservedAuditError.duplicateSupplementalID(points.id) { count += 1 }
        do {
            _ = try changes([], [], [points], [points, points], [.points])
            fatalError("duplicate new other ID accepted")
        } catch GradeObservedAuditError.duplicateSupplementalID(points.id) { count += 1 }
        do {
            _ = try changes([grade("")], [])
            fatalError("blank standard ID accepted")
        } catch GradeSemesterCoverageError.snapshotContainsDuplicateID("") { count += 1 }
        do {
            _ = try changes([], [], [other("")], [])
            fatalError("blank other ID accepted")
        } catch GradeObservedAuditError.duplicateSupplementalID(_) { count += 1 }

        // Deterministic counters under permutations and mixed families.
        for n in 0..<50 {
            let previous = (0..<n).map { grade("k\($0)", "4", $0 % 3 == 0 ? nil : 1) }
            let current = previous.reversed() + [grade("new-\(n)")]
            let report = try changes(previous, current)
            check(report.addedStandard == 1, "permutation + addition: \(n)")
            check(report.unchangedStandard == n, "permutation stable: \(n)")
            check(report.editedStandard == 0, "no false edits: \(n)")
        }
        print("PASS \(count) GradeObservedChangeAudit checks")
    }
}
