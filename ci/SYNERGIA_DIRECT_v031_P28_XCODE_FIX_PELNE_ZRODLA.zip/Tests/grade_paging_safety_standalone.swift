import Foundation

@main struct GradePagingSafety {
    static let base = URL(string: "https://synergia.librus.pl/gateway/api/2.0/Grades")!
    static var passed = 0
    static func check(_ name: String, _ ok: Bool) {
        guard ok else { fatalError("FAIL: \(name)") }
        passed += 1
    }
    static func fails(_ root: [String: Any], current: URL = base) -> Bool {
        do { _ = try DirectGradePagination.continuation(root, current: current, base: base); return false }
        catch { return true }
    }
    static func main() throws {
        for query in ["?page=2", "?offset=20&limit=20", "?cursor=abc%3D", "?x[y]=2"] {
            let url = try DirectGradePagination.continuation(["Next":query], current:base, base:base)
            check("accepted valid query \(query)", url?.path == base.path && url?.query != nil)
        }
        for link in ["?page=", "?page=1&page=1", "?page=1&Page=2", "?x=%0A",
                     "?page=1&", "?a=1#x", "https://evil.example/Gateway?page=2",
                     "https://synergia.librus.pl/gateway/api/2.0/Users?page=2",
                     "https://synergia.librus.pl:8443/gateway/api/2.0/Grades?page=2",
                     "https://other:pass@synergia.librus.pl/gateway/api/2.0/Grades?page=2",
                     "?" ] {
            check("reject unsafe link \(link)", fails(["Next":link]))
        }
        let page2 = URL(string:base.absoluteString+"?page=2")!
        check("same-page redirect blocked", fails(["Next":"?page=2"],current:page2))
        check("valid next page 3", !fails(["Next":"?page=3"],current:page2))
        let p1:[String:Any] = ["Grades":[["Id":1]],"Next":"?page=2"]
        let p2:[String:Any] = ["Grades":[["Id":2]],"Next":"?page=3"]
        let p3:[String:Any] = ["Grades":[["Id":3]]]
        let good=try DirectGradePagination.merge([p1,p2,p3],previousCount:1)
        check("complete three pages",(good["Grades"] as? [[String:Any]])?.count==3)
        let invalids: [[String: Any]] = [
            ["Grades":[["Id":2]],"Next":"?page=2"],
            ["Grades":[["Id":2]],"Next":"?page=1&page=2"],
            ["Grades":[["Id":2]],"Next":"?page=3#x"]
        ]
        for bad in invalids {
            do { _ = try DirectGradePagination.merge([p1,bad,p3],previousCount:1); check("reject invalid intermediate link",false) }
            catch { check("invalid chain refused",true) }
        }
        do { _ = try DirectGradePagination.merge([p1,p2],previousCount:1); check("missing page accepted",false) }
        catch { check("unfinished chain refused",true) }
        do { _ = try DirectGradePagination.merge([p1,["Grades":[["Id":1]]]],previousCount:1); check("repeat ID accepted",false) }
        catch { check("repeat ID blocked",true) }
        for error in [GradePagingError.invalidContinuation,.unsupportedContinuation,.repeatedPage,
                      .tooManyPages,.inconsistentTotal,.duplicateGradeID,.missingGrades,.interruptedPageChain] {
            check("Polish error description \(error)", !(error.errorDescription ?? "").isEmpty)
        }
        check("no credential text in error", !GradePagingError.repeatedPage.localizedDescription.lowercased().contains("hasł"))
        print("GRADE PAGING SAFETY PASS \(passed)/\(passed)")
    }
}
