import Foundation

@main struct GradeSubjectAuthorAuditChecks {
    static func grade(_ id: String, _ subject: String, _ author: String?) -> DirectGrade {
        DirectGrade(id: id, subjectId: subject, categoryId: nil, value: "5",
                    semester: 1, addedAt: nil, commentTexts: [], teacherId: author)
    }
    static func main() {
        var n = 0
        func ok(_ cond: Bool, _ label: String) {
            precondition(cond, "FAIL: " + label)
            n += 1
        }
        let a = grade("a", "s1", "u1")
        let b = grade("b", "s1", "u2")
        let c = grade("c", "s2", "u3")
        let d = grade("d", "s3", nil)
        let e = grade("e", "s4", "u4")
        let grades = [a,b,c,d,e]
        let subjects = ["s1":" Matematyka ", "s2":"", "s3":"  ", "s4":"Polski"]
        let names = ["u1":"  Anna Nowak  ", "u2":" Jan Kowalski ", "u3":" ", "u4":"Ola Nowak", "orphan":"Nie wolno"]
        let earlier = Set(["u2", "u3", "orphan"])
        let report = GradeSubjectAuthorAudit.summarize(grades, subjects:subjects,
                            authors:names, earlierAuthorIds:earlier)
        ok(report.totalGrades == 5, "all grades")
        ok(report.namedSubjects == 3, "explicit subject names only")
        ok(report.unnamedSubjects == 2, "missing and whitespace subjects")
        ok(report.missingSubjectIds == ["s2", "s3"], "distinct unresolved subject IDs")
        ok(report.currentAuthors == 2, "current author from explicit reference")
        ok(report.earlierAuthors == 1, "cached author flagged")
        ok(report.unresolvedAuthors == 1, "blank author not invented")
        ok(report.noAuthorReference == 1, "absent author not guessed")
        ok(report.hasWarnings, "warning needed")
        ok(report.currentAuthors + report.earlierAuthors + report.unresolvedAuthors + report.noAuthorReference == report.totalGrades,
           "author accounting invariant")
        ok(report.namedSubjects + report.unnamedSubjects == report.totalGrades,
           "subject accounting invariant")
        ok(report.message.contains("nie musi być nauczycielem"), "authorship not equated to teacher")
        ok(GradeSubjectAuthorAudit.attribution(for:a,names:names,earlierIds:earlier) == .current("Anna Nowak"), "fresh trimmed")
        ok(GradeSubjectAuthorAudit.attribution(for:b,names:names,earlierIds:earlier) == .earlier("Jan Kowalski"), "stale name")
        ok(GradeSubjectAuthorAudit.attribution(for:c,names:names,earlierIds:earlier) == .unresolved, "unknown author")
        ok(GradeSubjectAuthorAudit.attribution(for:d,names:names,earlierIds:earlier) == .notProvided, "no reference")
        ok(GradeSubjectAuthorAudit.attribution(for:e,names:names,earlierIds:earlier) == .current("Ola Nowak"), "unmarked author")
        ok(GradeSubjectAuthorAudit.attribution(for:b,names:names,earlierIds:earlier).label.contains("wcześniejszego"), "stale label")
        ok(GradeSubjectAuthorAudit.attribution(for:c,names:names,earlierIds:earlier).label == "Nieustalony", "unknown label")
        ok(GradeSubjectAuthorAudit.attribution(for:d,names:names,earlierIds:earlier).label == "Nieustalony", "absent label")
        let empty=GradeSubjectAuthorAudit.summarize([],subjects:subjects,authors:names,earlierAuthorIds:earlier)
        ok(empty.totalGrades==0 && empty.namedSubjects==0 && empty.unnamedSubjects==0,"empty report")
        ok(!empty.hasWarnings,"empty has no warnings")
        let perfect=GradeSubjectAuthorAudit.summarize([a,e],subjects:subjects,authors:names,earlierAuthorIds:earlier)
        ok(!perfect.hasWarnings && perfect.currentAuthors==2,"all references resolved")
        for i in 1...24 {
            let id=String(i)
            let g=grade(id,"s1","u"+id)
            let names=["u"+id:"Teacher "+id]
            let r=GradeSubjectAuthorAudit.summarize([g],subjects:subjects,authors:names,earlierAuthorIds:[])
            ok(r.namedSubjects==1 && r.currentAuthors==1 && !r.hasWarnings, "resolved row \(i)")
        }
        let repeated=GradeSubjectAuthorAudit.summarize([a,a],subjects:subjects,authors:names,earlierAuthorIds:earlier)
        ok(repeated.totalGrades==2 && repeated.namedSubjects==2,"each input record counted")
        ok(repeated.missingSubjectIds.isEmpty,"no missing subject metadata")
        print("PASS \(n)/\(n) GradeSubjectAuthorAudit cases")
    }
}
