import Foundation
@main struct SubjectBoundaries {
 static func main() throws {
  var n=0
  func ok(_ v: Bool,_ label:String){precondition(v,label);n+=1}
  func fails<T>(_ f:() throws -> T)->Bool { do {_=try f();return false} catch{return true} }
  let root:[String:Any] = ["Subjects": [["Id": 1,"Name":"Matematyka"], ["Id":"s2","Name":" Język polski "]]]
  let decoded=try SynergiaSubjects.decode(root)
  ok(decoded["1"] == "Matematyka", "numeric id")
  ok(decoded["s2"] == " Język polski ", "literal ID preserved")
  ok(decoded.count == 2, "count")
  for invalid in [true,false,1.2,-0.3,Double.infinity,Double.nan] as [Any] {
   ok(fails {try SynergiaSubjects.decode(["Subjects":[["Id":invalid,"Name":"A"]]])},"invalid numeric ID")
  }
  ok(fails {try SynergiaSubjects.decode(["Subjects":[["Id":2,"Name":"A"],["Id":"2","Name":"B"]]])},"mixed id duplicate")
  ok(fails {try SynergiaSubjects.decode(["Subjects":[["Id":"a","Name":"A"],["Id":"a","Name":"B"]]])},"duplicate string id")
  ok(fails {try SynergiaSubjects.decode(["Subjects":"bad"])},"malformed root")
  ok(fails {try SynergiaSubjects.decode(["X": []])},"missing root")
  let skipped=try SynergiaSubjects.decode(["Subjects":[["Name":"No ID"],["Id":9,"Name":"   "],["Id":10,"Name":"Yes"]]])
  ok(skipped.count == 1, "incomplete lookup row skipped")
  ok(skipped["10"] == "Yes", "valid row after incomplete preserved")
  ok(fails {try GradeReferenceIntegrity.validate(grades:[DirectGrade(id:"1",subjectId:"9",categoryId:nil,value:"5",semester:1,addedAt:nil,commentTexts:[])],subjects:skipped)},"grade with unresolved metadata blocked")
  ok(!fails {try GradeReferenceIntegrity.validate(grades:[DirectGrade(id:"2",subjectId:"10",categoryId:nil,value:"4",semester:2,addedAt:nil,commentTexts:[])],subjects:skipped)},"resolved metadata accepted")
  for id in 20...40 {
   let names=try SynergiaSubjects.decode(["Subjects":[["Id":id,"Name":"Subject \(id)"]]])
   ok(names[String(id)] == "Subject \(id)","subject numeric id \(id)")
  }
  print("PASS \(n)/\(n) subject lookup integrity checks")
 }
}
