import Foundation

@main struct GradeTeachersTest {
    static func main() throws {
        var passed = 0
        func check(_ value: @autoclosure () -> Bool, _ label: String) {
            precondition(value(), "FAIL: \(label)")
            passed += 1
        }
        func row(_ author: Any? = nil) -> [String: Any] {
            var g: [String:Any] = ["Id": 42, "Subject": ["Id": 8], "Grade": "5", "Semester": 1]
            if let author { g["AddedBy"] = author }
            return g
        }
        let users = try DirectGradeAuthors.decode(["Users": [
            ["Id": 7, "FirstName": "Anna", "LastName": "Kowalska"],
            ["Id": "8", "FirstName": NSNull(), "LastName": "Nowak"],
            ["Id": 9, "FirstName": NSNull(), "LastName": NSNull()]
        ]])
        check(users["7"] == "Anna Kowalska", "full name")
        check(users["8"] == "Nowak", "partial name")
        check(users["9"] == "", "no invented name")
        let grade = try SynergiaGradeRecords.decode(grades: ["Grades": [row(["Id":7])]], comments: nil)
        check(grade.first?.teacherId == "7", "reference")
        check(DirectGradeAuthors.missingIds(grade, users: users).isEmpty, "known reference")
        let noTeacher = try SynergiaGradeRecords.decode(grades: ["Grades": [row()]], comments: nil)
        check(noTeacher.first?.teacherId == nil, "absent author")
        check(DirectGradeAuthors.missingIds(grade, users: [:]) == ["7"], "unresolved author")
        let cached = try JSONEncoder().encode(noTeacher)
        let restored = try JSONDecoder().decode([DirectGrade].self, from: cached)
        check(restored.first?.teacherId == nil, "cache roundtrip")
        let legacy = """
        {"id":"42","subjectId":"8","categoryId":null,"value":"5","semester":1,"addedAt":null,"commentTexts":[],"categoryName":null,"weight":null,"countsToAverage":null}
        """.data(using: .utf8)!
        let restoredLegacy = try JSONDecoder().decode(DirectGrade.self, from: legacy)
        check(restoredLegacy.teacherId == nil, "old cache")
        do {
            _ = try SynergiaGradeRecords.decode(grades: ["Grades": [row(["Broken":7])]], comments: nil)
            preconditionFailure("invalid author accepted")
        } catch DirectGradeDecodeError.malformedTeacherReference { passed += 1 }
        do {
            _ = try DirectGradeAuthors.decode(["Users": [["Id": 7, "FirstName": "A"], ["Id": 7, "FirstName": "B"]]])
            preconditionFailure("duplicate user accepted")
        } catch DirectGradeAuthorsError.duplicateUser { passed += 1 }
        do {
            _ = try DirectGradeAuthors.decode(["Users": [["Id": true, "FirstName": "A"]]])
            preconditionFailure("boolean ID accepted")
        } catch DirectGradeAuthorsError.malformedUser { passed += 1 }
        print("PASS \(passed)/\(passed) teacher reference tests")
    }
}
