import Foundation

private func grade(_ id: String, _ value: String, _ weight: Double?, _ included: Bool?, subject: String = "math", semester: Int? = 1) -> DirectGrade {
    DirectGrade(id: id, subjectId: subject, categoryId: "cat", value: value,
                semester: semester, addedAt: nil, commentTexts: [],
                categoryName: "Test", weight: weight, countsToAverage: included)
}

@main struct GradeMeanSafetyTests {
    static func main() {
        var checks = 0
        func test(_ desc: String, _ condition: @autoclosure () -> Bool) {
            precondition(condition(), "FAILED: \(desc)")
            checks += 1
        }
        let simple = GradeWeightedAverage.calculate([grade("1", "5", 2, true), grade("2", "3", 1, true)])
        test("single subject/semester", simple.count == 1)
        test("weighted numeric mean", abs((simple.first?.mean ?? 0) - 13.0/3.0) < 1e-12)
        test("included count", simple[0].includedCount == 2)
        test("unresolved count", simple[0].unresolvedCount == 0)
        let huge = GradeWeightedAverage.calculate([grade("1", "6", 1e308, true), grade("2", "2", 1e308, true)])
        test("huge finite weights do not overflow", huge[0].mean == 4)
        let tiny = GradeWeightedAverage.calculate([grade("1", "6", 1e-300, true), grade("2", "2", 1e-300, true)])
        test("tiny finite weights", tiny[0].mean == 4)
        let mixed = GradeWeightedAverage.calculate([grade("1", "4", 1e308, true), grade("2", "2", 1, true)])
        test("mixed scale values finite", mixed[0].mean?.isFinite == true)
        let excluded = GradeWeightedAverage.calculate([grade("1", "6", nil, false), grade("2", "3", 2, true), grade("3", "5", 0, true)])
        test("explicitly excluded not unresolved", excluded[0].unresolvedCount == 0)
        test("zero-weight excluded", excluded[0].excludedCount == 2)
        test("zero-weight omitted in average", excluded[0].mean == 3)
        let unknown = GradeWeightedAverage.calculate([grade("1", "6", nil, true), grade("2", "2", 1, true)])
        test("missing weight prevents mean", unknown[0].mean == nil)
        test("missing weight reported", unknown[0].unresolvedCount == 1)
        let unknownFlag = GradeWeightedAverage.calculate([grade("1", "6", 1, nil)])
        test("unknown inclusion fails closed", unknownFlag[0].mean == nil)
        let unknownValue = GradeWeightedAverage.calculate([grade("1", "6+", 1, true)])
        test("plus grade unsupported", unknownValue[0].mean == nil)
        let infinity = GradeWeightedAverage.calculate([grade("1", "5", .infinity, true)])
        test("infinite weight rejected", infinity[0].mean == nil)
        let negative = GradeWeightedAverage.calculate([grade("1", "5", -1, true)])
        test("negative weight rejected", negative[0].mean == nil)
        let duplicate = GradeWeightedAverage.calculate([grade("x", "5", 2, true), grade("x", "3", 2, true)])
        test("duplicate identities fail closed", duplicate[0].mean == nil)
        test("duplicate count explicit", duplicate[0].unresolvedCount == 2)
        let crossSubject = GradeWeightedAverage.calculate([grade("x", "5", 2, true, subject: "a"), grade("x", "3", 2, true, subject: "b")])
        test("cross-subject identity conflict", crossSubject.count == 2 && crossSubject.allSatisfy { $0.mean == nil })
        let separate = GradeWeightedAverage.calculate([grade("x", "6", 2, true, semester: 1), grade("y", "2", 2, true, semester: 2)])
        test("different semesters separated", separate.map(\.semester) == [1,2])
        let none = GradeWeightedAverage.calculate([grade("1", "6", 1, true, semester: nil)])
        test("missing semester no fake group", none.isEmpty)
        let category = DirectGradeCategory(id:"7", name:"Wypracowanie", weight:0, countsToAverage:false)
        let enriched = SynergiaGradeCategories.enrich([grade("1", "6", nil, nil)], categories:["cat":category])
        test("category weight zero preserved", enriched[0].weight == 0)
        test("category excluded flag preserved", enriched[0].countsToAverage == false)
        let fromCategory = GradeWeightedAverage.calculate(enriched)
        test("category exclusion not unknown", fromCategory[0].mean == nil && fromCategory[0].excludedCount == 1 && fromCategory[0].unresolvedCount == 0)
        let noCategory = SynergiaGradeCategories.enrich([grade("1", "6", nil, nil)], categories: [:])
        test("unresolved category not fabricated", noCategory[0].weight == nil && noCategory[0].countsToAverage == nil)
        print("PASS \(checks)/\(checks) safety assertions for grade weights and averages")
    }
}
