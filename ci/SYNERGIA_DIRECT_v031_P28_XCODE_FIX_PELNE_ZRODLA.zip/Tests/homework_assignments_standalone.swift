import Foundation

// Foundation-only tests. They cannot prove actual Librus JSON shape or iOS UI.
enum SynergiaGatewayClient {
    enum Resource: String {
        case homework = "HomeWorks", homeworkAssignments = "HomeWorkAssignments"
        case schoolNotices = "SchoolNotices", schoolFiles = "SchoolFiles"
    }
}

@main struct HomeworkAssignmentTests {
    static var passed = 0
    static var failed = 0
    static func check(_ label: String, _ predicate: () throws -> Bool) {
        do {
            if try predicate() { passed += 1 }
            else { failed += 1; print("FAIL \(label)") }
        } catch { failed += 1; print("FAIL \(label): \(error)") }
    }
    static func rejects(_ f: () throws -> Any) -> Bool {
        do { _ = try f(); return false } catch { return true }
    }
    static func row(_ id: Int, due: String? = "2026-11-05", text: String = "<p>Ćwiczenie &amp; zadanie</p>") -> [String: Any] {
        var data: [String: Any] = ["Id": id, "Topic": "Zadanie \(id)", "Text": text,
            "Category": ["Name": "Praca domowa"], "Subject": ["Name": "Język polski"],
            "CreationDate": "2026-11-02", "HomeworkAssigmentFiles": [[String: Any]]()]
        if let due { data["DueDate"] = due }
        return data
    }
    static func feed(_ rows: [[String: Any]], account: String = "a", total: Int? = nil) throws -> DirectSchoolFeed {
        var root: [String: Any] = ["HomeWorkAssignments": rows]
        if let total { root["Total"] = total }
        return try DirectSchoolFeedParser.parse(root, module: .homework, accountId: account)
    }
    static func main() {
        check("correct resource") { try DirectSchoolFeedParser.resource(for: .homework) == .homeworkAssignments }
        check("not the agenda") { try DirectSchoolFeedParser.resource(for: .calendar) == .homework }
        check("parses optional due") { try feed([row(1)]).records[0].homework?.dueDay == "2026-11-05" }
        check("missing due unknown") { try feed([row(1, due: nil)]).records[0].homework?.dueDay == nil }
        check("Date not guessed as due") {
            var data = row(1, due: nil); data["Date"] = "2026-12-31"
            return try feed([data]).records[0].homework?.dueDay == nil
        }
        check("valid deadline alternate") {
            var data = row(1, due: nil); data["Deadline"] = "2026-11-08 12:00:00"
            return try feed([data]).records[0].homework?.dueDay == "2026-11-08"
        }
        check("invalid day remains unknown") { try feed([row(1, due: "2026-02-30")]).records[0].homework?.dueDay == nil }
        check("script inert in text") {
            try feed([row(1, text: "<script>steal()</script><p>Treść</p>")]).records[0].homework?.body == "Treść"
        }
        check("HTML entity decoded") { try feed([row(1)]).records[0].homework?.body == "Ćwiczenie & zadanie" }
        check("subject only from response") { try feed([row(1)]).records[0].homework?.subjectName == "Język polski" }
        check("category only from response") { try feed([row(1)]).records[0].homework?.categoryName == "Praca domowa" }
        check("unknown subject not inferred") {
            var item = row(1); item.removeValue(forKey: "Subject"); item["Teacher"] = ["Name": "Example"]
            return try feed([item]).records[0].homework?.subjectName == nil
        }
        check("wrong type category not guessed") {
            var item = row(1); item["Category"] = ["Id": 4]
            return try feed([item]).records[0].homework?.categoryName == nil
        }
        check("publication only explicit") { try feed([row(1)]).records[0].homework?.publishedDay == "2026-11-02" }
        check("no completion metadata invented") {
            try feed([row(1)]).records[0].homework?.dueDay != nil
        }
        check("sort dated then no-date") {
            let f = try feed([row(1,due:nil),row(2,due:"2026-11-20"),row(3,due:"2026-11-01")])
            return DirectHomeworkPresentation.entries(f,today:"2026-11-05").map { $0.serverId ?? "" } == ["3","2","1"]
        }
        check("today counts in upcoming") {
            let f = try feed([row(1,due:"2026-11-04"),row(2,due:"2026-11-05"),row(3,due:"2026-11-06")])
            return DirectHomeworkPresentation.entries(f,period:.upcoming,today:"2026-11-05").count == 2
        }
        check("past filters date not undone") {
            let f = try feed([row(1,due:"2026-11-04"),row(2,due:"2026-11-05")])
            return DirectHomeworkPresentation.entries(f,period:.overdue,today:"2026-11-05").count == 1
        }
        check("unknown due excluded from upcoming") {
            let f = try feed([row(1,due:nil)])
            return DirectHomeworkPresentation.entries(f,period:.upcoming,today:"2026-11-05").isEmpty
        }
        check("unknown today doesn't mislabel") {
            let f = try feed([row(1)])
            return DirectHomeworkPresentation.entries(f,period:.overdue,today:"2026-02-30").isEmpty
        }
        check("undated filter") {
            let f = try feed([row(1,due:nil),row(2)])
            return DirectHomeworkPresentation.entries(f,period:.undated,today:"2026-11-05").count == 1
        }
        check("search by text") { try DirectHomeworkPresentation.entries(feed([row(1)]),query:"ĆWICZENIE",today:"2026-11-05").count == 1 }
        check("search by subject") { try DirectHomeworkPresentation.entries(feed([row(1)]),query:"POLSKI",today:"2026-11-05").count == 1 }
        check("search by category") { try DirectHomeworkPresentation.entries(feed([row(1)]),query:"PRACA",today:"2026-11-05").count == 1 }
        check("search trims spaces") { try DirectHomeworkPresentation.entries(feed([row(1)]),query:"  zadanie 1  ",today:"2026-11-05").count == 1 }
        check("search by attached filename") {
            var item = row(1); item["HomeworkAssigmentFiles"] = [["Id": 90,"Name":"Polecenie.pdf", "Url":"https://synergia.librus.pl/gateway/api/2.0/HomeWorkAssignments/Attachment/1-90"]]
            let f = try feed([item])
            return DirectHomeworkPresentation.entries(f,query:"POLECENIE",today:"2026-11-05").count == 1 && f.records[0].homeworkFiles?.count == 1
        }
        check("no mixing with agenda") {
            let f = try DirectSchoolFeedParser.parse(["HomeWorks":[["Id": 1,"Content":"Wycieczka"]]],module:.calendar,accountId:"a")
            return f.records.first?.homework == nil && DirectHomeworkPresentation.entries(f,today:"2026-11-05").isEmpty
        }
        check("no mixing with notices") {
            let f = try DirectSchoolFeedParser.parse(["SchoolNotices":[["Id": 1,"Subject":"Info"]]],module:.announcements,accountId:"a")
            return f.records.first?.homework == nil && DirectHomeworkPresentation.entries(f,today:"2026-11-05").isEmpty
        }
        check("grouping by day") {
            let f = try feed([row(1),row(2),row(3,due:nil)])
            let g = DirectHomeworkPresentation.groups(DirectHomeworkPresentation.entries(f,today:"2026-11-05"))
            return g.count == 2 && g[0].entries.count == 2 && g[1].day == "Brak potwierdzonego terminu"
        }
        check("unknown empty feed refused") { rejects { try feed([]) } }
        check("known empty feed accepted") { try feed([],total:0).records.isEmpty }
        check("no fake completeness") { try !feed([row(1)]).completenessKnown }
        check("known total respected") { try feed([row(1)],total:1).completenessKnown }
        check("offline current roundtrip") {
            let f = try feed([row(1)])
            let d = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            return try DirectOfflineFeedCache.decode(d,module:.homework,expectedAccountId:"a").records[0].homework == f.records[0].homework
        }
        check("offline second account blocked") {
            let f = try feed([row(1)]); let data = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            return rejects { try DirectOfflineFeedCache.decode(data,module:.homework,expectedAccountId:"b") }
        }
        check("offline other module blocked") {
            let f = try feed([row(1)]); let data = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            return rejects { try DirectOfflineFeedCache.decode(data,module:.calendar,expectedAccountId:"a") }
        }
        check("legacy snapshot without homework still works") {
            let f = try feed([row(1)]); let data = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            var container = try JSONSerialization.jsonObject(with:data) as! [String:Any]
            var stored = container["feed"] as! [String:Any]
            var records = stored["records"] as! [[String:Any]]
            records[0].removeValue(forKey:"homework")
            stored["records"] = records; container["feed"] = stored
            let legacy = try JSONSerialization.data(withJSONObject:container)
            return try DirectOfflineFeedCache.decode(legacy,module:.homework,expectedAccountId:"a").records[0].homework == nil
        }
        check("offline injected foreign agenda rejected") {
            let f = try feed([row(1)]); let data = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            var container = try JSONSerialization.jsonObject(with:data) as! [String:Any]
            var stored = container["feed"] as! [String:Any]
            var records = stored["records"] as! [[String:Any]]
            records[0]["agenda"] = ["day":"2026-11-05"]
            stored["records"] = records; container["feed"] = stored
            let altered = try JSONSerialization.data(withJSONObject:container)
            return rejects { try DirectOfflineFeedCache.decode(altered,module:.homework,expectedAccountId:"a") }
        }
        check("offline bogus due rejected") {
            let f = try feed([row(1)]); let data = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            var container = try JSONSerialization.jsonObject(with:data) as! [String:Any]
            var stored = container["feed"] as! [String:Any]
            var records = stored["records"] as! [[String:Any]]
            var homework = records[0]["homework"] as! [String:Any]
            homework["dueDay"] = "2026-02-30"
            records[0]["homework"] = homework; stored["records"] = records; container["feed"] = stored
            let altered = try JSONSerialization.data(withJSONObject:container)
            return rejects { try DirectOfflineFeedCache.decode(altered,module:.homework,expectedAccountId:"a") }
        }
        check("audited data change") {
            let a = try feed([row(1)]); let b = try feed([row(1,due:"2026-11-06")])
            return DirectFeedChangeAudit.compare(previous:a,current:b).changed == 1
        }
        check("audited account change not compared") {
            let a = try feed([row(1)],account:"a"); let b = try feed([row(1)],account:"b")
            return !DirectFeedChangeAudit.compare(previous:a,current:b).comparable
        }
        check("missing record never called deleted") {
            let a = try feed([row(1),row(2)],total:2); let b = try feed([row(1)],total:1)
            return DirectFeedChangeAudit.compare(previous:a,current:b).removedConfirmed == 0
        }
        for year in 2022...2033 {
            for month in 1...12 {
                for day in 1...31 {
                    let literal = String(format:"%04d-%02d-%02d",year,month,day)
                    var calendar = Calendar(identifier:.gregorian)
                    calendar.timeZone = TimeZone(secondsFromGMT: 0)!
                    let checkDate = calendar.date(from: DateComponents(year:year,month:month,day:day))!
                    let expected = calendar.component(.month,from:checkDate) == month
                    check("strict date \(literal)") {
                        (DirectHomeworkAssignment.parse(["DueDate":literal]).dueDay != nil) == expected
                    }
                }
            }
        }
        print("HOMEWORK ASSIGNMENTS PASS=\(passed) FAIL=\(failed)")
        if failed > 0 { exit(1) }
    }
}
