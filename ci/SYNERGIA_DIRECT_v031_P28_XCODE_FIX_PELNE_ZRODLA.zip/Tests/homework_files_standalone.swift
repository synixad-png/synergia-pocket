import Foundation

@main struct HomeworkTests {
    static var passed=0, failed=0
    static func check(_ what:String,_ fn:() throws -> Bool) {
        do { if try fn() { passed += 1; print("PASS: \(what)") } else { failed += 1; print("FAIL: \(what)") } }
        catch { failed += 1; print("FAIL: \(what) - \(error)") }
    }
    static func base(_ id:String="32") -> [String:Any] {
        ["Id": 11, "Topic": "Zadanie", "HomeworkAssigmentFiles": [["Id": id, "Name": "Kartkówka.pdf",
          "Url": "https://synergia.librus.pl/gateway/api/2.0/HomeWorkAssignments/Attachment/11-\(id)"]]]
    }
    static func main() {
        check("real source attachment parsed") { try DirectHomeworkFilePolicy.parse(base())?.first?.key == "11:32" }
        check("nonnumeric ids rejected") { do { _ = try DirectHomeworkFilePolicy.parse(base("x"));return false } catch {return true} }
        check("mismatch assignment rejected") { var row=base();var files=row["HomeworkAssigmentFiles"] as! [[String:Any]];files[0]["Url"]="https://synergia.librus.pl/gateway/api/2.0/HomeWorkAssignments/Attachment/12-32";row["HomeworkAssigmentFiles"]=files; do {_ = try DirectHomeworkFilePolicy.parse(row);return false} catch{return true} }
        check("foreign domain rejected") { var row=base();var files=row["HomeworkAssigmentFiles"] as! [[String:Any]];files[0]["Url"]="https://evil.example/abc";row["HomeworkAssigmentFiles"]=files;do {_ = try DirectHomeworkFilePolicy.parse(row);return false} catch{return true} }
        check("duplicate file ids rejected") { var row=base();var files=row["HomeworkAssigmentFiles"] as! [[String:Any]];files.append(files[0]);row["HomeworkAssigmentFiles"]=files;do {_ = try DirectHomeworkFilePolicy.parse(row);return false} catch{return true} }
        check("unsafe filename rejected") { var row=base();var files=row["HomeworkAssigmentFiles"] as! [[String:Any]];files[0]["Name"]="../bad.txt";row["HomeworkAssigmentFiles"]=files;do {_ = try DirectHomeworkFilePolicy.parse(row);return false} catch{return true} }
        check("missing field unknown, not empty") { try DirectHomeworkFilePolicy.parse(["Id":1]) == nil }
        check("known empty array") { try DirectHomeworkFilePolicy.parse(["Id":1,"HomeworkAssigmentFiles": [[String:Any]]()])?.isEmpty == true }
        check("empty nonarray rejected") { do {_ = try DirectHomeworkFilePolicy.parse(["Id":1,"HomeworkAssigmentFiles": ""]) ;return false} catch{return true} }
        check("download url constrained") { try DirectHomeworkFilePolicy.downloadURL(DirectHomeworkFileReference(assignmentId:"11",id:"32",name:"file.txt")).absoluteString == "https://synergia.librus.pl/homework/downloadFile/32" }
        check("GetFile mode") { if case .getFile = try DirectHomeworkFilePolicy.ticket("https://sandbox.librus.pl/GetFile/abc32") { return true }; return false }
        check("single-use key mode") { if case .singleUseKey(_,let key) = try DirectHomeworkFilePolicy.ticket("https://sandbox.librus.pl/index.php?action=CSTryToDownload&singleUseKey=AbC_32") { return key == "AbC_32" }; return false }
        check("external redirect blocked") { do {_ = try DirectHomeworkFilePolicy.ticket("https://attacker.tld/GetFile/abc");return false} catch{return true} }
        check("http blocked") { do {_ = try DirectHomeworkFilePolicy.ticket("http://sandbox.librus.pl/GetFile/abc");return false} catch{return true} }
        check("query injection blocked") { do {_ = try DirectHomeworkFilePolicy.ticket("https://sandbox.librus.pl/index.php?action=CSTryToDownload&singleUseKey=abc&next=//evil");return false} catch{return true} }
        check("GET CSDownload URL fixed") { try DirectHomeworkFilePolicy.keyURL(action:"CSDownload",key:"abc").absoluteString.contains("action=CSDownload") }
        check("invalid key blocked") { do {_ = try DirectHomeworkFilePolicy.keyURL(action:"CSDownload",key:"abc&bad=x");return false} catch{return true} }
        check("HTML is not PDF") { !DirectHomeworkFilePolicy.fileResponseOK(status:200,type:"text/html",size:100) }
        check("file ok") { DirectHomeworkFilePolicy.fileResponseOK(status:200,type:"application/pdf",size:1500) }
        check("size rejected") { !DirectHomeworkFilePolicy.fileResponseOK(status:200,type:"application/pdf",size:20_000_000) }
        check("JSON rejected") { !DirectHomeworkFilePolicy.fileResponseOK(status:200,type:"application/json",size:150) }
        print("HOMEWORK FILES PASS=\(passed) FAIL=\(failed)")
        if failed != 0 { exit(1) }
    }
}
