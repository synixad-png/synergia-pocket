import Foundation

private var assertions = 0
private func check(_ condition: @autoclosure () -> Bool, _ label: String) {
    assertions += 1
    if !condition() { fputs("FAIL: \(label)\n", stderr); exit(1) }
}

var policy = DirectLoginRestorePolicy()
check(!policy.startupCheckClaimed, "not checked at init")
check(!policy.awaitingOfficialReturn, "no pending login at init")
check(policy.claimStartupVerification(), "first startup verification")
for _ in 0..<100 { check(!policy.claimStartupVerification(), "no duplicate startup verification") }
check(policy.startupCheckClaimed, "startup check recorded")
check(!policy.claimVerificationAfterReturn(to: URL(string: "https://synergia.librus.pl/")),
      "ordinary return not login")
policy.officialLoginOpened()
check(policy.awaitingOfficialReturn, "return is pending")
let unsafe = [
    "http://synergia.librus.pl/", "https://synergia.librus.pl.evil.test/",
    "https://evil.test/synergia.librus.pl", "https://portal.librus.pl/rodzina/synergia/loguj",
    "https://api.librus.pl/", "https://librus.pl/", "https://other.librus.pl/",
    "https://synergia.librus.pl:444/", "https://user@synergia.librus.pl/",
    "https://pass:secret@synergia.librus.pl/", "https://synergia.librus.pl/login",
    "https://synergia.librus.pl/loguj", "https://synergia.librus.pl/logout",
    "https://synergia.librus.pl/wyloguj", "https://synergia.librus.pl/oauth/authorization",
    "ftp://synergia.librus.pl/", "https://synergia.librus.pl.evil.test/panel"
]
for url in unsafe {
    check(!DirectLoginRestorePolicy.isTrustedLanding(URL(string: url)), "reject host/form: \(url)")
    check(!policy.claimVerificationAfterReturn(to: URL(string: url)), "pending remains after: \(url)")
}
check(policy.awaitingOfficialReturn, "unsafe redirects retain pending state")
check(!policy.claimVerificationAfterReturn(to: nil), "nil navigation rejected")
check(policy.awaitingOfficialReturn, "nil navigation does not consume pending")
let safe = ["https://synergia.librus.pl/", "https://synergia.librus.pl/uczen/",
            "https://synergia.librus.pl/index.php", "https://synergia.librus.pl/panel/?k=1"]
for url in safe { check(DirectLoginRestorePolicy.isTrustedLanding(URL(string: url)), "trusted site: \(url)") }
check(policy.claimVerificationAfterReturn(to: URL(string: safe[0])), "reverify after trusted return")
check(!policy.awaitingOfficialReturn, "one-shot consumed")
for _ in 0..<100 {
    check(!policy.claimVerificationAfterReturn(to: URL(string: safe[0])), "no repeated /Me requests")
}
policy.officialLoginOpened()
policy.cancelPendingReturn()
check(!policy.awaitingOfficialReturn, "logout cancels pending return")
check(!policy.claimVerificationAfterReturn(to: URL(string: safe[1])), "no verify after cancellation")
policy.officialLoginOpened()
policy.officialLoginOpened()
check(policy.claimVerificationAfterReturn(to: URL(string: safe[2])), "repeated login click still one-shot")
check(!policy.claimVerificationAfterReturn(to: URL(string: safe[3])), "no second callback")
check(!policy.claimStartupVerification(), "startup remains one-shot after logout")
print("LOGIN RESTORE POLICY PASS \(assertions)/\(assertions) checks")
