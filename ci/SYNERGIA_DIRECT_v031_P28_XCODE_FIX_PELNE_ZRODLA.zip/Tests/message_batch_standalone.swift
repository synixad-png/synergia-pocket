import Foundation

@main struct MessageBatchTests {
    static var pass = 0, fail = 0
    static func check(_ title: String, _ body: () throws -> Bool) {
        do {
            if try body() { pass += 1; print("PASS \(title)") }
            else { fail += 1; print("FAIL \(title)") }
        } catch { fail += 1; print("FAIL \(title): \(error)") }
    }
    static func row(_ id: String = "123", outgoing: Bool = false, preview: String = "") -> [String: Any] {
        let name = outgoing ? "receiverName" : "senderName"
        return ["messageId": id, name: "Jan Nowak", "topic": "Zebranie",
                "content": Data(preview.utf8).base64EncodedString(), "isAnyFileAttached": false]
    }
    static func detail(_ content: String, outgoing: Bool = false) -> [String: Any] {
        ["data": ["messageId": "123", outgoing ? "receiverName" : "senderName": "Osoba",
                   "topic": "Temat", "Message": Data(content.utf8).base64EncodedString(),
                   "attachments": [], "noReply": 0, "senderId": "employee1"]]
    }
    static func main() {
        check("all main and archive folders have distinct IDs") {
            DirectMailbox.allCases.count == 10 && Set(DirectMailbox.allCases.map(\.rawValue)).count == 10
        }
        check("archive endpoint paths") {
            DirectMailbox.archiveInbox.rawValue == "archive/inbox" && DirectMailbox.archiveOutbox.rawValue == "archive/outbox"
        }
        check("outgoing labels and reading side effects") {
            DirectMailbox.archiveOutbox.isOutgoing && DirectMailbox.outbox.isOutgoing &&
            !DirectMailbox.inbox.isOutgoing && !DirectMailbox.outbox.mayMarkRead
        }
        check("archives never provide direct attachments") {
            !DirectMailbox.archiveInbox.supportsDirectAttachments && !DirectMailbox.archiveOutbox.supportsDirectAttachments &&
            DirectMailbox.inbox.supportsDirectAttachments
        }
        check("bare JSON array in notes") {
            let page = try DirectMessageParser.list([row()], mailbox: .notes)
            return page.messages.count == 1 && page.total == nil
        }
        check("bare JSON empty array does not claim completeness") {
            let page = try DirectMessageParser.list([[String: Any]](), mailbox: .alerts)
            let snapshot = try DirectMessageParser.merge([page], mailbox: .alerts, accountId: "A")
            return snapshot.messages.count == 0 && !snapshot.complete
        }
        check("enveloped inbox remains complete") {
            let page = try DirectMessageParser.list(["data": [row()], "total": 1], mailbox: .inbox)
            return try DirectMessageParser.merge([page], mailbox: .inbox, accountId: "A").complete
        }
        check("array more than 50 rejected") {
            do { _ = try DirectMessageParser.list((1...51).map { row(String($0)) }, mailbox: .notes); return false }
            catch DirectMessageError.unexpectedShape { return true }
        }
        check("wrong JSON envelope rejected") {
            do { _ = try DirectMessageParser.list(["items": [row()]], mailbox: .notes); return false }
            catch DirectMessageError.unexpectedShape { return true }
        }
        check("archive outgoing reads receiver") {
            let p = try DirectMessageParser.list(["data": [row(outgoing: true)], "total": 1], mailbox: .archiveOutbox)
            return p.messages[0].correspondent == "Jan Nowak"
        }
        check("outbox detail receives receiver name") {
            let d = try DirectMessageParser.detail(detail("To tekst", outgoing: true), mailbox: .outbox, requestedId: "123")
            return d.sender == "Osoba" && !d.replyAllowed
        }
        check("archived inbox cannot trigger reply") {
            let d = try DirectMessageParser.detail(detail("Text"), mailbox: .archiveInbox, requestedId: "123")
            return !d.replyAllowed
        }
        check("CDATA XML renders readable paragraphs") {
            let body = "<Message><Content><![CDATA[<p>Cześć &amp; witaj!</p><p>Druga linia<br/>Trzecia</p>]]></Content></Message>"
            let d = try DirectMessageParser.detail(detail(body), mailbox: .inbox, requestedId: "123")
            return d.body == "Cześć & witaj!\n\nDruga linia\nTrzecia"
        }
        check("scripts styles remote images are inert") {
            let body = "<p>Jest OK</p><script>alert('secret')</script><style>body{color:red}</style><img src='https://evil.example/x.png'><p>Koniec</p>"
            let d = try DirectMessageParser.detail(detail(body), mailbox: .inbox, requestedId: "123")
            return d.body == "Jest OK\n\nKoniec" && !d.body.contains("alert(") && !d.body.contains("evil.example")
        }
        check("HTML entities Polish and unicode") {
            DirectMessagePlainText.render("&#380;&#322;&oacute;&nbsp;&#x1F44B;") == "żłó 👋"
        }
        check("invalid Unicode entities do not become control chars") {
            DirectMessagePlainText.render("X&#0;Y &#xD800;") == "X&#0;Y &#xD800;"
        }
        check("text containing less-than comparison retained") {
            DirectMessagePlainText.render("5 < 8, prawda?") == "5 < 8, prawda?"
        }
        check("raw email rendering escapes nothing executable") {
            DirectMessagePlainText.render("<a href='javascript:alert(1)'>Kliknij</a>") == "Kliknij"
        }
        check("trusted Librus ticket accepted") {
            let url = try DirectAttachmentPolicy.ticket(["data": ["status": "ok", "downloadLink": "https://sandbox.librus.pl/GetFile/a8K9"]])
            return url.host == "sandbox.librus.pl"
        }
        check("correct file path and original referer") {
            let ticket = URL(string: "https://sandbox.librus.pl/GetFile/a8K9")!
            return try DirectAttachmentPolicy.actualFileURL(ticket).absoluteString == "https://sandbox.librus.pl/GetFile/a8K9/get"
        }
        check("foreign ticket rejected even when https") {
            do { _ = try DirectAttachmentPolicy.ticket(["data": ["downloadLink": "https://external.example.net/GetFile/a8K9"]]); return false }
            catch DirectAttachmentError.untrustedDownloadLink { return true }
        }
        check("same hostname with prefixed domain rejected") {
            do { _ = try DirectAttachmentPolicy.ticket(["data": ["downloadLink": "https://sandbox.librus.pl.evil.example/GetFile/a8K9"]]); return false }
            catch DirectAttachmentError.untrustedDownloadLink { return true }
        }
        check("ticket incorrect path refused") {
            do { _ = try DirectAttachmentPolicy.ticket(["data": ["downloadLink": "https://sandbox.librus.pl/index.php?file=x"]]); return false }
            catch DirectAttachmentError.untrustedDownloadLink { return true }
        }
        check("double get suffix refused") {
            do { _ = try DirectAttachmentPolicy.ticket(["data": ["downloadLink": "https://sandbox.librus.pl/GetFile/a8K9/get"]]); return false }
            catch DirectAttachmentError.untrustedDownloadLink { return true }
        }
        check("no cleartext file link") {
            do { _ = try DirectAttachmentPolicy.ticket(["data": ["downloadLink": "http://sandbox.librus.pl/GetFile/x"]]); return false }
            catch DirectAttachmentError.untrustedDownloadLink { return true }
        }
        check("empty data list distinguish from unavailable") {
            let page = try DirectMessageParser.list(["data": [[String: Any]](), "total": 0], mailbox: .trash)
            return try DirectMessageParser.merge([page], mailbox: .trash, accountId: "A").complete
        }
        check("base64 truncated preview has safe replacement") {
            let truncated = Data([0x61,0xC4]).base64EncodedString()
            var r = row(); r["content"] = truncated
            let p = try DirectMessageParser.list(["data": [r], "total": 1], mailbox: .inbox)
            return p.messages[0].preview.hasPrefix("a")
        }
        print("TOTAL PASS=\(pass) FAIL=\(fail)")
        if fail > 0 { exit(1) }
    }
}
