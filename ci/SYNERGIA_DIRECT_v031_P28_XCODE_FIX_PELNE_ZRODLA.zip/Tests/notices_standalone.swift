import Foundation

// Linux Foundation-only transport stub; real application uses WebKit.
enum SynergiaGatewayClient {
    enum Resource: String {
        case homework = "HomeWorks"
        case homeworkAssignments = "HomeWorkAssignments"
        case schoolNotices = "SchoolNotices"
        case schoolFiles = "SchoolFiles"
    }
}

@main struct NoticeTests {
    static var pass = 0
    static var fail = 0
    static func check(_ name: String, _ test: () throws -> Bool) {
        do {
            guard try test() else { fail += 1; print("FAIL " + name); return }
            pass += 1
        } catch { fail += 1; print("FAIL " + name + ": \(error)") }
    }
    static func row(_ index: Int, read: Any? = false) -> [String: Any] {
        var value: [String: Any] = [
            "Id": "notice-\(index)", "Subject": "Ogłoszenie \(index)",
            "Content": "<p>Zajęcia <b>odwołane</b> &amp; &#322;&#243;d&#378;</p>",
            "CreationDate": "2026-11-05", "StartDate": "2026-11-05", "EndDate": "2026-11-12",
            "AddedBy": ["Id": "16", "Url": "https://example.invalid/"],
        ]
        if let read { value["WasRead"] = read }
        return value
    }
    static func page(_ range: Range<Int>, total: Int? = nil) -> [String: Any] {
        var payload: [String: Any] = ["SchoolNotices": range.map { row($0) }]
        if let total { payload["Total"] = total }
        return payload
    }
    static func refuses(_ result: () throws -> Any) -> Bool {
        do { _ = try result(); return false } catch { return true }
    }
    static func main() {
        check("real read flag") { DirectSchoolNotice.parse(row(1, read: true)).wasRead == true }
        check("real unread flag") { DirectSchoolNotice.parse(row(1, read: false)).wasRead == false }
        check("missing read flag unknown") { DirectSchoolNotice.parse(row(1, read: nil)).wasRead == nil }
        check("number read flag unknown") { DirectSchoolNotice.parse(row(1, read: 1)).wasRead == nil }
        check("string read flag unknown") { DirectSchoolNotice.parse(row(1, read: "true")).wasRead == nil }
        check("script stripped") { DirectSchoolNotice.plainText("<script>alert('secret')</script><p>A</p>") == "A" }
        check("style stripped") { DirectSchoolNotice.plainText("<style>.x{color:red}</style><div>OK</div>") == "OK" }
        check("iframe stripped") { DirectSchoolNotice.plainText("<iframe src='x'>bad</iframe>OK") == "OK" }
        check("no HTML tags") { DirectSchoolNotice.plainText("<h1>A</h1><p>B<br>C</p>") == "A\nB\nC" }
        check("entities decoded") { DirectSchoolNotice.plainText("&#322;&#243;d&#378; &amp; &lt;b&gt;") == "łódź & <b>" }
        check("bodies bounded") { DirectSchoolNotice.plainText(String(repeating: "X", count: 12001)) == nil }
        check("embedded author only reference") { DirectSchoolNotice.parse(row(0)).authorId == "16" }
        check("metadata dates") { DirectSchoolNotice.parse(row(0)).endDate == "2026-11-12" }
        check("two full pages merge") {
            let f = try DirectSchoolNoticePaging.merge([page(0..<50, total: 75),page(50..<75,total:75)],accountId:"account")
            return f.records.count == 75 && f.completenessKnown && f.records[0].notice?.wasRead == false
        }
        check("two pages no total remains unknown") {
            let f = try DirectSchoolNoticePaging.merge([page(0..<50),page(50..<75)],accountId:"account")
            return f.records.count == 75 && !f.completenessKnown
        }
        check("explicit empty zero") {
            let f = try DirectSchoolNoticePaging.merge([["SchoolNotices": [[String: Any]](), "Total": 0]], accountId:"a")
            return f.records.isEmpty && f.completenessKnown
        }
        check("unknown empty not accepted") { refuses { try DirectSchoolNoticePaging.merge([["SchoolNotices": [[String: Any]]()]],accountId:"a") } }
        check("duplicate identifier refused") {
            refuses { try DirectSchoolNoticePaging.merge([page(0..<50),page(49..<60)],accountId:"a") }
        }
        check("missing identifier refused") {
            refuses { try DirectSchoolNoticePaging.merge([["SchoolNotices": [["Subject": "A"]]]],accountId:"a") }
        }
        check("boolean identifier refused") {
            refuses { try DirectSchoolNoticePaging.merge([["SchoolNotices": [["Id": true,"Subject": "A"]]]],accountId:"a") }
        }
        check("conflicting total refused") {
            refuses { try DirectSchoolNoticePaging.merge([page(0..<50,total:50),page(50..<51,total:51)],accountId:"a") }
        }
        check("insufficient total refused") {
            refuses { try DirectSchoolNoticePaging.merge([page(0..<50,total:1)],accountId:"a") }
        }
        check("too many pages refused") {
            refuses { try DirectSchoolNoticePaging.merge(Array(repeating:page(0..<1),count:6),accountId:"a") }
        }
        check("bad page envelope refused") {
            refuses { try DirectSchoolNoticePaging.rowCount(["SchoolNotices": NSNull()]) }
        }
        check("read flag changes are audited") {
            let first = try DirectSchoolNoticePaging.merge([["SchoolNotices":[row(1,read:false)]]],accountId:"a")
            let last = try DirectSchoolNoticePaging.merge([["SchoolNotices":[row(1,read:true)]]],accountId:"a")
            return DirectFeedChangeAudit.compare(previous:first,current:last).changed == 1
        }
        check("no cross-account delta") {
            let a = try DirectSchoolNoticePaging.merge([page(0..<1)],accountId:"a")
            let b = try DirectSchoolNoticePaging.merge([page(0..<1)],accountId:"b")
            return !DirectFeedChangeAudit.compare(previous:a,current:b).comparable
        }
        check("offline encoded preserves flags") {
            let f = try DirectSchoolNoticePaging.merge([page(0..<2)],accountId:"a",date:Date())
            let d = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            let restored = try DirectOfflineFeedCache.decode(d,module:.announcements,expectedAccountId:"a")
            return restored.records[1].notice?.wasRead == false
        }
        check("offline cross-account denied") {
            let f = try DirectSchoolNoticePaging.merge([page(0..<1)],accountId:"a",date:Date())
            let d = try DirectOfflineFeedCache.encode(f,expectedAccountId:"a")
            return refuses { try DirectOfflineFeedCache.decode(d,module:.announcements,expectedAccountId:"b") }
        }
        check("legacy missing optional notice compatible") {
            let f = try DirectSchoolNoticePaging.merge([page(0..<1)],accountId:"a")
            let bytes = try JSONEncoder().encode(f)
            var root = try JSONSerialization.jsonObject(with: bytes) as! [String: Any]
            var records = root["records"] as! [[String: Any]]
            records[0].removeValue(forKey:"notice")
            root["records"] = records
            let legacy = try JSONSerialization.data(withJSONObject: root)
            let result = try JSONDecoder().decode(DirectSchoolFeed.self,from:legacy)
            return result.records[0].notice == nil
        }
        for i in 1...100 {
            check("paging count \(i)") {
                let expected = i
                let pages = stride(from:0,to:expected,by:DirectSchoolNoticePaging.pageSize).map {
                    page($0..<min(expected,$0+DirectSchoolNoticePaging.pageSize),total:expected)
                }
                return try DirectSchoolNoticePaging.merge(pages,accountId:"school").records.count == expected
            }
        }
        print("NOTICE_TESTS PASS=\(pass) FAIL=\(fail)")
        if fail != 0 { exit(1) }
    }
}
