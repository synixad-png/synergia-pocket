import Foundation

@main struct DirectNotificationPolicyStandaloneTests {
    static var passed = 0
    static func expect(_ name: String, _ test: @autoclosure () -> Bool) {
        precondition(test(), "FAIL: " + name)
        passed += 1
        print("PASS " + name)
    }

    static func changes(_ g: Bool, _ a: Bool, _ m: Bool) -> CoreLocalNotificationPlan {
        CoreLocalNotificationPlan(grades: g, attendance: a, messages: m)
    }
    static func kinds(_ names: DirectNotificationCategory...) -> [DirectNotificationCategory] { names }

    static func main() {
        let suite = "synergia-notification-tests-\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }

        let empty = DirectNotificationPreferences()
        expect("opt-in disabled on fresh installation", !empty.enabled)
        expect("grades chosen by default but not armed", empty.grades && !empty.permits(.grades))
        expect("attendance chosen but not armed", empty.attendance && !empty.permits(.attendance))
        expect("messages chosen but not armed", empty.messages && !empty.permits(.messages))
        expect("no categories when consent absent", empty.categories(from: changes(true,true,true)).isEmpty)
        expect("unknown saved settings fail closed", DirectNotificationPreferenceStorage.load(from: defaults) == empty)
        DirectNotificationPreferenceStorage.save(empty, to: defaults)
        expect("disabled preference survives restart", !DirectNotificationPreferenceStorage.load(from: defaults).enabled)
        expect("preferences serialized as plain settings only", {
            let text = String(data: defaults.data(forKey: DirectNotificationPreferenceStorage.key)!, encoding: .utf8)!
            return !text.contains("accountId") && !text.contains("student") && !text.contains("messageText")
        }())
        var prefs = empty
        prefs.enabled = true
        expect("enabling requires explicit consent in the model", prefs.enabled)
        expect("all categories armed after consent", prefs.categories(from: changes(true,true,true)) == kinds(.grades,.attendance,.messages))
        for kind in DirectNotificationCategory.allCases {
            prefs.set(kind, enabled: false)
            expect("category disabled \(kind.rawValue)", !prefs.permits(kind))
            expect("category filtered from plan \(kind.rawValue)", !prefs.categories(from: changes(true,true,true)).contains(kind))
            prefs.set(kind, enabled: true)
            expect("category enabled \(kind.rawValue)", prefs.permits(kind))
        }
        prefs.set(.grades, enabled: false)
        prefs.set(.messages, enabled: false)
        expect("attendance-only filter", prefs.categories(from: changes(true,true,true)) == kinds(.attendance))
        expect("no news never scheduled", prefs.categories(from: .none).isEmpty)
        expect("not signalled categories ignored", prefs.categories(from: changes(true,false,true)).isEmpty)
        DirectNotificationPreferenceStorage.save(prefs, to: defaults)
        expect("category preferences survive restart", DirectNotificationPreferenceStorage.load(from: defaults) == prefs)
        prefs.enabled = false
        DirectNotificationPreferenceStorage.save(prefs, to: defaults)
        expect("explicit disarm survives restart", !DirectNotificationPreferenceStorage.load(from: defaults).enabled)
        defaults.set(Data("not json".utf8), forKey: DirectNotificationPreferenceStorage.key)
        expect("corrupt JSON fails closed", DirectNotificationPreferenceStorage.load(from: defaults) == empty)
        defaults.set(Data("{\"enabled\":true}".utf8), forKey: DirectNotificationPreferenceStorage.key)
        expect("missing schema keys fails closed", DirectNotificationPreferenceStorage.load(from: defaults) == empty)
        defaults.set(Data("{\"enabled\":null,\"grades\":true,\"attendance\":true,\"messages\":true}".utf8), forKey: DirectNotificationPreferenceStorage.key)
        expect("invalid value type fails closed", DirectNotificationPreferenceStorage.load(from: defaults) == empty)
        defaults.set(Data("{\"schemaVersion\":2,\"enabled\":true,\"grades\":true,\"attendance\":true,\"messages\":true}".utf8), forKey: DirectNotificationPreferenceStorage.key)
        expect("future preference schema rejected", DirectNotificationPreferenceStorage.load(from: defaults) == empty)
        DirectNotificationPreferenceStorage.clear(from: defaults)
        expect("logout clears preferences", defaults.object(forKey: DirectNotificationPreferenceStorage.key) == nil)
        expect("post-logout defaults disabled", !DirectNotificationPreferenceStorage.load(from: defaults).enabled)

        let start = Date(timeIntervalSince1970: 1_700_000_000)
        var gate = DirectNotificationDebouncer(minimumInterval: 20)
        expect("first changed category accepted", gate.eligible(kinds(.grades), at: start) == kinds(.grades))
        expect("duplicate event same instant rejected", gate.eligible(kinds(.grades), at: start).isEmpty)
        expect("duplicate event 1s later rejected", gate.eligible(kinds(.grades), at: start.addingTimeInterval(1)).isEmpty)
        expect("duplicate event 19s later rejected", gate.eligible(kinds(.grades), at: start.addingTimeInterval(19)).isEmpty)
        expect("fresh event exactly at 20s accepted", gate.eligible(kinds(.grades), at: start.addingTimeInterval(20)) == kinds(.grades))
        expect("duplicate after acceptance rejected", gate.eligible(kinds(.grades), at: start.addingTimeInterval(21)).isEmpty)
        expect("different category immediately accepted", gate.eligible(kinds(.messages), at: start) == kinds(.messages))
        expect("third category immediately accepted", gate.eligible(kinds(.attendance), at: start) == kinds(.attendance))
        expect("identical category in one list deduplicated", gate.eligible(kinds(.messages,.messages), at: start.addingTimeInterval(60)) == kinds(.messages))
        expect("ordering deterministic", gate.eligible(kinds(.messages,.attendance,.grades), at: start.addingTimeInterval(90)) == kinds(.grades,.attendance,.messages))
        expect("empty batch does nothing", gate.eligible([], at: start.addingTimeInterval(91)).isEmpty)
        expect("time moved backward does not block indefinitely", gate.eligible(kinds(.grades), at: start.addingTimeInterval(-30)) == kinds(.grades))
        gate.reset()
        expect("reset clears stored dispatch", gate.lastDispatch.isEmpty)
        expect("after account change no old gate state", gate.eligible(kinds(.grades), at: start) == kinds(.grades))
        expect("negative gap normalized to zero", {
            var g = DirectNotificationDebouncer(minimumInterval: -200)
            return g.eligible(kinds(.grades), at: start) == kinds(.grades) &&
                   g.eligible(kinds(.grades), at: start) == kinds(.grades)
        }())
        for kind in DirectNotificationCategory.allCases {
            expect("stable notification request ID \(kind.rawValue)", kind.requestIdentifier == "pl.synixad.synergiadirect.change.\(kind.rawValue)")
            expect("notification ID cannot leak person data \(kind.rawValue)", !kind.requestIdentifier.contains("student"))
        }
        var authorization = DirectNotificationAuthorizationGate()
        expect("permission state initially idle", !authorization.requestInProgress)
        let firstTicket = authorization.beginUserRequest()
        expect("permission request enters pending state", authorization.requestInProgress)
        expect("foreground return cannot invalidate system prompt", authorization.beginStatusCheck() == nil)
        expect("first permission callback accepted", authorization.acceptUserRequest(firstTicket))
        expect("permission request ends", !authorization.requestInProgress)
        expect("replayed callback ignored", !authorization.acceptUserRequest(firstTicket))
        let oldStatus = authorization.beginStatusCheck()!
        let newStatus = authorization.beginStatusCheck()!
        expect("older status check callback ignored", !authorization.acceptStatusCheck(oldStatus))
        expect("latest status check accepted", authorization.acceptStatusCheck(newStatus))
        let revokedTicket = authorization.beginUserRequest()
        authorization.cancel()
        expect("disabling notification cancels permission request", !authorization.requestInProgress)
        expect("callback after disabling ignored", !authorization.acceptUserRequest(revokedTicket))
        expect("status checks work after cancelling", authorization.beginStatusCheck() != nil)
        let retryTicket = authorization.beginUserRequest()
        expect("new request after cancel has distinct ticket", retryTicket > revokedTicket)
        expect("success of new request is accepted", authorization.acceptUserRequest(retryTicket))
        let staleStatus = authorization.beginStatusCheck()!
        _ = authorization.beginUserRequest()
        expect("status callback cannot override ongoing permission prompt", !authorization.acceptStatusCheck(staleStatus))
        authorization.cancel()
        expect("all stale callbacks rejected on logout", !authorization.acceptUserRequest(retryTicket))

        var account = DirectNotificationAccountGate()
        expect("no account bound initially", account.lastVerifiedAccountId == nil)
        expect("first verified owner is only a baseline", !account.verify("child-A"))
        expect("owner stored only in memory", account.lastVerifiedAccountId == "child-A")
        expect("same account reverified without consent reset", !account.verify("child-A"))
        expect("unverified blank account cannot overwrite", !account.verify(""))
        expect("blank account leaves previous owner", account.lastVerifiedAccountId == "child-A")
        expect("switch to sibling requires new opt in", account.verify("child-B"))
        expect("sibling account now bound", account.lastVerifiedAccountId == "child-B")
        expect("repeated sibling check does not reset again", !account.verify("child-B"))
        account.reset()
        expect("sign out clears notification owner", account.lastVerifiedAccountId == nil)
        expect("next owner starts clean", !account.verify("child-A"))
        for mask in 0..<8 {
            var p = DirectNotificationPreferences(); p.enabled = true
            p.grades = (mask & 1) != 0
            p.attendance = (mask & 2) != 0
            p.messages = (mask & 4) != 0
            let output = p.categories(from: changes(true,true,true))
            expect("all category switch combinations mask \(mask)", output.count == mask.nonzeroBitCount)
            expect("all category switch membership mask \(mask)",
                output.contains(.grades) == p.grades && output.contains(.attendance) == p.attendance && output.contains(.messages) == p.messages)
        }
        // Exhaustive 8x8 combination of user options vs observed event kinds.
        for options in 0..<8 {
            for events in 0..<8 {
                var p = DirectNotificationPreferences(); p.enabled = true
                p.grades = (options & 1) != 0
                p.attendance = (options & 2) != 0
                p.messages = (options & 4) != 0
                let output = p.categories(from: changes((events&1) != 0,(events&2) != 0,(events&4) != 0))
                expect("category mask \(options)-\(events)", output.count == (options & events).nonzeroBitCount)
                p.enabled = false
                expect("disarmed mask \(options)-\(events)", p.categories(from: changes((events&1) != 0,(events&2) != 0,(events&4) != 0)).isEmpty)
            }
        }
        var scoped = DirectNotificationPreferences()
        scoped.enabled = true
        expect("freshly verified same owner can reuse consent", DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: "parent-001"))
        expect("sibling after app restart cannot inherit consent", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: "parent-002"))
        expect("first cold launch cannot schedule before live Me", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: nil))
        expect("missing keychain fails closed", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: nil, verifiedAccount: "parent-001"))
        expect("empty keychain binding is invalid", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "", verifiedAccount: "parent-001"))
        expect("empty live owner is invalid", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: ""))
        scoped.enabled = false
        expect("user disabled consent remains off for same owner", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: "parent-001"))
        scoped.enabled = true
        expect("owner IDs compared exactly", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: "Parent-001"))
        expect("unrelated owner prefix is rejected", !DirectNotificationOwnerPolicy.mayActivate(
            preferences: scoped, boundAccount: "parent-001", verifiedAccount: "parent-001-other"))
        expect("permission prompt can resolve in temporarily inactive scene",
            DirectNotificationPromptPolicy.canBind(verifiedOwner: "parent-001",
                currentVerifiedOwner: "parent-001", accountEpochUnchanged: true,
                enteredBackground: false))
        expect("background transition cancels permission consent",
            !DirectNotificationPromptPolicy.canBind(verifiedOwner: "parent-001",
                currentVerifiedOwner: "parent-001", accountEpochUnchanged: true,
                enteredBackground: true))
        expect("session epoch change cancels consent",
            !DirectNotificationPromptPolicy.canBind(verifiedOwner: "parent-001",
                currentVerifiedOwner: "parent-001", accountEpochUnchanged: false,
                enteredBackground: false))
        expect("switched account cancels consent",
            !DirectNotificationPromptPolicy.canBind(verifiedOwner: "parent-001",
                currentVerifiedOwner: "parent-002", accountEpochUnchanged: true,
                enteredBackground: false))
        expect("logout cancels pending consent",
            !DirectNotificationPromptPolicy.canBind(verifiedOwner: "parent-001",
                currentVerifiedOwner: nil, accountEpochUnchanged: true,
                enteredBackground: false))
        print("DIRECT_NOTIFICATIONS PASS \(passed)/\(passed)")
    }
}
