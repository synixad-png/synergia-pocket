import Foundation

// Linux-only shims for iOS WebKit transport and CryptoKit partitioning.
// Storage, cache codec and recovery policy under test are the REAL Sources files.
enum SynergiaGatewayClient {
    enum Resource: String { case homework = "HomeWorks", homeworkAssignments = "HomeWorkAssignments", schoolNotices = "SchoolNotices", schoolFiles = "SchoolFiles" }
}
enum GatewayReadError: Error {
    case transport(DirectConnectionIssue), loginRequired, forbidden, invalidResponse
}
enum AccountPartition {
    static func directory(for accountId: String, under root: URL) -> URL {
        // Standalone has no CryptoKit; production AccountPartition uses SHA256.
        let hex = accountId.utf8.map { String(format: "%02x", $0) }.joined()
        return root.appendingPathComponent(hex, isDirectory: true)
    }
}

@main struct OfflineRecoveryTests {
    static var passes = 0, fails = 0
    static func check(_ description: String, _ test: () throws -> Bool) {
        do {
            if try test() { passes += 1; print("PASS " + description) }
            else { fails += 1; print("FAIL " + description) }
        } catch { fails += 1; print("FAIL " + description + " — " + String(describing: error)) }
    }
    static func root(_ name: String) -> [String: Any] {
        switch name {
        case "homework": return ["HomeWorkAssignments": [["Id": 1,"Topic":"Matematyka","Text":"Zadanie", "HomeworkAssigmentFiles": []]], "total":1]
        case "calendar": return ["HomeWorks": [["Id": 2, "Content":"Sprawdzian", "Date":"2026-11-09"]], "Total":1]
        case "announcements": return ["SchoolNotices": [["Id":"LID-A","Subject":"Ogłoszenie", "Content":"Treść"]], "total":1]
        default: return ["Data": [["id": 41, "displayName":"Szkoła.pdf", "downloadUrl":"/pliki_szkoly/pobierz/41"]],"total":1]
        }
    }
    static func fixture(_ module: SchoolModule, account: String = "A", now: Date = Date()) throws -> DirectSchoolFeed {
        try DirectSchoolFeedParser.parse(root(module.rawValue), module: module, accountId: account, date: now)
    }
    static func mutation(_ bytes: Data, _ action: (inout [String: Any]) -> Void) throws -> Data {
        var object = try JSONSerialization.jsonObject(with: bytes) as! [String:Any]
        action(&object)
        return try JSONSerialization.data(withJSONObject: object)
    }
    @MainActor static func runStorage() {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("SynergiaCacheTest_" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = DirectOfflineFeedStore(directory: root)
        check("cache starts locked") { store.verifiedAccountId == nil && store.feeds.isEmpty }
        check("cannot write without live account verification") {
            do { try store.replace(fixture(.homework)); return false }
            catch DirectOfflineFeedCacheError.wrongAccountOrModule { return true }
        }
        store.unlock(accountId: "A")
        check("unlock A sets owner, no fabricated data") { store.verifiedAccountId == "A" && store.feeds.isEmpty }
        for module in DirectOfflineFeedCache.modules {
            check("save " + module.rawValue) { try store.replace(fixture(module)); return store.feeds[module]?.records.count == 1 }
        }
        let fresh = DirectOfflineFeedStore(directory: root)
        check("no read before identity on a fresh process") { fresh.feeds.isEmpty && fresh.verifiedAccountId == nil }
        fresh.unlock(accountId: "A")
        for module in DirectOfflineFeedCache.modules {
            check("A restores same " + module.rawValue) { fresh.feeds[module] == (try fixture(module, now: fresh.feeds[module]!.fetchedAt)) }
        }
        fresh.lock()
        check("lock revokes all locally restored rows") { fresh.feeds.isEmpty && fresh.verifiedAccountId == nil }
        fresh.unlock(accountId: "B")
        check("B cannot see A snapshots") { fresh.feeds.isEmpty && fresh.verifiedAccountId == "B" }
        check("B cannot write A snapshot") {
            do { try fresh.replace(fixture(.homework, account: "A")); return false }
            catch DirectOfflineFeedCacheError.wrongAccountOrModule { return true }
        }
        fresh.unlock(accountId: "A")
        check("return to A restores only A") { fresh.feeds.count == 4 }

        // Corruption in one account/module must not erase other valid caches.
        let corruptPath = AccountPartition.directory(for: "A", under: root.appendingPathComponent("feed-accounts"))
            .appendingPathComponent("calendar.json")
        try? Data("corrupted".utf8).write(to: corruptPath, options: .atomic)
        let partial = DirectOfflineFeedStore(directory: root)
        partial.unlock(accountId: "A")
        check("corrupt module is skipped without exposing contents") {
            partial.feeds[.calendar] == nil && partial.feeds[.homework] != nil &&
            partial.feeds[.announcements] != nil && partial.feeds[.documents] != nil
        }
        check("refuses overwrite from another account, unchanged cached data") {
            do { try partial.replace(fixture(.documents,account:"B"));return false }
            catch DirectOfflineFeedCacheError.wrongAccountOrModule {
                return partial.feeds[.documents]?.verifiedAccountId == "A"
            }
        }
        // Once the current verified account refreshes this module, storage repairs itself.
        check("valid refresh repairs one corrupted module") {
            try partial.replace(fixture(.calendar))
            let reopened=DirectOfflineFeedStore(directory:root);reopened.unlock(accountId:"A")
            return reopened.feeds.count == 4
        }
        do { try fresh.erase() } catch { fails += 1; print("FAIL erase: \(error)") }
        fresh.unlock(accountId: "A")
        check("explicit erase removes all cached feeds") { fresh.feeds.isEmpty }
    }
    @MainActor static func main() {
        let modules = DirectOfflineFeedCache.modules
        check("precisely four offline feed modules") { modules == [.homework, .calendar, .announcements, .documents] }
        for module in modules {
            check("roundtrip " + module.rawValue) {
                let before = try fixture(module)
                let bytes = try DirectOfflineFeedCache.encode(before, expectedAccountId:"A")
                let after = try DirectOfflineFeedCache.decode(bytes, module:module, expectedAccountId:"A")
                return after == before && bytes.count > 50
            }
            check("reject other account " + module.rawValue) {
                let bytes = try DirectOfflineFeedCache.encode(fixture(module), expectedAccountId:"A")
                do { _ = try DirectOfflineFeedCache.decode(bytes,module:module,expectedAccountId:"B"); return false }
                catch DirectOfflineFeedCacheError.wrongAccountOrModule { return true }
            }
            check("reject mismatching module " + module.rawValue) {
                let bytes = try DirectOfflineFeedCache.encode(fixture(module), expectedAccountId:"A")
                let other:SchoolModule = module == .calendar ? .homework : .calendar
                do { _ = try DirectOfflineFeedCache.decode(bytes,module:other,expectedAccountId:"A"); return false }
                catch DirectOfflineFeedCacheError.wrongAccountOrModule { return true }
            }
        }
        check("reject future snapshot") {
            do { _ = try DirectOfflineFeedCache.encode(fixture(.homework,now:Date().addingTimeInterval(3600)),expectedAccountId:"A");return false }
            catch DirectOfflineFeedCacheError.invalidSnapshot { return true }
        }
        check("reject invented record counter") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.calendar),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in var f=obj["feed"] as! [String:Any]; f["reportedTotal"]=0;obj["feed"]=f }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.calendar,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }
        check("reject unknown cache schema") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.calendar),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in obj["schemaVersion"]=3 }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.calendar,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.unsupportedVersion {return true}
        }
        check("reject broken JSON") {
            do {_ = try DirectOfflineFeedCache.decode(Data("!?".utf8),module:.calendar,expectedAccountId:"A");return false}
            catch {return true}
        }
        check("reject oversized cache blob") {
            do {_ = try DirectOfflineFeedCache.decode(Data(repeating:42,count:2_500_001),module:.calendar,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.oversized {return true}
        }
        check("reject unauthorized documents URL") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.documents),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in
                var feed=obj["feed"] as! [String:Any];var records=feed["records"] as! [[String:Any]]
                var file=records[0]["schoolFile"] as! [String:Any]
                file["path"]="https://evil.invalid/file";records[0]["schoolFile"]=file;feed["records"]=records;obj["feed"]=feed
            }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.documents,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }

        check("reject file path escape in cached school file name") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.documents),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in
                var feed=obj["feed"] as! [String:Any];var rows=feed["records"] as! [[String:Any]]
                var file=rows[0]["schoolFile"] as! [String:Any]
                file["displayName"]="../secret.pdf";rows[0]["schoolFile"]=file;feed["records"]=rows;obj["feed"]=feed
            }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.documents,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }
        check("reject file path escape in cached homework attachment name") {
            let file:[String:Any]=["Id":21,"Name":"zadanie.pdf","Url":"https://synergia.librus.pl/gateway/api/2.0/HomeWorkAssignments/Attachment/44-21"]
            let feed=try DirectSchoolFeedParser.parse(["HomeWorkAssignments": [["Id":44,"Topic":"Ćwiczenie","HomeworkAssigmentFiles":[file]]],"Total":1], module:.homework,accountId:"A")
            let bytes=try DirectOfflineFeedCache.encode(feed,expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in
                var f=obj["feed"] as! [String:Any];var rows=f["records"] as! [[String:Any]]
                var attachments=rows[0]["homeworkFiles"] as! [[String:Any]]
                attachments[0]["name"]="../../secret.txt";rows[0]["homeworkFiles"]=attachments;f["records"]=rows;obj["feed"]=f
            }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.homework,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }
        check("reject executable control character in cached filename") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.documents),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in
                var feed=obj["feed"] as! [String:Any];var rows=feed["records"] as! [[String:Any]]
                var file=rows[0]["schoolFile"] as! [String:Any]
                file["displayName"]="x\n.pdf";rows[0]["schoolFile"]=file;feed["records"]=rows;obj["feed"]=feed
            }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.documents,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }
        check("reject cache duplicate record identifiers") {
            let bytes=try DirectOfflineFeedCache.encode(fixture(.calendar),expectedAccountId:"A")
            let corrupt=try mutation(bytes) { obj in
                var feed=obj["feed"] as! [String:Any];var records=feed["records"] as! [[String:Any]]
                records.append(records[0]);feed["records"]=records;feed["reportedTotal"]=2;obj["feed"]=feed
            }
            do {_ = try DirectOfflineFeedCache.decode(corrupt,module:.calendar,expectedAccountId:"A");return false}
            catch DirectOfflineFeedCacheError.invalidSnapshot {return true}
        }
        check("reject empty account id") {
            do {_ = try DirectOfflineFeedCache.encode(fixture(.homework),expectedAccountId:"");return false}
            catch DirectOfflineFeedCacheError.wrongAccountOrModule {return true}
        }
        check("reject stale invalid encoded account") {
            do {_ = try DirectOfflineFeedCache.encode(fixture(.homework),expectedAccountId:"B");return false}
            catch DirectOfflineFeedCacheError.wrongAccountOrModule {return true}
        }
        check("offline network with unchanged verified session allowed") {
            DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:true,isForeground:true,observedRemoteAccount:nil,expectedAccount:"A",failure:GatewayReadError.transport(.offline))
        }
        for issue:DirectConnectionIssue in [.offline,.timedOut,.interrupted] {
            check("recoverable transport " + issue.message.prefix(12)) {
                DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:true,isForeground:true,observedRemoteAccount:"A",expectedAccount:"A",failure:GatewayReadError.transport(issue))
            }
        }
        for issue:DirectConnectionIssue in [.unknown,.maintenance,.forbidden,.rateLimited,.loginRequired,.invalidResponse] {
            check("no offline fallback for " + issue.message.prefix(12)) {
                !DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:true,isForeground:true,observedRemoteAccount:nil,expectedAccount:"A",failure:GatewayReadError.transport(issue))
            }
        }
        for (name,seen,expected,verified,foreground) in [
            ("changed remote account","B","A",true,true),
            ("changed local epoch","A","A",false,true),
            ("background lock","A","A",true,false),
            ("missing owner","A","",true,true)
        ] {
            check(name) {
                !DirectOfflineRecovery.mayRetain(previouslyVerified:verified,accountUnchanged:verified,isForeground:foreground,observedRemoteAccount:seen,expectedAccount:expected,failure:GatewayReadError.transport(.offline))
            }
        }
        check("a separately recorded account change overrides prior verification") {
            !DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:false,isForeground:true,observedRemoteAccount:"A",expectedAccount:"A",failure:GatewayReadError.transport(.offline))
        }
        check("must not keep offline after authentication error") {
            !DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:true,isForeground:true,observedRemoteAccount:"A",expectedAccount:"A",failure:GatewayReadError.loginRequired)
        }
        check("unknown error never unlocks offline") {
            !DirectOfflineRecovery.mayRetain(previouslyVerified:true,accountUnchanged:true,isForeground:true,observedRemoteAccount:"A",expectedAccount:"A",failure:NSURLErrorDomainError())
        }
        runStorage()
        print("OFFLINE RECOVERY \(passes)/\(passes+fails) PASS" )
        if fails != 0 { exit(1) }
    }
}
struct NSURLErrorDomainError: Error {}
