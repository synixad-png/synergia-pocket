import Foundation

// Standalone Linux tests only: app uses SHA256/CryptoKit in AccountPartition.
// This test shim changes directory naming ONLY; the codec + store are real Sources.
enum AccountPartition {
    static func directory(for accountId: String, under root: URL) -> URL {
        root.appendingPathComponent(accountId.utf8.map { String(format:"%02x",$0) }.joined(), isDirectory: true)
    }
}

@main struct OfflineTimetableTests {
    static var passed = 0, failed = 0
    static func test(_ name: String, _ body: () throws -> Bool) {
        do { if try body() { passed += 1; print("PASS "+name) } else { failed += 1; print("FAIL "+name) } }
        catch { failed += 1; print("FAIL \(name): \(error)") }
    }
    static func lesson(_ id: String = "42") -> [String: Any] {
        ["LessonNo":"2", "HourFrom":"08:55", "HourTo":"09:40", "Subject":["Id":id],
         "Teacher":["Id":"8"], "IsCanceled": false, "IsSubstitutionClass": false]
    }
    static func snapshot(_ monday: String = "2026-11-02", account: String = "A", history: Bool = true,
                         now: Date = Date()) throws -> DirectOfflineTimetableSnapshot {
        let day = monday
        let root: [String: Any] = ["Timetable": [day: [[lesson(),lesson("44")],[lesson("10")]]]]
        let week = try DirectTimetableParser.parse(root, monday: monday, accountId: account, date: now)
        let change = DirectPlanChange(id: "123", originalDate: day, originalLessonNumber: 2,
            currentDate: day, currentLessonNumber: 3, originalSubjectId: "42", currentSubjectId: "44",
            originalTeacherId: "8", currentTeacherId: "9", originalClassroom: "A1", currentClassroom: "B2", kind: .substitution)
        let list = history ? DirectPlanChangesSnapshot(changes: [change], accountId: account, fetchedAt: now) : nil
        return .init(week: week, history: list, subjects: ["42":"Matematyka", "44":"Angielski"], teachers: ["8":"Nauczyciel"])
    }
    static func mutated(_ data: Data, _ modify: (inout [String:Any]) -> Void) throws -> Data {
        var obj = try JSONSerialization.jsonObject(with: data) as! [String:Any]
        modify(&obj)
        return try JSONSerialization.data(withJSONObject: obj)
    }
    static func encode(_ snapshot: DirectOfflineTimetableSnapshot) throws -> Data {
        try DirectOfflineTimetableCodec.encode(snapshot, account: snapshot.week.accountId)
    }
    static func cannotDecode(_ bytes: Data, monday: String = "2026-11-02", account: String = "A") -> Bool {
        (try? DirectOfflineTimetableCodec.decode(bytes,monday:monday,account:account)) == nil
    }
    @MainActor static func run() {
        let monday = "2026-11-02"
        test("roundtrip all lesson references and parallel groups") {
            let s = try snapshot(); let d = try encode(s)
            let r = try DirectOfflineTimetableCodec.decode(d,monday:monday,account:"A")
            return r == s && r.week.splitPeriods == 1 && r.week.entries[1].parallelIndex == 1
        }
        test("roundtrip saved history and teacher names") {
            let s=try snapshot();let d=try encode(s)
            let r=try DirectOfflineTimetableCodec.decode(d,monday:monday,account:"A")
            return r.history?.forWeek(monday).count == 1 && r.subjects["42"] == "Matematyka" && r.teachers["8"] == "Nauczyciel"
        }
        test("missing optional history not fabricated") {
            let s=try snapshot(history:false);let d=try encode(s)
            return try DirectOfflineTimetableCodec.decode(d,monday:monday,account:"A").history == nil
        }
        test("other account rejected") {
            cannotDecode(try encode(snapshot()),account:"B")
        }
        test("other week rejected") {
            cannotDecode(try encode(snapshot()),monday:"2026-11-09")
        }
        test("malformed JSON rejected") { cannotDecode(Data("nope".utf8)) }
        test("oversized JSON rejected") { cannotDecode(Data(repeating:42,count:DirectOfflineTimetableCodec.maximumBytes+1)) }
        test("schema version mismatch rejected") {
            let d=try mutated(encode(snapshot())) { $0["version"]=99 };return cannotDecode(d)
        }
        test("envelope account swap rejected") {
            let d=try mutated(encode(snapshot())) { $0["accountId"]="B" };return cannotDecode(d)
        }
        test("week account swap rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                w["accountId"]="B";s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("history account swap rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var h=s["history"] as! [String:Any]
                h["accountId"]="B";s["history"]=h;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("week Monday spoofing rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                w["monday"]="2026-11-03";s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("reported date outside week rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                w["reportedDates"]=["2026-12-20"];s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("duplicate reported dates rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                w["reportedDates"]=[monday,monday];s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("duplicate lesson id rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                var items=w["entries"] as! [[String:Any]];items.append(items[0]);w["entries"]=items;s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("id and position divergence rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                var items=w["entries"] as! [[String:Any]];items[0]["parallelIndex"]=6;w["entries"]=items;s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("invalid hour rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var w=s["week"] as! [String:Any]
                var items=w["entries"] as! [[String:Any]];items[0]["timeFrom"]="29:99";w["entries"]=items;s["week"]=w;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("future-dated snapshot rejected") {
            let s=try snapshot(now:Date().addingTimeInterval(7200))
            return (try? encode(s)) == nil
        }
        test("history invalid date rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var h=s["history"] as! [String:Any]
                var changes=h["changes"] as! [[String:Any]];changes[0]["originalDate"]="2026-13-44"
                h["changes"]=changes;s["history"]=h;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("duplicate history id rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];var h=s["history"] as! [String:Any]
                var changes=h["changes"] as! [[String:Any]];changes.append(changes[0]);h["changes"]=changes;s["history"]=h;obj["snapshot"]=s
            };return cannotDecode(d)
        }
        test("huge teacher name rejected") {
            let d=try mutated(encode(snapshot())) { obj in
                var s=obj["snapshot"] as! [String:Any];s["teachers"]=["8":String(repeating:"X",count:1000)];obj["snapshot"]=s
            };return cannotDecode(d)
        }
        let root=FileManager.default.temporaryDirectory.appendingPathComponent("synergia_offline_week_test_"+UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        let store=DirectOfflineTimetableStore(directory:root)
        test("store starts locked and empty") {store.verifiedAccountId == nil && store.weeks.isEmpty}
        test("save before verification rejected") {
            do {try store.replace(snapshot());return false}
            catch DirectOfflineTimetableError.wrongAccount{return true}
        }
        test("unlock from no cache does not invent a week") {
            store.unlock(accountId:"A");return store.verifiedAccountId == "A" && store.weeks.isEmpty
        }
        test("one selected week saved") {try store.replace(snapshot());return store.snapshot(monday:monday)?.week.entries.count == 3}
        test("unknown week does not borrow a different week") {store.snapshot(monday:"2026-11-09") == nil}
        test("no read before /Me in another process") {
            let new=DirectOfflineTimetableStore(directory:root)
            return new.verifiedAccountId == nil && new.snapshot(monday:monday) == nil
        }
        test("same account reopens file only after unlock") {
            let new=DirectOfflineTimetableStore(directory:root)
            new.unlock(accountId:"A")
            return new.snapshot(monday:monday) == (try snapshot(now:new.snapshot(monday:monday)!.week.fetchedAt))
        }
        test("lock hides cached plan") {
            store.lock(); return store.weeks.isEmpty && store.snapshot(monday:monday) == nil
        }
        test("account B can't see account A") {
            store.unlock(accountId:"B")
            return store.snapshot(monday:monday) == nil && store.weeks.isEmpty
        }
        test("account B cannot overwrite A plan") {
            do { try store.replace(snapshot(account:"A")); return false }
            catch DirectOfflineTimetableError.wrongAccount {return true}
        }
        test("account A can restore after account B") {
            store.unlock(accountId:"A");return store.snapshot(monday:monday) != nil
        }
        test("corrupted one week is skipped without disabling others") {
            let next="2026-11-09";try store.replace(snapshot(next))
            let file=AccountPartition.directory(for:"A",under:root.appendingPathComponent("timetable-accounts"))
                .appendingPathComponent(monday+".json")
            try Data("corrupted".utf8).write(to:file)
            let fresh=DirectOfflineTimetableStore(directory:root);fresh.unlock(accountId:"A")
            return fresh.snapshot(monday:monday) == nil && fresh.snapshot(monday:next) != nil
        }
        test("a successful refresh repairs corrupted week") {
            try store.replace(snapshot())
            let fresh=DirectOfflineTimetableStore(directory:root);fresh.unlock(accountId:"A")
            return fresh.snapshot(monday:monday) != nil
        }
        test("bounded number of weeks on disk") {
            let date=ISO8601DateFormatter().date(from:"2026-11-02T00:00:00Z")!
            for i in 1...18 {
                let newDate=date.addingTimeInterval(Double(i)*7*86400)
                var cal=Calendar(identifier:.iso8601);cal.timeZone=TimeZone(secondsFromGMT:0)!
                let f=DateFormatter();f.calendar=cal;f.timeZone=cal.timeZone;f.dateFormat="yyyy-MM-dd"
                let m=f.string(from:newDate)
                try store.replace(snapshot(m))
            }
            let dir=AccountPartition.directory(for:"A",under:root.appendingPathComponent("timetable-accounts"))
            let files=try FileManager.default.contentsOfDirectory(atPath:dir.path).filter{$0.hasSuffix(".json")}
            return store.weeks.count == DirectOfflineTimetableCodec.maxStoredWeeks && files.count == DirectOfflineTimetableCodec.maxStoredWeeks
        }
        test("explicit erase clears disk and memory") {
            try store.erase()
            store.unlock(accountId:"A")
            return store.snapshot(monday:monday)==nil && store.weeks.isEmpty
        }
        print("OFFLINE_TIMETABLE PASS=\(passed) FAIL=\(failed)")
        if failed > 0 {exit(1)}
    }
    static func main() {run()}
}
