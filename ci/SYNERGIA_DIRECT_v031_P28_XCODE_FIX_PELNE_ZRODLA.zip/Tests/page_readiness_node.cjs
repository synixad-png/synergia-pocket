// Executable without building iOS: node Tests/page_readiness_node.cjs
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(__dirname+'/../Sources/PageReadiness.swift','utf8');
const match = source.match(/#"""\n([\s\S]*?)\n\s*"""#/);
assert(match, 'Missing raw JavaScript body');
const js = match[1];
async function scenario({neverReady=false, busyFor=0, mutateAt=[]}={}) {
  let time = 0;
  let callback = null;
  let disconnected = false;
  const timers = [];
  const document = { readyState:neverReady?'loading':'complete',
    documentElement:{}, querySelector: () => time < busyFor ? {} : null };
  class MutationObserver {
    constructor(fn) {callback=fn;}
    observe() {}
    disconnect() {disconnected=true;}
  }
  class FakeDate {static now(){return time;}}
  const context={ Date:FakeDate, document, MutationObserver,
    setTimeout:(fn, delay) => timers.push({at: time+delay, fn}) };
  const promise = vm.runInNewContext('(async()=>{'+js+'})()',context);
  // Advance synthetic time, flushing microtasks after every scheduled timer.
  let mut = 0;
  for (let i=0;i<200 && timers.length;i++) {
    timers.sort((a,b)=>a.at-b.at);
    const job=timers.shift();
    while (mut < mutateAt.length && mutateAt[mut]<=job.at) {
      time=mutateAt[mut++]; callback?.();
    }
    time=job.at;
    job.fn();
    await Promise.resolve();
  }
  return {outcome:await promise, time, disconnected};
}
(async()=>{
  const clean=await scenario();
  assert.strictEqual(clean.outcome,'stable');
  assert(clean.time>=650 && clean.time < 8000 && clean.disconnected);
  const changed=await scenario({mutateAt:[300,700,1100]});
  assert.strictEqual(changed.outcome,'stable');
  assert(changed.time>=1750 && changed.disconnected);
  const slow=await scenario({busyFor:9000});
  assert.strictEqual(slow.outcome,'timeout');
  const stuck=await scenario({neverReady:true});
  assert.strictEqual(stuck.outcome,'timeout');
  console.log('PASS: stable, mutating DOM, busy timeout, never-ready timeout');
})().catch(e=>{console.error(e);process.exit(1)});
