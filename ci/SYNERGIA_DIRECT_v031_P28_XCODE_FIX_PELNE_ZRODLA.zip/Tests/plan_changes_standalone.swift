import Foundation
@main struct PlanChangesTests {
    static var yes = 0, no = 0
    static func check(_ name: String, _ body: () throws -> Bool) {
        do { if try body() { print("PASS", name); yes += 1 } else { print("FAIL",name); no += 1 } }
        catch { print("FAIL",name,error); no += 1 }
    }
    static func base(_ id: Int = 7) -> [String: Any] {[
        "Id":id,"OrgDate":"2026-11-04", "OrgLessonNo":"2", "OrgSubject":["Id":5],
        "OrgTeacher":["Id":8], "OrgClassroomSymbol":"B21", "IsCancelled":false,
        "Date":"2026-11-04", "LessonNo":"2", "Teacher":["Id":12],
        "Subject":["Id":7], "ClassroomSymbol":"A1"
    ]}
    static func parse(_ rows:[[String:Any]]) throws -> DirectPlanChangesSnapshot {
        try DirectPlanChangesParser.parse(["Substitutions":rows],accountId:"A")
    }
    static func main() {
        check("substitution parses separate old/new") {
            let c=try parse([base()]).changes[0]
            return c.kind == .substitution && c.originalSubjectId == "5" && c.currentSubjectId == "7" &&
                c.originalTeacherId == "8" && c.currentTeacherId == "12" && c.currentClassroom == "A1"
        }
        check("cancellation has no replacement") {
            var b=base();b["IsCancelled"]=true;b.removeValue(forKey:"Date");b.removeValue(forKey:"Teacher")
            let c=try parse([b]).changes[0]; return c.kind == .cancelled && c.currentDate == nil
        }
        check("shifted priority") {
            var b=base();b["IsShifted"]=true
            return try parse([b]).changes[0].kind == .shifted
        }
        check("no replacement no invented type") {
            var b=base();b.removeValue(forKey:"Date")
            return try parse([b]).changes[0].kind == .unknown
        }
        check("current date previous week still shown") {
            var b=base(); b["OrgDate"]="2026-10-30";b["Date"]="2026-11-02"
            return try parse([b]).forWeek("2026-11-02").count == 1
        }
        check("old date selected week") { try parse([base()]).forWeek("2026-11-02").count == 1 }
        check("unrelated weeks excluded") { try parse([base()]).forWeek("2026-11-09").isEmpty }
        check("invalid Monday rejected") { try parse([base()]).forWeek("2026-11-03").isEmpty }
        check("empty list works without claiming all schedule") { try parse([]).changes.isEmpty }
        check("missing key rejected") {
            do { _=try DirectPlanChangesParser.parse(["Data":[]],accountId:"A"); return false }
            catch DirectPlanChangeError.unknownResponse {return true}
        }
        check("duplicate id rejected") {
            do { _=try parse([base(),base()]);return false }
            catch DirectPlanChangeError.duplicateId { return true }
        }
        check("missing original date rejected") {
            var b=base();b.removeValue(forKey:"OrgDate")
            do { _=try parse([b]);return false }
            catch DirectPlanChangeError.malformedChange { return true }
        }
        check("malformed date rejected") {
            var b=base();b["OrgDate"]="2026-02-30"
            do { _=try parse([b]);return false }
            catch DirectPlanChangeError.malformedChange { return true }
        }
        check("reject path traversal in id") {
            var b=base();b["Id"]="../../top"
            do { _=try parse([b]);return false }
            catch DirectPlanChangeError.malformedChange { return true }
        }
        check("invalid references not resolved by guessing") {
            var b=base();b["OrgSubject"]=["Foo":42]
            return try parse([b]).changes[0].originalSubjectId == nil
        }
        check("Boolean masquerading as substitution id rejected") {
            var b=base();b["Id"]=true
            do { _=try parse([b]);return false }
            catch DirectPlanChangeError.malformedChange { return true }
        }
        check("timestamp parsed as date") {
            var b=base();b["OrgDate"]="2026-11-04T10:00:00"
            return try parse([b]).changes[0].originalDate == "2026-11-04"
        }
        print("PLAN CHANGES: \(yes) PASS / \(no) FAIL")
        if no > 0 { exit(1) }
    }
}
