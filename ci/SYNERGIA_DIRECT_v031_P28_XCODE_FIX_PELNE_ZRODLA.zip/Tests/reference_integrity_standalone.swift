import Foundation

@main struct ReferenceIntegrityStandalone {
    static func main() throws {
        var count = 0
        func check(_ name: String, _ condition: Bool) {
            guard condition else { fatalError("FAIL: \(name)") }
            count += 1
            print("PASS \(name)")
        }
        func rejected(_ action: () throws -> Any) -> Bool {
            do { _ = try action(); return false } catch { return true }
        }
        let grade: [String: Any] = ["Id": 13, "Grade": "4", "Semester": 1,
                                     "Subject": ["Id": 7], "Comments": [["Id": 88]]]
        let root: [String: Any] = ["Grades": [grade]]
        let comments: [String: Any] = ["Comments": [["Id": 88, "Text": "Test"]]]
        let decoded = try SynergiaGradeRecords.decode(grades: root, comments: comments)
        check("comment attached", decoded[0].commentTexts == ["Test"])
        check("missing comment endpoint rejected", rejected { try SynergiaGradeRecords.decode(grades: root, comments: nil) })
        check("missing referenced comment rejected", rejected { try SynergiaGradeRecords.decode(grades: root, comments: ["Comments": []]) })
        check("duplicated comment ID rejected", rejected { try SynergiaGradeRecords.decode(grades: root, comments: ["Comments": [["Id":88,"Text":"A"],["Id":88,"Text":"B"]]]) })
        check("broken comment entry rejected", rejected { try SynergiaGradeRecords.decode(grades: root, comments: ["Comments": [["Text":"A"]]]) })
        check("known subject accepted", !rejected { try GradeReferenceIntegrity.validate(grades: decoded, subjects: ["7":"Matematyka"]) })
        check("missing subject rejected", rejected { try GradeReferenceIntegrity.validate(grades: decoded, subjects: [:]) })
        check("blank subject rejected", rejected { try GradeReferenceIntegrity.validate(grades: decoded, subjects: ["7":"   "]) })
        let clean: [String:Any] = ["Grades": [["Id": 14,"Grade": "5","Semester": 2,"Subject": ["Id": 7]]]]
        let noComment = try SynergiaGradeRecords.decode(grades: clean, comments: ["Comments":[]])
        check("no comments allowed with valid empty endpoint", noComment[0].commentTexts.isEmpty)
        print("RESULT \(count)/\(count) PASS")
    }
}
