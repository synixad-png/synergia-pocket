#!/usr/bin/env bash
# Full historical regression + current batch. May be slow; run parts separately if timed out.
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch9_offline.sh
bash Tests/run_batch10_offline.sh
