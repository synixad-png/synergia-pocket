#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch9_offline.sh
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/SynergiaGradeRecords.swift Sources/SynergiaAttendanceRecords.swift \
 Sources/SupplementalGrades.swift Sources/DirectMessagePlainText.swift \
 Sources/DirectMessages.swift Sources/DirectCoreSync.swift \
 Sources/DirectNotificationPolicy.swift Tests/notification_policy_standalone.swift \
 -o "$work/notification_policy"
"$work/notification_policy"
python3 Tests/verify_batch10_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH10 PASS: previous 748 + notification policy 235 = 983 checks. iOS NOT compiled.\n'
