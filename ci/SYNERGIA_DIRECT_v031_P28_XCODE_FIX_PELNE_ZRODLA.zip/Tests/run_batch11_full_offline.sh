#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch10_offline.sh
bash Tests/run_batch11_incremental_offline.sh
printf 'BATCH11 FULL PASS — 1095 Foundation-only checks. iOS NOT compiled.\n'
