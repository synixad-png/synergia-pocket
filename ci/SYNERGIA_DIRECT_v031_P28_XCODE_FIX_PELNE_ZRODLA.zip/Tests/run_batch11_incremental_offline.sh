#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
swiftc Sources/SynergiaGradeRecords.swift Sources/DirectGradeAuthors.swift \
 Tests/grade_author_resolution_standalone.swift -o "$tmp/author-tests"
"$tmp/author-tests"
swiftc Sources/SynergiaSubjects.swift Sources/SynergiaGradeRecords.swift \
 Sources/GradeReferenceIntegrity.swift Tests/grade_subjects_boundary_standalone.swift -o "$tmp/subject-tests"
"$tmp/subject-tests"
python3 Tests/verify_batch11_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH11 INCREMENTAL PASS — 74 author + 38 subject + 43 static, iOS not compiled.\n'
