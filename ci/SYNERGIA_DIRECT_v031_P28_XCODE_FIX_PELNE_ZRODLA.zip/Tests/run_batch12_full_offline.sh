#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch11_full_offline.sh
bash Tests/run_batch12_incremental_offline.sh
printf '\nBATCH12 FULL PASS: previous 1095 + new analytics cases; iOS NOT compiled.\n'
