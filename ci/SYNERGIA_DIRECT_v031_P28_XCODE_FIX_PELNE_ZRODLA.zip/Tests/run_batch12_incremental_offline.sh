#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift \
    Sources/DirectAttendanceAnalytics.swift Tests/attendance_analytics_standalone.swift -o "$work/attendance"
"$work/attendance"
python3 Tests/verify_batch12_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH12 INCREMENTAL PASS: offline analytics and Swift parser; iOS NOT compiled.\n'
