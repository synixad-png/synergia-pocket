#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift \
  Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift \
  Sources/DirectOfflineFeedCache.swift Sources/DirectFeedChangeAudit.swift \
  Tests/notices_standalone.swift -o "$work/notices"
"$work/notices"
python3 Tests/verify_batch13_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH13 INCREMENTAL PASS; iOS app NOT built.\n'
