#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift \
  Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift \
  Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift Sources/DirectOfflineFeedCache.swift Sources/DirectFeedChangeAudit.swift \
  Tests/homework_assignments_standalone.swift -o "$work/homework"
"$work/homework"
python3 Tests/verify_batch15_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH15 PASS; only Foundation logic compiled, iOS app not built, IPA not created.\n'
