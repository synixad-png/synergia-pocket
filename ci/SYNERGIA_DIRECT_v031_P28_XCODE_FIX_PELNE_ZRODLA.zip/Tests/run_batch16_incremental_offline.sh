#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift \
  Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift \
  Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift Sources/DirectOfflineFeedCache.swift \
  Sources/DirectFeedChangeAudit.swift Tests/documents_standalone.swift -o "$work/documents"
"$work/documents"
python3 Tests/verify_batch16_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH16 PASS. iOS application not built; IPA not created.\n'
