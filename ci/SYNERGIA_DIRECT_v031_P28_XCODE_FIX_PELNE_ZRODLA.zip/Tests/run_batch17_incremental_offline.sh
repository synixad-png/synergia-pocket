#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
cp Tests/login_restore_standalone.swift "$work/main.swift"
swiftc Sources/DirectLoginRestorePolicy.swift "$work/main.swift" -o "$work/login_restore_test"
"$work/login_restore_test"
python3 Tests/verify_batch17_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch16_incremental_offline.sh
printf 'BATCH17 PASS: login/session restore + batch16 regression + Swift parser; NOT a native iOS build.\n'
