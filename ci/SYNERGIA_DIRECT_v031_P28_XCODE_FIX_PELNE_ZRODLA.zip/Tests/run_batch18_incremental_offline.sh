#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
cp Tests/gateway_json_policy_standalone.swift "$work/main.swift"
swiftc Sources/GatewayJSONPolicy.swift "$work/main.swift" -o "$work/gateway_json_policy"
"$work/gateway_json_policy"
python3 Tests/verify_batch18_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch17_incremental_offline.sh
printf 'BATCH18 PASS: JSON policy + batch17 regression; iOS app not compiled.\n'
