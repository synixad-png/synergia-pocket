#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
testdir="$(mktemp -d)"
trap 'rm -rf "$testdir"' EXIT
cp Tests/direct_account_commit_policy_standalone.swift "$testdir/main.swift"
swiftc Sources/DirectAccountCommitPolicy.swift "$testdir/main.swift" -o "$testdir/account_tests"
"$testdir/account_tests"
python3 Tests/verify_batch19_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch18_incremental_offline.sh
printf 'BATCH19 PASS: account isolation; no iOS compile in this stage.\n'
