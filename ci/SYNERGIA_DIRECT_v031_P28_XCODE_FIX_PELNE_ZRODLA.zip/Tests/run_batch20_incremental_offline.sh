#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
cp Tests/direct_session_lifecycle_standalone.swift "$work/main.swift"
swiftc Sources/DirectSessionLifecyclePolicy.swift "$work/main.swift" -o "$work/session_test"
"$work/session_test"
python3 Tests/verify_batch20_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch19_incremental_offline.sh
printf 'BATCH20 PASS: session lifecycle + prior regression, no native iOS build.\n'
