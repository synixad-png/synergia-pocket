#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/GatewayJSONPolicy.swift Sources/DirectGradeCompleteness.swift Sources/DirectGradePagination.swift Tests/grade_paging_safety_standalone.swift -o "$work/grade_paging_safety"
"$work/grade_paging_safety"
python3 Tests/verify_batch21_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch20_incremental_offline.sh
echo 'BATCH21 PASS: paging safety, legacy regression, syntax; NOT a native Xcode build.'
