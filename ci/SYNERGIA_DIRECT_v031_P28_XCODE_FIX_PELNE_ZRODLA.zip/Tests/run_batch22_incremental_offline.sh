#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/SynergiaGradeRecords.swift Sources/GradeSemesterCoverage.swift \
 Sources/SupplementalGrades.swift Sources/SupplementalSemesterCoverage.swift \
 Tests/semester_portfolio_standalone.swift -o "$work/semester_portfolio"
"$work/semester_portfolio"
python3 Tests/verify_iphone_only_ci.py
python3 Tests/verify_batch22_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch21_incremental_offline.sh
printf 'BATCH22 PASS: semester portfolio, iPhone test scope, full legacy incremental regression. NO iOS build/IPA.\n'
