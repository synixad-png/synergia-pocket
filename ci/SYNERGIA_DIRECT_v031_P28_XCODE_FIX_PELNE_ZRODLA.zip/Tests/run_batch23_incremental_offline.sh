#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/SynergiaGradeRecords.swift Sources/SynergiaGradeCategories.swift Sources/GradeWeightedAverage.swift \
 Tests/grade_weighted_average_safe_standalone.swift -o "$work/grade_safe"
"$work/grade_safe"
swiftc Sources/SynergiaGradeRecords.swift Sources/GradeWeightedAverage.swift \
 Tests/grade_mean_standalone.swift -o "$work/grade_old"
"$work/grade_old"
python3 Tests/verify_batch23_boundaries.py
swiftc -frontend -parse Sources/*.swift
bash Tests/run_batch22_incremental_offline.sh
printf 'BATCH23 PASS: grade weight/average safe arithmetic, categories, older average and legacy full incremental regression. No Xcode/iOS runtime.\n'
