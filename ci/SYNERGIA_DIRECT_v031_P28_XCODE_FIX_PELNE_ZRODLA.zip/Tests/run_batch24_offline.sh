#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
temp="$(mktemp -d)"
trap 'rm -rf "$temp"' EXIT
run_swift() {
  local name="$1"; shift
  swiftc "$@" -o "$temp/$name"
  "$temp/$name"
}
run_swift grade_detail_access Sources/SynergiaGradeRecords.swift Sources/GradeDetailAccess.swift Tests/grade_details_access_standalone.swift
run_swift grade_details_old Sources/SynergiaGradeRecords.swift Tests/grade_details_standalone.swift
run_swift references Sources/SynergiaGradeRecords.swift Sources/GradeReferenceIntegrity.swift Tests/reference_integrity_standalone.swift
run_swift grade_mean Sources/SynergiaGradeRecords.swift Sources/GradeWeightedAverage.swift Tests/grade_mean_standalone.swift
run_swift grade_mean_safe Sources/SynergiaGradeRecords.swift Sources/SynergiaGradeCategories.swift Sources/GradeWeightedAverage.swift Tests/grade_weighted_average_safe_standalone.swift
run_swift semester_presentation Sources/SynergiaGradeRecords.swift Sources/GradeSemesterPresentation.swift Tests/semester_presentation_standalone.swift
run_swift authors Sources/SynergiaGradeRecords.swift Sources/DirectGradeAuthors.swift Tests/grade_author_resolution_standalone.swift
run_swift teachers Sources/SynergiaGradeRecords.swift Sources/DirectGradeAuthors.swift Tests/grade_teachers_standalone.swift
run_swift subjects Sources/SynergiaGradeRecords.swift Sources/SynergiaSubjects.swift Sources/GradeReferenceIntegrity.swift Tests/grade_subjects_boundary_standalone.swift
swiftc -frontend -parse Sources/*.swift
python3 Tests/verify_batch24_boundaries.py
echo 'BATCH24 PASS: model access, comments, references, grade averages, semesters, authors, subjects, Swift parser, code boundaries. NOT Xcode nor iOS device.'
