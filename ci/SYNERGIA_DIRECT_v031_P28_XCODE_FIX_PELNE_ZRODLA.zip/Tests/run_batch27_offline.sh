#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
# The new unit fixture includes real JSONSerialization and strict NSNumber / CFBoolean checks.
swiftc Sources/SynergiaAttendanceRecords.swift Tests/attendance_json_integrity_standalone.swift -o "$tmp/attendance_json"
"$tmp/attendance_json"
# Preserve existing attendance status classifications, school-specific type IDs,
# semesters, per-subject totals, invalid-date diagnostics and historic behavior.
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Sources/DirectAttendanceAnalytics.swift Tests/attendance_analytics_standalone.swift -o "$tmp/attendance_analytics"
"$tmp/attendance_analytics"
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Tests/attendance_stats_standalone.swift -o "$tmp/attendance_stats"
"$tmp/attendance_stats"
# Historical static boundaries still apply to the attendance decoder and UI.
python3 Tests/verify_batch12_boundaries.py
python3 Tests/verify_batch2_boundaries.py
python3 Tests/verify_batch27_boundaries.py
# Verify protected messages and attachments using the stronger session lifecycle
# assertions. The much slower batch4 functional regression is run separately.
python3 Tests/verify_message_boundaries.py
python3 Tests/verify_attachment_and_unread_boundaries.py
# Linux Swift only parses SwiftUI/WebKit files — this is NOT a full iOS typecheck.
swiftc -frontend -parse Sources/*.swift
printf 'P27 PASS: attendance JSON, analytics, statuses, message/attachment guards, 27/12/2 source invariants and Swift syntax (no Xcode/IPA/live account).\n'
