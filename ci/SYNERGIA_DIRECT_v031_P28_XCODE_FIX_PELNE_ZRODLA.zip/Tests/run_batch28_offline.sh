#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Sources/DirectAttendanceAnalytics.swift Tests/attendance_status_semantics_standalone.swift -o "$tmp/status_semantics"
"$tmp/status_semantics"
swiftc Sources/SynergiaAttendanceRecords.swift Tests/attendance_json_integrity_standalone.swift -o "$tmp/attendance_json"
"$tmp/attendance_json" | tail -2
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Sources/DirectAttendanceAnalytics.swift Tests/attendance_analytics_standalone.swift -o "$tmp/attendance_analytics"
"$tmp/attendance_analytics" | tail -2
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Tests/attendance_stats_standalone.swift -o "$tmp/attendance_stats"
"$tmp/attendance_stats" | tail -2
python3 Tests/verify_batch2_boundaries.py | tail -2
python3 Tests/verify_batch12_boundaries.py | tail -2
python3 Tests/verify_batch28_boundaries.py | tail -3
python3 Tests/verify_message_boundaries.py | tail -2
python3 Tests/verify_attachment_and_unread_boundaries.py | tail -2
swiftc -frontend -parse Sources/*.swift
printf 'P28 PASS: cautious absence status, old JSON/statistics/analytics tests and session/message boundaries; Linux Swift syntax (not iOS Xcode).\n'
