#!/usr/bin/env bash
# Tests Foundation-only on Linux/macOS; does NOT build or sign the iOS application.
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
bash Tests/run_message_batch_offline.sh
swiftc Sources/SynergiaAttendanceRecords.swift Sources/DirectAttendanceStatistics.swift Tests/attendance_stats_standalone.swift -o "$work/attendance_stats"
"$work/attendance_stats"
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift Tests/feed_mapping_standalone.swift -o "$work/feed_mapping"
"$work/feed_mapping"
swiftc Sources/DirectTimetable.swift Tests/timetable_standalone.swift -o "$work/timetable"
"$work/timetable"
python3 Tests/verify_batch2_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH2 baseline + compatible dependency check completed. No iOS build or IPA.\n'
