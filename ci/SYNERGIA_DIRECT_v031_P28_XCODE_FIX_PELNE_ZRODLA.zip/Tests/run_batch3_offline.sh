#!/usr/bin/env bash
# Full Foundation-only logic regression; explicitly NOT an iOS build or device test.
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
bash Tests/run_batch2_offline.sh
swiftc Sources/DirectTimetable.swift Sources/DirectPlanChanges.swift Tests/plan_changes_standalone.swift -o "$work/plan_changes"
"$work/plan_changes"
swiftc Sources/DirectSchoolFiles.swift Tests/school_files_standalone.swift -o "$work/school_files"
"$work/school_files"
python3 Tests/verify_batch3_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf 'BATCH3 SUCCESS: 160 earlier + 22 attendance + 18 feeds + 16 timetable + 17 plan changes + 25 document tests = 258 offline test cases. No iOS build or IPA.\n'
