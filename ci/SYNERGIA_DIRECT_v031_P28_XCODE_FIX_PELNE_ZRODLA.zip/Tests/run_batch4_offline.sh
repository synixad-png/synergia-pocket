#!/usr/bin/env bash
# Full Foundation-only checks; intentionally no iOS build, no IPA.
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
bash Tests/run_batch3_offline.sh
swiftc Sources/DirectHomeworkFiles.swift Tests/homework_files_standalone.swift -o "$work/homework"
"$work/homework"
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift Sources/DirectFeedChangeAudit.swift Tests/feed_delta_standalone.swift -o "$work/feeds"
"$work/feeds"
python3 Tests/verify_batch4_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH4 PASS: baseline 258 + homework 21 + feed deltas 16 = 295 offline cases; no iOS app compiled.\n'
