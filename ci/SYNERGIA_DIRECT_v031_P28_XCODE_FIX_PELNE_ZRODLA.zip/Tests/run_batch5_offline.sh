#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
bash Tests/run_batch4_offline.sh
swiftc Sources/SynergiaGradeRecords.swift Sources/SynergiaAttendanceRecords.swift \
    Sources/DirectAttendanceCompleteness.swift Sources/SupplementalGrades.swift \
    Sources/DirectMessagePlainText.swift Sources/DirectMessages.swift \
    Sources/DirectCoreSync.swift Tests/core_sync_standalone.swift -o "$work/core_sync"
"$work/core_sync"
python3 Tests/verify_batch5_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH5 PASS: baseline 295 + new 42 = 337 Foundation-only tests; NO iOS build/IPA.\n'
