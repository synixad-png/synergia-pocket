#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
bash Tests/run_batch5_offline.sh
cp Tests/connection_issue_standalone.swift "$work/main.swift"
swiftc Sources/DirectConnectionIssue.swift "$work/main.swift" -o "$work/connection_tests"
"$work/connection_tests"
python3 Tests/verify_batch6_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH6 PASS: 337 existing + 40 transport/redirect classification = 377 Foundation-only tests; no iOS build or IPA.\n'
