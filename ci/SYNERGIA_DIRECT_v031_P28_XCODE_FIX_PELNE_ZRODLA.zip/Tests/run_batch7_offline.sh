#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch6_offline.sh
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
cp Tests/direct_read_state_standalone.swift "$scratch/main.swift"
swiftc Sources/DirectModuleReadPresentation.swift "$scratch/main.swift" -o "$scratch/module_state"
"$scratch/module_state"
python3 Tests/verify_batch7_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH 7: regressions and direct read state PASS; no iOS build.\n'
