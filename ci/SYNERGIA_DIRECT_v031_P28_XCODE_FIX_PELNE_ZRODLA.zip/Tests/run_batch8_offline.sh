#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch7_offline.sh
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/Models.swift Sources/DirectSchoolFiles.swift Sources/DirectHomeworkFiles.swift \
  Sources/DirectSchoolNotices.swift Sources/DirectSchoolAgenda.swift Sources/DirectHomeworkAssignments.swift Sources/DirectSchoolDocuments.swift Sources/DirectSchoolFeeds.swift Sources/DirectOfflineFeedCache.swift \
  Sources/DirectOfflineFeedStore.swift Sources/DirectOfflineRecovery.swift \
  Sources/DirectConnectionIssue.swift Tests/offline_recovery_standalone.swift -o "$work/offline-tests"
"$work/offline-tests"
python3 Tests/verify_batch8_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH8 PASS: previous 650 + offline recovery 62 = 712 portable Swift checks. No iOS build or IPA.\n'
