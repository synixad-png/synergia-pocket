#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash Tests/run_batch8_offline.sh
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
swiftc Sources/DirectTimetable.swift Sources/DirectPlanChanges.swift \
 Sources/DirectOfflineTimetableStore.swift Tests/offline_timetable_standalone.swift -o "$work/timetable-offline"
"$work/timetable-offline"
python3 Tests/verify_batch9_boundaries.py
swiftc -frontend -parse Sources/*.swift
printf '\nBATCH9 PASS: previous 712 + timetable 36 = 748 standalone checks. iOS not compiled.\n'
