#!/usr/bin/env bash
# Foundation-only test executables. Does not run xcodebuild or produce IPA.
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
run() {
  local name="$1"; shift
  swiftc "$@" -o "$tmp/$name"
  "$tmp/$name"
}
run batch Sources/DirectMessages.swift Sources/DirectMessagePlainText.swift Sources/DirectAttachmentPolicy.swift Tests/message_batch_standalone.swift
run existing_messages Sources/DirectMessages.swift Sources/DirectMessagePlainText.swift Tests/direct_messages_standalone.swift
run compose Sources/DirectMessages.swift Sources/DirectMessagePlainText.swift Sources/DirectMessageCompose.swift Tests/direct_compose_standalone.swift
run attachment Sources/DirectAttachmentPolicy.swift Tests/direct_attachment_policy_standalone.swift
run unread Sources/DirectUnreadCounts.swift Tests/direct_unread_counts_standalone.swift
run grades_change Sources/SynergiaGradeRecords.swift Sources/GradeSemesterCoverage.swift Sources/GradeChangeAudit.swift Tests/grade_change_audit_standalone.swift
run grades_average Sources/SynergiaGradeRecords.swift Sources/GradeWeightedAverage.swift Tests/grade_mean_standalone.swift
python3 Tests/verify_message_boundaries.py
python3 Tests/verify_message_compose_boundaries.py
python3 Tests/verify_attachment_and_unread_boundaries.py
python3 verify_source_boundaries.py
swiftc -frontend -parse Sources/*.swift
echo 'OFFLINE BATCH: ALL CHECKS PASS; NO iOS BUILD'
