import Foundation
@main struct SchoolFileTests {
    static var ok=0, fail=0
    static func check(_ name:String, _ test:() throws -> Bool) {
        do { if try test(){print("PASS",name);ok+=1} else {print("FAIL",name);fail+=1} }
        catch {print("FAIL",name,error);fail+=1}
    }
    static func fixture(_ id:Any = 31, _ path:String = "/pliki_szkoly/pobierz/31", _ name:String = "Szkolny regulamin.pdf") -> [String:Any] {
        ["id":id,"downloadUrl":path,"displayName":name]
    }
    static func main() {
        check("valid item") {DirectSchoolFilePolicy.parse(fixture()) != nil}
        check("validated canonical path") {
            guard let ref=DirectSchoolFilePolicy.parse(fixture()) else{return false}
            return try DirectSchoolFilePolicy.documentURL(ref).absoluteString ==
              "https://synergia.librus.pl/pliki_szkoly/pobierz/31"
        }
        check("id as string allowed") {DirectSchoolFilePolicy.parse(fixture("31")) != nil}
        check("mismatched id rejected") {DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/32")) == nil}
        check("absolute injected URL rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"https://evil.test/")) == nil
        }
        check("unsafe path traversal rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/31/../../admin")) == nil
        }
        check("unsafe suffix rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/31?token=x")) == nil
        }
        check("encoded traversal rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/%2e%2e")) == nil
        }
        check("unsafe filename slash rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/31","folder/a.pdf")) == nil
        }
        check("unsafe filename backslash rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/31","folder\\a.pdf")) == nil
        }
        check("hidden filename rejected") {
            DirectSchoolFilePolicy.parse(fixture(31,"/pliki_szkoly/pobierz/31",".hidden")) == nil
        }
        check("bad id rejected") {DirectSchoolFilePolicy.parse(fixture("../31")) == nil}
        check("Boolean masquerading as document id rejected") { DirectSchoolFilePolicy.parse(fixture(true)) == nil }
        check("valid sandbox ticket") {
            try DirectSchoolFilePolicy.redirectTicket("https://sandbox.librus.pl/GetFile/secret").host == "sandbox.librus.pl"
        }
        check("sandbox /get target") {
            let t=try DirectSchoolFilePolicy.redirectTicket("https://sandbox.librus.pl/GetFile/ABC")
            return try DirectSchoolFilePolicy.actualDownloadURL(t).absoluteString ==
              "https://sandbox.librus.pl/GetFile/ABC/get"
        }
        check("external domain denied") {
            do {_=try DirectSchoolFilePolicy.redirectTicket("https://attacker.example/GetFile/ABC");return false}
            catch DirectSchoolFileError.untrustedRedirect{return true}
        }
        check("user-info spoof denied") {
            do {_=try DirectSchoolFilePolicy.redirectTicket("https://sandbox.librus.pl@evil.tld/GetFile/ABC");return false}
            catch DirectSchoolFileError.untrustedRedirect{return true}
        }
        check("http denied") {
            do {_=try DirectSchoolFilePolicy.redirectTicket("http://sandbox.librus.pl/GetFile/ABC");return false}
            catch DirectSchoolFileError.untrustedRedirect{return true}
        }
        check("port denied") {
            do {_=try DirectSchoolFilePolicy.redirectTicket("https://sandbox.librus.pl:8443/GetFile/ABC");return false}
            catch DirectSchoolFileError.untrustedRedirect{return true}
        }
        check("redirect escape denied") {
            do {_=try DirectSchoolFilePolicy.redirectTicket("https://sandbox.librus.pl/GetFile/../private");return false}
            catch DirectSchoolFileError.untrustedRedirect{return true}
        }
        check("HTML placeholder not saved") {
            !DirectSchoolFilePolicy.validFileResponse(status:200,contentType:"text/html",length:100)
        }
        check("HTTP 302 placeholder not saved") {
            !DirectSchoolFilePolicy.validFileResponse(status:302,contentType:"application/pdf",length:100)
        }
        check("15 MB cap") {
            !DirectSchoolFilePolicy.validFileResponse(status:200,contentType:"application/pdf",length:15_000_001)
        }
        check("PDF allowed") {DirectSchoolFilePolicy.validFileResponse(status:200,contentType:"application/pdf",length:20_000)}
        check("XML error not saved") {!DirectSchoolFilePolicy.validFileResponse(status:200,contentType:"text/xml",length:300)}
        print("SCHOOL FILES: \(ok) PASS / \(fail) FAIL")
        if fail>0 {exit(1)}
    }
}
