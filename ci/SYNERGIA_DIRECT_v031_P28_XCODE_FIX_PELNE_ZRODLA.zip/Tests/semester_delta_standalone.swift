import Foundation
@main struct Runner {
 static func main() throws {
  func g(_ id: String, _ semester: Int?, _ value: String = "5") -> DirectGrade {
   DirectGrade(id:id, subjectId:"math", categoryId:nil, value:value, semester:semester, addedAt:nil, commentTexts:[])
  }
  var count = 0
  func check(_ value: Bool, _ label: String) { precondition(value,label); count += 1 }
  let before=[g("a",1),g("b",1),g("c",2)]
  let sorted=try GradeSemesterCoverage.compare(incoming:before.reversed(), previous:before)
  check(sorted.allSatisfy {$0.addedIds.isEmpty && $0.missingIds.isEmpty},"order")
  let missing=try GradeSemesterCoverage.compare(incoming:[g("a",1),g("c",2)],previous:before)
  check(missing[0].missingIds == ["b"] && missing[0].hasUnexplainedShrinkage,"missing")
  let change=try GradeSemesterCoverage.compare(incoming:[g("a",1,"4"),g("b",1),g("c",2)],previous:before)
  check(change[0].changedIds == ["a"] && change[0].addedIds.isEmpty,"change")
  let moved=try GradeSemesterCoverage.compare(incoming:[g("a",2),g("b",1),g("c",2)],previous:before)
  check(moved[0].movedOutIds == ["a"] && moved[1].movedInIds == ["a"],"migration")
  check(moved.allSatisfy {$0.addedIds.isEmpty && $0.missingIds.isEmpty},"no false add")
  do { _ = try GradeSemesterCoverage.compare(incoming:[g("a",1),g("a",2)],previous:[]); fatalError("duplicate") } catch GradeSemesterCoverageError.snapshotContainsDuplicateID("a") {count += 1}
  let report=GradeSemesterCoverage.report(before)
  check(report.firstCount == 2 && report.secondCount == 1 && report.message.contains("niepotwierdzona"),"coverage honesty")
  let unassigned=try GradeSemesterCoverage.compare(incoming:[g("z",nil)],previous:[])
  check(unassigned.allSatisfy {$0.addedIds.isEmpty},"no guessed semesters")
  print("PASS \(count)/8 semester delta checks")
 }
}
