import Foundation

@main struct SemesterPortfolioTests {
    static func normal(_ id: String, _ semester: Int?) -> DirectGrade {
        DirectGrade(id: id, subjectId: "s1", categoryId: nil, value: "5", semester: semester,
                    addedAt: nil, commentTexts: [])
    }
    static func extra(_ family: SupplementalGradeFamily, _ id: String, _ semester: Int?) -> SupplementalGrade {
        SupplementalGrade(family: family, sourceId: id, subjectId: "s1",
                          value: "4", semester: semester, addedAt: nil)
    }
    static func main() throws {
        var count = 0
        func check(_ condition: Bool, _ message: String) {
            precondition(condition, message)
            count += 1
        }
        func rejected(_ fresh: [SupplementalGrade], _ old: [SupplementalGrade],
                      _ unavailable: Set<SupplementalGradeFamily> = []) -> Bool {
            do { try SupplementalSemesterCoverage.validateReplacement(fresh: fresh,
                previous: old, unavailable: unavailable); return false }
            catch { return true }
        }
        let previous = [extra(.points, "1", 1), extra(.text, "1", 2), extra(.behaviour, "x", nil)]
        check(!rejected(previous, previous), "unchanged snapshot")
        check(!rejected(previous.reversed(), previous), "reordered snapshot")
        check(rejected(previous.filter { $0.family != .text }, previous), "lost entire second-semester family")
        check(rejected(previous.filter { $0.family != .points }, previous), "lost first-semester family")
        check(rejected(previous.filter { $0.family != .behaviour }, previous), "lost unspecified-semester record")
        check(!rejected(previous.filter { $0.family != .text }, previous, [.text]), "403/404 retains unavailable family")
        check(rejected(previous, previous, [.text]), "fresh data for unavailable family")
        check(rejected(previous + [previous[0]], previous), "duplicate family-scoped ID")
        check(!rejected(previous + [extra(.descriptive, "1", 2)], previous), "different families share numeric IDs")
        check(!rejected(previous.map { $0.id == "PointGrades:1" ? extra(.points, "1", 2) : $0 }, previous), "same identity moved between semesters")
        check(rejected([], previous), "unconfirmed complete erasure")
        check(!rejected([], []), "first empty observation, unverified")
        let combined = GradePortfolioSemesterCoverage.report(
            standard: [normal("s",1), normal("t",2), normal("u",nil)],
            supplemental: [extra(.descriptive,"1",1),extra(.points,"1",2),extra(.text,"2",3)])
        check(combined.standard.firstCount == 1 && combined.standard.secondCount == 1, "standard counts")
        check(combined.supplemental.firstCount == 1 && combined.supplemental.secondCount == 1, "additional counts")
        check(combined.supplemental.otherSemesterCount == 1, "unusual semester preserved")
        check(combined.message.contains("Kompletność") && combined.message.contains("nie jest potwierdzona"), "no invented completeness")
        func decodeRejected(_ root: [String:Any]) -> Bool {
            do { _ = try SupplementalGrades.decode(family:.points, root:root); return false }
            catch { return true }
        }
        let one = ["Id": 1, "Grade": "5", "Subject": ["Id": 2], "Semester": 1] as [String:Any]
        check(!decodeRejected(["Grades":[one]]), "normal supplemental page")
        check(decodeRejected(["Grades":[one], "Next":"?page=2"]), "continuation not ignored")
        check(decodeRejected(["Grades":[one], "NextPage":true]), "unsupported continuation blocked")
        check(!decodeRejected(["Grades":[one], "Next":false]), "explicit false continuation")
        check(decodeRejected(["Grades":[one], "TotalCount":2]), "partial total blocked")
        check(decodeRejected(["Grades":[one], "TotalCount":true]), "boolean total blocked")
        check(!decodeRejected(["Grades":[one], "TotalCount":1, "Total":"1"]), "consistent total metadata")
        check(decodeRejected(["Grades":[one], "TotalCount":1, "Total":2]), "conflicting totals blocked")
        check(!decodeRejected(["Grades":[]]), "initial empty family not claimed complete")
        print("SEMESTER PORTFOLIO: \(count)/\(count) PASS (Foundation only; no live Synergia)")
    }
}
