import Foundation

@main struct VerifyPresentation {
    static func make(_ id: String, _ sem: Int?, _ subject: String = "2") -> DirectGrade {
        DirectGrade(id: id, subjectId: subject, categoryId: nil,
                    value: "5", semester: sem, addedAt: nil, commentTexts: [])
    }
    static func main() {
        let grades = [make("b", 2), make("z", nil), make("a", 1),
                      make("c", 1), make("x", 3), make("d", 2)]
        func test(_ title: String, _ condition: Bool) {
            guard condition else { fputs("FAIL: \(title)\n", stderr); exit(1) }
            print("PASS: \(title)")
        }
        let all = GradeSemesterPresentation.select(grades, filter: 0)
        test("all grades preserved", all.count == 6)
        test("semester I 2", GradeSemesterPresentation.select(grades, filter: 1).count == 2)
        test("semester II 2", GradeSemesterPresentation.select(grades, filter: 2).count == 2)
        test("unassigned and nonstandard preserved", GradeSemesterPresentation.select(grades, filter: 3).count == 2)
        let combined = [1,2,3].flatMap { GradeSemesterPresentation.select(grades, filter: $0) }
        test("no missing IDs across filters", Set(combined.map(\.id)) == Set(grades.map(\.id)))
        test("no double counting", combined.count == grades.count)
        test("stable ordering", GradeSemesterPresentation.select(grades.reversed(), filter: 0).map(\.id) == all.map(\.id))
        test("summary warns about unknown", GradeSemesterPresentation.summary(grades: grades, filter: 2).contains("niepotwierdzona"))
        test("empty result visible", GradeSemesterPresentation.select([], filter: 0).isEmpty)
        print("9/9 PASS")
    }
}
