import Foundation
@main struct SemesterSafetyTest {
 static func grade(_ id: String, _ semester: Int?) -> DirectGrade {
    DirectGrade(id: id, subjectId: "2", categoryId: nil, value: "5", semester: semester, addedAt: nil, commentTexts: [])
 }
 static func main() throws {
    var n=0
    func check(_ title: String, _ condition: Bool) { if !condition { fatalError("FAIL: \(title)") }; n += 1; print("PASS: \(title)") }
    func rejected(_ incoming: [DirectGrade], _ previous: [DirectGrade]) -> Bool {
        do { _ = try GradeSemesterCoverage.validateReplacement(incoming: incoming, previous: previous); return false }
        catch { return true }
    }
    check("initial snapshot allowed", !rejected([grade("a",1),grade("b",2)], []))
    check("reorder allowed", !rejected([grade("b",2),grade("a",1)], [grade("a",1),grade("b",2)]))
    check("partial semester drop blocked", rejected([grade("a",1),grade("c",2)], [grade("a",1),grade("b",1),grade("c",2)]))
    check("whole semester drop blocked", rejected([grade("a",1)], [grade("a",1),grade("b",2)]))
    check("moved grade allowed", !rejected([grade("a",2)], [grade("a",1)]))
    check("unassigned disappearing blocked", rejected([grade("a",1)], [grade("a",1),grade("b",nil)]))
    check("other semester disappearing blocked", rejected([grade("a",1)], [grade("a",1),grade("b",3)]))
    check("duplicate ids blocked", rejected([grade("a",1),grade("a",2)], []))
    check("additions allowed", !rejected([grade("a",1),grade("b",2)], [grade("a",1)]))
    let d=try GradeSemesterCoverage.compare(incoming: [grade("a",2)], previous: [grade("a",1)])
    check("migration is not insertion", d.allSatisfy { $0.addedIds.isEmpty && $0.missingIds.isEmpty })
    check("report retains uncertainty", GradeSemesterCoverage.report([grade("a",1),grade("b",2)]).message.contains("niepotwierdzona"))
    print("RESULT: \(n)/\(n) PASS")
 }
}
