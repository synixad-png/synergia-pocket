import Foundation

@main struct Tests {
 static func main() throws {
  let examples: [(SupplementalGradeFamily, [String:Any],String)] = [
    (.descriptive,["Grades":[["Id":1,"Map":"6","Grade":3,"Subject":["Id":21],"Semester":1]]],"6"),
    (.points,["Grades":[["Id":1,"Grade":"9.5/10","GradeValue":9.5,"Subject":["Id":21],"Semester":2]]],"9.5/10"),
    (.text,["Grades":[["Id":1,"Grade":"Postęp \n 80%","Subject":["Id":21]]]],"Postęp \n 80%"),
    (.behaviour,["Grades":[["Id":1,"BehaviourGrade":["Id":2],"Semester":2]]],"Typ zachowania ID 2")
  ]
  var checks = 0
  for (family,root,value) in examples {
   let result = try SupplementalGrades.decode(family: family,root:root)
   precondition(result.count == 1 && result[0].value == value)
   checks += 1
  }
  let empty = try SupplementalGrades.decode(family:.text,root:["Grades":[]])
  precondition(empty.isEmpty); checks += 1
  do { _ = try SupplementalGrades.decode(family:.points,root:["Grades":[["Id":1,"Grade":"5","Subject":["Id":2]],["Id":1,"Grade":"4","Subject":["Id":2]]]])
    fatalError("Duplicate not detected")
  } catch SupplementalGradeError.duplicateIdentity { checks += 1 }
  do { _ = try SupplementalGrades.decode(family:.descriptive,root:["Grades":[["Id":1,"Grade":3,"Subject":["Id":2]]]])
    fatalError("Missing Map not detected")
  } catch SupplementalGradeError.invalidRecord { checks += 1 }
  do { _ = try SupplementalGrades.decode(family:.text,root:["Grades":[["Id":1,"Grade":"5","Subject":["Id":2],"Semester":true]]])
    fatalError("Boolean semester not detected")
  } catch SupplementalGradeError.invalidRecord { checks += 1 }
  print("\(checks)/\(checks) synthetic supplemental grade tests PASS")
 }
}
