import Foundation

@main struct TimetableTests {
    static var pass = 0, fail = 0
    static func check(_ title: String, _ body: () throws -> Bool) {
        do { if try body() { pass += 1; print("PASS " + title) } else { fail += 1; print("FAIL " + title) } }
        catch { fail += 1; print("FAIL \(title): \(error)") }
    }
    static func lesson(_ subject: String = "42", cancel: Bool = false) -> [String: Any] {
        ["LessonNo": "2", "HourFrom": "08:55", "HourTo": "09:40",
         "Subject": ["Id": subject], "IsCanceled": cancel, "IsSubstitutionClass": false,
         "Teacher": ["Id": 8], "Classroom": ["Id": "12"]]
    }
    static func main() {
        let week = "2026-11-02"
        check("ISO week starts Monday") { DirectTimetableParser.isMonday(week) }
        check("reject Tuesday as starting day") { !DirectTimetableParser.isMonday("2026-11-03") }
        check("reject invalid calendar date") { !DirectTimetableParser.isMonday("2026-11-32") }
        check("reject query injection") { !DirectTimetableParser.isMonday("2026-11-02&foo=bar") }
        check("Monday of Wednesday computed") {
            var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(identifier: "Europe/Warsaw")!
            let d = c.date(from: DateComponents(year: 2026, month: 11, day: 4))!
            return DirectTimetableParser.monday(containing: d) == week
        }
        check("real structure day, slot, parallel groups") {
            let payload: [String: Any] = ["Timetable": ["2026-11-03": [
                [[String:Any]](), [lesson(), lesson("66")], [lesson("71",cancel:true)]
            ]]]
            let s = try DirectTimetableParser.parse(payload, monday: week, accountId: "account")
            return s.entries.count == 3 && s.splitPeriods == 1 &&
                s.entries[0].parallelCount == 2 && s.entries[1].parallelIndex == 1 &&
                s.entries[2].isCanceled == true && s.accountId == "account" &&
                s.entries[0].subjectId == "42" && s.entries[0].teacherId == "8"
        }
        check("empty published days accepted, not invented lessons") {
            let s = try DirectTimetableParser.parse(["Timetable": ["2026-11-02": [[String:Any]]()]], monday: week, accountId: "X")
            return s.entries.isEmpty && s.reportedDates == ["2026-11-02"]
        }
        check("unpublished empty dictionary not claimed a real timetable") {
            do { _ = try DirectTimetableParser.parse(["Timetable": [String:Any]()], monday: week, accountId: "X"); return false }
            catch DirectTimetableError.missingTimetable { return true }
        }
        check("wrong root rejected") {
            do { _ = try DirectTimetableParser.parse(["Timetables": [:]], monday: week, accountId: "X"); return false }
            catch DirectTimetableError.missingTimetable { return true }
        }
        check("outside requested week rejected") {
            do { _ = try DirectTimetableParser.parse(["Timetable": ["2026-11-09": [[lesson()]]]], monday: week, accountId: "X"); return false }
            catch DirectTimetableError.invalidDate { return true }
        }
        check("malformed slot rejected") {
            do { _ = try DirectTimetableParser.parse(["Timetable": ["2026-11-02": ["wrong"]]], monday: week, accountId: "X"); return false }
            catch DirectTimetableError.malformedDay { return true }
        }
        check("empty lesson rejected") {
            do { _ = try DirectTimetableParser.parse(["Timetable": ["2026-11-02": [[[String:Any]()]]]], monday: week, accountId: "X"); return false }
            catch DirectTimetableError.malformedLesson { return true }
        }
        check("unresolved group subject remains absent") {
            let r: [String:Any] = ["LessonNo":"3", "Subject":["garbage":"unknown"]]
            let s = try DirectTimetableParser.parse(["Timetable": ["2026-11-02": [[r]]]], monday:week,accountId:"A")
            return s.entries[0].subjectId == nil
        }
        check("parallel grouping never merges student subgroups") {
            let s = try DirectTimetableParser.parse(["Timetable": ["2026-11-02": [[lesson("42"),lesson("43"),lesson("44")]]]], monday:week,accountId:"A")
            return s.entries.map(\.subjectId) == ["42","43","44"] && s.splitPeriods == 1
        }
        check("day keys sorted regardless JSON ordering") {
            let s = try DirectTimetableParser.parse(["Timetable": ["2026-11-04": [[lesson("5")]],"2026-11-02": [[lesson("7")]]]], monday:week,accountId:"A")
            return s.entries.map(\.date) == ["2026-11-02", "2026-11-04"]
        }
        check("no Monday checking relying on locale current") { DirectTimetableParser.isMonday("2026-11-02") }
        print("TIMETABLE PASS=\(pass) FAIL=\(fail)")
        if fail > 0 { exit(1) }
    }
}
