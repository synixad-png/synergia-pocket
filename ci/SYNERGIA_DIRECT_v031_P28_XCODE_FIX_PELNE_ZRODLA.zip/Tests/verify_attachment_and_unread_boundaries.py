#!/usr/bin/env python3
"""Static invariants for attachment downloads and unread counts. NOT an iOS build/test."""
from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]/'Sources'
policy=(r/'DirectAttachmentPolicy.swift').read_text()
client=(r/'SynergiaMessagesClient.swift').read_text()
portal=(r/'Portal.swift').read_text()
view=(r/'MainView.swift').read_text()
counts=(r/'DirectUnreadCounts.swift').read_text()
checks = {
  'HTTPS download link validation': 'components.scheme?.lowercased() == "https"' in policy,
  'download link rejects embedded credentials': 'components.user == nil, components.password == nil' in policy,
  'local hosts/IP refused': 'host.hasSuffix(".local")' in policy and 'allSatisfy(\\.isNumber)' in policy,
  'ticket follows documented API field': 'payload["downloadLink"]' in policy,
  'ticket not persisted': 'JSONEncoder' not in policy and 'UserDefaults' not in policy,
  'link GET has no cookies': 'req.httpShouldHandleCookies = false' in client and 'session.bytes(for: req)' in client,
  'attachments remain GET and never POST': 'func attachment(' in client and 'req.httpMethod = "GET"' in client and 'session.bytes(for: req)' in client,
  'redirects disabled': 'completionHandler(nil)' in client,
  'max download size': 'DirectAttachmentPolicy.maxBytes' in client,
  'no HTML-as-attachment': 'mime.contains("text/html")' in client,
  'direct API ticket endpoint': 'attachments/\\(file.id)/messages/\\(messageId)' in client,
  'unread API endpoint': 'inbox/unreadMessagesCount' in client,
  'unread unknown not zero': 'guard let raw = data[key] else { continue }' in counts,
  'account checked before and after download': 'let contents = try await client.attachment' in portal and 'let last = try DirectAccountIdentity.parse' in portal.split('func downloadDirectMessageAttachment')[1],
  'account checked before and after counters': 'let counts = try await messages.unreadCounts()' in portal and 'guard first == last' in portal.split('func refreshDirectUnreadCounts')[1].split('/// Odczyt całej')[0],
  'file writing has full file protection': 'options: [.atomic, .completeFileProtection]' in portal,
  'no persistent file cache for message downloads': 'FileManager.default.temporaryDirectory' in portal and 'clearDirectAttachments()' in portal,
  'cleanup on logout': re.search(r'func signOutAndClear\(\) \{\s*//[^\n]*\n\s*guard sessionLifecycle.beginCleanup\(\) else \{ return \}\s*privacyShieldActive = true\s*cancelCoreSync\(\)\s*UNUserNotificationCenter.current\(\).removeAllDeliveredNotifications\(\)\s*lockDirectMessages\(\)', portal) is not None,
  'cleanup on account verification': re.search(r'func verifyAccount\(\) \{\s*//[^\n]*\n\s*guard !backgroundSuspended, sessionLifecycle.beginVerification\(\) else \{ return \}\s*cancelCoreSync\(\)\s*lockDirectMessages\(\)', portal) is not None,
  'cleanup on navigation': re.search(r'didStartProvisionalNavigation navigation: WKNavigation!\) \{\s*sessionLifecycle.cancelVerification\(\)\s*cancelCoreSync\(\)\s*lockDirectMessages\(\)', portal) is not None,
  'downloads only after explicit button': 'portal.downloadDirectMessageAttachment(file, in: detail)' in view,
  'share sheet after download': 'ShareLink(item: localURL)' in view,
  'warning about read side effect': 'może oznaczyć jako przeczytaną' in view,
  'send separate from attachment reads': 'func sendOnce(' in client and 'func attachment(' in client and 'func recipientGroups(' in client,
}
for k,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+k)
print(f'TOTAL {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
