#!/usr/bin/env python3
"""Static/source boundary assertions for batch 10; not an iOS runtime test."""
from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
p=(r/'Sources/Portal.swift').read_text()
v=(r/'Sources/MainView.swift').read_text()
s=(r/'Sources/DirectNotificationPolicy.swift').read_text()
c=(r/'Sources/DirectCoreSync.swift').read_text()
a=(r/'Sources/SynergiaDirectApp.swift').read_text()
settings=p[p.index('    func refreshLocalNotificationAuthorization()'):p.index('    private func cancelCoreSync(')]
delivery=p[p.index('    private func deliverCoreNotifications('):p.index('    /// In-memory staging;',p.index('    private func deliverCoreNotifications('))]
sync=p[p.index('    func synchronizeCoreModules()'):p.index('    private func deliverCoreNotifications(')] if False else p[p.index('    func synchronizeCoreModules()'):]
checks={
 'policy is separate Foundation-only module':'import Foundation' in s and 'import SwiftUI' not in s and 'import UserNotifications' not in s,
 'default explicit opt in false':'var enabled: Bool = false' in s,
 'grades individually selectable':'case grades, attendance, messages' in s and 'case .grades: grades = enabled' in s,
 'attendance individually selectable':'case .attendance: attendance = enabled' in s,
 'messages individually selectable':'case .messages: messages = enabled' in s,
 'preferences persisted through explicit store':'enum DirectNotificationPreferenceStorage' in s and 'defaults.set(data, forKey: key)' in s,
 'settings are schema versioned':'var schemaVersion: Int = 1' in s and 'saved.schemaVersion == 1' in s,
 'corrupt settings fail closed':'return DirectNotificationPreferences()' in s,
 'preferences store only toggles and version':all(f'var {name}: Bool' in s for name in ['enabled','grades','attendance','messages']) and 'var accountId:' not in s,
 'session account ID held in memory only':'private(set) var lastVerifiedAccountId: String?' in s and 'UserDefaults' not in s[s.index('struct DirectNotificationAccountGate'):],
 'account switch detected only after live Me': 'self.notificationAccountGate.verify(identity.id)' in p and 'SynergiaGatewayClient(webView: self.webView).read(.me)' in p,
 'switch account requires renewed opt-in':'let switchedWithinProcess = self.notificationAccountGate.verify(identity.id)' in p and 'self.setLocalNotifications(false)' in p,
 'relaunch requires persisted verified owner binding':'savedConsentMatchesOwner = DirectNotificationOwnerPolicy.mayActivate(' in p and 'DirectNotificationOwnerKeychain.read()' in p,
 'no consent before /Me verification':'guard let verifiedOwner = store.verifiedAccountId' in settings,
 'device-only keychain binding exists':(r/'Sources/DirectNotificationOwnerKeychain.swift').exists() and 'kSecAttrAccessibleWhenUnlockedThisDeviceOnly' in (r/'Sources/DirectNotificationOwnerKeychain.swift').read_text(),
 'keychain wiped at explicit logout':'DirectNotificationOwnerKeychain.clear()' in p[p.index('func signOutAndClear()'):p.index('func signOutAndClear()')+800],
 'account ID never stored in UserDefaults':'Data(verifiedAccount.utf8)' not in s and 'Data(verifiedAccount.utf8)' in (r/'Sources/DirectNotificationOwnerKeychain.swift').read_text(),
 'logout clears saved opt in':'DirectNotificationPreferenceStorage.clear()' in p[p.index('func signOutAndClear()'):p.index('func signOutAndClear()')+1000],
 'logout invalidates asynchronous permission': 'notificationAuthorizationGate.cancel()' in p[p.index('func signOutAndClear()'):p.index('func signOutAndClear()')+1000],
 'logout clears account binding':'notificationAccountGate.reset()' in p,
 'logout removes delivered alerts':'removeAllDeliveredNotifications()' in p[p.index('func signOutAndClear()'):p.index('func signOutAndClear()')+250],
 'logout locks messages before clearing preferences':'lockDirectMessages()' in p[p.index('func signOutAndClear()'):p.index('func signOutAndClear()')+260],
 'initial app init loads preferences':'localNotificationPreferences = DirectNotificationPreferenceStorage.load()' in p,
 'startup checks actual iOS permission':'refreshLocalNotificationAuthorization()' in p[p.index('override init()'):p.index('override init()')+900],
 'foreground refreshes iOS permission':'case .active:\n            refreshLocalNotificationAuthorization()' in p,
 'permission checks OS authorization state':'settings.authorizationStatus == .authorized' in settings,
 'provisional permission handled':'settings.authorizationStatus == .provisional' in settings,
 'permission denied fails closed':'self.localNotificationPreferences.enabled = false' in settings,
 'system request requires explicit user action':'func setLocalNotifications(_ enabled: Bool)' in settings and 'requestAuthorization(options:' in settings,
 'permission prompt race prevented':'notificationAuthorizationGate.beginStatusCheck()' in settings and 'notificationAuthorizationGate.acceptUserRequest(ticket)' in settings,
 'manual disabling cancels pending permission':'notificationAuthorizationGate.cancel()' in settings,
 'manual disabling clears delivered alerts':'removeAllDeliveredNotifications()' in settings,
 'category disabling removes pending category':'removePendingNotificationRequests(withIdentifiers: [kind.requestIdentifier])' in settings,
 'category disabling removes delivered category':'removeDeliveredNotifications(withIdentifiers: [kind.requestIdentifier])' in settings,
 'notification plan requires reliable baseline':'hadGradesBaseline && gradesReliable' in c and 'hadInboxBaseline && inboxReliable' in c,
 'missing records never notified':'disappearedGrades' not in c[c.index('struct CoreLocalNotificationPlan'):],
 'delivery never during background':'!backgroundSuspended, !privacyShieldActive' in delivery,
 'delivery requires verified owner':'let owner = store.verifiedAccountId' in delivery,
 'delivery rechecks OS permission':'getNotificationSettings' in delivery,
 'delivery checks current account epoch':'self.accountEpoch == accountTicket' in delivery,
 'delivery checks same account identity':'self.store.verifiedAccountId == owner' in delivery,
 'delivery checks sync epoch':'self.coreSyncEpoch == syncTicket' in delivery,
 'delivery checks permission generation':'self.notificationAuthorizationGate.generation == permissionTicket' in delivery,
 'delivery rejects pending permission prompt':'!self.notificationAuthorizationGate.requestInProgress' in delivery,
 'notification sound and content are generic':'content.title = title' in delivery and 'content.body = body' in delivery and 'content.sound = .default' in delivery,
 'message text not exposed':'Wykryto nowe wiadomości odebrane.' in delivery and 'detail.body' not in delivery,
 'stable identifiers per category':'let id = kind.requestIdentifier' in delivery and 'UUID().uuidString' not in delivery,
 'delivery removes queued duplicate by identifier':'center.removePendingNotificationRequests(withIdentifiers: [id])' in delivery,
 'delivery removes already delivered category duplicate':'center.removeDeliveredNotifications(withIdentifiers: [id])' in delivery,
 'rapid rechecks are de-bounced':'notificationDebouncer.eligible(candidates, at: Date())' in delivery,
 'notification schedule is single shot':'UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)' in delivery,
 'category switches in real settings UI':all(f'portal.setLocalNotificationCategory(.{k}, enabled: $0)' in v for k in ['grades','attendance','messages']),
 'explicit system status UI': 'portal.refreshLocalNotificationAuthorization()' in v,
 'no automatic background polling':'BackgroundTasks' not in p and 'BGTaskScheduler' not in p and 'BGAppRefreshTask' not in a,
 'notification never initiates send':'confirmDirectSend' not in delivery,
 'testable pure policy present':(r/'Tests/notification_policy_standalone.swift').exists(),
 'no IPA or EXE files':not list(r.rglob('*.ipa')) and not list(r.rglob('*.exe')),
}
for label,passed in checks.items(): print(('PASS ' if passed else 'FAIL ')+label)
print(f'BATCH10 STATIC {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
