#!/usr/bin/env python3
"""Source boundary checks only; they are not a full SwiftUI/iOS typecheck."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
portal=(r/'Sources/Portal.swift').read_text()
client=(r/'Sources/SynergiaGatewayClient.swift').read_text()
authors=(r/'Sources/DirectGradeAuthors.swift').read_text()
store=(r/'Sources/DirectGradeStore.swift').read_text()
view=(r/'Sources/MainView.swift').read_text()
subjects=(r/'Sources/SynergiaSubjects.swift').read_text()
grade=(r/'Sources/SynergiaGradeRecords.swift').read_text()
old=(r/'Tests/grade_teachers_standalone.swift').read_text()
checks={
 'new workflow edits existing Portal': 'let authors = try await client.readGradeAuthors(grades: parsed' in portal,
 'core sync authors use same resolver': 'let authors = try await client.readGradeAuthors(grades: rows' in portal,
 'core sync commits resolution after final identity check': portal.index('let last = try DirectAccountIdentity.parse') < portal.index('olderTeacherIds: g.authors.staleIds'),
 'individual reads check final account': portal.index('let finalMe = try DirectAccountIdentity.parse') < portal.index('olderTeacherIds: authors.staleIds'),
 'manual sync captures previous after verification': 'let previousVerifiedNames = directGradeStore.verifiedAccountId == previousOwner' in portal,
 'cached names passed only after matching first account': 'previous: firstMe.id == previousOwner ? previousVerifiedNames : [:]' in portal,
 'core names from same account store': 'previous: self.directGradeStore.teachers' in portal,
 'manual sync lock persists': 'directGradeStore.lock()' in portal,
 'single endpoint whitelisted': 'func readUser(id: String)' in client,
 'single endpoint rejects bad ids': 'guard DirectGradeAuthors.requestableUserId(id)' in client,
 'single endpoint constructs path under /Users': '.appendingPathComponent(Resource.users.rawValue)' in client and '.appendingPathComponent(id)' in client,
 'single endpoint validates path': 'return try await readValidated(path, resource: .users, userId: id)' in client,
 'transport exact permitted path': 'url.path == permitted.path' in client,
 'transport requires https official domain': 'url.scheme == "https", url.host?.lowercased() == "synergia.librus.pl"' in client,
 'transport excludes foreign port/user/fragment': 'url.port == nil, url.user == nil, url.password == nil' in client and 'url.fragment == nil' in client,
 'single user query forbidden': 'if userId != nil && url.query != nil' in client,
 'limited sequential user lookup': '.prefix(24)' in client,
 'read existing Users first': 'current = try DirectGradeAuthors.decode((try await read(.users)).json)' in client,
 'single lookup ID validated twice': 'guard requestableUserId(requestedId)' in authors and 'received == requestedId' in authors,
 'single lookup validated fields': 'try decode(["Users": [entry]])' in authors,
 'server 403 does not trigger large retry loop': 'catch GatewayReadError.forbidden { break }' in client,
 'auth expiry not hidden in lookup': 'catch GatewayReadError.loginRequired { throw GatewayReadError.loginRequired }' in client,
 'no made-up teacher from timetable': 'let ids = Set(grades.compactMap(\\.teacherId))' in authors,
 'unresolved truly includes blank names': 'users[$0]?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty != false' in authors,
 'account cache stores older name markers': 'let olderTeacherIds: [String]?' in store and 'Set(saved.olderTeacherIds ?? [])' in store,
 'account cache clears markers on lock': 'olderTeacherIds = []' in store,
 'account-scoped encrypted-ish path filenames remain hash': 'SHA256.hash(data: Data(accountId.utf8))' in store,
 'account cache no unverified unlock': 'verifiedAccountId = accountId' in store and 'saved.accountId == accountId' in store,
 'cache retains iOS file protection': '.completeFileProtection' in store,
 'UI filter by subject': 'gradeSubjectSelection' in view and 'Wszystkie przedmioty' in view,
 'UI filters normal grades': '.filter { gradeSubjectSelection.isEmpty || $0.subjectId == gradeSubjectSelection }' in view,
 'UI filters extra grades': '(gradeSubjectSelection.isEmpty || item.subjectId == gradeSubjectSelection)' in view,
 'UI displays unverified subject id': 'Text("Przedmiot: \\(portal.directGradeStore.subjects[subject]' in view,
 'UI labels older names': 'Autor wpisu (z wcześniejszego odczytu)' in view,
 'UI offers filter reset when stale': 'Button("Pokaż wszystkie przedmioty")' in view,
 'subject parser forbids bool IDs': 'CFGetTypeID(number) != CFBooleanGetTypeID()' in subjects,
 'subject parser requires integer': 'number.doubleValue.rounded() == number.doubleValue' in subjects,
 'subject integrity remains enforced': 'try GradeReferenceIntegrity.validate(grades: parsed, subjects: names)' in portal,
 'author field sourced from AddedBy': 'item["AddedBy"]' in grade,
 'regression test preserved': 'DirectGradeAuthors.decode' in old,
 'new author tests exist': (r/'Tests/grade_author_resolution_standalone.swift').exists(),
 'new subject tests exist': (r/'Tests/grade_subjects_boundary_standalone.swift').exists(),
 'never build IPA': not list(r.rglob('*.ipa')) and not list(r.rglob('*.exe')),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL') + ' ' + k)
print('BATCH11 STATIC',sum(checks.values()),'/',len(checks))
if not all(checks.values()): raise SystemExit(1)
