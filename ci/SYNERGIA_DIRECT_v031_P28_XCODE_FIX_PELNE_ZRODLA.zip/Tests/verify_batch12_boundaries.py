#!/usr/bin/env python3
"""Static integration guards for attendance analytics. Not an iOS typecheck."""
from pathlib import Path
r = Path(__file__).resolve().parents[1]
read = lambda name: (r/'Sources'/name).read_text()
ui = read('DirectAttendanceAnalyticsView.swift')
statistics = read('DirectAttendanceStatistics.swift')
analytics = read('DirectAttendanceAnalytics.swift')
model = read('SynergiaAttendanceRecords.swift')
portal = read('Portal.swift')
main = read('MainView.swift')
checks = {
    'existing attendance decoder remains': 'enum SynergiaAttendanceRecords' in model,
    'uses status from server': 'isPresenceKind: type.isPresenceKind' in model,
    'cannot infer presence from numeric type': 'let type = typeLookup[typeId]' in model,
    'unknown type rejects read': 'throw AttendanceDecodeError.missingAttendanceType' in model,
    'normalizes lesson string numeric': 'let lessonNo = positiveNumber(row["LessonNo"])' in model,
    'normalizes semester string numeric': 'let semester = positiveNumber(row["Semester"])' in model,
    'rejects Boolean numeric fields': 'CFGetTypeID(number) != CFBooleanGetTypeID()' in model,
    'still groups by actual semester': 'Dictionary(grouping: records, by: \\.semester)' in statistics,
    'still groups by actual subject': 'Dictionary(grouping: records, by: \\.subjectId)' in statistics,
    'all counters partition records': 'recorded == present + absent' in statistics,
    'classification unknown separate': 'absenceStatusUnknown: unknown' in statistics,
    'excused status requires name': 'static func excuse(_ text: String)' in statistics,
    'late must be present kind': 'if DirectAttendanceStatus.isLate(record.typeName)' in statistics,
    'invalid dates handled explicitly': 'calendar.component(.day, from: date) == d' in statistics,
    'no percentages inferred from entries': 'nie podajemy oficjalnego procentu frekwencji' in ui,
    'date parser used for unique day count': 'records.compactMap { DirectAttendanceCalendar.day($0.date) }' in statistics,
    'subject term cross grouping': 'DirectAttendanceSubjectSemesterStatistics' in analytics,
    'monthly aggregate': 'DirectAttendanceMonthStatistics' in analytics,
    'status type aggregate': 'DirectAttendanceTypeStatistics' in analytics,
    'null semester retained': 'case .unspecified: if entry.semester != nil' in analytics,
    'null subject retained': 'case .unspecified: if entry.subjectId != nil' in analytics,
    'null month retained': 'case .invalid: if DirectAttendanceCalendar.month' in analytics,
    'no dropping repeated periods': 'if !knownSlots.insert(slot).inserted { repeats += 1 }' in analytics,
    'custom presence kind retained': 'case .present: return entry.isPresenceKind' in analytics,
    'school-specific type identifiers retained': 'typeId: key.id' in analytics,
    'list filter by semester': 'Picker("Semestr", selection: $semesterFilter)' in ui,
    'list filter by subject': 'Picker("Przedmiot", selection: $subjectFilter)' in ui,
    'list filter by month': 'Picker("Miesiąc", selection: $monthFilter)' in ui,
    'list filter by status': 'Picker("Status", selection: $statusFilter)' in ui,
    'clear filters action': 'Button("Wyczyść filtry") { resetFilters() }' in ui,
    'filter reset on account switch': '.onChange(of: accountId) { _ in resetFilters() }' in ui,
    'bounded list': 'prefix(80)' in ui,
    'quality unknown statuses visible': 'Niespójne opisy identyfikatorów statusów' in ui,
    'quality missing subject visible': 'Bez powiązanego przedmiotu' in ui,
    'quality invalid date visible': 'Daty wymagające weryfikacji' in ui,
    'same store and account used in new view': 'accountId: portal.directAttendanceStore.verifiedAccountId' in main,
    'existing verified attendance replace': 'try self.directAttendanceStore.replace(records: parsed' in portal,
    'existing completeness check': 'DirectAttendanceCompleteness.validateNoUnexplainedDisappearance' in portal,
    'existing store uses protection': '.completeFileProtection' in read('DirectAttendanceStore.swift'),
    'new UI is actually connected': 'DirectAttendanceAnalyticsView(records: portal.directAttendanceStore.records' in main,
    'new tests included': (r/'Tests/attendance_analytics_standalone.swift').exists(),
    'no unexpected iOS artifact': not list(r.rglob('*.ipa')) and not list(r.rglob('*.exe')),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + name)
print(f'BATCH12 ATTENDANCE BOUNDARIES {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
