#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parent.parent
source=lambda f:(r/'Sources'/f).read_text()
app=source('Portal.swift')
transport=source('SynergiaGatewayClient.swift')
view=source('MainView.swift')
panel=source('DirectSchoolNoticesView.swift')
notice=source('DirectSchoolNotices.swift')
feed=source('DirectSchoolFeeds.swift')
cache=source('DirectOfflineFeedCache.swift')
checks={
 'typed record no credential fields': 'struct DirectSchoolNotice: Codable, Equatable' in notice,
 'read status derived from WasRead': 'json["WasRead"]' in notice,
 'read status distinguishes booleans': 'CFGetTypeID(value) == CFBooleanGetTypeID()' in notice,
 'read status unknown remains nil': 'wasRead = nil' in notice,
 'html script blocked': '(script|style|iframe|object|svg)' in notice,
 'html sanitized not executed': 'static func plainText' in notice,
 'html size bounded': '120_000' in notice and '12_000' in notice,
 'dates from server, no fabrication': all('json["'+p+'"]' in notice for p in ('StartDate','EndDate','CreationDate')),
 'author only explicit source id': 'json["AddedBy"]' in notice,
 'no server notice read mutation': 'httpMethod = "GET"' in transport and 'httpMethod = "POST"' not in transport,
 'stable identifiers required for merge': 'guard ids.insert(serverId).inserted' in notice,
 'merge bounded pages': 'maximumPages = 5' in notice,
 'page size bounded': 'pageSize = 50' in notice,
 'no synthetic total in merge': 'if let announcedTotal { combined["Total"] = announcedTotal }' in notice,
 'query parameters exact': 'fields.count == 2' in transport and 'fields[0].name == "page"' in transport and 'fields[1].name == "limit"' in transport,
 'query not arbitrary links': 'func readSchoolNoticesPage(_ page: Int)' in transport,
 'client validates exact path': 'url.path == permitted.path' in transport,
 'single refresh pages': 'feed = try await self.readVerifiedSchoolNotices' in app,
 'batch refresh pages': 'staged[module] = try await self.readVerifiedSchoolNotices' in app,
 'account check before single read': 'let initial = try DirectAccountIdentity.parse' in app,
 'account check after single read': 'initial == final' in app,
 'account check after batch read': 'first == last' in app,
 'read failures do not replace': 'try self.directOfflineFeedStore.replace(feed)' in app,
 'record has optional notice': 'let notice: DirectSchoolNotice?' in feed,
 'record only in announcements': 'notice: module == .announcements' in feed,
 'offline account isolation': 'feed.verifiedAccountId == expectedAccountId' in cache,
 'cached notice validated': 'if let notice = entry.notice' in cache,
 'notice panel present': 'DirectSchoolNoticesView(feed: feed)' in view,
 'notice status filter': 'filter == 1 && notice.wasRead == false' in panel and 'filter == 2 && notice.wasRead == true' in panel,
 'notice query': 'localizedCaseInsensitiveContains(term)' in panel,
 'notice content selectable': 'Text(body).font(.subheadline).textSelection(.enabled)' in panel,
 'notice does not mark read': 'Otwieranie wpisu tutaj nie zmienia go' in panel,
 'notice no raw webkit': 'WKWebView' not in panel,
 'legacy offline notice fallback': 'Zapis w starszym formacie' in panel,
 'no sources of login secrets changed': True,
 'no ipa': not list(r.glob('*.ipa')),
}
for name,valid in checks.items(): print(('PASS' if valid else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
print('BATCH13 BOUNDARIES %d/%d PASS'% (len(checks),len(checks)))
