from pathlib import Path
r=Path(__file__).resolve().parent.parent
source=lambda x:(r/'Sources'/x).read_text()
feed=source('DirectSchoolFeeds.swift')
ui=source('MainView.swift')
panel=source('DirectSchoolAgendaView.swift')
parser=source('DirectSchoolAgenda.swift')
cache=source('DirectOfflineFeedCache.swift')
audit=source('DirectFeedChangeAudit.swift')
transport=source('SynergiaGatewayClient.swift')
checks={
 'calendar resource remains HomeWorks': 'case .calendar: return .homework' in feed,
 'homework resource remains HomeWorkAssignments': 'case .homework: return .homeworkAssignments' in feed,
 'calendar structured entry dedicated': 'agenda: module == .calendar ? DirectSchoolAgendaEvent.parse(record) : nil' in feed,
 'no assignment agenda metadata': 'module == .calendar ? DirectSchoolAgendaEvent.parse(record) : nil' in feed,
 'calendar view integrated': 'DirectSchoolAgendaView(feed: feed)' in ui,
 'announcements view untouched': 'DirectSchoolNoticesView(feed: feed)' in ui,
 'date strict validation': 'static func validDay' in parser,
 'HTML converted to plain text': 'DirectSchoolNotice.plainText' in parser,
 'no UI execution of HTML': 'WKWebView' not in panel and 'HTML' not in panel,
 'unknown category remains unknown': 'nazwa niedostępna' in panel,
 'date-free records segregated': 'Bez rozpoznanej daty' in parser,
 'separate upcoming and past': 'case .upcoming:' in parser and 'case .past:' in parser,
 'per-account cache check': 'feed.verifiedAccountId == expectedAccountId' in cache,
 'calendar cache validates date': 'DirectSchoolAgendaEvent.validDay($0) == $0' in cache,
 'change audit sees agenda edits': 'earlier.agenda != pair.value.agenda' in audit,
 'transport only GET': 'request.httpMethod = "GET"' in transport,
 'account check before and after': 'initial == final' in source('Portal.swift'),
 'same feed in batch': 'staged[module] = try DirectSchoolFeedParser.parse' in source('Portal.swift'),
 'no IPA produced': not list(r.glob('*.ipa')),
}
for name, passed in checks.items():print(('PASS' if passed else 'FAIL')+' '+name)
if not all(checks.values()):raise SystemExit(1)
print('BATCH14 BOUNDARIES %d/%d PASS'%(len(checks),len(checks)))
