from pathlib import Path
r=Path(__file__).resolve().parent.parent
get=lambda n:(r/'Sources'/n).read_text()
feed=get('DirectSchoolFeeds.swift'); model=get('DirectHomeworkAssignments.swift')
ui=get('DirectHomeworkAssignmentsView.swift'); main=get('MainView.swift')
cache=get('DirectOfflineFeedCache.swift'); audit=get('DirectFeedChangeAudit.swift')
checks={
 'homework resource unchanged': 'case .homework: return .homeworkAssignments' in feed,
 'agenda resource unchanged': 'case .calendar: return .homework' in feed,
 'dedicated homework parsing': 'homework: module == .homework ? DirectHomeworkAssignment.parse(record) : nil' in feed,
 'dedicated agenda parsing remains': 'agenda: module == .calendar ? DirectSchoolAgendaEvent.parse(record) : nil' in feed,
 'homework UI integrated': 'DirectHomeworkAssignmentsView(' in main,
 'agenda UI retained': 'DirectSchoolAgendaView(feed: feed)' in main,
 'notice UI retained': 'DirectSchoolNoticesView(feed: feed)' in main,
 'no assumed completion': 'isComplete' not in model and 'hasSubmitted' not in model and 'let completed:' not in model,
 'explicit due only': 'record["DueDate"]' in model and 'record["Deadline"]' in model,
 'no Date inferred for due': 'validDay(record["Date"])' not in model,
 'html sanitization': 'DirectSchoolNotice.plainText' in model,
 'explicit subject only': 'subject?["Name"]' in model,
 'offline account isolation': 'feed.verifiedAccountId == expectedAccountId' in cache,
 'offline homework validated': 'if let homework = entry.homework' in cache,
 'change audit includes homework': 'earlier.homework != pair.value.homework' in audit,
 'file downloader preserved': 'onDownload(file, item)' in ui and 'portal.downloadDirectHomeworkFile(file, from: item)' in main,
 'no write action in homework view': 'WKWebView' not in ui and 'submit(' not in ui and 'upload' not in ui,
 'unknown file list visibly distinct': 'Lista załączników nie została potwierdzona' in ui,
 'filter is only date status': 'nie potwierdza, że zadanie jest nieodrobione' in ui,
 'no IPA': not list(r.glob('*.ipa')),
 'transport still GET': 'request.httpMethod = "GET"' in get('SynergiaGatewayClient.swift'),
 'no build workflow run': not list((r/'build').glob('**/*.ipa')),
}
for k,v in checks.items():
 print(('PASS ' if v else 'FAIL ')+k)
assert all(checks.values()),'Batch15 source boundaries not met'
print(f'BATCH15 BOUNDARIES {len(checks)}/{len(checks)} PASS')
