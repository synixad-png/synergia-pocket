from pathlib import Path
root=Path(__file__).resolve().parent.parent
read=lambda name:(root/'Sources'/name).read_text()
feed=read('DirectSchoolFeeds.swift'); model=read('DirectSchoolDocuments.swift')
ui=read('DirectSchoolDocumentsView.swift'); main=read('MainView.swift')
portal=read('Portal.swift'); cache=read('DirectOfflineFeedCache.swift')
audit=read('DirectFeedChangeAudit.swift'); client=read('SynergiaSchoolFileClient.swift')
checks={
 'unchanged endpoint': 'case .documents: return .schoolFiles' in feed,
 'typed model scoped to docs': 'document: module == .documents ? DirectSchoolDocument.parse(record) : nil' in feed,
 'UI integrated': 'DirectSchoolDocumentsView(' in main,
 'no unverified file link UI': 'uniqueDownloadReference(entry, in: feed)' in ui,
 'no unverified file link controller': 'uniqueDownloadReference(item, in: feed) == file' in portal,
 'duplicate ID guarded': 'feed.records.filter({ $0.serverId == file.id }).count == 1' in model,
 'title-derived extension not MIME': 'filenameExtension(_ name: String)' in model and 'typ pliku niezweryfikowany' in ui,
 'added date only known field': 'record["addedOnDate"]' in model and 'record["Date"]' not in model,
 'server status not treated as authority': 'fileStatus' in model and 'serverStatus' not in client,
 'offline account validation': 'feed.verifiedAccountId == expectedAccountId' in cache,
 'offline docs validation': 'if let document = entry.document' in cache,
 'audit includes docs': 'earlier.document != pair.value.document' in audit,
 'document retrieval remains manual': 'onDownload(file, entry)' in ui,
 'existing download handler retained': 'portal.downloadDirectSchoolFile(file, from: item)' in main,
 'cookie sandbox separation': 'No Synergia Cookie, Authorization, or OAuth headers' in client,
 'download size remains limited': 'DirectSchoolFilePolicy.maxBytes' in client,
 'homework UI retained': 'DirectHomeworkAssignmentsView(' in main,
 'agenda UI retained': 'DirectSchoolAgendaView(feed: feed)' in main,
 'notice UI retained': 'DirectSchoolNoticesView(feed: feed)' in main,
 'homework route unchanged': 'case .homework: return .homeworkAssignments' in feed,
 'agenda route unchanged': 'case .calendar: return .homework' in feed,
 'no iOS release created': not list(root.glob('*.ipa')),
}
for name,good in checks.items():print(('PASS ' if good else 'FAIL ')+name)
assert all(checks.values())
print(f'BATCH16 BOUNDARIES {len(checks)}/{len(checks)} PASS')
