from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=(root/'Sources/Portal.swift').read_text()
main=(root/'Sources/MainView.swift').read_text()
policy=(root/'Sources/DirectLoginRestorePolicy.swift').read_text()
gateway=(root/'Sources/SynergiaGatewayClient.swift').read_text()
checks={
 'persistent WebKit default store': 'config.websiteDataStore = .default()' in p,
 'one-shot startup check': 'loginRestorePolicy.claimStartupVerification()' in p,
 'navigation race restored after startup': 'recheckAfterTrustedNavigation = true' in p,
 'user sees truthful expiry notice': 'Jeśli wygasła, wymagane jest ponowne logowanie.' in main,
 'startup /Me verified': 'func restoreOfficialSessionAtLaunch()' in p and 'guard !sessionLifecycle.isClearing, loginRestorePolicy.claimStartupVerification() else { return }\n        verifyAccount()' in p,
 'root view invokes startup': '.onAppear { portal.restoreOfficialSessionAtLaunch() }' in main,
 'official login URL retained': 'https://portal.librus.pl/rodzina/synergia/loguj' in p,
 'login only via WebKit': 'webView.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData))' in p,
 'login pending set': 'loginRestorePolicy.officialLoginOpened()' in p,
 'redirect does not auto-authorize': 'claimVerificationAfterReturn(to: webView.url)' in p,
 'existing sessions rechecked after navigation': 'recheckAfterTrustedNavigation &&' in p,
 'only official Synergia host': 'url.host?.lowercased() == "synergia.librus.pl"' in policy,
 'never trust login/logout paths': '!path.contains("/login")' in policy and '!path.contains("/logout")' in policy,
 'verified /Me not HTML/cookie': 'SynergiaGatewayClient(webView: self.webView).read(.me)' in p,
 'return after login avoids old web sync': 'if !isSyncing && !backgroundSuspended && !privacyShieldActive {' in p,
 'old sync still verifies page identity': 'verifyIdentityForSyncPage()' in p,
 'foreground verification retained': 'if resumeNeedsAccountVerification && !backgroundSuspended {' in p,
 'account switch epochs retained': 'accountEpoch = epoch' in p,
 'cache locks retained': 'store.lock(); downloads.lock(); routes.lock(); auditStore.lock()' in p,
 'logout cancels login ticket': 'loginRestorePolicy.cancelPendingReturn()\n        recheckAfterTrustedNavigation = false' in p,
 'gateway ephemeral transport': 'URLSessionConfiguration.ephemeral' in gateway,
 'gateway uses WebKit cookies not passwords': 'webView.configuration.websiteDataStore.httpCookieStore' in gateway,
 'gateway never redirects blindly': 'completionHandler(nil)' in gateway,
 'no credential capture in policy': not any(v in policy.lower() for v in ['password=', 'token=', 'cookie=', 'keychain.', 'userdefaults.']),
 'legacy manual verify remains available': 'portal.verifyAccount()' in main,
 'legacy capture available': 'portal.capture(selection)' in main,
 'all modules intact': all(x in main for x in ['DirectSchoolDocumentsView(', 'DirectSchoolAgendaView(', 'DirectSchoolNoticesView(', 'DirectHomeworkAssignmentsView(']),
 'no IPA': not list(root.rglob('*.ipa')),
}
for label,good in checks.items():print(('PASS' if good else 'FAIL')+': '+label)
assert all(checks.values())
print(f'LOGIN BOUNDARIES PASS {len(checks)}/{len(checks)}')
