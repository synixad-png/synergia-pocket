#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
gateway=(r/'Sources/SynergiaGatewayClient.swift').read_text()
policy=(r/'Sources/GatewayJSONPolicy.swift').read_text()
portal=(r/'Sources/Portal.swift').read_text()
message=(r/'Sources/SynergiaMessagesClient.swift').read_text()
manifest=(r/'HARMONOGRAM_STALY.md').read_text()
checks={
 'new policy source exists': (r/'Sources/GatewayJSONPolicy.swift').exists(),
 'transport uses host/path-aware cookie policy': 'GatewayJSONPolicy.applicableCookies(allCookies, to: url)' in gateway,
 'cookie policy requires secure HTTPS': 'cookie.isSecure' in policy and 'url.scheme?.lowercased() == "https"' in policy,
 'host-only cookies not shared to subdomains': 'host == domain' in policy and 'domainCookie' in policy,
 'path boundary enforced': 'suffix.first == "/"' in policy,
 'expiry enforced': 'cookie.expiresDate.map({ $0 > now })' in policy,
 'content-type parsed by actual MIME': 'GatewayJSONPolicy.isJSONContentType' in gateway,
 'no content-type substring acceptance': 'type.contains("json")' not in gateway,
 'byte limit enforced': 'GatewayJSONPolicy.withinJSONLimit' in gateway,
 'declared Content-Length checked': 'expectedBytes: http.expectedContentLength' in gateway,
 'invalid JSON normalized to read error': 'try? JSONSerialization.jsonObject(with: data)' in gateway,
 'full response URL matches request': 'http.url == url' in gateway,
 'grade continuation explicitly bounded': 'guard GatewayJSONPolicy.safeContinuationQuery(url)' in gateway,
 'grade URL query checked twice': 'resource == .grades && url.query != nil && !GatewayJSONPolicy.safeContinuationQuery(url)' in gateway,
 'read only GET': 'request.httpMethod = "GET"' in gateway,
 'redirects blocked': 'completionHandler(nil)' in gateway,
 'resource whitelist remains': 'enum Resource: String' in gateway,
 'no arbitrary foreign hosts': 'url.host?.lowercased() == "synergia.librus.pl"' in gateway,
 'no domain cookie shared to portal via GET': 'SynergiaGatewayClient(webView:' in portal,
 'messages client untouched': 'private final class MessagesNoRedirects' in message,
 'offline and account protection retained': 'DirectAccountIdentity.parse' in portal,
 'no IPA or app artifacts': not list(r.rglob('*.ipa')) and not list(r.rglob('*.app')),
 'unchanged version': 'v0.31' in manifest,
 'standalone tests present': (r/'Tests/gateway_json_policy_standalone.swift').exists(),
}
for label, result in checks.items(): print(('PASS' if result else 'FAIL')+'  '+label)
print('BATCH18 CODE BOUNDARIES:',sum(checks.values()),'/',len(checks))
if not all(checks.values()):raise SystemExit(1)
