from pathlib import Path
p=Path(__file__).resolve().parent.parent/'Sources'/'Portal.swift'
s=p.read_text()
policy=(p.parent/'DirectAccountCommitPolicy.swift').read_text()
grade=s[s.index('    func refreshDirectGrades() {'):s.index('    /// This accessor is used in both single and batch refresh.')]
attendance=s[s.index('    func refreshDirectAttendance() {'):s.index('    @Published var syncSummary')]
checks={
 'policy checks verified owner and remote identities': 'remoteBefore == start && remoteAfter == start && current == start' in policy,
 'policy checks both epochs and foreground': 'accountEpochUnchanged && requestEpochUnchanged && foregroundAndVisible' in policy,
 'grade requires current verified account before request': 'guard let authorizedOwner = store.verifiedAccountId' in grade,
 'grade initial /Me bound to verified owner': 'remoteBefore: firstMe.id, remoteAfter: firstMe.id' in grade,
 'grade final /Me before local unlock': grade.index('guard firstMe == finalMe && DirectAccountCommitPolicy.permits') < grade.index('self.directGradeStore.unlock(accountId: finalMe.id)'),
 'grade both requests scoped to same owner epoch':grade.count('accountEpochUnchanged: self.accountEpoch == ownerEpoch') == 2,
 'attendance requires current verified account before request': 'guard let authorizedOwner = store.verifiedAccountId' in attendance,
 'attendance initial /Me bound to verified owner': 'remoteBefore: initial.id, remoteAfter: initial.id' in attendance,
 'attendance final /Me before local unlock': attendance.index('guard initial == final && DirectAccountCommitPolicy.permits') < attendance.index('self.directAttendanceStore.unlock(accountId: final.id)'),
 'attendance both checks include owner epoch': attendance.count('accountEpochUnchanged: self.accountEpoch == ownerEpoch') == 2,
 'attendance checks foreground': attendance.count('foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive') == 2,
 'grades checks foreground': grade.count('foregroundAndVisible: !self.backgroundSuspended && !self.privacyShieldActive') == 2,
 'other core sync remains present':'func refreshAllDirectFeeds' in s and 'func refreshDirectTimetable' in s,
 'no credential caching added':'password' not in policy.lower(),
}
for title,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+title)
assert all(checks.values()), 'isolation static boundary failure'
print('PASS:',len(checks),'boundary checks')
