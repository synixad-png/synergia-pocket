from pathlib import Path
sroot=Path(__file__).resolve().parent.parent/'Sources'
p=(sroot/'Portal.swift').read_text()
policy=(sroot/'DirectSessionLifecyclePolicy.swift').read_text()
seg_verify=p[p.index('    func verifyAccount() {'):p.index('    /// Read-only grade sync.')]
seg_scene=p[p.index('    func scenePhaseChanged('):p.index('    private func suspendVisibleAccountData')]
seg_signout=p[p.index('    func signOutAndClear() {'):p.index('    // MARK: - One account-scoped')]
seg_nav=p[p.index('    func webView(_ webView: WKWebView, didStartProvisionalNavigation'):p.index('    func webView(_ webView: WKWebView, didFinish')]
checks = {
    'dedicated foundation-only policy':'import Foundation' in policy and 'import WebKit' not in policy,
    'verification is single-flight':'!verificationInFlight' in policy,
    'cleanup prevents verification':'!isClearing && !verificationInFlight' in policy,
    'duplicate cleanup refused':'guard !isClearing' in policy,
    'cleanup invalidates active verify':'verificationInFlight = false' in policy[policy.index('mutating func beginCleanup()'):],
    'verification gate before stored data operations':seg_verify.index('sessionLifecycle.beginVerification()') < seg_verify.index('cancelCoreSync()'),
    'verification guard rejects background': 'guard !backgroundSuspended, sessionLifecycle.beginVerification()' in seg_verify,
    'verification success releases gate only after valid epoch':seg_verify.index('guard self.accountEpoch == epoch else { return }') < seg_verify.index('self.sessionLifecycle.finishVerification()'),
    'verification failure releases gate': seg_verify.count('self.sessionLifecycle.finishVerification()') == 2,
    'navigation invalidates prior check before changing epoch':seg_nav.index('sessionLifecycle.cancelVerification()') < seg_nav.index('accountEpoch = UUID()'),
    'background cancels verification':'sessionLifecycle.cancelVerification()' in seg_scene,
    'background remembers interrupted startup verification':'resumeNeedsAccountVerification = store.verifiedAccountId != nil || wasCheckingSession' in seg_scene,
    'pending verification sampled before cancelling':seg_scene.index('let wasCheckingSession = sessionLifecycle.verificationInFlight') < seg_scene.index('sessionLifecycle.cancelVerification()'),
    'foreground retains cover while clearing':'if sessionLifecycle.isClearing { privacyShieldActive = true; return }' in seg_scene,
    'cleanup gate before signout actions':seg_signout.index('guard sessionLifecycle.beginCleanup()') < seg_signout.index('cancelCoreSync()'),
    'signout immediately hides personal data':'privacyShieldActive = true' in seg_signout[:300],
    'cleanup held through WebKit completion':'self.sessionLifecycle.finishCleanup()' in seg_signout[seg_signout.index('webView.configuration.websiteDataStore.removeData('):],
    'never unshield while backgrounded':'if !self.backgroundSuspended { self.privacyShieldActive = false }' in seg_signout,
    'manual login blocked during purge':'guard !sessionLifecycle.isClearing else { return }' in p[p.index('func openLoginPage()'):p.index('func start()')],
    'startup restore blocked during purge': 'guard !sessionLifecycle.isClearing, loginRestorePolicy.claimStartupVerification()' in p,
    'never saves password':'password' not in policy.lower(),
    'live /Me remains identity authority':'DirectAccountIdentity.parse(' in seg_verify and 'SynergiaGatewayClient(webView: self.webView).read(.me)' in seg_verify,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()),'session boundary checks failed'
print(f'SESSION BOUNDARIES PASS {len(checks)}/{len(checks)} checks')
