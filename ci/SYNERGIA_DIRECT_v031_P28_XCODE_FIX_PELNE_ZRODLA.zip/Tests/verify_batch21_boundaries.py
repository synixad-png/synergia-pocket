from pathlib import Path
s=Path(__file__).resolve().parent.parent/'Sources'
paging=(s/'DirectGradePagination.swift').read_text()
gateway=(s/'SynergiaGatewayClient.swift').read_text()
portal=(s/'Portal.swift').read_text()
policy=(s/'GatewayJSONPolicy.swift').read_text()
checks={
'Pagination URL checked before HTTP': 'GatewayJSONPolicy.safeContinuationQuery(url)' in paging,
'Repeated current page checked before HTTP': 'url.absoluteString != current.absoluteString' in paging,
'Repeated earlier page checked during merge': 'visited.insert(next.absoluteString).inserted' in paging,
'Grade paging error descriptions localized': 'enum GradePagingError: LocalizedError' in paging,
'Empty gradebook still protected': 'merged.isEmpty && expectedTotal != 0' in paging,
'No arbitrary grade endpoint': 'url.path == base.path' in paging,
'No foreign resource host': 'url.host?.lowercased() == "synergia.librus.pl"' in paging,
'Query count bounded': '(1...8).contains(items.count)' in policy,
'Grade continuation request uses gateway validation': 'GatewayJSONPolicy.safeContinuationQuery(url)' in gateway,
'No redirects on URLSession': 'completionHandler(nil)' in gateway,
'Grade read keeps 20-page ceiling': 'pages.count < DirectGradePagination.maximumPages' in portal,
'Core sync keeps 20-page ceiling': portal.count('pages.count < DirectGradePagination.maximumPages') >= 2,
'Grade store still has offline fail protection': 'Zapis na dysku nie został zmieniony' in portal,
'Existing account protection unchanged': 'DirectAccountCommitPolicy.permits(' in portal,
}
for label,valid in checks.items(): print(('PASS' if valid else 'FAIL'),label)
assert all(checks.values())
print(f'PAGING BOUNDARIES PASS {len(checks)}/{len(checks)}')
