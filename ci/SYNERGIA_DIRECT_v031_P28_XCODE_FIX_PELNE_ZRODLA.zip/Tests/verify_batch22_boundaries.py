from pathlib import Path
root=Path(__file__).resolve().parent.parent
src=root/'Sources'
portal=(src/'Portal.swift').read_text()
normal=(src/'GradeSemesterCoverage.swift').read_text()
extra=(src/'SupplementalGrades.swift').read_text()
guard=(src/'SupplementalSemesterCoverage.swift').read_text()
store=(src/'DirectGradeStore.swift').read_text()
ui=(src/'MainView.swift').read_text()
workflow=(root/'.github/workflows/ios.yml').read_text()
checks={
 'both single and batch sync guarded':portal.count('try SupplementalSemesterCoverage.validateReplacement(')==2,
 'guards precede both merge operations':portal.find('try SupplementalSemesterCoverage.validateReplacement(')<portal.find('let supplemental = GradeFamilySnapshot.reconcile(') and portal.rfind('try SupplementalSemesterCoverage.validateReplacement(')<portal.find('let mergedSupplemental = GradeFamilySnapshot.reconcile('),
 'regular grade guard preserved':portal.count('GradeSemesterCoverage.validateReplacement(')>=2,
 'account before/after verification unchanged':'DirectAccountCommitPolicy.permits(' in portal and 'let finalMe = try DirectAccountIdentity.parse' in portal,
 'atomic account-scoped store unchanged':'let saved = Saved(accountId: accountId' in store and '.atomic, .completeFileProtection' in store,
 '403/404 saved from missing guard':'where !unavailable.contains(family)' in guard,
 'previous grade IDs protected':'!freshIDs.contains($0.id)' in guard,
 'extra grades keyed by family':'family.rawValue + ":" + sourceId' in extra,
 'malformed continuation rejected':'SupplementalGradeError.incompleteResponse' in extra,
 'total metadata validated':'SupplementalGradeError.invalidTotal' in extra,
 'non-standard semesters preserved':'otherSemesterCount' in guard,
 'ordinary and supplemental reported':'GradePortfolioSemesterCoverage.report(' in ui,
 'false completeness explicitly excluded':'Kompletność żadnego semestru nie jest potwierdzona' in guard,
 'no fabricated semester assignment':'case 1, 2:' in (src/'GradeSemesterPresentation.swift').read_text(),
 'manual iPhone-only workflow':'iPhone-only verification' in workflow,
 'no iPad simulator requested':'platform=iOS Simulator,name=iPad' not in workflow,
 'project keeps iPad compatibility':"TARGETED_DEVICE_FAMILY: '1,2'" in (root/'project.yml').read_text(),
 'no Xcode or IPA fabricated in tests':'swiftc' not in workflow or 'xcodebuild' in workflow,
}
for title,ok in checks.items(): print(('PASS' if ok else 'FAIL'),title)
assert all(checks.values())
print('BATCH22 INTEGRATION',len(checks),'/',len(checks),'PASS')
