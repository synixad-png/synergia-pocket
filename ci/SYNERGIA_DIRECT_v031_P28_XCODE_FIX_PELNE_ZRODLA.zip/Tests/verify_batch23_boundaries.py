#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, re
root=Path(__file__).resolve().parents[1]
expected=json.loads((root/'Tests/EXPECTED_UNCHANGED_SOURCES_P23_SHA256.json').read_text())
seen={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'Sources').glob('*.swift')}
for name, digest in expected.items():
    assert seen.get(name)==digest, f"unexpected source modification: {name}"
assert set(seen)-set(expected)=={'GradeWeightedAverage.swift','MainView.swift'}
mean=(root/'Sources'/'GradeWeightedAverage.swift').read_text()
ui=(root/'Sources'/'MainView.swift').read_text()
for fragment in ['let unresolvedCount: Int','idCounts[grade.id] == 1','weight.isFinite','weight >= 0',
                 'exactNumericValue(grade.value)','weight: $0.weight / maximum',
                 'denominator.isFinite','result.isFinite','countsToAverage','mean = nil']:
    assert fragment in mean, fragment
for fragment in ['summary.includedCount','summary.excludedCount','summary.unresolvedCount',
                 'Średnie lokalne — wyłącznie orientacyjne','summary.reason']:
    assert fragment in ui, fragment
assert (root/'project.yml').read_bytes()==(root/'Tests'/'PROJECT_CONFIG_P22_PINNED.txt').read_bytes()
assert not any(root.rglob('*.ipa'))
assert not any(root.rglob('*.exe'))
plan=(root/'HARMONOGRAM_STALY.md').read_text()
rows=re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$',plan,re.M)
assert len(rows)==36, len(rows)
assert [int(r[0]) for r in rows]==list(range(1,37))
assert [(int(num),int(old),int(now),int(change)) for num,_,old,now,change in rows if old!=now]==[(7,75,95,20)]
assert all(int(now)-int(old)==int(change) for num,_,old,now,change in rows)
print('PASS 17/17 boundary controls; 36 tasks unchanged; only 2 Swift files modified')
