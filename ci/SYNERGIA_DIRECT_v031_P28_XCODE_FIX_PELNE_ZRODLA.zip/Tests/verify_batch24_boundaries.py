#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, json
root=Path(__file__).resolve().parents[1]
actual=root/'Sources'
# Frozen source inventory for P23 is included in this archive.
stored=json.loads((root/'Tests'/'P24_BASE_SOURCE_HASHES.json').read_text())
assert 'MainView.swift' in stored and 'SynergiaGradeRecords.swift' in stored
assert len(stored) >= 80
newFiles={'GradeDetailAccess.swift','DirectGradeDetailView.swift'}
assert set(p.name for p in actual.glob('*.swift'))==set(stored)|newFiles
assert all(hashlib.sha256((actual/name).read_bytes()).hexdigest()==sha for name,sha in stored.items() if name!='MainView.swift')
ui=(actual/'MainView.swift').read_text()
view=(actual/'DirectGradeDetailView.swift').read_text()
access=(actual/'GradeDetailAccess.swift').read_text()
checks=[
    'ForEach(selectedGrades) { grade in' in ui,
    'DirectGradeDetailView(' in ui,
    'expectedAccountID: portal.store.verifiedAccountId ?? ""' in ui,
    'gradeID: grade.id' in ui,
    'GradeDetailAccess.resolve(' in view,
    'portal.privacyShieldActive' in view,
    'portal.directGradeStore.verifiedAccountId' in view,
    'portal.store.verifiedAccountId' in view,
    'portal.directGradeStore.grades' in view,
    'ContentUnavailableView(' in view,
    'textSelection(.enabled)' in view,
    'fixedSize(horizontal: false, vertical: true)' in view,
    'ForEach(Array(grade.commentTexts.enumerated()), id: \\.offset)' in view,
    'Section("Komentarze (' in view,
    'grade.commentTexts.isEmpty' in view,
    'verifiedAccountID == expectedAccountID' in access,
    'cacheAccountID == expectedAccountID' in access,
    '!privacyShieldActive' in access,
    'grades.first { $0.id == gradeID }' in access,
    'grade.commentTexts' not in ui[ui.index('ForEach(selectedGrades) { grade in'):ui.index('if module == .messages')].replace('grade.commentTexts.isEmpty','').replace('grade.commentTexts.count',''),
]
assert all(checks),[i+1 for i,ok in enumerate(checks) if not ok]
rows=re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$',(root/'HARMONOGRAM_STALY.md').read_text(),re.M)
assert len(rows)==36 and [int(x[0]) for x in rows]==list(range(1,37))
assert [(int(n),int(prev),int(curr)) for n,_,prev,curr,_ in rows if prev!=curr]==[(8,70,95)]
assert all(int(curr)-int(prev)==int(change) for n,_,prev,curr,change in rows)
assert not list(root.rglob('*.ipa'))
print('PASS 20/20 UI+privacy boundaries; 36 fixed tasks; unchanged sources SHA256')
