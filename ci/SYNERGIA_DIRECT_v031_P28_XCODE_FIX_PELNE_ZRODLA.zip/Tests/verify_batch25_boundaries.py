#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parents[1]
old=json.loads((root/'Tests/P25_BASE_SOURCE_HASHES.json').read_text())
now={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'Sources').glob('*.swift')}
modified={'MainView.swift','DirectGradeDetailView.swift'}
assert set(now)==set(old)|{'GradeSubjectAuthorAudit.swift'}, 'missing or unexpected Swift source file'
assert {name for name in old if now[name]!=old[name]}==modified,'unexpected source modification'
ui=(root/'Sources/MainView.swift').read_text()
view=(root/'Sources/DirectGradeDetailView.swift').read_text()
helper=(root/'Sources/GradeSubjectAuthorAudit.swift').read_text()
checks=[
    'let referenceAudit = GradeSubjectAuthorAudit.summarize(' in ui,
    'selectedGrades,' in ui,
    'subjects: portal.directGradeStore.subjects' in ui,
    'authors: portal.directGradeStore.teachers' in ui,
    'earlierAuthorIds: portal.directGradeStore.olderTeacherIds' in ui,
    'Text(referenceAudit.message)' in ui,
    'referenceAudit.hasWarnings' in ui,
    'GradeSubjectAuthorAudit.attribution(for: grade,' in view,
    'portal.directGradeStore.olderTeacherIds' in view,
    'GradeDetailAccess.resolve(' in view,
    'portal.privacyShieldActive' in view,
    'portal.store.verifiedAccountId' in view,
    'portal.directGradeStore.verifiedAccountId' in view,
    'case current(String)' in helper,
    'case earlier(String)' in helper,
    'case .unresolved' in helper,
    'case .notProvided' in helper,
    'earlierIds.contains(id)' in helper,
    'subjects[grade.subjectId]' in helper,
    'nie musi być nauczycielem prowadzącym przedmiot' in helper,
    'teacherId' in helper and 'AddedBy' not in helper, # no extra API inference in helper
    'verifiedAccountID == expectedAccountID' in (root/'Sources/GradeDetailAccess.swift').read_text(),
    (root/'project.yml').read_bytes()==(root/'Tests/P25_BASE_PROJECT_YML.txt').read_bytes(),
    not list(root.rglob('*.ipa')),
]
assert all(checks),[i+1 for i,x in enumerate(checks) if not x]
rows=re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$',(root/'HARMONOGRAM_STALY.md').read_text(),re.M)
assert len(rows)==36 and [int(r[0]) for r in rows]==list(range(1,37))
assert [(int(n),int(a),int(b),int(diff)) for n,_,a,b,diff in rows if a!=b]==[(9,90,95,5)]
assert all(int(b)-int(a)==int(diff) for _,_,a,b,diff in rows)
print(f'PASS {len(checks)}/{len(checks)} source/UI/security boundaries; 36/36 unchanged roadmap tasks; source SHA256')
