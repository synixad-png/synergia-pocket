#!/usr/bin/env python3
from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parents[1]
base=json.loads((root/'Tests/P26_BASE_SOURCE_HASHES.json').read_text())
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'Sources').glob('*.swift')}
assert set(source)==set(base)|{'GradeObservedChangeAudit.swift'},'unexpected sources added/removed'
modified={name for name in base if base[name]!=source[name]}
assert modified=={'Portal.swift'},f'unexpected changed Swift sources: {modified}'
portal=(root/'Sources/Portal.swift').read_text()
helper=(root/'Sources/GradeObservedChangeAudit.swift').read_text()
checks={
 'new compare used in both paths': portal.count('GradeObservedChangeAudit.compare(')==2,
 'manual owner verified': 'let finalMe = try DirectAccountIdentity.parse' in portal,
 'manual same-account guard': 'firstMe == finalMe && DirectAccountCommitPolicy.permits' in portal,
 'batch owner verified': 'guard first == last, last.id == owner, stillCurrent()' in portal,
 'manual snapshot compare before replace': portal.index('let observed = try GradeObservedChangeAudit.compare(')<portal.index('try self.directGradeStore.replace(grades: parsed'),
 'batch snapshot compare before replace': portal.rindex('let observed = try GradeObservedChangeAudit.compare(')<portal.index('try self.directGradeStore.replace(grades: g.rows'),
 'batch status only after commit': portal.index('gradeChangeExplanation = explanation')>portal.index('try self.directGradeStore.replace(grades: g.rows'),
 'batch count observed additions': 'newGrades: hadGradesBaseline ? observed.observedNew : 0' in portal,
 'batch count observed edits': 'editedGrades: hadGradesBaseline ? observed.observedEdited : 0' in portal,
 'notifications reliability remains guarded': 'gradeReliable = g.reliable && delta.missing == 0 && other.missing == 0' in portal,
 'status flags absent family': 'unavailable: g.unavailable' in portal,
 'manual status flags absent family': 'unavailable: unavailableFamilySet' in portal,
 'manual first observation not news': 'let hadPreviousSnapshot = self.directGradeStore.capturedAt != nil' in portal,
 'batch first observation not news': 'hadGradesBaseline ? observed.observedNew : 0' in portal,
 'metadata-only independent': 'metadataOnlyStandard' in helper and 'GradeObservedContent(a) == GradeObservedContent(b) && a != b' in helper,
 'old author id included': 'authorId = row.teacherId' in helper,
 'content comments included': 'commentTexts = row.commentTexts' in helper,
 'metadata excluded from content': 'categoryName' not in helper.split('private struct GradeObservedContent: Equatable {')[1].split('enum GradeObservedAuditError')[0],
 'missing not a deletion': 'nie potwierdzenie zmian w dzienniku ani usunięć' in helper,
 'unavailable families skipped': 'unavailable.contains($0.value.family)' in helper,
 'duplicate additional ID checked': 'duplicateSupplementalID(row.id)' in helper,
 'legacy audit preserved': 'GradeChangeAudit.compare(' in portal,
 'single iPhone test configuration unchanged': hashlib.sha256((root/'project.yml').read_bytes()).hexdigest()==(root/'Tests/P26_BASE_PROJECT_SHA256.txt').read_text().strip(),
 'no IPA': not list(root.rglob('*.ipa')),
}
assert all(checks.values()),[name for name,ok in checks.items() if not ok]
rows=re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$', (root/'HARMONOGRAM_STALY.md').read_text(),re.M)
assert len(rows)==36 and [int(row[0]) for row in rows]==list(range(1,37))
assert [(int(n),int(a),int(b),int(d)) for n,_,a,b,d in rows if a!=b]==[(10,65,90,25)]
assert all(int(b)-int(a)==int(d) for _,_,a,b,d in rows)
print(f'PASS {len(checks)}/{len(checks)} integration/source checks; 36/36 roadmap entries; SHA256 frozen files')
