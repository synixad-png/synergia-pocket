#!/usr/bin/env python3
"""Offline source and roadmap invariants; no live server or iOS assertions."""
from pathlib import Path
import hashlib, json, re
r = Path(__file__).resolve().parents[1]
base = json.loads((r/'Tests/P27_BASE_SOURCE_HASHES.json').read_text())
current = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'Sources').glob('*.swift')}
assert set(current) == set(base), 'Source list changed unexpectedly'
changed = {name for name in base if base[name] != current[name]}
assert changed == {'SynergiaAttendanceRecords.swift'}, f'unexpected source changes: {changed}'
model = (r/'Sources/SynergiaAttendanceRecords.swift').read_text()
portal = (r/'Sources/Portal.swift').read_text()
store = (r/'Sources/DirectAttendanceStore.swift').read_text()
completeness = (r/'Sources/DirectAttendanceCompleteness.swift').read_text()
checks = {
 'true JSON Boolean must be CFBoolean': 'CFGetTypeID(number) == CFBooleanGetTypeID()' in model and 'private static func jsonBoolean' in model,
 'uses strict Boolean for type classification': 'let present = jsonBoolean(row["IsPresenceKind"])' in model,
 'numerical identity rejects fraction': 'value.isFinite && value.rounded() == value' in model,
 'numerical identity rejects Bool': 'CFGetTypeID(number) != CFBooleanGetTypeID()' in model,
 'empty string ID rejected': '!string.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty' in model,
 'type reference duplicates tracked': 'knownTypeIds.insert(id).inserted' in model,
 'type duplicate tracked before metadata': model.index('knownTypeIds.insert(id).inserted') < model.index('let present = jsonBoolean(row["IsPresenceKind"])'),
 'lesson duplicates retained': 'knownLessonIds.insert(id).inserted' in model,
 'attendance duplicates retained': 'seen.insert(id).inserted' in model,
 'unresolved type still fails closed': 'throw AttendanceDecodeError.missingAttendanceType(typeId)' in model,
 'unresolved subject remains nil': 'subjectId: subjectsByLesson[lessonId]' in model,
 'date not fabricated': 'let date = row["Date"] as? String' in model,
 'lesson and semester no coercion of Boolean': 'let lessonNo = positiveNumber(row["LessonNo"])' in model and 'let semester = positiveNumber(row["Semester"])' in model,
 'Polish LocalizedError for all malformed cases': 'extension AttendanceDecodeError: LocalizedError' in model and model.count('Nie zapisano odczytu.') == 5,
 'manual read uses decoder': 'try SynergiaAttendanceRecords.decode(' in portal and portal.count('try SynergiaAttendanceRecords.decode(') == 2,
 'manual and batch still check disappearance': portal.count('DirectAttendanceCompleteness.validateNoUnexplainedDisappearance(') == 2,
 'manual owner reverified before write': 'guard initial == final && DirectAccountCommitPolicy.permits(' in portal,
 'manual snapshot write remains': 'try self.directAttendanceStore.replace(records: parsed' in portal,
 'batch snapshot write remains': 'try self.directAttendanceStore.replace(records: a.rows' in portal,
 'completeness retains unread paging rejection': 'throw AttendanceCompletenessError.unsupportedPagination' in completeness,
 'full file protection unchanged': '.completeFileProtection' in store,
 'iPhone-only project configuration unchanged': hashlib.sha256((r/'project.yml').read_bytes()).hexdigest() == (r/'Tests/P27_BASE_PROJECT_SHA256.txt').read_text().strip(),
 'test covers JSONSerialization': 'JSONSerialization.jsonObject(with: data)' in (r/'Tests/attendance_json_integrity_standalone.swift').read_text(),
 'no IPA or EXE within sources': not list(r.rglob('*.ipa')) and not list(r.rglob('*.exe')),
}
for name, result in checks.items(): print(('PASS' if result else 'FAIL') + ' ' + name)
assert all(checks.values()), [name for name,ok in checks.items() if not ok]
rows = re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$', (r/'HARMONOGRAM_STALY.md').read_text(), re.M)
assert len(rows) == 36 and [int(t[0]) for t in rows] == list(range(1,37))
assert [(int(n),int(a),int(b),int(d)) for n,_,a,b,d in rows if a!=b] == [(11,80,90,10)]
assert all(int(b)-int(a)==int(d) for _,_,a,b,d in rows)
print(f'P27 SOURCE INTEGRATION {len(checks)}/{len(checks)}; ROADMAP 36/36; only Attendance JSON decoder changed')
