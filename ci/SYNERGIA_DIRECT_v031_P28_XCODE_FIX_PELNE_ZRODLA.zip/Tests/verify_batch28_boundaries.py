#!/usr/bin/env python3
"""Guard the exact scope of packet 28 versus the cryptographic package 27 baseline."""
from pathlib import Path
import hashlib, json, re
r=Path(__file__).resolve().parents[1]
base=json.loads((r/'Tests/P28_BASE_SOURCE_HASHES.json').read_text())
now={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'Sources').glob('*.swift')}
assert set(now)==set(base), 'Unexpected source deletion/addition'
changed={name for name in base if base[name]!=now[name]}
assert changed=={'DirectAttendanceStatistics.swift','DirectAttendanceAnalyticsView.swift', 'LocalStore.swift', 'Portal.swift'}, changed
local=(r/'Sources/LocalStore.swift').read_text()
portal=(r/'Sources/Portal.swift').read_text()
assert 'self.directory = base.appendingPathComponent("school-data"' in local
assert 'private func runCoreSync(' in portal and 'await self.runCoreSync(' in portal
assert hashlib.sha256((r/'project.yml').read_bytes()).hexdigest()==(r/'Tests/P28_BASE_PROJECT_SHA256.txt').read_text().strip()
stat=(r/'Sources/DirectAttendanceStatistics.swift').read_text()
ui=(r/'Sources/DirectAttendanceAnalyticsView.swift').read_text()
model=(r/'Sources/SynergiaAttendanceRecords.swift').read_text()
analytics=(r/'Sources/DirectAttendanceAnalytics.swift').read_text()
checks={
  'types from true JSON booleans unchanged': 'CFGetTypeID(number) == CFBooleanGetTypeID()' in model,
  'server isPresenceKind decides attendance': 'if record.isPresenceKind {' in stat,
  'no invented type numbers': 'typeId' not in stat,
  'pending statuses remain unknown': 'unresolvedPhrases.contains(where: s.contains)' in stat,
  'explicit negative checked before positive': stat.index('s.contains("nieusprawiedliwion")')<stat.index('s.contains("usprawiedliwion")'),
  'positive adjectives not raw stem': 's.contains("usprawiedliwion")' in stat and 's.contains("usprawiedliw") ||' not in stat,
  'negative abbreviation supported': 's.hasSuffix("nieuspr.")' in stat,
  'positive abbreviation supported': 's.hasSuffix("uspr.")' in stat,
  'unknown counts retained': 'absenceStatusUnknown: unknown' in stat,
  'unsettled statuses described in UI': 'Wnioski, oczekiwanie na decyzję' in ui,
  'filter uses same status classifier': 'DirectAttendanceStatus.excuse(entry.typeName)' in analytics,
  'no fake official attendance percentage': 'nie podajemy oficjalnego procentu frekwencji' in ui,
  'regression executable': (r/'Tests/attendance_status_semantics_standalone.swift').is_file(),
  'no IPA/EXE in source': not list(r.rglob('*.ipa')) and not list(r.rglob('*.exe'))
}
for label,passed in checks.items():print(('PASS' if passed else 'FAIL')+' '+label)
assert all(checks.values()), [label for label,value in checks.items() if not value]
rows=re.findall(r'^\|\s*(\d+)\s*\|\s*(.*?)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*\+(-?\d+) pp\s*\|$',(r/'HARMONOGRAM_STALY.md').read_text(),re.M)
assert len(rows)==36 and [int(x[0]) for x in rows]==list(range(1,37)), 'Roadmap must remain exactly 36 ordered tasks'
assert [(int(n),int(a),int(b),int(d)) for n,_,a,b,d in rows if a!=b]==[(12,75,90,15)], 'Only task 12 may change'
assert all(int(b)-int(a)==int(d) for _,_,a,b,d in rows)
print(f'P28_BOUNDARIES PASS={len(checks)} ROADMAP=36 MODIFIED={sorted(changed)}')
