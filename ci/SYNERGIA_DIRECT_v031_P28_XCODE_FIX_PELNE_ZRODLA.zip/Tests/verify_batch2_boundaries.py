#!/usr/bin/env python3
"""Static source invariants, not an iOS build or runtime test."""
from pathlib import Path
w=Path(__file__).resolve().parent.parent
files={name:(w/'Sources'/name).read_text() for name in [
    'DirectAttendanceStatistics.swift','DirectTimetable.swift',
    'DirectSchoolFeeds.swift','SynergiaGatewayClient.swift',
    'SynergiaAttendanceRecords.swift','MainView.swift','DirectAttendanceAnalyticsView.swift','Portal.swift']}
checks={
  'attendance status uses server IsPresenceKind': 'record.isPresenceKind' in files['DirectAttendanceStatistics.swift'],
  'attendance unknown excuse preserved': 'absenceStatusUnknown' in files['DirectAttendanceStatistics.swift'],
  'attendance never claims official percentage': 'nie podajemy oficjalnego procentu frekwencji' in files['DirectAttendanceAnalyticsView.swift'],
  'no fabricated subject for attendance': 'Przedmiot nieustalony' in files['DirectAttendanceAnalyticsView.swift'],
  'homework assignments endpoint': 'case homeworkAssignments = "HomeWorkAssignments"' in files['SynergiaGatewayClient.swift'],
  'calendar uses HomeWorks': 'case .calendar: return .homework' in files['DirectSchoolFeeds.swift'],
  'homework uses assignments': 'case .homework: return .homeworkAssignments' in files['DirectSchoolFeeds.swift'],
  'documents use SchoolFiles': 'case .documents: return .schoolFiles' in files['DirectSchoolFeeds.swift'],
  'feed rejects guessed Data fallback': 'root[primary] ??' not in files['DirectSchoolFeeds.swift'],
  'timetable Monday query only': 'DirectTimetableParser.isMonday(monday)' in files['SynergiaGatewayClient.swift'],
  'timetable response tied to account twice': 'let first = try DirectAccountIdentity.parse' in files['Portal.swift'] and 'guard first == last else' in files['Portal.swift'],
  'timetable parallel lessons not collapsed': 'parallelCount: parallels.count' in files['DirectTimetable.swift'],
  'timetable lists all parallel groups warning': 'przydział nieznany' in files['MainView.swift'],
  'timetable account invalidated in three boundaries': files['Portal.swift'].count('directTimetableEpoch = UUID()') >= 4,
  'feed account invalidated at logout': all(term in files['Portal.swift'].split('func signOutAndClear()')[1].split('func ')[0] for term in ['directFeedEpoch = UUID()', 'clearDirectSchoolFiles()', 'clearDirectHomeworkFiles()', 'directFeeds.removeAll()', 'directFeedDeltas.removeAll()']),
  'full file protection attendance unchanged': '.completeFileProtection' in (w/'Sources/DirectAttendanceStore.swift').read_text(),
  'IPA not generated': not list(w.glob('*.ipa')),
}
for title,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' '+title)
if not all(checks.values()): raise SystemExit(1)
print(f'BATCH2 SOURCE BOUNDARIES {len(checks)}/{len(checks)} PASS')
