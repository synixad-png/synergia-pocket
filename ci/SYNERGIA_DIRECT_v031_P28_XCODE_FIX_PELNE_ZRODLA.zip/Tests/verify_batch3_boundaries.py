#!/usr/bin/env python3
"""Static checks on source boundaries. Not a SwiftUI typecheck, runtime iOS test or live API test."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
src={f.name:f.read_text() for f in (root/'Sources').glob('*.swift')}
portal=src['Portal.swift']; view=src['MainView.swift']; download=src['SynergiaSchoolFileClient.swift']
school=src['DirectSchoolFiles.swift']; history=src['DirectPlanChanges.swift']; gateway=src['SynergiaGatewayClient.swift']
docview=src['DirectSchoolDocumentsView.swift']; docpolicy=src['DirectSchoolDocuments.swift']
checks={
 'SchoolFiles exact path metadata': '"/pliki_szkoly/pobierz/"' in school,
 'document id matches the link': 'link == prefix + id' in school,
 'document never accepts user-provided absolute link': 'link == prefix + id' in school,
 'document link scoped to official host': 'url.host == "synergia.librus.pl"' in school,
 'follow only official sandbox': 'url.host?.lowercased() == "sandbox.librus.pl"' in school,
 'ticket link only GetFile': 'url.path.hasPrefix("/GetFile/")' in school,
 'reject file HTML waiting page': 'type.contains("text/html")' in school,
 'document byte cap': 'static let maxBytes = 15_000_000' in school,
 'school downloader forbids redirects': 'completionHandler(nil)' in download,
 'school downloader isolates cookies': 'config.httpCookieStorage = nil' in download and 'config.httpShouldSetCookies = false' in download,
 'cookies added only to initial Synergia request': download.count('forHTTPHeaderField: "Cookie"') == 1,
 'school sandbox second phase': 'actualDownloadURL(ticket)' in download and 'await session.bytes(for: download)' in download,
 'sandbox starts signed ticket waiting page': 'await session.bytes(for: warm)' in download,
 'ticket waiting page is limited': 'warmSize > 128_000' in download,
 'sandbox polling bounded': 'for attempt in 0..<15' in download and 'until = Date().addingTimeInterval(32)' in download,
 'no saving before final Me': portal.index('let final = try DirectAccountIdentity.parse', portal.index('func downloadDirectSchoolFile')) < portal.index('try contents.write(to: url', portal.index('func downloadDirectSchoolFile')),
 'document download explicitly user-initiated': 'portal.downloadDirectSchoolFile(file, from: item)' in view,
 'document cannot be downloaded from other module': 'guard feed.module == .documents' in docpolicy and 'DirectSchoolDocumentsView(' in view,
 'document button refuses unverified URL': 'if let file = DirectSchoolDocumentsPresentation.uniqueDownloadReference(entry, in: feed)' in docview and 'Brak jednoznacznego, zweryfikowanego odnośnika' in docview,
 'documents protected by epoch': 'self.directSchoolFileEpoch == epoch' in portal and 'self.accountEpoch == originalAccountEpoch' in portal,
 'temporary documents destroyed on account transitions': portal.count('        clearDirectSchoolFiles()') >= 3,
 'server resource for historical substitutions': 'case planChanges = "Calendars/Substitutions"' in gateway,
 'plan changes require original date': 'date(row["OrgDate"])' in history,
 'plan changes keep initial and replacement subjects': 'originalSubjectId:' in history and 'currentSubjectId:' in history,
 'plan change preserves unknown kind': 'kind = .unknown' in history,
 'plan history read guarded by identity': 'let history = try await client.read(.planChanges)' in portal,
 'plan history cannot hide timetable if unavailable': 'case .failure(let error):' in portal and 'Plan tygodniowy nadal jest odczytany.' in portal,
 'users lookup optional without fictitious name': 'try? DirectGradeAuthors.decode(users.json)' in portal,
 'unverified names not fabricated': 'change.originalTeacherId.flatMap' in view and 'change.currentTeacherId.flatMap' in view,
 'plan changes invalidated during account changes': portal.count('        directPlanChanges = nil') >= 3,
 'school file URLs not persisted in old LocalStore': 'directSchoolFileURLs: [String: URL]' in portal and 'directSchoolFileFolder' in portal,
 'no IPA created': not list(root.glob('*.ipa')),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'BATCH3 BOUNDARIES: {sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
