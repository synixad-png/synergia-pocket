#!/usr/bin/env python3
"""Checks source-level invariants; NOT a SwiftUI typecheck or a live Synergia test."""
from pathlib import Path
r=Path(__file__).resolve().parent.parent
s={p.name:p.read_text() for p in (r/'Sources').glob('*.swift')}
p=s['Portal.swift']; v=s['MainView.swift']; hw=s['DirectHomeworkFiles.swift']
client=s['SynergiaHomeworkFileClient.swift']; changes=s['DirectFeedChangeAudit.swift']; feed=s['DirectSchoolFeeds.swift']
checks={
    'homework attachments only from confirmed HomeWorkAssignments list': 'record["HomeworkAssigmentFiles"]' in hw or 'row["HomeworkAssigmentFiles"]' in hw,
    'identifier path must match parent and file': 'attachmentPath + homework + "-" + id' in hw,
    'only Synergia metadata URL may authorize download': 'u.host?.lowercased() == "synergia.librus.pl"' in hw,
    'homework raw URLs never used as download target': 'downloadPath + file.id' in hw,
    'two documented sandbox modes': 'case getFile' in hw and 'case singleUseKey' in hw,
    'ticket only on https sandbox': 'u.host?.lowercased() == "sandbox.librus.pl"' in hw,
    'single-use key query shape exact': 'params.count == 2' in hw and 'Set(params.map(\\.name)).count == 2' in hw,
    'sandbox CSCheckKey POST': 'request.httpMethod = "POST"' in client and 'keyURL(action: "CSCheckKey")' in client,
    'sandbox CSDownload GET': 'keyURL(action: "CSDownload", key: key)' in client,
    'GetFile /get guarded': 'target.path == page.path + "/get"' in client,
    'sandbox no Synergia cookies': client.count('forHTTPHeaderField: "Cookie"') == 1,
    'ephemeral session without cookie jar': 'config.httpCookieStorage = nil' in client,
    'no redirect following': 'completionHandler(nil)' in client,
    'one user action to download': 'portal.downloadDirectHomeworkFile(file, from: item)' in v,
    'stale attachment cannot be requested after data refresh': 'self.directFeedEpoch == feedEpoch' in p,
    'before and after identity checks download': p.index('let before = try DirectAccountIdentity.parse',p.index('func downloadDirectHomeworkFile')) < p.index('let after = try DirectAccountIdentity.parse',p.index('func downloadDirectHomeworkFile')),
    'no file exposed before final account check': p.index('let after = try DirectAccountIdentity.parse',p.index('func downloadDirectHomeworkFile')) < p.index('try contents.write(to: target',p.index('func downloadDirectHomeworkFile')),
    'homework temporary files protected': '.completeFileProtection' in p[p.index('func downloadDirectHomeworkFile'):p.index('func downloadDirectSchoolFile')],
    'download protected by 15MB ceiling': 'static let maxBytes = 15_000_000' in hw and 'data.count >= DirectHomeworkFilePolicy.maxBytes' in client,
    'bounded session download': 'deadline = Date().addingTimeInterval(150)' in client,
    'bounded sandbox polling': 'for attempt in 0..<15' in client,
    'HTML waiting page cannot be stored': 'return nil // Waiting page is not an attachment.' in client,
    'homework temp clear invoked for every account change': p.count('        clearDirectHomeworkFiles()')>=3,
    'previous feed preserved on transient error': 'Pozostał wcześniejszy odczyt (NIEAKTUALNY)' in p,
    'uncertain missing record not deleted': 'missingUnconfirmed' in changes and 'removedConfirmed: 0' in changes,
    'changes require stable server IDs': 'guard let serverId = entry.serverId' in changes,
    'batch refresh final identity check': 'first == last' in p[p.index('func refreshAllDirectFeeds'):p.index('func refreshDirectTimetable')],
    'batch read stages updates until final verification': p.index('let last = try DirectAccountIdentity.parse',p.index('func refreshAllDirectFeeds')) < p.index('self.directFeeds[module] = feed',p.index('func refreshAllDirectFeeds')),
    'batch authentication failure fatal': 'if (error as? GatewayReadError) == .loginRequired { throw error }' in p,
    'single feed failure rechecks identity': 'let current = try? DirectAccountIdentity.parse' in p[p.index('func refreshDirectFeed'):p.index('func refreshAllDirectFeeds')],
    'batch refresh explicitly invoked': 'portal.refreshAllDirectFeeds()' in v,
    'separate test source exists': (r/'Tests/homework_files_standalone.swift').exists() and (r/'Tests/feed_delta_standalone.swift').exists(),
    'no compiled or signed iOS artifacts': not any(r.rglob('*.ipa')) and not any(r.rglob('*.app')),
}
for key,value in checks.items(): print(('PASS' if value else 'FAIL')+' '+key)
print(f'BATCH4 SOURCE CHECKS {sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
