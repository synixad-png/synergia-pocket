#!/usr/bin/env python3
"""Offline source security checklist for v0.31 batch 5; NOT iOS runtime test."""
from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
p=(r/'Sources/Portal.swift').read_text()
v=(r/'Sources/MainView.swift').read_text()
a=(r/'Sources/DirectCoreSync.swift').read_text()
c=(r/'Sources/DirectAttendanceCompleteness.swift').read_text()
func=p[p.index('    func synchronizeCoreModules() {'):p.index('\n}\n\nstruct PortalWebView')]
checks={
 'core sync explicitly manual': 'Button { portal.synchronizeCoreModules() }' in v and 'func synchronizeCoreModules()' in p,
 'core sync does not auto run on launch': 'synchronizeCoreModules()' not in (r/'Sources/SynergiaDirectApp.swift').read_text(),
 'core sync verifies /Me before and after staged work': func.count('client.read(.me)')>=2,
 'core sync checks matching account throughout': 'func stillCurrent()' in func and 'self.store.verifiedAccountId == owner' in func,
 'core sync staged grades before final identity': func.index('gradesStage =') < func.index('let last = try DirectAccountIdentity.parse'),
 'core sync staged attendance before final identity': func.index('attendanceStage =') < func.index('let last = try DirectAccountIdentity.parse'),
 'core sync staged inbox before final identity': func.index('inboxStage =') < func.index('let last = try DirectAccountIdentity.parse'),
 'writes only after final identity': func.index('let last = try DirectAccountIdentity.parse') < func.index('try self.directGradeStore.replace'),
 'core sync preserves previous grades on error': 'errorLabels.append("Oceny:' in func and 'directGradeStore.lock()' not in func.split('let first = try DirectAccountIdentity.parse')[1].split('let last = try DirectAccountIdentity.parse')[0],
 'core sync protects attendance from disappearance': 'validateNoUnexplainedDisappearance' in func and 'case missingRecords(Int)' in c,
 'core sync protects supplemental grades from disappearance': 'familyDelta.missing == 0' in func,
 'first grade read not reported as new': 'hadGradesBaseline ? delta.added + other.added : 0' in func,
 'first attendance read not reported as new': 'hadAttendanceBaseline ? delta.added : 0' in func,
 'incomplete inbox has no notification': 'previous.complete && current.complete' in a and 'inboxReliable: inboxReliable' in func,
 'grades notification only when reliable': 'gradesReliable: gradeReliable' in func,
 'core notifications explicit opt in': 'localNotificationsEnabled = false' in p and 'requestAuthorization(options:' in p,
 'core notifications have no names or values': 'content.title = title' in p and 'Wykryto nowe wiadomości odebrane.' in p and 'content.body = body' in p and 'detail.body' not in func,
 'no background sync': 'BGTaskScheduler' not in p and 'BackgroundTasks' not in p,
 'updates blocked while core sync running': all(f'func {n}(' in p and 'guard !coreSyncBusy else { return' in p[p.index('func '+n+'('):p.index('func '+n+'(')+350] for n in ('refreshDirectGrades','refreshDirectAttendance','refreshDirectMessages','refreshDirectFeed','confirmDirectSend')),
 'navigation invalidates in-flight sync': re.search(r'didStartProvisionalNavigation navigation: WKNavigation!\) \{\s*cancelCoreSync\(\)',p) is not None,
 'reverification invalidates in-flight sync': re.search(r'func verifyAccount\(\) \{\s*cancelCoreSync\(\)',p) is not None,
 'logout removes old local alerts': 'removeAllDeliveredNotifications()' in p and 'localNotificationsEnabled = false' in p,
 'pending alerts removed on session change': 'removeAllPendingNotificationRequests()' in p[p.index('private func cancelCoreSync('):p.index('private func deliverCoreNotifications')],
 'notification UI opt in': 'Toggle("Powiadomienia lokalne po ręcznym odświeżeniu"' in v,
 'retains version no IPA generated': not any(r.rglob('*.ipa')) and not any(r.rglob('*.app')),
 'standalone Swift test present': (r/'Tests/core_sync_standalone.swift').is_file(),
 'different account inbox rejected': 'case differentAccount' in a and 'previous.accountId == current.accountId' in a,
 'missing only records do not trigger notification': 'newMessages > 0' in a and 'changes.newGrades > 0' in a,
}
for name, passed in checks.items():
 print(('PASS ' if passed else 'FAIL ')+name)
print(f'BATCH5 STATIC {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
