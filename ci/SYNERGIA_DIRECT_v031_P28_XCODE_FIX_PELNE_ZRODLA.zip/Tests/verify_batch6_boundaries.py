#!/usr/bin/env python3
"""Source-contract checks, not an iOS simulator or live Synergia test."""
from pathlib import Path
r = Path(__file__).resolve().parents[1]
p = (r/'Sources/Portal.swift').read_text()
v = (r/'Sources/MainView.swift').read_text()
g = (r/'Sources/SynergiaGatewayClient.swift').read_text()
m = (r/'Sources/SynergiaMessagesClient.swift').read_text()
i = (r/'Sources/DirectConnectionIssue.swift').read_text()
app = (r/'Sources/SynergiaDirectApp.swift').read_text()
sc = p.split('    private func suspendVisibleAccountData() {', 1)[1].split('\n    func openLoginPage()', 1)[0]
verification = p.split('    func verifyAccount() {', 1)[1].split('\n    func refreshDirectGrades()',1)[0]
checks = {
    'scenePhase observer installed': '@Environment(\\.scenePhase) private var scenePhase' in v and '.onChange(of: scenePhase)' in v,
    'shield covers all tabs': '.overlay {' in v.split('struct DashboardView: View')[0] and 'if portal.privacyShieldActive' in v,
    'shield has opaque background': 'Color(.systemBackground).ignoresSafeArea()' in v,
    'inactive hides app-switcher view': 'case .inactive:\n            privacyShieldActive = true' in p,
    'background locks exactly once': 'guard !backgroundSuspended else { return }' in p,
    'foreground calls verified account check': 'if resumeNeedsAccountVerification {' in p and 'verifyAccount()' in p.split('case .active:',1)[1].split('@unknown default:',1)[0],
    'no background data sync': 'case .background:' in p and 'synchronizeCoreModules()' not in p.split('case .background:',1)[1].split('case .active:',1)[0],
    'background invalidates core sync': 'cancelCoreSync(reason:' in sc,
    'background invalidates legacy sync': 'stopSync(' in sc,
    'background clears in-memory mail': 'lockDirectMessages()' in sc,
    'background cancels draft and file temps': 'clearDirectHomeworkFiles()' in sc and 'clearDirectSchoolFiles()' in sc,
    'background invalidates in-flight grade': 'directGradeEpoch = UUID()' in sc,
    'background invalidates in-flight attendance': 'directAttendanceEpoch = UUID()' in sc,
    'background invalidates in-flight timetable': 'directTimetableEpoch = UUID()' in sc,
    'background invalidates in-flight feeds': 'directFeedEpoch = UUID()' in sc,
    'background locks stores rather than deleting': 'store.lock(); downloads.lock(); routes.lock(); auditStore.lock()' in sc and '.erase()' not in sc,
    'verification keeps shield until result': 'self.privacyShieldActive = false' in verification and 'self.resumeNeedsAccountVerification = false' in verification,
    'verification unlocks only after /Me': verification.index('client' if 'client' in verification else 'SynergiaGatewayClient') < verification.index('self.directGradeStore.unlock'),
    'verification error leaves stores locked': verification.rfind('self.store.lock()') > verification.index('} catch {'),
    'verified data stays hidden on navigation': 'store.lock(); downloads.lock(); routes.lock(); auditStore.lock()' in p.split('didStartProvisionalNavigation',1)[1].split('didFinish navigation',1)[0],
    'official login only': 'https://portal.librus.pl/rodzina/synergia/loguj' in p,
    'user can check current account': 'Button("Sprawdź aktywną sesję")' not in v and 'Sprawdź aktywną sesję' in v,
    'settings explicitly explain offline': 'Brak internetu nie oznacza wylogowania z serwera' in v,
    'HTTP unauthorized distinct from forbidden': 'case 401: throw GatewayReadError.loginRequired' in g and 'case 403: throw GatewayReadError.forbidden' in g,
    'HTTP throttling distinct from login': 'case 408, 429, 503: throw GatewayReadError.transport(.http(http.statusCode))' in g,
    'gateway network errors classified': 'DirectConnectionIssue.network(error)' in g,
    'message transport does not auto retry': 'DirectMessagesTransportError.transport(DirectConnectionIssue.network(error))' in m and 'sendOnce(' in m,
    'no password storage introduced': not any(token in i for token in ('UserDefaults', 'Keychain', 'oauth_token')),
    'redirect login only official hosts': '["synergia.librus.pl", "portal.librus.pl", "api.librus.pl"].contains(host)' in i,
    'gateway login redirect handled without follow': 'DirectConnectionIssue.redirect(' in g and 'completionHandler(nil)' in g,
    'messages sign-in redirect invalidates session': 'if issue == .loginRequired { throw DirectMessagesTransportError.authorizationRequired }' in m,
    'message POST remains single': m.count('let (data, response) = try await session.data(for: req)') >= 1 and 'func sendOnce(' in m,
    'no compilation or IPA artifacts': not list(r.rglob('*.ipa')) and not list(r.rglob('*.app')),
    'version preserved': 'v0.31' in (r/'HARMONOGRAM_STALY.md').read_text(),
    'no background refresh framework': 'BackgroundTasks' not in app and 'BGTaskScheduler' not in p,
}
for n,b in checks.items(): print(('PASS' if b else 'FAIL')+'  '+n)
print('BATCH6 STATIC', sum(checks.values()), '/', len(checks))
if not all(checks.values()): raise SystemExit(1)
