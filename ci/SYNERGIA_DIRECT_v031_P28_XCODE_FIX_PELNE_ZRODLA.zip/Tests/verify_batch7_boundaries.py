from pathlib import Path
r = Path(__file__).resolve().parents[1]
p = (r / 'Sources/Portal.swift').read_text()
v = (r / 'Sources/MainView.swift').read_text()
states = (r / 'Sources/DirectModuleReadPresentation.swift').read_text()
panel = (r / 'Sources/DirectReadStatusPanel.swift').read_text()
checks = {
    'single typed model': 'enum DirectReadDisplayKind' in states and 'static func evaluate' in states,
    'account lock precedence': 'guard verified && accountMatches else' in states,
    'busy precedence': 'if loading' in states,
    'fresh read vs stale': 'if failed' in states and 'capturedAt == nil ? .failed : .stale' in states,
    'empty must have count': 'count == 0 ? .empty' in states,
    'no count means no proof': 'guard let capturedAt, let count' in states,
    'not claiming official completeness': 'To nie potwierdza zakresu uprawnień' in states,
    'readability supports VoiceOver': '.accessibilityElement(children: .combine)' in panel,
    'no misleading empty HTML message': 'Brak dodatkowego zapisu HTML.' in v,
    'panel visible for each module': 'Section("Stan odczytu JSON")' in v and 'DirectReadStatusPanel(state: readPresentation)' in v,
    'module visual state all 8': all(x in v for x in ('case .grades:', 'case .attendance:', 'case .messages:', 'case .timetable:', 'case .homework, .calendar, .announcements, .documents:')),
    'mailbox per-folder visual states': 'portal.failedDirectMailboxes.contains(mailbox)' in v,
    'mail summaries all loaded boxes': 'Array(portal.directMailboxes.values)' in v,
    'module failure flags typed': '@Published private(set) var failedDirectReads: Set<SchoolModule>' in p,
    'mail failure flags typed': '@Published private(set) var failedDirectMailboxes: Set<DirectMailbox>' in p,
    'freshness is separate from account verification': 'freshDirectReads: Set<SchoolModule>' in p and 'if !fresh' in states,
    'cached grade flagged stale until refreshed': 'fresh: portal.freshDirectReads.contains(.grades)' in v,
    'cached attendance flagged stale until refreshed': 'fresh: portal.freshDirectReads.contains(.attendance)' in v,
    'grade transitions': 'self.failedDirectReads.insert(.grades)' in p and 'self.failedDirectReads.remove(.grades)' in p,
    'attendance transitions': 'self.failedDirectReads.insert(.attendance)' in p and 'self.failedDirectReads.remove(.attendance)' in p,
    'timetable transitions': 'self.failedDirectReads.insert(.timetable)' in p and 'self.failedDirectReads.remove(.timetable)' in p,
    'message transitions': 'self.failedDirectMailboxes.insert(mailbox)' in p and 'self.failedDirectMailboxes.remove(mailbox)' in p,
    'feed failure transitions': 'self.failedDirectReads.insert(module)' in p and 'self.failedDirectReads.remove(module)' in p,
    'account check resets failure flags': 'func verifyAccount() {\n        cancelCoreSync()\n        lockDirectMessages()\n        failedDirectReads.removeAll()' in p,
    'background resets failure flags': 'private func suspendVisibleAccountData() {\n        failedDirectReads.removeAll()' in p,
    'module transport stays official': 'SynergiaGatewayClient' in p and 'SynergiaMessagesClient' in p,
    'source list automatically includes additions': '      - Sources' in (r/'project.yml').read_text(),
    'no iOS outputs': not list(r.rglob('*.ipa')) and not list(r.rglob('*.app')),
}
for name, passed in checks.items(): print(('PASS' if passed else 'FAIL'), name)
print('BATCH7 STATIC', sum(checks.values()), '/', len(checks))
if not all(checks.values()): raise SystemExit(1)
