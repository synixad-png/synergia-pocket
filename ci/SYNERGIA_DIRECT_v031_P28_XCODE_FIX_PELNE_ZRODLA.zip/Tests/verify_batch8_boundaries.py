from pathlib import Path
r=Path(__file__).resolve().parents[1]
portal=(r/'Sources/Portal.swift').read_text()
views=(r/'Sources/MainView.swift').read_text()
codec=(r/'Sources/DirectOfflineFeedCache.swift').read_text()
store=(r/'Sources/DirectOfflineFeedStore.swift').read_text()
policy=(r/'Sources/DirectOfflineRecovery.swift').read_text()
checks={
    'only four persistable feed modules': 'static let modules: [SchoolModule] = [.homework, .calendar, .announcements, .documents]' in codec,
    'no mail persisted': 'case .messages' not in codec,
    'store init no autounlock': 'init(directory: URL? = nil)' in store and 'func unlock(accountId: String)' in store,
    'account-sha path partition': 'AccountPartition.directory(for: account, under: root)' in store,
    'session-restricted unlock': 'verifiedAccountId = accountId' in store and 'DirectOfflineFeedCache.decode(' in store,
    'no cross-account replace': 'account == feed.verifiedAccountId' in store,
    'atomic protected storage': '.atomic, .completeFileProtection' in store,
    'no cloud backup': 'values.isExcludedFromBackup = true' in store,
    'erase supported': 'func erase() throws' in store and 'removeItem(at: root)' in store,
    'file size read bound': 'size.intValue <= DirectOfflineFeedCache.maximumBytes' in store,
    'payload version and owner': 'schemaVersion == version' in codec and 'envelope.accountId == expectedAccountId' in codec,
    'module shape validation': 'feed.module == module' in codec,
    'record count cap': 'feed.records.count <= maximumRecords' in codec,
    'future dates rejected': 'feed.fetchedAt <= now.addingTimeInterval(300)' in codec,
    'duplicate item keys rejected': 'ids.insert(entry.id).inserted' in codec,
    'path traversal rejected by filename': 'safeFilename(file.name)' in codec and 'safeFilename(file.displayName)' in codec,
    'download link revalidated': 'DirectSchoolFilePolicy.documentURL(file)' in codec and 'DirectHomeworkFilePolicy.downloadURL(file)' in codec,
    'snapshot freshness flag': 'fresh: portal.freshDirectReads.contains(module)' in views,
    'offline cache exposed only after live identity': 'self.directOfflineFeedStore.unlock(accountId: identity.id)' in portal and 'client.read(.me)' in portal,
    'stale cache labelled': 'Wcześniejszy zapis lokalny (NIEAKTUALNY)' in portal,
    'save feed after account confirmation': 'try self.directOfflineFeedStore.replace(feed)' in portal,
    'save batch feed after final /Me': 'do { try self.directOfflineFeedStore.replace(feed) }' in portal,
    'successful individual fresh mark': 'self.freshDirectReads.insert(module)' in portal,
    'freshness revoked after failure': 'self.freshDirectReads.remove(module)' in portal,
    'verified active epoch offline rule': 'self.accountEpoch == ownerEpoch' in portal and 'accountUnchanged:' in policy,
    'transport only offline rule': 'guard case .transport(let issue) = gateway' in policy,
    'only offline timeout interrupt': 'issue == .offline || issue == .timedOut || issue == .interrupted' in policy,
    'remote mismatch denied': 'observedRemoteAccount == nil || observedRemoteAccount == expectedAccount' in policy,
    'background denied': 'isForeground' in policy and '!self.backgroundSuspended && !self.privacyShieldActive' in portal,
    'grade cache restored after transient failure': 'self.directGradeStore.unlock(accountId: owner)' in portal,
    'attendance cache restored after transient failure': 'self.directAttendanceStore.unlock(accountId: owner)' in portal,
    'feed cache locked all four transitions': portal.count('        directOfflineFeedStore.lock()\n        directFeedStatus.removeAll()') == 4,
    'feed cache locked when final /Me fails': 'self.directOfflineFeedStore.lock()\n                self.directFeeds.removeAll()' in portal,
    'feed cache erased on logout': 'try self.directOfflineFeedStore.erase()' in portal,
    'messages remain in memory': 'Wiadomości są w pamięci, bez nieszyfrowanego cache na dysku.' in portal,
    'dashboard manual feed retry': 'Button { portal.refreshAllDirectFeeds() }' in views,
    'no background task polling': 'Brak automatycznego pobierania w tle' in views,
    'UI explains offline security': 'NIEAKTUALNY do ponownego odświeżenia' in views,
    'no change to nil login auto retry': 'func openLoginPage()' in portal and 'func refreshDirectGrades()' in portal,
    'source inclusion via directory': '- Sources' in (r/'project.yml').read_text(),
    'not packaging IPA': not list(r.rglob('*.ipa')) and not list(r.rglob('*.app')),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL'), name)
print('OFFLINE STATIC', sum(checks.values()),'/',len(checks))
if not all(checks.values()): raise SystemExit(1)
