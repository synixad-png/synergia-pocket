from pathlib import Path
r=Path(__file__).resolve().parents[1]
portal=(r/'Sources/Portal.swift').read_text()
view=(r/'Sources/MainView.swift').read_text()
cache=(r/'Sources/DirectOfflineTimetableStore.swift').read_text()
week=(r/'Sources/DirectTimetable.swift').read_text()
history=(r/'Sources/DirectPlanChanges.swift').read_text()
tests=(r/'Tests/offline_timetable_standalone.swift').read_text()
checks={
    'snapshot and store in real Sources': 'struct DirectOfflineTimetableSnapshot: Codable' in cache and 'final class DirectOfflineTimetableStore' in cache,
    'week model codable': 'struct DirectTimetableWeek: Codable' in week,
    'entry model codable': 'struct DirectTimetableEntry: Codable' in week,
    'history model codable': 'struct DirectPlanChangesSnapshot: Codable' in history,
    'history kind codable': 'enum Kind: String, Codable' in history,
    'schema version': 'envelope.version == version' in cache,
    'size bound': 'data.count <= maximumBytes' in cache,
    'account bound': 'envelope.accountId == account' in cache and 's.week.accountId == account' in cache,
    'Monday bound': 'DirectTimetableParser.isMonday(monday)' in cache,
    'week and record bounds': 's.week.entries.count <= 250' in cache and 's.week.reportedDates.count <= 7' in cache,
    'no fabricated parallel groups': '(0..<item.parallelCount).contains(item.parallelIndex)' in cache and 'item.id == ' in cache,
    'duplicate lesson rejection': 'ids.insert(item.id).inserted' in cache,
    'duplicate history rejection': 'changes.insert(change.id).inserted' in cache,
    'history account bound': 'history.accountId == account' in cache,
    'lookup field bounds': 'checkLookups(s.subjects)' in cache and 'checkLookups(s.teachers)' in cache,
    'future timestamp rejection': 'date <= now.addingTimeInterval(300)' in cache,
    'no auto-unlock': 'init(directory: URL? = nil)' in cache and 'func unlock(accountId: String)' in cache,
    'no read prior verified account': 'guard verifiedAccountId != nil' in cache,
    'partition by SHA256 account in app': 'AccountPartition.directory(for: account, under: root)' in cache,
    'regular file check': '(attr[.type] as? FileAttributeType) == .typeRegular' in cache,
    'size check before reading bytes': 'size.intValue <= DirectOfflineTimetableCodec.maximumBytes' in cache,
    'atomic protected cache': 'options: [.atomic, .completeFileProtection]' in cache,
    'excluded from backup': 'values.isExcludedFromBackup = true' in cache,
    'bounded 16 weeks': 'static let maxStoredWeeks = 16' in cache and 'dropFirst(DirectOfflineTimetableCodec.maxStoredWeeks)' in cache,
    'erase disk on logout': 'try self.directOfflineTimetableStore.erase()' in portal,
    'identity check before saving': 'let last = try DirectAccountIdentity.parse((try await client.read(.me)).json)' in portal and 'first == last' in portal,
    'account epoch check before save': 'self.accountEpoch == ownerEpoch' in portal and 'self.directOfflineTimetableStore.replace(snapshot)' in portal,
    'account mismatch rejects rather than returns': 'guard first.id == owner else {' in portal,
    'rechecks account on identity failure': 'self.verifyAccount()' in portal,
    'unlock after successful /Me': portal.count('self.directOfflineTimetableStore.unlock(accountId: identity.id)') == 2,
    'lock on multiple session invalidations': portal.count('directOfflineTimetableStore.lock()') >= 7,
    'restore selected week after verification': portal.count('self.selectCachedTimetableWeek()') == 2,
    'no alternate week substitution': 'directOfflineTimetableStore.snapshot(monday: monday)' in portal,
    'account failure in other modules clears visible timetable': portal.count('self.revokeDirectTimetableOnAccountFailure()') == 3,
    'account failure invalidates timetable epoch': 'private func revokeDirectTimetableOnAccountFailure()' in portal and 'directTimetableEpoch = UUID()' in portal,

    'cached reads explicitly stale': 'Zapis offline (NIEAKTUALNY)' in portal,
    'live read marks freshness': 'self.freshDirectReads.insert(.timetable)' in portal,
    'stale restore revokes freshness': 'freshDirectReads.remove(.timetable)' in portal,
    'transport-only offline fallback': 'DirectOfflineRecovery.mayRetain(' in portal and 'self.displayCachedTimetable(saved)' in portal,
    'UI uses freshness': 'fresh: portal.freshDirectReads.contains(.timetable)' in view,
    'picker only restores chosen week': 'portal.selectCachedTimetableWeek()' in view,
    'UI explains offline stale status': 'Zapis offline zawsze ma oznaczenie NIEAKTUALNY' in view,
    'no iOS build command': not any('xcodebuild' in line or 'xcrun' in line for line in (r/'Tests/run_batch9_offline.sh').read_text().splitlines()),
    'offline test exercises store': 'store.unlock(accountId:"B")' in tests and 'store.erase()' in tests,
    'previous static assertions preserved': (r/'Tests/verify_batch8_boundaries.py').exists(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL'), name)
print(f'BATCH9 STATIC: {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
