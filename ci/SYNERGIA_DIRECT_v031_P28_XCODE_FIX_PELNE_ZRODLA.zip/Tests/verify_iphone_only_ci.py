#!/usr/bin/env python3
"""Static CI safeguard: no iPad test workflow and app stays universal."""
from pathlib import Path
root = Path(__file__).resolve().parent.parent
wf = (root / '.github/workflows/ios.yml').read_text()
project = (root / 'project.yml').read_text()
plan = (root / 'Tests/IOS_DEVICE_TEST_PLAN.md').read_text()
checks = {
    'workflow remains manual': 'workflow_dispatch:' in wf,
    'workflow explicitly excludes iPad tests': 'No iPad simulator tests.' in wf,
    'workflow documents iPhone scope': 'iPhone-only verification' in wf,
    'manual build is not a device test': 'xcodebuild -project' in wf and ' CODE_SIGNING_ALLOWED=NO ' in wf,
    'no iPad test step': 'name=iPad' not in wf and 'platform=iOS Simulator,name=iPad' not in wf,
    'universal app device family preserved': "TARGETED_DEVICE_FAMILY: '1,2'" in project,
    'policy explicitly scopes to iPhone': 'iPhone only' in plan,
    'policy warns previous build was not device testing': 'steps=[]' in plan,
}
for key, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + key)
assert all(checks.values())
print(f'IOS DEVICE POLICY: {len(checks)}/{len(checks)} PASS (static; no iOS build)')
