#!/usr/bin/env python3
"""Source-level safety checks; never presented as an iOS runtime test."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
portal = (root/'Sources/Portal.swift').read_text()
client = (root/'Sources/SynergiaMessagesClient.swift').read_text()
view = (root/'Sources/MainView.swift').read_text()
checks = {
    'session locks on account verification': re.search(r'func verifyAccount\(\) \{\s*//[^\n]*\n\s*guard !backgroundSuspended, sessionLifecycle.beginVerification\(\) else \{ return \}\s*cancelCoreSync\(\)\s*lockDirectMessages\(\)', portal) is not None,
    'session locks on navigation': re.search(r'didStartProvisionalNavigation navigation: WKNavigation!\) \{\s*sessionLifecycle.cancelVerification\(\)\s*cancelCoreSync\(\)\s*lockDirectMessages\(\)', portal) is not None,
    'session locks on logout': re.search(r'func signOutAndClear\(\) \{\s*//[^\n]*\n\s*guard sessionLifecycle.beginCleanup\(\) else \{ return \}\s*privacyShieldActive = true\s*cancelCoreSync\(\)\s*UNUserNotificationCenter.current\(\).removeAllDeliveredNotifications\(\)\s*lockDirectMessages\(\)', portal) is not None,
    'fresh identity before and after mailbox reads': 'let first = try DirectAccountIdentity.parse' in portal and 'let last = try DirectAccountIdentity.parse' in portal,
    'browser bootstrap via Synergia': 'https://synergia.librus.pl/wiadomosci3' in portal,
    'no message plaintext disk write': 'try JSONEncoder().encode' not in client and 'Data.write(to:' not in portal.split('/// Odczyt całej dostępnej skrzynki')[1].split('/// Explicit account authorization')[0],
    'HTTPS messages api': 'https://wiadomosci.librus.pl/api/' in client,
    'GET read methods and restricted POST send': 'method: String = "GET"' in client and 'func sendOnce(' in client and 'method: "POST"' in client,
    'manual credentials never used': not any(token in client.lower() for token in ('"password"', '"login"', '"pass"', 'userdefaults', 'keychain')),
    'cross domain guard': 'target.host == "wiadomosci.librus.pl"' in client,
    'no redirect': 'completionHandler(nil)' in client,
    'exact path guard': 'target.path == url.path' in client,
    'base64 decoding in domain parser': 'Data(base64Encoded:' in (root/'Sources/DirectMessages.swift').read_text(),
    'UI uses Text and not WebView for message bodies': 'Text(detail.body)' in view,
    'send requires confirmation dialog': '.confirmationDialog("Potwierdź wysłanie wiadomości"' in view and 'portal.confirmDirectSend()' in view,
    'no IPA build step executed by tests': 'xcodebuild' not in client and 'xcodebuild' not in portal
}
for name, ok in checks.items():
    print(('PASS ' if ok else 'FAIL ') + name)
assert all(checks.values()), 'Message boundary validation failed'
print(f'TOTAL {len(checks)}/{len(checks)}')
