#!/usr/bin/env python3
"""Statyczny audyt wymuszenia potwierdzenia, sesji i pojedynczego POST.
Nie jest testem sieci ani kompilacją iOS.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[1] / 'Sources'
compose=(root/'DirectMessageCompose.swift').read_text()
client=(root/'SynergiaMessagesClient.swift').read_text()
portal=(root/'Portal.swift').read_text()
view=(root/'MainView.swift').read_text()
detail=(root/'DirectMessages.swift').read_text()
method = portal.split('func confirmDirectSend() {',1)[1].split('    func refreshDirectRecipientGroups()',1)[0]
transport = client.split('func sendOnce(',1)[1].split('    func recipientGroups()',1)[0]
checks={
 'właściwy endpoint nowej wiadomości': '"messages" : "messages/reply"' in client,
 'jeden POST w kodzie transportu': transport.count('session.data(for: req)') == 1,
 'bez automatycznego retry POST': method.count('client.sendOnce(draft)') == 1,
 'POST tylko po weryfikacji tożsamości': method.index('first.id == verifiedAccountId') < method.index('client.sendOnce(draft)'),
 'sesja wiadomości sprawdzona przed POST': method.index('client.currentSessionAccountId()') < method.index('client.sendOnce(draft)'),
 'sesja Wiadomości powiązana z odbiorcami': 'remoteSessionId == draft.messageSessionId' in method and 'listed.messageSessionId' in compose,
 'konto porównane przed POST': 'guard first == last' in method,
 'prepare nie wysyła': 'client.sendOnce' not in portal.split('func prepareDirectSend()',1)[1].split('func confirmDirectSend()',1)[0],
 'potwierdzenie użytkownika w SwiftUI': 'portal.confirmDirectSend()' in view and '.confirmationDialog("Potwierdź wysłanie wiadomości"' in view,
 'anulowanie przygotowanej wysyłki': 'portal.cancelPreparedDirectSend()' in view,
 'lokalny podgląd adresata': 'directSendPreview = "Do:' in portal,
 'dane redagowania usuwane przy zmianie konta': 'func lockDirectMessages() {\n        clearDirectComposer()' in portal,
 'nieznany wynik nie powoduje ponownego POST': 'case .uncertain(let reason)' in method and 'self.directDraftBody = ""' in method,
 'oddzielna ochrona przy kodzie 4xx': '[400, 401, 403, 404, 422].contains(status)' in compose,
 'błąd 5xx traktowany jako niepewność': 'return .uncertain(' in compose,
 'wysyłka nie ma załączników': '"storageId": NSNull()' in compose,
 'treść wychodząca HTML-escaped': 'htmlEscapedBody(draft.text)' in compose,
 'reply bez flagi noReply nie jest możliwe': 'record["noReply"]' in detail and 'allowed = false' in detail,
 'wysyłka tylko do odbiorcy z aktualnej listy': 'listed.recipients.contains(recipient)' in compose,
 'brak zapisywania treści draftu na dysk': 'UserDefaults' not in compose and 'FileManager' not in compose,
 'redirecty zablokowane': 'completionHandler(nil)' in client,
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
print(f'TOTAL {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
