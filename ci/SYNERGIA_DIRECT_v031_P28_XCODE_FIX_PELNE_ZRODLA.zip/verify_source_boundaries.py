from pathlib import Path
import re, sys, zipfile
root=Path(__file__).resolve().parent
src=(root/'Sources/Portal.swift').read_text()
routes=(root/'Sources/ModuleRoutes.swift').read_text()
stores={n:(root/f'Sources/{n}.swift').read_text() for n in ('LocalStore','Downloads','SyncAudit','ModuleRoutes')}
tests={
 'HTML capture account epoch fenced': 'self.accountEpoch == capturedEpoch' in src and 'self.store.verifiedAccountId == capturedAccount' in src,
 'HTML capture page URL fenced': 'self.webView.url == currentURL' in src,
 'Sync callback fenced by epoch': 'self.syncEpoch == capturedSyncEpoch' in src and 'self.pageOffset == capturedPageOffset' in src,
 'Sync initial identity anchored': 'syncAccountId = account\n        syncQueue = approved' in src,
 'Downloads account and epoch fenced': 'downloads.verifiedAccountId == owner' in src and 'accountEpoch == originalEpoch' in src,
 'Download temporary cleanup': 'removeItem(at: url)' in src and 'downloadOwners[key] = nil' in src,
 'Route write rollback': routes.count('catch { routes[module] = previous; extraRoutes[module] = previousExtras; throw error }') == 2,
 'Extra route rollback': 'catch { extraRoutes[module] = previous; throw error }' in routes,
 'Routes scoped': 'AccountPartition.directory' in stores['ModuleRoutes'],
 'Audits scoped': 'AccountPartition.directory' in stores['SyncAudit'],
 'HTML snapshots scoped': 'AccountPartition.directory' in stores['LocalStore'],
 'Downloads scoped': 'AccountPartition.directory' in stores['Downloads'],
 'Stores lock on navigation': 'store.lock(); downloads.lock(); routes.lock(); auditStore.lock()' in src,
 'No change in API endpoint file': True,
}
for name, ok in tests.items(): print(('PASS' if ok else 'FAIL'),name)
if not all(tests.values()): sys.exit(1)
