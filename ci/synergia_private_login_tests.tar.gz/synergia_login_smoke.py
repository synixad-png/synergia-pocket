#!/usr/bin/env python3
"""Conservative, privacy-preserving smoke tests for public Synergia login.

Never prints credentials, URLs with query parameters, cookies, page HTML,
account details, API payloads, screenshots, HAR, or browser traces.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

SCHOOL_LOGIN = "https://synergia.librus.pl/loguj/portalRodzina"
ME_ENDPOINT = "https://synergia.librus.pl/gateway/api/2.0/Me"
TRUSTED_PAGE_HOSTS = frozenset((
    "synergia.librus.pl", "api.librus.pl", "konto.librus.pl", "portal.librus.pl"
))
TRUSTED_CREDENTIAL_HOSTS = frozenset((
    "synergia.librus.pl", "api.librus.pl", "konto.librus.pl"
))


def trusted_https(url: str, allowed: frozenset[str]) -> bool:
    try:
        p = urllib.parse.urlsplit(url)
    except ValueError:
        return False
    try:
        port = p.port
    except ValueError:
        return False
    return (p.scheme.lower() == "https" and p.hostname in allowed and
            p.username is None and p.password is None and port in (None, 443))


def safe_host(url: str) -> str:
    try:
        host = urllib.parse.urlsplit(url).hostname
    except ValueError:
        host = None
    return host if host in TRUSTED_PAGE_HOSTS else "untrusted_or_unknown"


def public_preflight() -> int:
    request = urllib.request.Request(
        SCHOOL_LOGIN, headers={"User-Agent": "SynergiaDirect-CI-Public-Preflight/1.0", "Accept": "text/html"}
    )
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            final = response.geturl()
            print("public_tls=verified")
            print("public_http_status=", response.status, sep="")
            print("final_host=", safe_host(final), sep="")
            if not trusted_https(final, TRUSTED_PAGE_HOSTS):
                print("public_result=UNTRUSTED_REDIRECT")
                return 3
            print("public_result=REACHABLE_NOT_AUTHENTICATED")
            return 0
    except urllib.error.HTTPError as error:
        # Even 405 can follow an expected OAuth redirect; do not print the URL.
        print("public_http_status=", error.code, sep="")
        print("final_host=", safe_host(error.geturl()), sep="")
        print("public_result=REQUIRES_BROWSER_FLOW")
        return 0 if trusted_https(error.geturl(), TRUSTED_PAGE_HOSTS) else 3
    except (urllib.error.URLError, TimeoutError, OSError):
        print("public_result=UNREACHABLE_OR_TLS_ERROR")
        return 3


def discover_form(page):
    # Password handling is deliberately restricted to a browser-rendered form
    # on an exact approved HTTPS host; arbitrary frames/actions are rejected.
    for frame in page.frames:
        if not trusted_https(frame.url, TRUSTED_CREDENTIAL_HOSTS):
            continue
        try:
            pwd = frame.locator('input[type="password"]:visible')
            if pwd.count() != 1:
                continue
            form = pwd.first.locator('xpath=ancestor::form[1]')
            if form.count() != 1:
                continue
            action = form.get_attribute("action") or frame.url
            action_url = urllib.parse.urljoin(frame.url, action)
            if not trusted_https(action_url, TRUSTED_CREDENTIAL_HOSTS):
                return None, "UNTRUSTED_FORM_ACTION"
            possible_users = form.locator('input[type="text"]:visible, input[type="email"]:visible, input:not([type]):visible')
            if possible_users.count() != 1:
                return None, "AMBIGUOUS_USER_FIELD"
            return (frame, pwd.first, possible_users.first, form), "FORM_READY"
        except Exception:
            return None, "FORM_INSPECTION_FAILED"
    return None, "FORM_NOT_FOUND"


def live_smoke() -> int:
    login = os.environ.get("SYNERGIA_TEST_LOGIN", "")
    password = os.environ.get("SYNERGIA_TEST_PASSWORD", "")
    if not login or not password:
        print("live_result=NOT_RUN_GITHUB_SECRETS_MISSING")
        return 2
    if "\n" in login or "\r" in login or len(login) > 128 or len(password) > 512:
        print("live_result=INVALID_SECRET_FORMAT")
        return 2
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("live_result=BROWSER_DEPENDENCY_MISSING")
        return 2
    try:
        with sync_playwright() as p:
            browser = p.webkit.launch(headless=True)
            context = browser.new_context(
                ignore_https_errors=False, accept_downloads=False,
                service_workers="block", record_har_path=None,
            )
            page = context.new_page()
            try:
                page.goto(SCHOOL_LOGIN, wait_until="domcontentloaded", timeout=35000)
                # JS-backed pages may need time to render the form.
                match, status = discover_form(page)
                if match is None:
                    page.wait_for_timeout(5500)
                    match, status = discover_form(page)
                print("login_page_host=", safe_host(page.url), sep="")
                print("form_state=", status, sep="")
                if match is None:
                    print("live_result=NOT_COMPLETED_FORM_UNAVAILABLE")
                    return 3
                _, pwd, username, form = match
                # Credentials are in memory only. Never expose page text or traces.
                username.fill(login)
                pwd.fill(password)
                submit = form.locator('button[type="submit"]:visible, input[type="submit"]:visible')
                if submit.count() == 1:
                    submit.first.click(timeout=10000)
                elif submit.count() == 0:
                    pwd.press("Enter", timeout=10000)
                else:
                    print("live_result=NOT_COMPLETED_AMBIGUOUS_SUBMIT")
                    return 3
                page.wait_for_timeout(4500)
                # One read-only request. Playwright context shares browser cookies,
                # like the application's persistent WKWebView cookie jar.
                resp = context.request.get(ME_ENDPOINT, headers={"Accept": "application/json"},
                                           max_redirects=0, timeout=20000)
                print("me_http_status=", resp.status, sep="")
                if resp.status != 200:
                    print("live_result=NOT_VERIFIED_ME_NON_200")
                    return 4
                if "json" not in resp.headers.get("content-type", "").lower():
                    print("live_result=NOT_VERIFIED_ME_NOT_JSON")
                    return 4
                try:
                    payload = resp.json()
                except (json.JSONDecodeError, ValueError):
                    print("live_result=NOT_VERIFIED_ME_INVALID_JSON")
                    return 4
                # No account attributes or data are ever output or persisted.
                if not isinstance(payload, dict) or not payload:
                    print("live_result=NOT_VERIFIED_ME_UNEXPECTED_SHAPE")
                    return 4
                print("live_result=ME_RETURNED_AUTHENTICATED_JSON")
                return 0
            finally:
                context.close()
                browser.close()
    except Exception:
        # In particular, do not print raw Playwright exceptions: URLs sometimes
        # contain authorization codes, state parameters or account identifiers.
        print("live_result=BROWSER_FLOW_ERROR_REDACTED")
        return 5


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("preflight", "live"))
    args = parser.parse_args()
    return public_preflight() if args.mode == "preflight" else live_smoke()


if __name__ == "__main__":
    sys.exit(main())
