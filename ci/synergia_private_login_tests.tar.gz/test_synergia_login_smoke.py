import unittest
import synergia_login_smoke as m


class PrivateLoginSafetyTests(unittest.TestCase):
    def test_only_exact_hosts(self):
        for host in m.TRUSTED_CREDENTIAL_HOSTS:
            self.assertTrue(m.trusted_https('https://' + host + '/login', m.TRUSTED_CREDENTIAL_HOSTS))
            self.assertFalse(m.trusted_https('http://' + host + '/login', m.TRUSTED_CREDENTIAL_HOSTS))
            self.assertFalse(m.trusted_https('https://' + host + '.example.net/', m.TRUSTED_CREDENTIAL_HOSTS))
    def test_url_credentials_blocked(self):
        self.assertFalse(m.trusted_https('https://someone:secret@synergia.librus.pl/', m.TRUSTED_CREDENTIAL_HOSTS))
    def test_untrusted_domains(self):
        self.assertFalse(m.trusted_https('https://synergia.librus.pl.evil.test/', m.TRUSTED_CREDENTIAL_HOSTS))
        self.assertFalse(m.trusted_https('https://example.net/', m.TRUSTED_PAGE_HOSTS))
    def test_ports(self):
        self.assertFalse(m.trusted_https('https://synergia.librus.pl:8443/', m.TRUSTED_CREDENTIAL_HOSTS))
        self.assertTrue(m.trusted_https('https://synergia.librus.pl:443/', m.TRUSTED_CREDENTIAL_HOSTS))
    def test_form_target_limited(self):
        self.assertFalse(m.trusted_https('https://portal.librus.pl/rodzina/', m.TRUSTED_CREDENTIAL_HOSTS))
    def test_host_display(self):
        self.assertEqual(m.safe_host('https://synergia.librus.pl/login?token=secret'), 'synergia.librus.pl')
        self.assertEqual(m.safe_host('https://unknown.example/login?token=secret'), 'untrusted_or_unknown')

if __name__ == '__main__':
    unittest.main()
